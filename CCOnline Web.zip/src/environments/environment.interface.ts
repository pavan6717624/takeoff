export interface IEnvironment {
  production: boolean;
  type: 'dev' | 'sit' | 'uat' | 'prod';
  apiUrl: string;
  apiLogout: boolean;
}
