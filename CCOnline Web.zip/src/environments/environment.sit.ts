import { IEnvironment } from './environment.interface';

export const environment: IEnvironment = {
  production: true,
  type: 'sit',
  apiUrl: 'https://devcconline.bank.sbi/api',
  apiLogout: true,
};
