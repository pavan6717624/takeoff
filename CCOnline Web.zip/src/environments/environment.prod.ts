import { IEnvironment } from './environment.interface';

export const environment: IEnvironment = {
  production: true,
  type: 'prod',
  apiUrl: 'https://cconline.sbi/api',
  apiLogout: true,
};
