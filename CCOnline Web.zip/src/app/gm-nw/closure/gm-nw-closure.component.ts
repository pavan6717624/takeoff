import { Component, OnInit } from '@angular/core';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

@Component({
  selector: 'app-gm-nw-closure',
  template: `<app-verification-closure [startUrl]="startUrl" [tabs]="tabs" [activeTab]="activeTab"></app-verification-closure>`,
})
export class GmNwClosureComponent implements OnInit {
  startUrl = '/gm-nw/compliance/';

  tabs: Tab[] = [
    {
      id: 1,
      title: 'Controller (RM/DGM) Visit',
      key: 'rm-dgm-controller-visit',
      assignable: false,
    },
    {
      id: 2,
      title: 'DGM (B&O) Visit',
      key: 'dgm-bo-module-head-visit',
      assignable: false,
    },
    {
      id: 3,
      title: 'DGM CFO Visit (New)',
      key: 'dgm-cfo-visit',
      assignable: false,
    },
  ];

  activeTab: Tab = {
    id: 1,
    title: 'Controller (RM/DGM) Visit',
    key: 'rm-dgm-controller-visit',
    assignable: false,
  };

  constructor() {}

  ngOnInit(): void {}
}
