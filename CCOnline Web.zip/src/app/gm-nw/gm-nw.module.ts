import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerificationComponent } from './verification/verification.component';
import { RouterModule, Routes } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { ControllerVisitGmNwComponent } from './controller-visit-gm-nw/controller-visit-gm-nw.component';
import { SectionsComponent } from '../verification/sections/sections.component';
import { BranchProfileComponent } from '../verification/branch-profile/branch-profile.component';
import { ValueStatementsComponent } from '../verification/value-statements/value-statements.component';
import { PreviewForSubmissionComponent } from '../verification/preview-for-submission/preview-for-submission.component';
import { SubmitResultComponent } from '../verification/submit-result/submit-result.component';
import { ScrutinyComponent } from '../controller/scrutiny/scrutiny.component';
import { SectionsComplianceComponent } from '../compliance/sections/sections-compliance.component';
import { VerificationModule } from '../verification/verification.module';
import { ComplianceModule } from '../compliance/compliance.module';
import { GmNwClosureComponent } from './closure/gm-nw-closure.component';
import { ClosureModule } from '../closure/closure.module';

const routes: Routes = [
  { path: '', redirectTo: 'controllerVisit', pathMatch: 'full' },
  { path: 'verifications', redirectTo: 'controllerVisit', pathMatch: 'full' },
  { path: 'controllerVisit', component: ControllerVisitGmNwComponent },
  { path: 'verification/:verificationId', component: SectionsComponent, data: { userRoutePrefix: 'gm-nw' } },
  { path: 'verification/:verificationId/branch-profile', component: BranchProfileComponent },
  { path: 'verification/:verificationId/value-statements/:sectionId', component: ValueStatementsComponent },
  { path: 'verification/:verificationId/preview', component: PreviewForSubmissionComponent, data: { userRoutePrefix: 'gm-nw' } },
  { path: 'verification/:verificationId/submitted', component: SubmitResultComponent, data: { userRoutePrefix: 'gm-nw' } },
  { path: 'scrutiny', component: ScrutinyComponent },
  { path: 'closure', component: GmNwClosureComponent, data: { userRoutePrefix: 'gm-nw' } },
  { path: 'compliance/:verificationId', component: SectionsComplianceComponent },
];

@NgModule({
  declarations: [VerificationComponent, ControllerVisitGmNwComponent, GmNwClosureComponent],
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes), VerificationModule, ComplianceModule, ClosureModule],
})
export class GmNwModule {}
