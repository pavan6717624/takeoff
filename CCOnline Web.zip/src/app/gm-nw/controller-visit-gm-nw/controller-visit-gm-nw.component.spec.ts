import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControllerVisitGmNwComponent } from './controller-visit-gm-nw.component';

describe('ControllerVisitGmNwComponent', () => {
  let component: ControllerVisitGmNwComponent;
  let fixture: ComponentFixture<ControllerVisitGmNwComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControllerVisitGmNwComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControllerVisitGmNwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
