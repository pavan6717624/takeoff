import { TestBed } from '@angular/core/testing';

import { UploadEkuberStmtService } from './upload-ekuber-stmt.service';

describe('UploadEkuberStmtService', () => {
  let service: UploadEkuberStmtService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UploadEkuberStmtService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
