import { HttpClient, HttpRequest, HttpResponse } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { en_US, NzI18nService, zh_CN } from "ng-zorro-antd/i18n";
import differenceInCalendarDays from "date-fns/differenceInCalendarDays";
import { DatePipe } from "@angular/common";
import { NzMessageService } from 'ng-zorro-antd/message';
import {UploadEkuberStmtService} from './upload-ekuber-stmt.service';
import { environment } from 'src/environments/environment';


export class Flso {
  fsloCode: number;
  fsloName: string;
  deposit: number;
  withdrawal: number;
  ct: number;
  fileurl: string;
}
export class DisplayData
{
  status: string;
  message: string;
  data: Flso[];
}

@Component({
  selector: 'app-upload-ekuber-stmt',
  templateUrl: './upload-ekuber-stmt.component.html',
  styleUrls: ['./upload-ekuber-stmt.component.less'],
})
export class UploadEkuberStmtComponent implements OnInit {
  loading = false;
  formData = new FormData();
  displayData =  new DisplayData();
  selectfile = "Select File";
  uploaded = false;
  error = false;
  server = `${environment.apiUrl}`;
  date = null;
  file: any = "";
  today = new Date();
  latestUploadDate: Date;

  constructor(private http: HttpClient, private i18n: NzI18nService,private message: NzMessageService,private uploadEkuberStmtService: UploadEkuberStmtService) {
    this.i18n.setLocale(en_US);
    this.getLatestUploadDate();
  }

  ngOnInit(): void {}

  getLatestUploadDate()
  {
    this.uploadEkuberStmtService.getLatestUploadDate().subscribe(
      (res:string) => {
        this.latestUploadDate = new Date(res);
      }
     
    );
  }
  onClose()
  {
  this.displayData.status='';
  this.displayData.message="";
    this.error=false;
  }
  disabledDate = (current: Date): boolean => {
	

		return (
			differenceInCalendarDays(current, this.today) > 0 ||
			(this.latestUploadDate &&
				differenceInCalendarDays(current, this.latestUploadDate) <= 0)
		);
	};

  beforeUpload = (file: any) => {
    
    if (this.date == null || this.date == "") {
     	this.displayData.data = [];
      this.displayData.message = "Please select Date.";
      this.message.create('error',this.displayData.message);
      this.displayData.status="Error";
      this.error=true;
			return false;
		}
    
    this.loading = true;
    
    this.selectfile = "Processing...";
    this.formData.set("file", file);

    var datePipe = new DatePipe("en-US");
		let dateValue = datePipe.transform(this.date, "yyyy-MM-dd");

    this.formData.set("date",dateValue);
    this.uploadEkuberStmtService.processBGLStatement(this.formData).subscribe(
        (res) => {
          this.processResponse(res);
        },
        (err) => {
        
          this.processError(err);
        }
      );
    return false;
  };

  processError(err) {
    this.displayData.data = [];
      this.displayData.message = "Error Occured. Please try Again...";
      this.message.create('error',this.displayData.message);
      this.displayData.status="Error";
    this.loading = false;
    this.selectfile = "Select File";
    this.error=true;
  }

  processResponse(res) {
 this.error=false;
    this.displayData = res;
    console.log(this.displayData);
    this.selectfile = "Select File";
    this.loading = false;
    this.message.create(this.displayData.status.toLowerCase(),this.displayData.message);
    this.getLatestUploadDate();
  }
}
