import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { BglCcDifferenceService } from './bgl-cc-difference.service';
import { NzMessageService } from 'ng-zorro-antd/message';

export class DisplayDifference {
  circle: string;
  network: number;
  module: number;
  moduleName: string;
  region: number;
  brCode: number;
  brName: string;
  bgl98958balance: number;
  bgl98908balance: number;
  closingBalance: number;
  net: number;
  closingDifference: number;
  netDifference: number;
  lastTalliedDateBgl98958: Date;
  lastTalliedDateBgl98908: Date;
}

@Component({
  selector: 'app-bgl-cc-difference',
  templateUrl: './bgl-cc-difference.component.html',
})
export class BglCcDifferenceComponent implements OnInit {
  constructor(private bglCcDifferenceService: BglCcDifferenceService, private message: NzMessageService) {}

  date: Date;
  status: boolean = false;
  misReport: DisplayDifference[];
  displayReport: DisplayDifference[];

  showZeroDifference = false;

  ngOnInit(): void {}

  log(value: string[]): void {
    if (!this.showZeroDifference) {
      this.displayReport = this.misReport;
    } else {
      this.displayReport = this.misReport.filter((data: DisplayDifference) => data.closingDifference !== 0 || data.netDifference !== 0);
    }
  }

  export() {
    this.bglCcDifferenceService.exportToExcel(this.displayReport).subscribe(res => {
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
      link.download = 'BGL CC Difference.csv';
      link.click();
      link.remove();
    });
  }

  onChange() {
    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.date, 'dd/MM/yyyy');
    console.log('date: ', date);
    var formData = new FormData();
    formData.set('date', date);
    this.misReport = [];
    this.displayReport = [];
    if (date != null) {
      this.status = true;
      this.bglCcDifferenceService.displayDifferenceOnDate(formData).subscribe(
        res => {
          this.misReport = res;

          this.displayReport = res;
          if (this.displayReport == null || this.displayReport.length == 0) {
            this.message.create('error', 'No Data to Display.');
          }

          console.log(this.displayReport);

          this.status = false;
          console.log(res);
        },
        err => {
          this.misReport = [];
          this.displayReport = [];
          this.status = false;
          console.log(err);
        }
      );
    }
  }
}
