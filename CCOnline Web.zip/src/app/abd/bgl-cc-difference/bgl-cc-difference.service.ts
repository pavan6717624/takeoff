import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { DisplayDifference } from './bgl-cc-difference.component';

import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class BglCcDifferenceService {
  constructor(private http: HttpClient) {}

  displayDifferenceOnDate(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-position/displayDifferenceOnDate`, formData);
  }

  exportToExcel(misReport: DisplayDifference[]): Observable<any>
  {
    return this.http.post(`${environment.apiUrl}/cc-position/exportToExcelBGLCCDiff`, misReport,{responseType: 'blob'});
  }
}
