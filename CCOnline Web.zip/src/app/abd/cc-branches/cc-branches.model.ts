// for CC branches list
export interface CcBranchesListReport{
    circleCode: number;
    circleName: String;
    networkCode: number;
    moduleName: String;
    regionCode: number;
    branchCode: number;
    branchName: String;
    fsloCode: number;
    ccCode: number;
    state: String;
    district: String;
    centerName: String;
    centerType: String;
    ccType: String;
    populationGroup: String;
    storageCapacity: number;
    cashBalanceLimit: number;
}

// for CC branches summary
export interface CcBranchesSummaryReport{
    circleCode: number;
    circleName: string;
    branchesCount: number;
}

// for CC closed branches list
export interface CcClosedBranchesListReport{
    circleCode: number;
    circleName: String;
    networkCode: number;
    moduleName: String;
    regionCode: number;
    branchCode: number;
    branchName: String;
    fsloCode: number;
    ccCode: number;
    state: String;
    district: String;
    centerName: String;
    closedDate?: any;
    
}
