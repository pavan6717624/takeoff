import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { CcBranchReportService } from '../cc-branches.service'
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { STColumn, STComponent, STPage } from '@delon/abc/st';

@Component({
  selector: 'app-closed-branches',
  templateUrl: './closed-branches.component.html',
  styleUrls: ['./closed-branches.component.less']
})
export class ClosedBranchesComponent implements OnInit {

  constructor(
    private ccBranchReportService: CcBranchReportService, 
    private log: NGXLogger,
    private notification: NzNotificationService,
  ) { }

  fromDate: Date;
  toDate: Date;
  dateFormat = DATE_FORMAT;
  today = new Date();

  disabledFromDate = (current: Date): boolean => {
    return differenceInCalendarDays(current, new Date()) > 0;
  };

  disabledToDate = (current: Date): boolean => {
    return differenceInCalendarDays(current, this.fromDate) < 0 || differenceInCalendarDays(current, new Date()) > 0;
  };

  loaded = false;
  details: any[];

  selectedFromDate: Date;
  selectedToDate: Date;
  isLoading = false;
  
  pagerConfig: STPage = { front: false, simple: true };

  @ViewChild('st', { static: false }) private st: STComponent;

  columns: STColumn[] = [
    { title: 'Sl. No.', index: 'id', type: 'no'},
    { title: 'Circle', index: 'circleName' },
    { title: 'Network', index: 'networkCode', className: 'text-center' },
    { title: 'Module Name', index: 'moduleName' },
    { title: 'Region Code', index: 'regionCode', className: 'text-center' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-center' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'FSLO Code', index: 'fsloCode', className: 'text-center' },
    { title: 'CC Code', index: 'ccCode', className: 'text-center' },
    { title: 'State', index: 'state' },
    { title: 'District', index: 'district' },
    { title: 'Center', index: 'centerName' },
    { title: 'Closed Date', index: 'closedDate', type: 'date', dateFormat: 'dd-MM-yyyy' },
  ];

  ngOnInit(): void {
    
  }

  onChangeFromDate(e: any): void{
    this.log.debug('From Date: ', e);
    this.selectedFromDate = e;
    this.toDate = null;
  }

  onChangeToDate(e1: any): void{
    this.log.debug('To Date: ', e1);
    this.selectedToDate = e1;
    this.isLoading = false;
    this.loadSummary(this.selectedFromDate, this.selectedToDate);
    console.log(e1, typeof e1);
  }

  // onDateChange(e: any): void{
  //   this.log.debug('Date changed: ', e);
  //   this.selectedMonth = e;
  //   this.isLoading = true;
  //   this.loadSummary(e);
  //   console.log(e, typeof e);
  // }

  loadSummary(fromDate: Date, toDate: Date): void {
    if(fromDate && toDate){
      this.isLoading = true;
    }
    this.ccBranchReportService.getClosedBranchesList(fromDate, toDate).subscribe(
      value => {
        console.log('Details:', value);
        this.details = value;
        this.loaded = true;
      },
      error => {
        console.log(' Detailed Report error: ', error);
      },
      () => (this.isLoading = false)
    );
  }

}
