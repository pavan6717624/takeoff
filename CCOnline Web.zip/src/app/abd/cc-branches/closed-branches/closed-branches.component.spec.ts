import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClosedBranchesComponent } from './closed-branches.component';

describe('ClosedBranchesComponent', () => {
  let component: ClosedBranchesComponent;
  let fixture: ComponentFixture<ClosedBranchesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClosedBranchesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClosedBranchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
