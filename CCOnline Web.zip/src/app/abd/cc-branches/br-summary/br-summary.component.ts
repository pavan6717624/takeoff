import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { CcBranchReportService } from '../cc-branches.service'
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { STColumn, STComponent, STData, STPage } from '@delon/abc/st';

@Component({
  selector: 'app-br-summary',
  templateUrl: './br-summary.component.html',
  styleUrls: ['./br-summary.component.less']
})
export class BrSummaryComponent implements OnInit {

  constructor(
    private ccBranchReportService: CcBranchReportService, 
    private log: NGXLogger,
    private notification: NzNotificationService,
  ) { }

  dateFormat = DATE_FORMAT;
  today = new Date();

  disabledDate = (current: Date): boolean => {
    return differenceInCalendarDays(current, this.today) > 0;
  };

  asOn: string;
  loaded = false;
  //details: any[];
  details: STData[];

  selectedMonth: string;
  isLoading = false;

  sum = {
    totalCCBranchesCount: 0,
  };
  
  pagerConfig: STPage = { front: false, simple: true };

  @ViewChild('st', { static: false }) private st: STComponent;

  columns: STColumn[] = [
    { title: 'Circle Name', index: 'circleName' },
    { title: 'No. of CC Branches', index: 'branchesCount', className: 'text-center' },
  ];

  ngOnInit(): void {
    
  }

  onDateChange(e: any): void{
    this.log.debug('Date changed: ', e);
    this.selectedMonth = e;
    this.isLoading = false;
    this.loadSummary(e);
    console.log(e, typeof e);
  }

  loadSummary(asOn: Date): void {
    if(asOn){
      this.isLoading = true;
    }    
    this.ccBranchReportService.getBranchesSummary(asOn).subscribe(
      value => {
        this.sum.totalCCBranchesCount = 0;
        value.forEach(item => {
          this.sum.totalCCBranchesCount += item.branchesCount;

        });
        console.log('Details:', value);
        this.details = value;
        this.loaded = true;
      },
      error => {
        console.log(' Detailed Report error: ', error);
      },
      () => (this.isLoading = false)
    );
  }
}
