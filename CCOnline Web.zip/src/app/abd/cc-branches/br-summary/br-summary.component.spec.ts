import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrSummaryComponent } from './br-summary.component';

describe('BrSummaryComponent', () => {
  let component: BrSummaryComponent;
  let fixture: ComponentFixture<BrSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
