import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CcBranchesComponent } from './cc-branches.component';

describe('CcBranchesComponent', () => {
  let component: CcBranchesComponent;
  let fixture: ComponentFixture<CcBranchesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CcBranchesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CcBranchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
