import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { CcBranchReportService } from './cc-branches.service'
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { STColumn, STComponent, STPage } from '@delon/abc/st';
import { AuthService } from 'src/app/core/auth/auth.service';
import { Role } from 'src/app/shared/constants/role.constants';

@Component({
  selector: 'app-cc-branches',
  templateUrl: './cc-branches.component.html',
  styleUrls: ['./cc-branches.component.less']
})

export class CcBranchesComponent implements OnInit {
  constructor(
    private ccBranchReportService: CcBranchReportService, 
    private log: NGXLogger,
    private notification: NzNotificationService,
    private authService: AuthService,
  ) { }

  dateFormat = DATE_FORMAT;
  today = new Date();
  displayMenu = false;

  disabledDate = (current: Date): boolean => {
    return differenceInCalendarDays(current, this.today) > 0;
  };

  //months: Option[];
  asOn: string;
  //summary: MonthlyCertificateSubmissionSummary;
  loaded = false;
  details: any[];

  selectedMonth: string;
  isLoading = false;
  
  pagerConfig: STPage = { front: true, simple: true };

  @ViewChild('st', { static: false }) private st: STComponent;

  columns: STColumn[] = [
    { title: 'Circle', index: 'circleName' },
    { title: 'Network', index: 'networkCode', className: 'text-center' },
    { title: 'Module Name', index: 'moduleName' },
    { title: 'Region Code', index: 'regionCode', className: 'text-center' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-center' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'FSLO Code', index: 'fsloCode', className: 'text-center' },
    { title: 'CC Code', index: 'ccCode', className: 'text-center' },
    { title: 'State', index: 'state' },
    { title: 'District', index: 'district' },
    { title: 'Center', index: 'centerName' },
    //{ title: 'Center Type', index: 'centerType' },
    { title: 'Payments/Receipts', index: 'ccType' },
    { title: 'Population Group', index: 'populationGroup' },
    { title: 'Storage Capacity', index: 'storageCapacity', className: 'text-center' },
    { title: 'CBL (in Crs.)', index: 'cashBalanceLimit', className: 'text-center' },
  ];

  ngOnInit(): void {
    // Checking ABD user  to filter menus
    this.authService.getPrincipal().subscribe(
      principal => {
        if (this.authService.hasAnyRolesDirect([Role.ABD_USER])) {
          this.displayMenu = true;
          this.log.debug('displayMenu1 ', this.displayMenu);
        } 
      },
      //this.displayMenu = false;
    );
  }

  monthChanged(e: any): void {
    this.log.debug('month changed: ', e);
    this.selectedMonth = e;
    this.isLoading = true;
    //this.loadSummary(e);
  }

  onDateChange(e: any): void{
    this.log.debug('Date changed: ', e);
    this.selectedMonth = e;
    this.isLoading = false;
    this.loadSummary(e);
    console.log(e, typeof e);
  }

  loadSummary(asOn: Date): void {
    if(asOn){
      this.isLoading = true;
    }
    this.ccBranchReportService.getBranchesList(asOn).subscribe(
      value => {
        console.log('Details:', value);
        this.details = value;
        this.loaded = true;
      },
      error => {
        console.log(' Detailed Report error: ', error);
      },
      () => (this.isLoading = false)
    );
  }
}