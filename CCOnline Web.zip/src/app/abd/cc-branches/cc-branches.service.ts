import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { CcBranchesListReport, CcBranchesSummaryReport, CcClosedBranchesListReport } from './cc-branches.model';
import format from 'date-fns/format';

@Injectable({
  providedIn: 'root'
})
export class CcBranchReportService {

  constructor(private http: HttpClient) { }

  // for CC branches list
  getBranchesList(asOn: Date): Observable<CcBranchesListReport[]>{
    let params = new HttpParams();
    params = params.append('asOn', format(asOn, 'yyyy-MM-dd'));
    console.log('Params:', asOn);
    return this.http.get<CcBranchesListReport[]>(`${environment.apiUrl}/ccbranches/listreport`, { params: params })
  }

  // for CC branches summary
  getBranchesSummary(asOn: Date): Observable<CcBranchesSummaryReport[]>{
    let params = new HttpParams();
    params = params.append('asOn', format(asOn, 'yyyy-MM-dd'));
    console.log('Params:', asOn);
    return this.http.get<CcBranchesSummaryReport[]>(`${environment.apiUrl}/ccbranches/summaryreport`, { params: params })
  }

  // for CC closed branches list
  getClosedBranchesList(fromDate: Date, toDate: Date): Observable<CcClosedBranchesListReport[]>{
    let params = new HttpParams();
    params = params.append('fromDate', format(fromDate, 'yyyy-MM-dd'));
    params = params.append('toDate', format(toDate, 'yyyy-MM-dd'));
    console.log('Params1:', toDate);
    return this.http.get<CcClosedBranchesListReport[]>(`${environment.apiUrl}/ccbranches/closedlistreport`, { params: params })
  }
}
