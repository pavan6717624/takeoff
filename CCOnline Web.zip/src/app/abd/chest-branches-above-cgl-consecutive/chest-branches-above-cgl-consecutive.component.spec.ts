import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChestBranchesAboveCglConsecutiveComponent } from './chest-branches-above-cgl-consecutive.component';

describe('ChestBranchesAboveCglConsecutiveComponent', () => {
  let component: ChestBranchesAboveCglConsecutiveComponent;
  let fixture: ComponentFixture<ChestBranchesAboveCglConsecutiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChestBranchesAboveCglConsecutiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChestBranchesAboveCglConsecutiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
