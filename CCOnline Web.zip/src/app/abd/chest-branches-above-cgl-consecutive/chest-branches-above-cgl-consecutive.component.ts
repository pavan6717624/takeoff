import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { CustomReportsService } from '../custom-reports/custom-reports.service';


export class ConsecutiveDaysReport {


  branchCode: number;
  branchName: string;
  circleCode: number;
  moduleCode: number;
  regionCode: number;
  networkCode: number;

  circleName: string;
  moduleName: string;

  cashBalanceLimit: number;

  chestSlipDate: string ;

  status: string;
  closingBalance: number;

  monthDays: number;
  monthConsecutiveDays: number;

}

export class Report{
  keys : string[] = [];
  monthCount: number[]=[];
  monthConsecutiveCount: number[]=[];
   values: ConsecutiveDaysReport[][] ;
}

@Component({
  selector: 'app-chest-branches-above-cgl-consecutive',
  templateUrl: './chest-branches-above-cgl-consecutive.component.html',
  styleUrls: ['./chest-branches-above-cgl-consecutive.component.less']
})
export class ChestBranchesAboveCglConsecutiveComponent implements OnInit {

  constructor(private customReportsService: CustomReportsService) { }

  ngOnInit(): void {
  }

  fromdate: Date;
  todate: Date;

  status: boolean = false;
  listOfDisplayData: Report ;
  selectedData : number;

  cancel()
  {
    this.previewVisible=false;
    this.selectedData=0;
  }

  onChangeFromDate() {
    this.listOfDisplayData = null;
    this.todate = this.fromdate;
    


  }

  display(index: number)
  {
    this.previewVisible=true;
    this.selectedData=index;
  }

  onChangeToDate() {
    this.listOfDisplayData = null;
  }

  disabledDate1 = (current: Date): boolean => {
    return differenceInCalendarDays(current, new Date()) > 0;
  };

  disabledDate2 = (current: Date): boolean => {
    return differenceInCalendarDays(current, this.fromdate) < 0 || differenceInCalendarDays(current, new Date()) > 0 || differenceInCalendarDays(current, this.fromdate) > 31;
  };

  previewVisible=false;

  generateReport() {


    var formData = new FormData();

    var datePipe = new DatePipe('en-US');

    formData.set('fromdate', datePipe.transform(this.fromdate, 'dd/MM/yyyy'));
    formData.set('todate', datePipe.transform(this.todate, 'dd/MM/yyyy'));

    this.status = true;
    this.customReportsService.getCBLExceedingDaysReport(formData).subscribe(
      res => {
        this.status = false;


        this.listOfDisplayData = (res);

        console.log(res);

        // for(var i=0;i<this.listOfDisplayData.values.length)
        // this.listOfDisplayData. this.listOfDisplayData.values[0].filter(o=>o.status=='Exceeded').length;

        console.log(this.listOfDisplayData.keys);

        
      },
      err => {
        this.status = false;
        this.listOfDisplayData = null;


        console.log(err);
      }
    );

  }


}
