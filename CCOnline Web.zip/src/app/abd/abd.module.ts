import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { IdentifyVoModule } from '../circle-admin/identify-vo/identify-vo.module';
import { IdentifyVoComponent } from '../circle-admin/identify-vo/identify-vo.component';
import { ChestSlipNotUploadedBranchesComponent } from './chest-slip-not-uploaded-branches/chest-slip-not-uploaded-branches.component';
import { SharedModule } from '../shared/shared.module';
import { ChestSlipUploadedBranchesComponent } from './chest-slip-uploaded-branches/chest-slip-uploaded-branches.component';
import { ChestBranchesAboveCglComponent } from './chest-branches-above-cgl/chest-branches-above-cgl.component';
import { BglCcDifferenceComponent } from './bgl-cc-difference/bgl-cc-difference.component';
import { ExceptionReportComponent } from './exception-report/exception-report.component';
import { RbiPenaltyUploadComponent } from './rbi-penalty-upload/rbi-penalty-upload.component';
import { CustomReportsComponent } from './custom-reports/custom-reports.component';
import { AddNsmToMasterComponent } from './nsm/add_nsm/add-nsm-to-master/add-nsm-to-master.component';
import { NsmMasterListComponent } from './nsm/nsm-master-list/nsm-master-list.component';
import { RbiPenaltyUpdationStatusComponent } from '../fslo/rbi-penalty-updation-status/rbi-penalty-updation-status.component';
import { EmailReminderComponent } from './email-reminder/email-reminder.component';
import { CcBranchesComponent } from './cc-branches/cc-branches.component';
import { BrSummaryComponent } from './cc-branches/br-summary/br-summary.component';
import { ClosedBranchesComponent } from './cc-branches/closed-branches/closed-branches.component';
import { ZeroBalanceCcsComponent } from './zero-balance-ccs/zero-balance-ccs.component';
import { CcClosureComponent } from './cc-closure/cc-closure.component';
import { MonthWiseVerificationComponent } from './month-wise-verification/month-wise-verification.component';
import { VerificationModule } from '../verification/verification.module';
import { SectionsComplianceComponent } from '../compliance/sections/sections-compliance.component';
import { AbdClosureComponent } from './closure/abd-closure.component';
import { ClosureModule } from '../closure/closure.module';
import { AutoAlertsComponent } from '../branch/auto-alerts/auto-alerts.component';
import { AutoAlertsHbbComponent } from '../branch/auto-alerts-hbb/auto-alerts-hbb.component';
import { ChestBranchesAboveCglConsecutiveComponent } from './chest-branches-above-cgl-consecutive/chest-branches-above-cgl-consecutive.component';
import { AdjustChestSlipComponent } from './adjust-chest-slip/adjust-chest-slip.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        redirectTo: 'upload-ekuber-stmt',
        pathMatch: 'full',
      },
      {
        path: 'upload-ekuber-stmt',
        loadChildren: () => import('./upload-ekuber-stmt/upload-ekuber-stmt.module').then(m => m.UploadEkuberStmtModule),
      },
      {
        path: 'verifications',
        component: IdentifyVoComponent,
      },

      {
        path: 'consecutiveDaysReport',
        component: ChestBranchesAboveCglConsecutiveComponent,
      },

      {
        path: 'chest-slip-not-uploaded-branches',
        component: ChestSlipNotUploadedBranchesComponent,
      },
      {
        path: 'month-wise-verifications',
        component: MonthWiseVerificationComponent,
      },
      {
        path: 'chest-slip-uploaded-branches',
        component: ChestSlipUploadedBranchesComponent,
      },
      {
        path: 'chest-branches-above-cbl',
        component: ChestBranchesAboveCglComponent,
      },
      {
        path: 'consecutiveDaysReport',
        component: ChestBranchesAboveCglConsecutiveComponent,
      },
      {
        path: 'bgl-cc-difference',
        component: BglCcDifferenceComponent,
      },
      {
        path: 'exception-report',
        component: ExceptionReportComponent,
      },
      {
        path: 'rbi-penalty-upload',
        component: RbiPenaltyUploadComponent,
      },
      {
        path: 'custom-reports',
        component: CustomReportsComponent,
      },
      {
        path: 'nsm-master-list',
        component: NsmMasterListComponent,
      },
      {
        path: 'add-nsm-to-master',
        component: AddNsmToMasterComponent,
      },
      {
        path: 'zero-balance-ccs',
        component: ZeroBalanceCcsComponent,
      },
      {
        path: 'penalty-reports',
        component: RbiPenaltyUpdationStatusComponent,
      },
      {
        path: 'autoAlertSettings',
        component: AutoAlertsComponent,
      },
      {
        path: 'autoAlertSettingsHbb',
        component: AutoAlertsHbbComponent,
      },
      {
        path: 'cc-branches',
        children: [
          { path: '', redirectTo: 'branches', pathMatch: 'full' },
          { path: 'branches', component: CcBranchesComponent },
          { path: 'br-summary', component: BrSummaryComponent },
          { path: 'closed-branches', component: ClosedBranchesComponent },
        ],
      },
      {
        path: 'email',
        component: EmailReminderComponent,
      },
      {
        path: 'cc-closure',
        component: CcClosureComponent,
      },
      { path: 'closure', component: AbdClosureComponent, data: { userRoutePrefix: 'abd' } },
      { path: 'compliance/:verificationId', component: SectionsComplianceComponent },
      { path: 'adjustChestSlip', component: AdjustChestSlipComponent },
    ],
  },
];

@NgModule({
  declarations: [
    ChestSlipNotUploadedBranchesComponent,
    ChestSlipUploadedBranchesComponent,
    ChestBranchesAboveCglComponent,
    BglCcDifferenceComponent,
    ExceptionReportComponent,
    RbiPenaltyUploadComponent,
    CustomReportsComponent,
    NsmMasterListComponent,
    AddNsmToMasterComponent,
    EmailReminderComponent,
    CcBranchesComponent,
    BrSummaryComponent,
    ClosedBranchesComponent,
    ZeroBalanceCcsComponent,
    MonthWiseVerificationComponent,
    AbdClosureComponent,
    ChestBranchesAboveCglConsecutiveComponent,
    AdjustChestSlipComponent,
  ],
  imports: [CommonModule, RouterModule.forChild(routes), IdentifyVoModule, SharedModule, VerificationModule, ClosureModule],
})
export class AbdModule {}
