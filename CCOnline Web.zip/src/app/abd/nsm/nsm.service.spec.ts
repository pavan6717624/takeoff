import { TestBed } from '@angular/core/testing';

import { NsmService } from './nsm.service';

describe('NsmService', () => {
  let service: NsmService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NsmService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
