import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { NsmMasterList } from './nsm-master-list.model';

@Injectable({
  providedIn: 'root'
})
export class NsmService {

  constructor(private http: HttpClient) { }

  getNsmMasterList(): Observable<NsmMasterList> {
    return this.http.get<NsmMasterList>(`${environment.apiUrl}/nsms/master`);
  }

  addNsmToMasterList(): Observable<NsmMasterList> {
    return this.http.get<NsmMasterList>(`${environment.apiUrl}/nsms/add`);
  }

  postSubmitAddNsm(data: any): Observable<any> {
    console.log('Submit Data:', data);
    return this.http.post(`${environment.apiUrl}/nsms/add/submit`, data);
  }

  markNSMStatus(data: any): Observable<any> {
    console.log('Submit Data:', data);
    return this.http.post(`${environment.apiUrl}/nsms/add/submit`, data);
  }

}
