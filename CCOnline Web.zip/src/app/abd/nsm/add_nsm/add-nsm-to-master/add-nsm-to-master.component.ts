import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NsmMasterList } from '../../nsm-master-list.model';
import { NsmService } from '../../nsm.service';
import { Router } from '@angular/router';

interface NsmType {
  id: number;
  description: string;
}

@Component({
  selector: 'app-add-nsm-to-master',
  templateUrl: './add-nsm-to-master.component.html',
  styleUrls: ['./add-nsm-to-master.component.less']
})
export class AddNsmToMasterComponent implements OnInit {

  nsmTypes: NsmType[] = [
    { id: 0, description: '1+1' },
    { id: 1, description: '2+1' },
    { id: 2, description: '3+1' },
    { id: 3, description: '4+1' },
  ];
  constructor(
    private nsmService: NsmService ,
    private fb: FormBuilder,
    private notification: NzNotificationService,
    private router: Router,
  ) { }

  addNsmForm: FormGroup;

  ngOnInit(): void {
    this.addNsmForm = this.fb.group({
      nsmMake: ['', [Validators.required, Validators.maxLength(30), Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      nsmModel: ['', [Validators.required, Validators.maxLength(30), Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      nsmType: ['', [Validators.required]],
    });
  }

  AddNsmSubmit(){
    console.log('On submit-ts file', this.addNsmForm);
    for (const i in this.addNsmForm.controls) {
      this.addNsmForm.controls[i].markAsDirty();
      this.addNsmForm.controls[i].updateValueAndValidity();
    }
    this.nsmService.postSubmitAddNsm(this.addNsmForm.value).subscribe(
      res => {
        console.log('success:', res);
        this.notification.success('Data Added Successfully', '');
        this.router.navigate(['abd/nsm-master-list']);
      },
      error => {
        console.log('error:', error);
        this.notification.error('Problem in adding the NSM, Please Check', '');
      },
      () => console.log('completed')
    );
  }
}
