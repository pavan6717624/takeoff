import { NsmType } from 'src/app/branch/cc-profile/model/cc-profile.model';

export interface NsmMasterList {
  id: number;
  nsmType: NsmType; 
  make: string;
  model: string;

}
