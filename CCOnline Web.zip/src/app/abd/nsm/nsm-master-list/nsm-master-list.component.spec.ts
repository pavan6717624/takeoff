import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NsmMasterListComponent } from './nsm-master-list.component';

describe('NsmMasterListComponent', () => {
  let component: NsmMasterListComponent;
  let fixture: ComponentFixture<NsmMasterListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NsmMasterListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NsmMasterListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
