import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NsmMasterList } from '../nsm-master-list.model';
import { NsmService } from '../nsm.service';

@Component({
  selector: 'app-nsm-master-list',
  templateUrl: './nsm-master-list.component.html',
  styleUrls: ['./nsm-master-list.component.less']
})
export class NsmMasterListComponent implements OnInit {
  data: NsmMasterList;
  constructor(private nsmService: NsmService, private router: Router) { }

  ngOnInit(): void {
    // get data from server
    this.nsmService.getNsmMasterList().subscribe(
      value => {
        console.log(value);
        this.data = value;
       
      },
      error => {
        console.log('error: ', error);
      },
      
    );
  }

  openComponent(): void {
    this.router.navigate(["./abd/add-nsm-to-master"]);
  }
}
