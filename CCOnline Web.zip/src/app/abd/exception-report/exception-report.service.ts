/*import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ExceptionReportService {

  constructor() { }
}*/

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { ExceptionReport } from './exception-report.component';

@Injectable({
  providedIn: 'root',
})
export class ExceptionReportService {
  constructor(private http: HttpClient) {}

  exceptionReportOnDate(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-position/exceptionReportOnDate`, formData);
  }

  exportToExcel(misReport: ExceptionReport[]): Observable<any>
  {
    return this.http.post(`${environment.apiUrl}/cc-position/exportToExcelExceptionReport`, misReport,{responseType: 'blob'});
  }

 
}

