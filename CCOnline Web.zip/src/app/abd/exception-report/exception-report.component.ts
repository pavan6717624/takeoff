
/*import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exception-report',
  templateUrl: './exception-report.component.html',
  styleUrls: ['./exception-report.component.less']
})
export class ExceptionReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}*/

import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import {ExceptionReportService} from './exception-report.service'

export class ExceptionReport
{
  reportDate: Date;

  
  branchCode: number;
  
  branchName: string;

  bgl98958Balance: number;
  bgl98908Balance: number;
  
  status: string;
}


@Component({
  selector: 'app-exception-report',
  templateUrl: './exception-report.component.html',
  styleUrls: ['./exception-report.component.less']
})
export class ExceptionReportComponent implements OnInit {

  constructor(private exceptionReportService: ExceptionReportService) { }

  ngOnInit(): void {
  }

 
  date: Date;
  status: boolean =  false;
  expReport: ExceptionReport[];

  export()
  {
    this.exceptionReportService.exportToExcel(this.expReport).subscribe(
      (res) => {
     
const link = document.createElement('a');
    link.href = window.URL.createObjectURL(new Blob([res], {type: 'text/csv'}));
    link.download =  'Closed Branches with Non-Zero BGL Balances Report.csv';
    link.click();
    link.remove();

      });
  }

  onChange()
  {
    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.date, 'dd/MM/yyyy');
    console.log('date: ', date);
    var formData = new FormData();
    formData.set("date",date);
    this.expReport=[];
    if(date!= null)
    {
      this.status = true;
      this.exceptionReportService.exceptionReportOnDate(formData).subscribe(
        (res) => {
          this.expReport = res;
          this.status=false;
        console.log(res);
        },
        (err) =>
        {
          this.status=false;
          console.log(err);
        }
       
      );
    }
  
  }
  
  }
  

