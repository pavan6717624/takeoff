import { TestBed } from '@angular/core/testing';

import { ExceptionReportService } from './exception-report.service';

describe('ExceptionReportService', () => {
  let service: ExceptionReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExceptionReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
