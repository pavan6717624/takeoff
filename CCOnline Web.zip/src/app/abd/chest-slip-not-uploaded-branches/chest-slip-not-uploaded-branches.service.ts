import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { Report } from './chest-slip-not-uploaded-branches.component';
@Injectable({
  providedIn: 'root',
})
export class ChestSlipNotUploadedBranchesService {
  constructor(private http: HttpClient) {}

  getNotUploadedBranches(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-upload/getNotUploadedBranches`, formData);
  }
  exportToExcel(misReport: Report[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-position/exportToExcelNotUploaded`, misReport, { responseType: 'blob' });
  }
}
