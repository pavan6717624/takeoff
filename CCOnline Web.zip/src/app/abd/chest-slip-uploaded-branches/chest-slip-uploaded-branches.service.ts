import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { Report } from './chest-slip-uploaded-branches.component';
@Injectable({
  providedIn: 'root',
})
export class ChestSlipUploadedBranchesService {
  constructor(private http: HttpClient) {}

  getUploadedBranches(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-upload/getUploadedBranches`, formData);
  }

  exportToExcel(misReport: Report[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-position/exportToExcelUploaded`, misReport, { responseType: 'blob' });
  }
}
