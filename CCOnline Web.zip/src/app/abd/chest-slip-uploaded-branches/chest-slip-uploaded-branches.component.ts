import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ChestSlipUploadedBranchesService } from './chest-slip-uploaded-branches.service';

export class Report {
  circle: string;
  network: number;
  module: number;
  moduleName: string;
  region: number;
  brcode: number;
  brname: string;
  cccode: number;
  fslocode: number;
  fsloName: string;
}

@Component({
  selector: 'app-chest-slip-uploaded-branches',
  templateUrl: './chest-slip-uploaded-branches.component.html',
})
export class ChestSlipUploadedBranchesComponent implements OnInit {
  constructor(private chestSlipUploadedBranchesService: ChestSlipUploadedBranchesService) {}

  date: Date;
  status: boolean = false;
  misReport: Report[];

  @ViewChild('ReportData') tableRef: ElementRef;

  ngOnInit(): void {}
  export() {
    this.chestSlipUploadedBranchesService.exportToExcel(this.misReport).subscribe(res => {
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
      link.download = 'Chest Slip Uploaded Branches.csv';
      link.click();
      link.remove();
    });
  }
  onChange() {
    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.date, 'dd/MM/yyyy');
    console.log('date: ', date);
    var formData = new FormData();
    formData.set('date', date);
    this.misReport = [];
    if (date != null) {
      this.status = true;
      this.chestSlipUploadedBranchesService.getUploadedBranches(formData).subscribe(
        res => {
          this.misReport = res;
          this.status = false;
          console.log(res);
        },
        err => {
          this.status = false;
          console.log(err);
        }
      );
    }
  }
}
