import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { CustomReport } from './custom-reports.component';

@Injectable({
  providedIn: 'root',
})
export class CustomReportsService {
  constructor(private http: HttpClient) {}

  getCustomReports(formData: FormData, report: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}/`+report, formData);
  }

  getCBLExceedingDaysReport(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-upload/getCBLExceedingDaysReport`, formData);
  }

 
  getDownloadCustomReport(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getDownloadCustomReport`, formData,{ responseType: 'blob' });
  }


  getCircles(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/getCircles`);
  }

  getRoles(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/getRoles`);
  }



 
  getModules(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getModules`,formData);
  }


  
  getRegions(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getRegions`,formData);
  }



  
  getNetworks(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getNetworks`,formData);
  }

  getHierarchy(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/getHierarchy`);
  }


  downloadCustomReport1(listOfDisplayData: CustomReport[],report: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}/`+report, listOfDisplayData, { responseType: 'blob' });
  }


  downloadCustomReport(formData: FormData,report: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}/`+report, formData, { responseType: 'blob' });
  }

}
