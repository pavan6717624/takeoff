import { Component, OnInit } from '@angular/core';
import { CustomReportsService } from './custom-reports.service';
import { DatePipe } from '@angular/common';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { NzMessageService } from 'ng-zorro-antd/message';
import { AuthService } from 'src/app/core/auth/auth.service';
import { Role } from 'src/app/shared/constants/role.constants';
/*export class CustomReport {
  circle: string;
  network: number;
  zone: string;
  region: number;
  fslocode: number;
  fsloname: string;
  cccode: number;
  brname: string;
  popcd: string;
  state: string;
  date: Date;
  cbl: number;
  data: number[];
}
*/
export class CustomReport {

  csdate: string;
	circle: string;
	net: number;
	zone : string;
	region: number;
	brcode: number;
	brname: string;
	cccode: number;
	fslocode: number;
	popcode : string;
	state: string;
	fsloname: string;
	cbl: number;
	n1: number;
	n2: number;
	n5: number;
	n10: number;
	n20: number;
	n50: number;
	n100: number;
	n200: number;
	n500: number;
	n1000: number;
	n2000: number;
	c1: number;
	c2: number;
	c5: number;
	c10: number;
	c20: number;
	totalpieces: number;
	totalvalue: number;

}



@Component({
  selector: 'app-custom-reports',
  templateUrl: './custom-reports.component.html',
  styles: [
    `
      .search-box {
        padding: 8px;
      }

      .search-box input {
        width: 188px;
        margin-bottom: 8px;
        display: block;
      }

      .search-box button {
        width: 90px;
      }

      .search-button {
        margin-right: 8px;
      }
    `,
  ],
})
export class CustomReportsComponent implements OnInit {
  constructor(private customReportsService: CustomReportsService, private message: NzMessageService, private authService: AuthService) {}

  fromdate: Date;
  todate: Date;
  status: boolean = false;
  report: string = '';
  customReport: CustomReport[];
  reportName: string = '';
  dateDisable2: boolean= false;


  isAbdUser : boolean;
  isAoUser: boolean;
  isCircleUser: boolean;
  isFsloUser: boolean;
  isRegionUser: boolean;

  circle: string[];
  network: string[];
  region: string[];
  module: string[];

  filterCircle: string;
  filterNetwork: string;
  filterRegion: string;
  filterModule: string;
  summary: string = "0";

  visibleSearch1: boolean = false;1
  visibleSearch2: boolean = false;
  visibleSearch3: boolean = false;
  visibleSearch4: boolean = false;
  visibleSearch5: boolean = false;
  visibleSearch6: boolean = false;
  visibleSearch7: boolean = false;
  visibleSearch8: boolean = false;
  visibleSearch9: boolean = false;

  searchValue1: string = '';
  searchValue2: string = '';
  searchValue3: string = '';
  searchValue4: string = '';
  searchValue5: string = '';
  searchValue6: string = '';
  searchValue7: string = '';
  searchValue8: string = '';
  searchValue9: string = '';

  listOfDisplayData: CustomReport[];
  filters = [];

  map: any;

  ngOnInit(): void {

    this.getCircles();
    this.isAbdUser = this.authService.hasAnyRolesDirect([Role.ABD_DGM, Role.ABD_USER]);
    this.isAoUser = this.authService.hasAnyRolesDirect([Role.AGM_GB, Role.AO_OFFICER]);
    this.isCircleUser = this.authService.hasAnyRolesDirect([Role.CIRCLE_ADMIN, Role.DGM_CFO]);
    this.isFsloUser = this.authService.hasAnyRolesDirect([Role.FSLO_USER]);
    this.isRegionUser=this.authService.hasAnyRolesDirect([Role.REGIONAL_MAGER,Role.CM_CR]);
    this.filterCircle=null;
    this.filterModule=null;
    this.filterNetwork=null;
    this.filterRegion=null;
    this.summary = "0";

    this.map = new Map<string, string>();

    this.map.set("Paid Notes Closing Balance","Paid Notes");
    this.map.set("Withdrawals (LBB/Other branches)","Withdrawals");
    this.map.set("Deposits (LBB/Other branches)","Deposits");
    this.map.set("I/W (RO) (Remittance)","Remittances from RBI");
    this.map.set("I/W (CC) (Diversion)","Remittances from Other CCs");
    this.map.set("O/W (CC) (Diversion)","Diversions to other CCs");
    this.map.set("O/W (RO) (Remittance)","Soiled Notes Remittance to RBI");
    this.map.set("Opening Balance","Total CC Opening Balance");
    this.map.set("Closing Balance (OB + A - B)","Total CC Closing Balance");
    this.map.set("Re-Issuable Notes Closing Balance","Issuable Notes");
    this.map.set("Fresh Notes Closing Balance","Fresh Notes");
    this.map.set("Unsorted Notes Closing Balance","UnSorted Notes");
    this.map.set("Soiled Notes Closing Balance","Soiled Notes");
    

  }

  getRoles()
  {
    this.status=true;
    this.customReportsService.getRoles().subscribe(
      res => {
        console.log(res);
        this.status=false;
              },
      err => {
        console.log(err);
        this.status=false;
      }
    );
  }

  getCircles()
  {
    this.status=true;
    this.customReportsService.getCircles().subscribe(
      res => {
               
        this.circle = res;

        if(!this.isAbdUser)
        {
          this.filterCircle=this.circle[0]; 
          
          this.onChangeCircle();        
        }
        else
        {
      
        this.filterCircle='%';
       }

       this.filterNetwork='%';
          this.filterModule='%';
          this.filterRegion='%'; 
        

        console.log(this.circle);
        this.status=false;
              },
      err => {
        console.log(err);
        this.status=false;
      }
    );
  }


  onChangeSummary()
  {
    this.customReport=null;
console.log(this.summary);
  }
  onChangeCircle() {
    
    var formData = new FormData();
    console.log(this.filterCircle);
    formData.set("circle",this.filterCircle);


    if(this.filterCircle=='%')
    {
      this.filterNetwork='%';
      this.filterModule='%';
      this.filterRegion='%';
      this.network=null;
      this.module=null;
      this.region=null;
      this.customReport = null;
      return;
    }
    this.status=true;
    this.filterNetwork = null;
    this.filterModule=null;
    this.filterRegion=null;
    this.customReport = null;

    this.customReportsService.getNetworks(formData).subscribe(
      res => {
               
        this.network = res;

        if(!this.isAbdUser && !this.isCircleUser)
        {
          this.filterNetwork=this.network[0];
          this.onChangeNetwork();
         
        }
        else
        {
          this.filterNetwork='%';
         
        }

        this.filterModule='%';
        this.filterRegion='%';

        console.log(this.network);
        this.status=false;
              },
      err => {
        console.log(err);
        this.status=false;
      }
    );
  
  }


  onChangeNetwork() {
    
    var formData = new FormData();
    formData.set("circle",this.filterCircle);
    formData.set("network",this.filterNetwork);

    if(this.filterNetwork=='%')
    {
      this.filterModule='%';
      this.module=null;
      this.filterRegion='%';
      this.region=null;
      this.customReport = null;

      return;
    }

    this.filterModule=null;
    this.filterRegion=null;
    this.customReport = null;
    this.status=true;
    this.customReportsService.getModules(formData).subscribe(
      res => {
               
        this.module = res;

        if(!this.isAbdUser && !this.isCircleUser)
       {
          this.filterModule=this.module[0];
          this.onChangeModule();
         
       }
        else
       {
        
        this.filterModule='%';
       }


       this.filterRegion='%';
       
        console.log(this.module);
        this.status=false;
              },
      err => {
        console.log(err);
        this.status=false;
      }
    );

  }


  onChangeModule() {
    
    var formData = new FormData();
    formData.set("circle",this.filterCircle);
    formData.set("network",this.filterNetwork);
    formData.set("module",this.filterModule);

    if(this.filterModule=='%')
    {
      this.filterRegion='%';
      this.region=null;
      this.customReport = null;
      return;
    }

    this.filterRegion=null;
    this.customReport = null;

    this.status=true;
    this.customReportsService.getRegions(formData).subscribe(
      res => {
               
        this.region = res;

        if(!this.isAbdUser && !this.isCircleUser && !this.isAoUser)
        {
          this.filterRegion=this.region[0];
          this.onChangeRegion();
        }
        else
        this.filterRegion='%';


        console.log(this.region);
        this.status=false;
              },
      err => {
        console.log(err);
        this.status=false;
      }
    );


  }
onChangeRegion()
{
  this.customReport = null;
}

  


  onChangeFromDate() {
    this.listOfDisplayData = null;
    this.todate = this.fromdate;

   

  }

  onChangeToDate() {
    this.listOfDisplayData = null;
  }

  onChangeReport() {
    this.listOfDisplayData = null;
    this.fromdate = null;
    if(this.report=='Paid Notes Closing Balance' || this.report=='Closing Balance (OB + A - B)' || this.report=='Re-Issuable Notes Closing Balance' || this.report=='Fresh Notes Closing Balance' || this.report=='Unsorted Notes Closing Balance' || this.report=='Soiled Notes Closing Balance')
    {
      this.dateDisable2=true;
    }
    else
    this.dateDisable2=false;

    this.todate = null;
  }

 /* handleClose(removedtag) {
    console.log(this.filters);

    this.filters = this.filters.filter(tag => tag !== removedtag);
    var field = removedtag.toString();
    var searchField = field.split(':')[0].trim();

    console.log(removedtag + ' ' + searchField + ' ' + this.filters);

    if (searchField == 'Circle') this.reset1();

    if (searchField == 'Network') this.reset2();

    if (searchField == 'Zone') this.reset3();

    if (searchField == 'FSLO CODE') this.reset4();

    if (searchField == 'CCCODE') this.reset5();

    if (searchField == 'BR NAME') this.reset6();

    if (searchField == 'POP CD') this.reset7();

    if (searchField == 'STATE') this.reset8();

    if (searchField == 'Region') this.reset9();
  }*/

  disabledDate1 = (current: Date): boolean => {
    return differenceInCalendarDays(current, new Date()) > 0;
  };

  disabledDate2 = (current: Date): boolean => {
    return differenceInCalendarDays(current, this.fromdate) < 0 || differenceInCalendarDays(current, new Date()) > 0 || differenceInCalendarDays(current,this.fromdate) > 31 ;
  };

  download() {

    this.status=true;

    let requiredDownload= "";
    let downloadName="";
    if(this.summary=="0")
    requiredDownload = "downloadCustomReport";
    else if (this.summary=="1")
    {
    requiredDownload = "downloadCustomReportCircleSummary";
    downloadName="Circle Summary";
    }
    else if (this.summary=="2")
    {
    requiredDownload = "downloadCustomReportCircleStateSummary";
    downloadName="Circle State Summary";
    }
    else if (this.summary=="3")
    {
    requiredDownload = "downloadCustomReportFsloSummary";
    downloadName="Fslo Summary";
    }

    var formData = new FormData();

    var datePipe = new DatePipe('en-US');


    formData.set('fromdate', datePipe.transform(this.fromdate, 'dd/MM/yyyy'));
    formData.set('todate', datePipe.transform(this.todate, 'dd/MM/yyyy'));
    formData.set('report', this.report);

    formData.set('circle',this.filterCircle)
    formData.set('network',this.filterNetwork)
    formData.set('module',this.filterModule)
    formData.set('region',this.filterRegion)

    if(this.summary == "0")
    {
    this.customReportsService.downloadCustomReport(formData,requiredDownload).subscribe(res => {
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
      link.download = this.map.get(this.report).replace(/[^\w\s]/gi, '') + ' '+downloadName+ '.csv';
      link.click();
      link.remove();
      this.status=false;
    });
  }

  else 
  {
    this.customReportsService.downloadCustomReport1(this.listOfDisplayData,requiredDownload).subscribe(res => {
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
      link.download = this.map.get(this.report).replace(/[^\w\s]/gi, '') + ' '+downloadName+ '.csv';
      link.click();
      link.remove();
      this.status=false;
    });
  }
  }

  



   generateReport() {
    var formData = new FormData();

    var datePipe = new DatePipe('en-US');

    formData.set('fromdate', datePipe.transform(this.fromdate, 'dd/MM/yyyy'));
    formData.set('todate', datePipe.transform(this.todate, 'dd/MM/yyyy'));
    formData.set('report', this.report);

    if(this.filterCircle == null)
    {
        this.filterCircle='%';
    }

    if(this.filterNetwork == null)
    {
      this.module=null;
    this.filterNetwork='%';
    }
    if(this.filterModule == null)
    {
      this.region=null;
      this.filterModule='%';
    }

    if(this.filterRegion == null)
    this.filterRegion='%';


console.log(this.filterNetwork+" "+this.filterCircle+" "+this.filterModule+" "+this.filterRegion);


    if(this.isFsloUser)
    {
      this.filterCircle='%';
      this.filterNetwork='%';
      this.filterModule='%';
      this.filterRegion='%';
    }

    formData.set('circle',this.filterCircle)
    formData.set('network',this.filterNetwork)
    formData.set('module',this.filterModule)
    formData.set('region',this.filterRegion)

    if (this.fromdate != null && this.todate != null && this.report != null) {
      this.status = true;

      let requiredSummary = "";
      if(this.summary=="0")
      requiredSummary = "getCustomReports";
      else if (this.summary=="1")
      requiredSummary = "getCustomReportsCircleSummary";
      else if (this.summary=="2")
      requiredSummary = "getCustomReportsCircleStateSummary";
      else if (this.summary=="3")
      requiredSummary = "getCustomReportsFsloSummary";


      this.customReportsService.getCustomReports(formData,requiredSummary).subscribe(
        res => {
          this.status = false;
          this.reportName = this.report;
          this.customReport = res;
          console.log(res);
          
          this.listOfDisplayData = this.customReport;
          if (this.listOfDisplayData == null || this.listOfDisplayData.length == 0) 
          this.message.create('error', 'No Data to Display.');
          console.log(this.listOfDisplayData);
        },
        err => {
          this.status = false;
          this.customReport = [];
          this.listOfDisplayData = [];
          console.log(err);
        }
      );
    }
  }

  resetall(): void {
    this.searchValue1 = '';
    this.searchValue2 = '';
    this.searchValue3 = '';
    this.searchValue4 = '';
    this.searchValue5 = '';
    this.searchValue6 = '';
    this.searchValue7 = '';
    this.searchValue8 = '';
    this.searchValue9 = '';
    this.filters = [];
    this.listOfDisplayData = this.customReport;
  }

 /* add(): CustomReport {
    var total = new CustomReport();
    if (!this.listOfDisplayData[0] || !this.listOfDisplayData[0].data) return total;

    total.circle = null;
    total.network = null;
    total.zone = null;
    total.fslocode = null;
    total.cccode = null;
    total.popcd = null;
    total.state = 'TOTAL';
    total.date = null;
    total.region = null;

    total.data = new Array(this.listOfDisplayData[0].data.length);
    for (var i = 0; i < total.data.length; i++) {
      total.data[i] = 0;
      for (var j = 0; j < this.listOfDisplayData.length; j++) {
        total.data[i] += this.listOfDisplayData[j].data[i];
      }
    }
    return total;
  }*/

 /* reset(): void {
    console.log('1' + this.searchValue1);
    console.log('2' + this.searchValue2);
    console.log('3' + this.searchValue3);
    console.log('4' + this.searchValue4);
    console.log('5' + this.searchValue5);
    console.log('6' + this.searchValue6);
    console.log('7' + this.searchValue7);
    console.log('8' + this.searchValue8);

    this.listOfDisplayData = this.customReport
      .slice(0, this.customReport.length - 1)
      .filter((item: CustomReport) => item.circle.toLowerCase().indexOf(this.searchValue1.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.network.toString().toLowerCase().indexOf(this.searchValue2.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.zone.toLowerCase().indexOf(this.searchValue3.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.fslocode.toString().toLowerCase().indexOf(this.searchValue4.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.cccode.toString().toLowerCase().indexOf(this.searchValue5.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.brname.toLowerCase().indexOf(this.searchValue6.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.popcd.toLowerCase().indexOf(this.searchValue7.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.state.toLowerCase().indexOf(this.searchValue8.toLowerCase()) !== -1);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length)
      .filter((item: CustomReport) => item.region.toString().toLowerCase().indexOf(this.searchValue9.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
  }

  reset1(): void {
    this.searchValue1 = '';
    // this.search1();
    this.reset();
  }

  search1(): void {
    this.visibleSearch1 = false;
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.circle.toLowerCase().indexOf(this.searchValue1.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue1 != '') this.filters.push('Circle : ' + this.searchValue1);
  }

  reset2(): void {
    this.searchValue2 = '';
    // this.search2();
    this.reset();
  }

  search2(): void {
    this.visibleSearch2 = false;
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.network.toString().toLowerCase().indexOf(this.searchValue2.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue2 != '') this.filters.push('Network : ' + this.searchValue2);
  }

  reset3(): void {
    this.searchValue3 = '';
    // this.search3();
    this.reset();
  }

  search3(): void {
    this.visibleSearch3 = false;

    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.zone.toLowerCase().indexOf(this.searchValue3.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue3 != '') this.filters.push('Zone : ' + this.searchValue3);
  }

  reset4(): void {
    this.searchValue4 = '';
    //  this.search4();
    this.reset();
  }

  search4(): void {
    this.visibleSearch4 = false;

    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.fslocode.toString().toLowerCase().indexOf(this.searchValue4.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue4 != '') this.filters.push('FSLO CODE : ' + this.searchValue4);
  }

  reset5(): void {
    this.searchValue5 = '';
    //  this.search5();
    this.reset();
  }

  search5(): void {
    this.visibleSearch5 = false;
    console.log(this.searchValue5);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.cccode.toString().toLowerCase().indexOf(this.searchValue5.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue5 != '') this.filters.push('CCCODE : ' + this.searchValue5);
  }

  reset6(): void {
    this.searchValue6 = '';
    ///  this.search6();
    this.reset();
  }

  search6(): void {
    this.visibleSearch6 = false;
    console.log(this.searchValue6);
    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.brname.toLowerCase().indexOf(this.searchValue6.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue6 != '') this.filters.push('BR NAME : ' + this.searchValue6);
  }

  reset7(): void {
    this.searchValue7 = '';
    //  this.search7();
    this.reset();
  }

  search7(): void {
    this.visibleSearch7 = false;

    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.popcd.toLowerCase().indexOf(this.searchValue7.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue7 != '') this.filters.push('POP CD : ' + this.searchValue7);
  }

  reset8(): void {
    this.searchValue8 = '';
    // this.search8();
    this.reset();
  }

  search8(): void {
    this.visibleSearch8 = false;

    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.state.toLowerCase().indexOf(this.searchValue8.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue8 != '') this.filters.push('STATE : ' + this.searchValue8);
  }

  reset9(): void {
    this.searchValue9 = '';
    // this.search8();
    this.reset();
  }

  search9(): void {
    this.visibleSearch9 = false;

    this.listOfDisplayData = this.listOfDisplayData
      .slice(0, this.listOfDisplayData.length - 1)
      .filter((item: CustomReport) => item.region.toString().toLowerCase().indexOf(this.searchValue9.toLowerCase()) !== -1);
    this.listOfDisplayData.push(this.add());
    if (this.searchValue9 != '') this.filters.push('Region : ' + this.searchValue9);
  }*/
}
