import { TestBed } from '@angular/core/testing';

import { RbiPenaltyUploadService } from './rbi-penalty-upload.service';

describe('RbiPenaltyUploadService', () => {
  let service: RbiPenaltyUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RbiPenaltyUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
