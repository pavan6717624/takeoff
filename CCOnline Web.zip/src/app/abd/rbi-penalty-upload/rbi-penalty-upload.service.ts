/*(import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RbiPenaltyUploadService {

  constructor() { }
}*/


import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import {PenaltyRowData} from './rbi-penalty-upload.component'
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RbiPenaltyUploadService {

  constructor(private http: HttpClient, private log: NGXLogger) { }

 

  processRBIPenalty(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/processRBIPenalty`,formData);
  }

  getLatestUploadDate(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/rbiPenaltyLatestUploadedDate`);
  }


  saveRBIPenaltyData(penaltyData: PenaltyRowData[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/saveRBIPenaltyData`, penaltyData);
  }

  deleteRBIPenaltyData(penaltyData: PenaltyRowData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/deleteRBIPenaltyData`, penaltyData);
  }


}
