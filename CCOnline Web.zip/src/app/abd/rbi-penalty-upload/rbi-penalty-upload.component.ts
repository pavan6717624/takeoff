import { HttpClient, HttpRequest, HttpResponse } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { en_US, NzI18nService, zh_CN } from "ng-zorro-antd/i18n";
import differenceInCalendarDays from "date-fns/differenceInCalendarDays";
import { DatePipe } from "@angular/common";
import { NzMessageService } from 'ng-zorro-antd/message';
import {RbiPenaltyUploadService} from './rbi-penalty-upload.service';

export class Fslo {
  branchCode: number;
  branchName: string;
}


export class PenaltyDisplayData
{
  debitTotal: number;
  creditTotal: number;
  openingBalance: number;
  closingBalance: number;
  penaltyData: PenaltyRowData[];
  status: string;
  message: string;
 }

export class PenaltyRowData {
	id: number;
	date: Date;
	valueDate: Date;
	particulars: string;
  debit: number;
  color: string;
  fslo : RBI_Fslo;
  status: string;
  postedStatus: string;
  disposalStatus: string;
  }

  export class RBI_Fslo
  {
    rbiRegionCode: number;
    fslo: Fslo
  }

@Component({
  selector: 'app-rbi-penalty-upload',
  templateUrl: './rbi-penalty-upload.component.html',
  styleUrls: ['./rbi-penalty-upload.component.less']
})
export class RbiPenaltyUploadComponent implements OnInit {


  loading = false;
  formData = new FormData();
  selectfile = "Select File";
  uploaded = false;
  error = false;
  date = null;
  file: any = "";
  today = new Date();
  displayData: PenaltyDisplayData;
  penaltyAmount: number = 0;
  submittedPenaltyAmount: number=0;
  penaltyData: PenaltyRowData[];
  latestUploadDate: Date;
  
  listOfKeywords = [];
  confirmStatus=true;
  constructor(private http: HttpClient, private i18n: NzI18nService,private message: NzMessageService,private rbiPenaltyUploadService: RbiPenaltyUploadService ) { 

    this.getLatestUploadDate();
  }


  getLatestUploadDate()
  {
    this.rbiPenaltyUploadService.getLatestUploadDate().subscribe(
      (res) => {
        
        this.latestUploadDate = res;
      }
     
    );
  }

  

  
  ngOnInit(): void {
  }

  disabledDate = (current: Date): boolean => {
			return (
			differenceInCalendarDays(current, this.today) > 0);
  };
  
  delete(i)
  {
     this.rbiPenaltyUploadService.deleteRBIPenaltyData( this.displayData.penaltyData[i]).subscribe(
      res => {
        this.submittedPenaltyAmount -= this.displayData.penaltyData[i].debit;
        this.penaltyAmount -= this.displayData.penaltyData[i].debit;
        this.displayData.penaltyData[i].status="Not Submitted";
        this.message.create(res.status,res.message)
      },
      err => {
        this.message.create('error','Error Occured. Please try Again.')
      }
    );



  }
  beforeUpload = (file: any) => {
    if (this.date == null || this.date == "") {
     this.message.create('error',"Please select Date.");
     this.error=true;
     return false;
   }

  
   this.loading = true;

   this.selectfile = "Processing...";
   this.formData.set("file", file);

   var datePipe = new DatePipe("en-US");
   let dateValue = datePipe.transform(this.date, "yyyy-MM-dd");

   this.formData.set("date",dateValue);
   this.penaltyAmount=0;
   this.submittedPenaltyAmount = 0;
   console.log(JSON.stringify(this.listOfKeywords));
   this.formData.set("keywords",JSON.stringify(this.listOfKeywords));
   this.rbiPenaltyUploadService.processRBIPenalty(this.formData).subscribe(
       (res) => {
         this.loading = false;
         this.displayData = res;
        console.log(res);
        if(this.displayData.status && this.displayData.status == 'Error' && this.displayData.message && this.displayData.message.length > 0)
        this.message.create('error',this.displayData.message);
        else if(this.displayData.status && this.displayData.status == 'Warning' && this.displayData.message && this.displayData.message.length > 0)
        this.message.create('warning',this.displayData.message);
        else if(this.displayData.status && this.displayData.status == 'Success' && this.displayData.message && this.displayData.message.length > 0 && !this.displayData.message.includes('parsed'))
        this.message.create('success',this.displayData.message);
        
        for(var i=0;i<this.displayData.penaltyData.length;i++)
        if(this.displayData.penaltyData[i].status=='Submitted')
        this.submittedPenaltyAmount += this.displayData.penaltyData[i].debit;

        this.penaltyAmount = this.submittedPenaltyAmount;

        this.selectfile = "Select File";
         console.log(res);

         this.getLatestUploadDate();
        
       },
       (err) => {
        this.loading = false;
        this.displayData = new PenaltyDisplayData();
         console.log(err);
       }
     );
   return false;
 }

 demo()
{
console.log("this is pavan");
}
log(value: string[]): void {

  if(value.length > 0)
  {
    this.confirmStatus = false;
  }
  else
  this.confirmStatus = true;
  
  this.penaltyData = new Array(value.length);
  
for(var i=0;i<this.displayData.penaltyData.length;i++)
this.displayData.penaltyData[i].color="";

  this.penaltyAmount = this.submittedPenaltyAmount;
  for(var i=0;i<value.length;i++)
  {

  this.penaltyAmount+=Number(this.displayData.penaltyData[Number(value[i])-1].debit);
  this.displayData.penaltyData[Number(value[i])-1].color='lightblue';
  this.penaltyData[i]=this.displayData.penaltyData[Number(value[i])-1];
  }
  console.log(this.penaltyAmount);

}


RequestBack() {
  this.displayData = new PenaltyDisplayData();
  this.file = '';
  this.date = '';
  this.listOfKeywords = [];
  this.loading = false;
}


RequestConfirm() {

this.loading=true;

  this.rbiPenaltyUploadService.saveRBIPenaltyData(this.penaltyData).subscribe(
    (res) => {
  this.displayData = new PenaltyDisplayData();
  this.file = '';
  this.date = '';
  this.listOfKeywords = [];
  this.loading = false;
  this.confirmStatus = true;
      console.log(res);
      this.message.create('success',res.message);
      this.getLatestUploadDate();
    },
    (err) => {
      this.displayData = new PenaltyDisplayData();
  this.file = '';
  this.date = '';
  this.listOfKeywords = [];
  this.loading = false;
  this.confirmStatus = true;
      console.log(err);
      this.message.create('error','Error Occured. Please try Again.');
    }
  );
}


}
