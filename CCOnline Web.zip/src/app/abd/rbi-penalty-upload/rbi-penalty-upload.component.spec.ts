import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RbiPenaltyUploadComponent } from './rbi-penalty-upload.component';

describe('RbiPenaltyUploadComponent', () => {
  let component: RbiPenaltyUploadComponent;
  let fixture: ComponentFixture<RbiPenaltyUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RbiPenaltyUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RbiPenaltyUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
