import { Component, OnInit } from '@angular/core';
import { CcPositionService } from 'src/app/branch/cc-position/cc-position.service';

@Component({
  selector: 'app-adjust-chest-slip',
  templateUrl: './adjust-chest-slip.component.html',
  styleUrls: ['./adjust-chest-slip.component.less']
})
export class AdjustChestSlipComponent implements OnInit {

  constructor(private ccPositionService: CcPositionService) { }

  ngOnInit(): void {
  }

  editStatus=false;

  loading=false;
  

  text="";

  beforeUpload = (file: any) => {
  
var formData= new FormData();
    this.loading = true;
    formData.set('file', file);

    this.ccPositionService.beforeUploadAdmin(formData).subscribe(
      res => {
        this.loading=false;
        console.log(res);
        this.text=res.message;
      },
      err => {
        this.loading=false;
        console.log(err);
      }
    );
    return false;
  };


  edit()
  {
    if(!this.editStatus)
    this.editStatus=true;
    else
    {
      this.loading = true;
      var formData= new FormData();
      formData.set('htmlData',this.text);
      this.ccPositionService.generatedPDF(formData).subscribe(
        res => {

          const link = document.createElement('a');
      link.href = 'data:application/pdf;base64,' + res.message;
      link.download = 'Adjusted Chest Slip.pdf';
      link.click();
      link.remove();

      this.loading = false;

         
        },
        err => {
          this.loading=false;
          console.log(err);
        }
      );
    }

  }


}
