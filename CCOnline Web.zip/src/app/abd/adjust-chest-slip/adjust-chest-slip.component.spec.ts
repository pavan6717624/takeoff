import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustChestSlipComponent } from './adjust-chest-slip.component';

describe('AdjustChestSlipComponent', () => {
  let component: AdjustChestSlipComponent;
  let fixture: ComponentFixture<AdjustChestSlipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdjustChestSlipComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdjustChestSlipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
