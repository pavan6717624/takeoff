import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MonthWiseVerificationService } from './month-wise-verification.service';

export class MonthWiseVerificationReport {
	
	circleName: string;
	total: number;
	biMonthly: number;
	quarterly: number;
	halfYearly: number;
	securityOfficer: number;
	dgmcfo: number;
	controllerVisit: number;
	moduleHeadVisit: number;
	gmNetworkVisit: number;
  cgmVisit: number;
	dgmCFO: number;
  month: string;

}



@Component({
  selector: 'app-month-wise-verification',
  templateUrl: './month-wise-verification.component.html',
  styleUrls: ['./month-wise-verification.component.less']
})
export class MonthWiseVerificationComponent implements OnInit {

  constructor(private monthWiseVerificationService: MonthWiseVerificationService) { }
  month:number;
  status: boolean;
  monthWiseVerificationReport: MonthWiseVerificationReport[];
  ngOnInit(): void {
  }

onChange()
{
  if(this.month == 0 || this.month==null)
  return;

  this.monthWiseVerificationReport = null;

  var datePipe = new DatePipe('en-US');
  var date = datePipe.transform(this.month, 'MM/yyyy');

  
  console.log(date);

  var formData = new FormData();
  formData.set("date",date);
 
 this.status=true;
     this.monthWiseVerificationService.getMonthWiseVerifications(formData).subscribe(
       res => {
         this.status=false;
         this.monthWiseVerificationReport = res;
         console.log(this.monthWiseVerificationReport);
       },
       err => {
        this.status=false;
       }
     );
 
  

}

download() {

  this.status=true;

  this.monthWiseVerificationService.downloadMonthWiseVerification(this.monthWiseVerificationReport).subscribe(res => {
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
    link.download = 'Month Wise Summary Report.csv';
    link.click();
    link.remove();
    this.status=false;
  });
}


}
