import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthWiseVerificationComponent } from './month-wise-verification.component';

describe('MonthWiseVerificationComponent', () => {
  let component: MonthWiseVerificationComponent;
  let fixture: ComponentFixture<MonthWiseVerificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MonthWiseVerificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthWiseVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
