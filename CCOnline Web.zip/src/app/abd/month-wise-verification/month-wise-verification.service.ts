import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MonthWiseVerificationReport } from './month-wise-verification.component';

@Injectable({
  providedIn: 'root'
})
export class MonthWiseVerificationService {
  
  
  downloadMonthWiseVerification(monthWiseVerificationReport: MonthWiseVerificationReport[]) {
    return this.http.post(`${environment.apiUrl}/mis/verification/downloadMonthWiseVerifications`, monthWiseVerificationReport, { responseType: 'blob' });
  }




  constructor(private http: HttpClient, private log: NGXLogger) {}

  getMonthWiseVerifications(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/mis/verification/getMonthWiseVerifications`, formData);
  }



}
