import { TestBed } from '@angular/core/testing';

import { MonthWiseVerificationService } from './month-wise-verification.service';

describe('MonthWiseVerificationService', () => {
  let service: MonthWiseVerificationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MonthWiseVerificationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
