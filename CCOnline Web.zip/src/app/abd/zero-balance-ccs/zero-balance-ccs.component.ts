import { Component, OnInit } from '@angular/core';
import { ZeroBalanceCcsService } from './zero-balance-ccs.service';


export class ZeroBalanceCCs
{
  circle : string;
	network: number;
	module: number;
	moduleName: string;
	region: number;
  brcode: number;
  brname: string;
  csdate: Date;
  openingBalance: number;
	closingBalance: number;
}


@Component({
  selector: 'app-zero-balance-ccs',
  templateUrl: './zero-balance-ccs.component.html',
  styleUrls: ['./zero-balance-ccs.component.less']
})
export class ZeroBalanceCcsComponent implements OnInit {

  constructor(private zeroBalanceCcsService: ZeroBalanceCcsService) { }

  zeroBalanceCcs: ZeroBalanceCCs[];


  ngOnInit(): void {

    this.zeroBalanceCcsService.getZeroClosingBalanceCCs().subscribe(
      res => {
       this.zeroBalanceCcs  = res;
       console.log(this.zeroBalanceCcs);
      },
      err => {
        console.log(err);
      }
    );



  }


  export() {
    this.zeroBalanceCcsService.exportToExcel(this.zeroBalanceCcs).subscribe(res => {
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
      link.download = 'Zero Balance Currency Chests.csv';
      link.click();
      link.remove();
    });
  }



}
