import { TestBed } from '@angular/core/testing';

import { ZeroBalanceCcsService } from './zero-balance-ccs.service';

describe('ZeroBalanceCcsService', () => {
  let service: ZeroBalanceCcsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ZeroBalanceCcsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
