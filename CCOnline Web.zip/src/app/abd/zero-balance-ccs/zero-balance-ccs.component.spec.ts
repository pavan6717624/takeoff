import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZeroBalanceCcsComponent } from './zero-balance-ccs.component';

describe('ZeroBalanceCcsComponent', () => {
  let component: ZeroBalanceCcsComponent;
  let fixture: ComponentFixture<ZeroBalanceCcsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZeroBalanceCcsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZeroBalanceCcsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
