/*import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ZeroBalanceCcsService {

  constructor() { }
}*/


import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';


import { environment } from 'src/environments/environment';
import { ZeroBalanceCCs } from './zero-balance-ccs.component';

@Injectable({
  providedIn: 'root',
})
export class ZeroBalanceCcsService {
  constructor(private http: HttpClient) {}

  getZeroClosingBalanceCCs(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/cc-position/getZeroClosingBalanceCCs`);
  }

  exportToExcel(misReport: ZeroBalanceCCs[]): Observable<any>
  {
    return this.http.post(`${environment.apiUrl}/cc-position/exportToExcelZeroBalanceCCs`, misReport,{responseType: 'blob'});
  }

}

