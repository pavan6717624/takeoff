import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { EmailReminderService } from './email-reminder.service';

@Component({
  selector: 'app-email-reminder',
  templateUrl: './email-reminder.component.html',
  styleUrls: ['./email-reminder.component.less'],
})
export class EmailReminderComponent implements OnInit {
  reminderFor = [
    { id: 1, name: 'EXCEPTIONS', description: 'Exceptions' },
    { id: 2, name: 'DIFF_IN_98908', description: 'Difference in BGL 98908' },
    { id: 3, name: 'DIFF_IN_98958', description: 'Difference in BGL 98958' },
    { id: 4, name: 'CHEST_SLIP_UPLOAD', description: 'Chest Slip Not Uploaded' },
  ];

  submitting = false;
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private log: NGXLogger,
    private emailService: EmailReminderService,
    private msg: NzNotificationService
  ) {}

  get control() {
    return this.form.get('reminderFor') as FormArray;
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      reminderFor: [[], [Validators.required]],
      toBeSentTo: ['', [Validators.required]],
      pendencyFor: ['', [Validators.required, Validators.min(1), Validators.max(10)]],
    });
  }

  submit(): void {
    this.submitting = true;
    if (this.form.valid) {
      this.log.debug('form data:', this.form.value);
      this.emailService.submit(this.form.value).subscribe(
        data => {
          this.msg.success('', data.message ? data.message : 'Email remainder will be sent in some time');
          this.submitting = false;
        },
        err => {
          this.submitting = false;
        }
      );
    }
  }
}
