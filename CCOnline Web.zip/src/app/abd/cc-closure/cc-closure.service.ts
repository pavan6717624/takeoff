import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Option } from 'src/app/shared/models/option.model';
import { environment } from 'src/environments/environment';
import { CcClosureDetails } from './cc-closure-details.model';

@Injectable({ providedIn: 'root' })
export class  CcClosureService{
  constructor(private http: HttpClient) {}

  postFetchCcClosure(data: any): Observable<any> {
    console.log('Fetch Data:', data);
    // return this.http.post(`${environment.apiUrl}/ccclosure/submit`, data);
    return this.http.post<CcClosureDetails[]>(`${environment.apiUrl}/ccclosure/fetch`, data)
 
  }

  postSubmitCcClosure(data: any): Observable<any> {
    console.log('Submit Data:', data);
    // return this.http.post(`${environment.apiUrl}/ccclosure/submit`, data);
    return this.http.post(`${environment.apiUrl}/ccclosure/submit`, data)
 
  }
}
