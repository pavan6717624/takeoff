import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CcClosureComponent } from './cc-closure.component';

describe('CcClosureComponent', () => {
  let component: CcClosureComponent;
  let fixture: ComponentFixture<CcClosureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CcClosureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CcClosureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
