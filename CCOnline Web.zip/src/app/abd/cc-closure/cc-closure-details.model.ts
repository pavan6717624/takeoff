export interface CcClosureDetails{
    circleCode: number;
    circleName: String;
    networkCode: number;
    moduleCodeCode: number;
    moduleName: String;
    regionCode: number;
    branchCode: number;
    branchName: String;
    fsloCode: number;
    ccCode: number;
    ccClosingBalance: number;
    ccClosingBalanceDate: Date;
    ccBalanceZeroFlag: boolean;
    bgl98908ClosingBalance: number;
    bgl98958ClosingBalance: number;
}