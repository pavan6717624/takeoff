import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { Router } from '@angular/router';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { CcClosureService } from './cc-closure.service';
import { STColumn, STComponent, STData, STPage } from '@delon/abc/st';
import { NzModalService } from 'ng-zorro-antd/modal';

@Component({
  selector: 'app-cc-closure',
  templateUrl: './cc-closure.component.html',
  styleUrls: ['./cc-closure.component.less'],
})
export class CcClosureComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private notification: NzNotificationService,
    private router: Router,
    private ccClosureService: CcClosureService,
    private modalService: NzModalService
  ) {}

  ccClosureForm: FormGroup;
  dateFormat = DATE_FORMAT;
  certify = false;

  today = new Date();
  loaded = false;
  details: STData[] = [];

  ccBalanceZeroFlag: boolean;

  pagerConfig: STPage = { front: true, simple: true };
  isLoading = false;

  @ViewChild('st', { static: false }) private st: STComponent;

  columns: STColumn[] = [
    { title: 'Circle', index: 'circleName' },
    { title: 'Network', index: 'networkCode', className: 'text-center' },
    // { title: 'Module Code', index: 'moduleCodeCode', className: 'text-center' },
    { title: 'Module Name', index: 'moduleName' },
    { title: 'Region Code', index: 'regionCode', className: 'text-center' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-center' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'FSLO Code', index: 'fsloCode', className: 'text-center' },
    { title: 'CC Code', index: 'ccCode', className: 'text-center' },
    { title: 'CC Closing Balance', index: 'ccClosingBalance', className: 'text-center' },
    { title: 'CC Closing Balance Date', index: 'ccClosingBalanceDate', className: 'text-center' },
    { title: 'BGL 98908 Closing Balance', index: 'bgl98908ClosingBalance', className: 'text-center' },
    { title: 'BGL 98958 Closing Balance', index: 'bgl98958ClosingBalance', className: 'text-center' },
  ];

  disabledDate = (current: Date): boolean => {
    return differenceInCalendarDays(current, this.today) > 0;
  };

  ngOnInit(): void {
    this.ccClosureForm = this.fb.group({
      brCode: ['', [Validators.required, Validators.maxLength(5), Validators.pattern('^[0-9]*$')]],
      dateOfClosure: ['', [Validators.required]],
      // certify: [false, [Validators.requiredTrue]],
    });
  }

  CcClosureFetch() {
    console.log('On submit-ts file', this.ccClosureForm);
    for (const i in this.ccClosureForm.controls) {
      this.ccClosureForm.controls[i].markAsDirty();
      this.ccClosureForm.controls[i].updateValueAndValidity();
    }
    this.ccClosureService.postFetchCcClosure(this.ccClosureForm.value).subscribe(
      value => {
        console.log('Details:', value);
        this.details = [value];
        this.ccBalanceZeroFlag = value.ccBalanceZeroFlag; //not being used
        this.loaded = true;
      },
      error => {
        console.log(' Error in fetching details: ', error);
      },
      () => (this.isLoading = false)
     
    );
  }

  toggleCertify(): void {
    this.certify = !this.certify;
  }

  submit(): void {
    console.log('On submit-ts file', this.ccClosureForm);
    console.log('Form:', this.ccClosureForm.valid);
    console.log('Certify', this.certify);
    if(!this.certify)
    {
      this.notification.warning('Please Certify before proceeding to Submit', '');
    }
    if (this.ccClosureForm.valid && this.certify) {
      this.modalService.confirm({
        nzTitle: 'Are you sure you want to close the currency chest?',
        // nzContent: 'Once submitted, report cannot be modified',
        nzOnOk: () => {
          this.ccClosureService
            .postSubmitCcClosure({
              brCode: this.ccClosureForm.get('brCode').value,
              dateOfClosure: this.ccClosureForm.get('dateOfClosure').value,
              certify: this.certify,
            })
            .subscribe(
              res => {
                console.log('success:', res);
                this.notification.success('Currency Chest is marked as closed successfully', '');
              },
              error => {
                console.log(' Error in Closing Currency Chest: ', error);
              },
              () => console.log('completed')
            );
        },
      });
    }
  }
}
