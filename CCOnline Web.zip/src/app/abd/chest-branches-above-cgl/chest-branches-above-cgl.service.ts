import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { Report } from './chest-branches-above-cgl.component';

@Injectable({
  providedIn: 'root',
})
export class ChestBranchesAboveCglService {
  constructor(private http: HttpClient) {}

  getListofCCAboveCBL(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-upload/getListofCCAboveCBL`, formData);
  }
  exportToExcel(misReport: Report[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-position/exportToExcelAboveCGL`, misReport, { responseType: 'blob' });
  }
}
