import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ChestBranchesAboveCglService } from './chest-branches-above-cgl.service';
import { NzMessageService } from 'ng-zorro-antd/message';

export class Report {
  circle: string;
  network: number;
  module: number;
  moduleName: string;
  region: number;
  brcode: number;
  brname: string;
  cccode: number;
  fslocode: number;
  fsloName: string;
  cbl: number;
  total: number;
}

@Component({
  selector: 'app-chest-branches-above-cgl',
  templateUrl: './chest-branches-above-cgl.component.html',
})
export class ChestBranchesAboveCglComponent implements OnInit {
  constructor(private message: NzMessageService,private ChestBranchesAboveCglService: ChestBranchesAboveCglService) {}

  ngOnInit(): void {}

  date: Date;
  status: boolean = false;
  misReport: Report[];
  limit: number = 85;

  export() {
    this.ChestBranchesAboveCglService.exportToExcel(this.misReport).subscribe(res => {
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
      link.download = 'Chest Branches CBL Greater than '+this.limit+' percent.csv';
      link.click();
      link.remove();
    });
  }

  onChange() {
    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.date, 'dd/MM/yyyy');
    console.log('date: ', date);
    var formData = new FormData();
    formData.set('date', date);

    if(this.limit <=0 || this.limit>=1000 || this.limit == null)
    this.limit=85;

    formData.set('limit',this.limit+"");

    if(date == null)
    this.message.create("error","Select Date");

    this.misReport = [];
    if (date != null) {
      this.status = true;
      this.ChestBranchesAboveCglService.getListofCCAboveCBL(formData).subscribe(
        res => {
          this.misReport = res;
          if(this.misReport.length == 0)
          this.message.create('error','No Data to Display');
          this.status = false;
          console.log(res);
        },
        err => {
          this.status = false;
          console.log(err);
        }
      );
    }
  }
}
