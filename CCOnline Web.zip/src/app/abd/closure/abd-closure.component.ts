import { Component, OnInit } from '@angular/core';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

@Component({
  selector: 'app-abd-closure',
  template: `<app-verification-closure [startUrl]="startUrl" [tabs]="tabs" [activeTab]="activeTab"></app-verification-closure>`,
})
export class AbdClosureComponent implements OnInit {
  startUrl = '/abd/compliance/';

  tabs: Tab[] = [
    {
      id: 1,
      title: 'CGM Visit',
      key: 'cgm-visit',
      assignable: false,
    },
  ];

  activeTab: Tab = {
    id: 1,
    title: 'CGM Visit',
    key: 'cgm-visit',
    assignable: false,
  };

  constructor() {}

  ngOnInit(): void {}
}
