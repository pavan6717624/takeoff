import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { STColumn, STComponent, STData } from '@delon/abc/st';
import { NGXLogger } from 'ngx-logger';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-compliance-verification',
  templateUrl: './compliance-verification.component.html',
})
export class ComplianceVerificationComponent implements OnInit {
  constructor(private router: Router, private log: NGXLogger) {}

  loading = false;

  columns: STColumn[] = [
    { title: 'Period', index: 'period' },
    { title: 'Branch Code', index: 'branchCode' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'Verification Officer', format: item => `${item.verificationOfficerName} (${item.verificationOfficerPfId})` },
    { title: 'Status', index: 'statusDescription' },
    { title: 'Action', buttons: [{ text: 'View', click: r => this.start(r) }] },
  ];

  selectedType = 'bi-monthly';

  tabs: Tab[] = [
    {
      id: 1,
      title: 'Bi-Monthly',
      key: 'bi-monthly',
      assignable: true,
    },
    {
      id: 2,
      title: 'Half-Yearly',
      key: 'half-yearly',
      assignable: true,
    },
  ];

  activeTab: Tab = { id: 1, key: 'bi-monthly', title: 'Bi-Monthly', assignable: true };

  onlyActionRequired = true;

  @ViewChild('st', { static: false }) private st: STComponent;

  ngOnInit(): void {}

  reqParams(): any {
    return { params: { onlyActionRequired: this.onlyActionRequired }, reName: { pi: 'page', ps: 'size' } };
  }

  dataUrl(): string {
    return `${environment.apiUrl}/verifications/compliance-verification/${this.activeTab.key}`;
  }

  start(data: STData): void {
    this.router.navigate(['/verification-officer/compliance/' + data.verificationId]);
  }

  tabChange(tab: Tab): void {
    this.log.trace('args: ', tab);
    this.activeTab = tab;
  }

  onChangeOnlyActionRequired(e): void {
    this.log.trace('event: ', e);
    this.st.reset(this.reqParams().params);
  }
}
