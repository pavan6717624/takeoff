import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { AssignedComponent } from './assigned/assigned.component';
import { SharedModule } from '../shared/shared.module';
import { SectionsComponent } from '../verification/sections/sections.component';
import { BranchProfileComponent } from '../verification/branch-profile/branch-profile.component';
import { BalanceVerificationComponent } from '../verification/balance-verification/balance-verification.component';
import { NotesVerificationComponent } from '../verification/notes-verification/notes-verification.component';
import { NotesAdjudicatedComponent } from '../verification/notes-adjudicated/notes-adjudicated.component';
import { ValueStatementsComponent } from '../verification/value-statements/value-statements.component';
import { VerificationModule } from '../verification/verification.module';
import { PreviewForSubmissionComponent } from '../verification/preview-for-submission/preview-for-submission.component';
import { ComplianceVerificationComponent } from './compliance-verification/compliance-verification.component';
import { SubmitResultComponent } from '../verification/submit-result/submit-result.component';
import { SectionsComplianceComponent } from '../compliance/sections/sections-compliance.component';

const routes: Routes = [
  { path: '', redirectTo: 'assigned', pathMatch: 'full' },
  { path: 'assigned', component: AssignedComponent },
  { path: 'verifications', component: AssignedComponent },
  {
    path: 'verification/:verificationId',
    component: SectionsComponent,
    data: { userRoutePrefix: 'verification-officer' },
  },
  { path: 'verification/:verificationId/branch-profile', component: BranchProfileComponent },
  { path: 'verification/:verificationId/balance-verification', component: BalanceVerificationComponent },
  { path: 'verification/:verificationId/notes-verification', component: NotesVerificationComponent },
  { path: 'verification/:verificationId/notes-adjudicated', component: NotesAdjudicatedComponent },
  { path: 'verification/:verificationId/value-statements/:sectionId', component: ValueStatementsComponent },
  {
    path: 'verification/:verificationId/preview',
    component: PreviewForSubmissionComponent,
    data: { userRoutePrefix: 'verification-officer' },
  },
  { path: 'verification/:verificationId/submitted', component: SubmitResultComponent, data: { userRoutePrefix: 'verification-officer' } },
  { path: 'compliance/verification', component: ComplianceVerificationComponent },
  { path: 'compliance/:verificationId', component: SectionsComplianceComponent, data: { isVerificationOfficer: true } },
];

@NgModule({
  declarations: [AssignedComponent, ComplianceVerificationComponent],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule, VerificationModule],
})
export class VerificationOfficerModule {}
