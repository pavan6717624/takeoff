import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NGXLogger } from 'ngx-logger';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { Verification } from 'src/app/shared/models/verification.model';
import { VerificationService } from 'src/app/verification/service/verification.service';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-assigned',
  templateUrl: './assigned.component.html',
})
export class AssignedComponent implements OnInit {
  dateFormat = DATE_FORMAT;
  url = `${environment.apiUrl}/verifications`;
  params = {};
  assignedVerifications: Verification[] = [];
  loading = false;

  //#region begin
  selectedType = 'bi-monthly';
  //#region end

  constructor(private route: ActivatedRoute, private verificationService: VerificationService, private log: NGXLogger) {}

  ngOnInit(): void {
    this.loading = true;
    this.getAssignedVerifications();
  }

  getAssignedVerifications(): void {
    this.verificationService.assignedVerifications(this.selectedType).subscribe(
      res => {
        this.assignedVerifications = res;
        this.loading = false;
      },
      () => (this.loading = false)
    );
  }

  onChangeOfType(): void {
    this.log.debug('selected type: ', this.selectedType);
    this.loading = true;
    this.getAssignedVerifications();
  }

  isSubmitted(status: any): boolean {
    return status && status !== 'IN_PROGRESS';
  }

  reportUrl(v: Verification): string {
    return `${environment.apiUrl}/verification/${v.id}/report`;
  }
}
