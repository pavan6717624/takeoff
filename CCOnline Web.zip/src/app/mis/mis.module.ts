import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { StatisticsComponent } from './verification/statistics.component';
import { SharedModule } from '../shared/shared.module';
import { RepeatedObservationsComponent } from './verification/repeated-observations.component';
import { ConsolidatedCircleWiseComponent } from './verification/consolidated-circle-wise.component';
import { ConsolidatedBranchWiseComponent } from './verification/consolidated-branch-wise.component';

const route: Routes = [
  { path: '', redirectTo: 'consolidated-branch-wise' },
  { path: 'consolidated-branch-wise', component: ConsolidatedBranchWiseComponent },
  { path: 'consolidated-circle-wise', component: ConsolidatedCircleWiseComponent },
  { path: 'statistics', component: StatisticsComponent },
  { path: 'repetition-observations', component: RepeatedObservationsComponent },
];

@NgModule({
  declarations: [StatisticsComponent, RepeatedObservationsComponent, ConsolidatedCircleWiseComponent, ConsolidatedBranchWiseComponent],
  imports: [CommonModule, RouterModule.forChild(route), SharedModule],
})
export class MisModule {}
