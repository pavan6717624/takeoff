import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { XlsxService } from '@delon/abc/xlsx';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { VerificationBlock, VerificationBlocks } from 'src/app/circle-admin/identify-vo/assign-vo-models';
import { IdentifyVoService } from 'src/app/circle-admin/identify-vo/identify-vo.service';
import { AuthService } from 'src/app/core/auth/auth.service';
import { Circle } from 'src/app/shared/models/circle.model';
import { environment } from 'src/environments/environment';
import { ConsolidatedCircleWise } from './model/consolidated-circle-wise.model';

@Component({
  selector: 'app-consolidated-circle-wise',
  templateUrl: './consolidated-circle-wise.component.html',
  styles: [
    `
      .ant-advanced-search-form {
        padding: 24px;
        background: #fbfbfb;
        border: 1px solid #d9d9d9;
        border-radius: 6px;
      }

      [nz-form-label] {
        overflow: visible;
      }

      button {
        margin-left: 8px;
      }

      .collapse {
        margin-left: 8px;
        font-size: 12px;
      }

      .search-area {
        /* text-align: right; */
      }
    `,
  ],
})
export class ConsolidatedCircleWiseComponent implements OnInit, OnDestroy {
  form: FormGroup;
  loading = false;
  submitting = false;

  types = [
    { id: 1, key: 'bi-monthly', name: 'Bi-Monthly' },
    { id: 2, key: 'quarterly', name: 'Quarterly' },
    { id: 3, key: 'half-yearly', name: 'Half Yearly' },
    { id: 4, key: 'security-officer', name: 'Security Officer' },
    { id: 5, key: 'dgm-cfo', name: 'DGM & CFO' },
    { id: 6, key: 'dgm-cfo-visit', name: 'DGM CFO Visit (New)' },
    { id: 7, key: 'rm-dgm-controller-visit', name: 'Controller Visit (RM/DGM)' },
    { id: 8, key: 'dgm-bo-module-head-visit', name: 'Module Head Visit (DGM (B&O))' },
    { id: 9, key: 'gm-network-visit', name: 'GM Network Visit' },
    { id: 10, key: 'cgm-visit', name: 'CGM Visit' },
  ];

  displayData = false;

  periods: VerificationBlock[];
  selectedPeriod: VerificationBlock;

  typeChangeSub: Subscription;
  periodChangeSub: Subscription;

  summaryData: ConsolidatedCircleWise;

  constructor(
    private log: NGXLogger,
    private fb: FormBuilder,
    private authService: AuthService,
    private http: HttpClient,
    private voService: IdentifyVoService,
    private xlsx: XlsxService
  ) {}

  ngOnInit(): void {
    this.log.trace('>> ngOnInit()');

    this.loading = true;

    const formGroup: FormGroup = new FormGroup({});

    formGroup.addControl('type', new FormControl('', [Validators.required]));
    formGroup.addControl('period', new FormControl({ value: '', disabled: true }, [Validators.required]));

    this.form = formGroup;

    this.typeChangeSub = this.form.get('type').valueChanges.subscribe(t => {
      this.onTypeChange(t);
    });

    this.periodChangeSub = this.form.get('period').valueChanges.subscribe(p => {
      this.onPeriodChange(p);
    });

    this.loading = false;
  }

  onTypeChange(e): void {
    this.log.trace('>> onTypeChange()', e);

    this.form.get('period').setValue('');

    if (e) {
      this.loading = true;

      // load periods
      this.http.get<VerificationBlocks>(`${environment.apiUrl}/verification/blocks/${e}/past`).subscribe(
        res => {
          this.periods = res.blocks;
          this.form.get('period').enable();
          this.loading = false;
        },
        () => {
          this.loading = false;
        }
      );
    } else {
      this.form.get('period').disable();
    }
  }

  onPeriodChange(p): void {
    this.log.trace('>> onPeriodChange()', p);

    if (p) {
      this.periods.forEach(value => {
        if (value.id === p) {
          this.selectedPeriod = value;
          this.log.trace('selectedPeriod', this.selectedPeriod);
        }
      });
    }
  }

  submit(): void {
    this.submitting = true;

    var params = new HttpParams();
    params = params.append('type', this.form.get('type').value);
    params = params.append('blockFrom', String(this.selectedPeriod.blockFrom));
    params = params.append('blockTo', String(this.selectedPeriod.blockTo));

    this.log.trace('params', params);
    this.http
      .get<ConsolidatedCircleWise>(`${environment.apiUrl}/mis/verification/vs-consolidated/circle-wise`, { params: params })
      .subscribe(
        res => {
          console.log(res);

          this.summaryData = res;

          this.displayData = true;
          this.submitting = false;
        },
        () => {
          this.submitting = false;
        }
      );
  }

  download(): void {
    this.log.trace('>> download()');

    const data = [];

    var row = [];
    row.push('Section');
    row.push('#');
    row.push('Description');

    this.summaryData.circles.forEach(element => row.push(element.circleName));

    data.push(row);

    this.summaryData.data.forEach(r => {
      row = [];

      row.push(r.vs.section.displayNo);
      row.push(r.vs.displayNumber);
      row.push(r.vs.description);

      r.notCompliedCounts.forEach(c => {
        row.push(r.vs.isOnlyAsHeader ? '' : c);
      });

      data.push(row);
    });

    const type = this.form.get('type') && this.form.get('type').value;

    this.xlsx.export({
      sheets: [{ data, name: 'Sheet1' }],
      filename: `vs-consolidated-circle-wise_${type}.xlsx`,
    });
  }

  ngOnDestroy(): void {
    if (this.typeChangeSub) {
      this.typeChangeSub.unsubscribe();
    }
  }
}
