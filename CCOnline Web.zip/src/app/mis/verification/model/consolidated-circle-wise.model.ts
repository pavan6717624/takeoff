import { Circle } from "src/app/shared/models/circle.model";
import { ValueStatement } from "src/app/verification/model/value-statement";

export interface Datum {
    vs: ValueStatement;
    notCompliedCounts: number[];
}

export interface ConsolidatedCircleWise {
    circles: Circle[];
    data: Datum[];
}
