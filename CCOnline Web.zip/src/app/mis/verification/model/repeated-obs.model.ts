export interface RepeatedObservations {
  vsId: number;
  sectionId: number;
  isOnlyAsHeader: number;
  sectionDisplayNo: string;
  repeatingBranches?: any;
  sectionName: string;
  vsIndentLevel: number;
  vsDisplayOrder: number;
  vsDisplayNo: string;
  vsInputType: string;
  vsDescription: string;
}
