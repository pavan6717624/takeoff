export interface ParamWisePending {
  description: string;
  inputType: string;
  valueStatement?: any;
  vsId: number;
  sectionId: number;
  displayNumber: string;
  isOnlyAsHeader: boolean;
  displayOrder: number;
  indentLevel: number;
  sectionDisplayNo: string;
  sectionDisplayOrder: number;
  pendingBranches: number;
}
