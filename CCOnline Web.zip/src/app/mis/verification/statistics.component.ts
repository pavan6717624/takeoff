import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { VerificationBlock, VerificationBlocks } from 'src/app/circle-admin/identify-vo/assign-vo-models';
import { IdentifyVoService } from 'src/app/circle-admin/identify-vo/identify-vo.service';
import { AuthService } from 'src/app/core/auth/auth.service';
import { Role } from 'src/app/shared/constants/role.constants';
import { Circle } from 'src/app/shared/models/circle.model';
import { Module } from 'src/app/shared/models/module.model';
import { Network } from 'src/app/shared/models/network.model';
import { Region } from 'src/app/shared/models/region.model';
import { environment } from 'src/environments/environment';
import { ClosureStatistics } from './model/closure-statistics.model';
import { ParamWisePending } from './model/param-wise-pending.mode';

@Component({
  selector: 'app-statistics',
  templateUrl: './statistics.component.html',
  styles: [
    `
      .ant-advanced-search-form {
        padding: 12px 24px 0px 24px;
        background: #fbfbfb;
        border: 1px solid #d9d9d9;
        border-radius: 3px;
      }

      [nz-form-label] {
        overflow: visible;
      }

      .collapse {
        margin-left: 8px;
        font-size: 12px;
      }
    `,
  ],
})
export class StatisticsComponent implements OnInit, OnDestroy {
  form = this.fb.group({
    type: ['', [Validators.required]],
    period: [{ value: '', disabled: true }, [Validators.required]],
    circle: [{ value: '', disabled: true }],
    network: [{ value: '', disabled: true }],
    module: [{ value: '', disabled: true }],
    region: [{ value: '', disabled: true }],
    reportType: ['', [Validators.required]],
  });

  loading = false;
  submitting = false;

  types = [
    { id: 1, key: 'bi-monthly', name: 'Bi-Monthly' },
    { id: 2, key: 'quarterly', name: 'Quarterly' },
    { id: 3, key: 'half-yearly', name: 'Half Yearly' },
    { id: 4, key: 'security-officer', name: 'Security Officer' },
    { id: 5, key: 'dgm-cfo', name: 'DGM & CFO' },
    { id: 6, key: 'dgm-cfo-visit', name: 'DGM CFO Visit (New)' },
    { id: 7, key: 'rm-dgm-controller-visit', name: 'Controller Visit (RM/DGM)' },
    { id: 8, key: 'dgm-bo-module-head-visit', name: 'Module Head Visit (DGM (B&O))' },
    { id: 9, key: 'gm-network-visit', name: 'GM Network Visit' },
    { id: 10, key: 'cgm-visit', name: 'CGM Visit' },
  ];

  displayCircleFilter = false;
  displayNetworkFilter = false;
  displayModuleFilter = false;
  displayRegionFilter = false;

  displayStats = false;
  displayParamWise = false;

  periods: VerificationBlock[];
  selectedPeriod: VerificationBlock;

  circles: Circle[];
  networks: Network[];
  modules: Module[];
  regions: Region[];

  typeChangeSub: Subscription;
  periodChangeSub: Subscription;
  circleChangeSub: Subscription;
  networkChangeSub: Subscription;
  moduleChangeSub: Subscription;
  regionChangeSub: Subscription;

  statsData: ClosureStatistics[];
  paramWiseData: ParamWisePending[];

  constructor(
    private log: NGXLogger,
    private fb: FormBuilder,
    private authService: AuthService,
    private http: HttpClient,
    private voService: IdentifyVoService
  ) {}

  ngOnInit(): void {
    this.log.trace('>> ngOnInit()');

    this.loading = true;

    this.authService.getPrincipal().subscribe(
      principal => {
        if (this.authService.hasAnyRolesDirect([Role.ABD_USER])) {
          this.displayCircleFilter = true;
          this.displayNetworkFilter = true;
          this.displayModuleFilter = true;
          this.displayRegionFilter = true;
        }

        if (this.authService.hasAnyRolesDirect([Role.CIRCLE_ADMIN])) {
          this.form.removeControl('circle');

          this.displayNetworkFilter = true;
          this.displayModuleFilter = true;
          this.displayRegionFilter = true;
        }

        if (this.authService.hasAnyRolesDirect([Role.AGM_GB, Role.AO_OFFICER])) {
          this.displayRegionFilter = true;

          this.form.removeControl('circle');
          this.form.removeControl('network');
          this.form.removeControl('module');
        }

        this.typeChangeSub = this.form.get('type').valueChanges.subscribe(t => {
          this.onTypeChange(t);
        });

        this.periodChangeSub = this.form.get('period').valueChanges.subscribe(p => {
          this.onPeriodChange(p);
        });

        if (this.displayCircleFilter) {
          this.circleChangeSub = this.form.get('circle').valueChanges.subscribe(c => {
            this.onCircleChange(c);
          });
        }

        if (this.displayNetworkFilter) {
          this.networkChangeSub = this.form.get('network').valueChanges.subscribe(n => {
            this.onNetworkChange(n);
          });
        }

        if (this.displayModuleFilter) {
          this.moduleChangeSub = this.form.get('module').valueChanges.subscribe(m => {
            this.onModuleChange(m);
          });
        }

        this.loading = false;
      },
      () => (this.loading = false)
    );
  }

  onTypeChange(e): void {
    this.log.trace('>> onTypeChange()', e);

    this.form.get('period').setValue('');

    if (e) {
      this.loading = true;

      // load periods
      this.http.get<VerificationBlocks>(`${environment.apiUrl}/verification/blocks/${e}/past`).subscribe(
        res => {
          this.periods = res.blocks;
          this.form.get('period').enable();
          this.loading = false;
        },
        () => {
          this.loading = false;
        }
      );
    } else {
      this.form.get('period').disable();
    }
  }

  onPeriodChange(p): void {
    this.log.trace('>> onPeriodChange()', p);

    if (p) {
      this.periods.forEach(value => {
        if (value.id === p) {
          this.selectedPeriod = value;
          this.log.trace('selectedPeriod', this.selectedPeriod);
        }
      });

      if (this.displayCircleFilter) {
        // load circles
        this.voService.circles(this.form.get('type').value, this.selectedPeriod).subscribe(circles => {
          this.circles = circles;
          this.form.get('circle').enable();
        });
      } else {
        this.onCircleChange();
      }
    }
  }

  onCircleChange(c?): void {
    this.log.trace('>> onCircleChange()', c);

    if ((c || !this.displayCircleFilter) && this.displayNetworkFilter) {
      // load networks
      var circle = this.form.get('circle') ? this.form.get('circle').value : null;
      this.voService.networks(this.form.get('type').value, this.selectedPeriod, circle).subscribe(networks => {
        this.networks = networks;
        this.form.get('network').enable();
      });
    } else {
      this.onNetworkChange();
    }
  }

  onNetworkChange(n?): void {
    this.log.trace('>> onNetworkChange()', n);

    if ((n || !this.displayNetworkFilter) && this.displayModuleFilter) {
      // load modules
      var circle = this.form.get('circle') ? this.form.get('circle').value : null;
      var network = this.form.get('network') ? this.form.get('network').value : null;
      this.voService.modules(this.form.get('type').value, this.selectedPeriod, network, circle).subscribe(modules => {
        this.modules = modules;
        this.form.get('module').enable();
      });
    } else {
      this.onModuleChange();
    }
  }

  onModuleChange(m?): void {
    this.log.trace('>> onModuleChange()', m);

    if ((m || !this.displayModuleFilter) && this.displayRegionFilter) {
      var circle = this.form.get('circle') ? this.form.get('circle').value : null;
      var network = this.form.get('network') ? this.form.get('network').value : null;
      var module = this.form.get('module') ? this.form.get('module').value : null;

      this.voService.regions(this.form.get('type').value, this.selectedPeriod, module, network, circle).subscribe(regions => {
        this.regions = regions;
        this.form.get('region').enable();
      });
    }
  }

  submit(): void {
    this.submitting = true;

    const reportType = this.form.get('reportType').value;

    var params = new HttpParams();
    params = params.append('type', this.form.get('type').value);
    params = params.append('blockFrom', String(this.selectedPeriod.blockFrom));
    params = params.append('blockTo', String(this.selectedPeriod.blockTo));

    if (this.form.get('circle') && this.form.get('circle').value) {
      params = params.append('circle', this.form.get('circle').value);
    }

    if (this.form.get('network') && this.form.get('network').value) {
      params = params.append('network', this.form.get('network').value);
    }

    if (this.form.get('module') && this.form.get('module').value) {
      params = params.append('module', this.form.get('module').value);
    }

    if (this.form.get('region') && this.form.get('region').value) {
      params = params.append('region', this.form.get('region').value);
    }

    this.log.trace('params', params);

    if (reportType === 'STATS') {
      this.http
        .get<ClosureStatistics[]>(`${environment.apiUrl}/mis/verification/vs-closure-statistics`, { params: params })
        .subscribe(stats => {
          console.log(stats);
          this.statsData = stats;

          this.displayParamWise = false;
          this.displayStats = true;

          this.submitting = false;
        });
    } else if (reportType === 'PARAM_WISE') {
      console.log('params', params);
      this.http
        .get<ParamWisePending[]>(`${environment.apiUrl}/mis/verification/vs-param-wise-pending`, { params: params })
        .subscribe(pw => {
          this.log.trace('pw:', pw);
          this.paramWiseData = pw;

          this.displayParamWise = true;
          this.displayStats = false;

          this.submitting = false;
        });
    } else {
      console.log('invalid report type');
    }
  }

  ngOnDestroy(): void {
    if (this.typeChangeSub) {
      this.typeChangeSub.unsubscribe();
    }
  }
}
