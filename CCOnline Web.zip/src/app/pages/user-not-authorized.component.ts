import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-not-authorized',
  template: `<exception type="403" style="min-height: 500px; height: 80%;"></exception>`,
})
export class UserNotAuthorizedComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
