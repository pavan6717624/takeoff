import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExceptionModule } from '@delon/abc/exception';

import { PageNotFoundComponent } from './page-not-found.component';
import { UserNotAuthorizedComponent } from './user-not-authorized.component';
import { ServerErrorComponent } from './server-error.component';
import { RouterModule, Routes } from '@angular/router';

const DELON_MODULES = [ExceptionModule];

const routes: Routes = [
  { path: 'page-not-found', component: PageNotFoundComponent },
  { path: 'user-not-authorized', component: UserNotAuthorizedComponent },
  { path: 'server-error', component: ServerErrorComponent },
];

@NgModule({
  declarations: [PageNotFoundComponent, UserNotAuthorizedComponent, ServerErrorComponent],
  imports: [CommonModule, RouterModule.forChild(routes), ...DELON_MODULES],
})
export class PagesModule {}
