import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-server-error',
  template: `<exception type="500" style="min-height: 500px; height: 80%;"></exception>`,
})
export class ServerErrorComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
