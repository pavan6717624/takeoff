import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { Network } from 'src/app/branch/cc-profile/model/cc-profile-checker.model';
import { AuthService } from 'src/app/core/auth/auth.service';
import { User } from 'src/app/core/auth/user';
import { UserRole } from 'src/app/core/auth/user-role';
import { PF_ID_VALIDATOR } from 'src/app/core/constants/validation.constants';
import { Branch } from 'src/app/core/interface/branch';
import { Role } from 'src/app/shared/constants/role.constants';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
})
export class UserEditComponent implements OnInit, OnDestroy {
  loading = false;
  submitting = false;
  isFetchingUserDetails = false;
  fetchedUserDetails = false;
  loadingRoles = false;
  loadingFslos = false;
  isGm=false;

  role : UserRole;
  netcode : number = -1;
  loadingNetworks = false;

  private sub: Subscription;
  private pfIdSub: Subscription;

  fsloRoleId: number;
  user: User;
  roles: UserRole[];
  fslos: Branch[] = [];
  networks: Number[];

  form: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private msg: NzMessageService,
    private userService: UserService,
    private log: NGXLogger,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      pfId: ['', PF_ID_VALIDATOR],
      roles: [[], [Validators.required]],
      fslo: [{ value: '', disabled: true }],
      network: -1
    });

    this.sub = this.route.params.subscribe(params => {
      const id = +params['id'];
      this.log.trace('id from route', id);
      this.load(id);
    });
  
    
  }

getNetworks()
{

  var formData = new FormData();
  formData.set('brcode',this.user.branchCode+"");
  this.loadingNetworks=true;
  this.userService.getNetworksByBranchCode(formData).subscribe(
    res => {
    
      this.networks = res;
      console.log(this.networks);
      this.loadingNetworks=false;
    });

}
onchange()
{
let selectedRoles = this.form.get('roles').value;
if(selectedRoles[0] === 'GM_NETWORK')
{
  this.isGm = true;
  this.getNetworks();
}
else
this.isGm=false;

console.log(this.isGm+" ASDFASDF ");
}

  load(id: any) {
    if (!Number.isNaN(id)) {
      this.fetchUserDetails(id);
      this.form.patchValue({ pfId: id });

      this.log.trace('approved: ', this.user?.approved);
    }

    this.onRoleChanges();
    this.onPfIdChanges();
  }

  fetchUserDetails(pfId: number): void {
    this.isFetchingUserDetails = true;

    this.userService.get(pfId).subscribe(
      res => {
        this.user = res;
      
        this.userService.roles().subscribe(
          data => {
            this.roles = data;
            this.isFetchingUserDetails = false;
            this.fetchedUserDetails = true;
            this.roles.forEach(item => {
              if (item.name === Role.FSLO_USER) {
                this.fsloRoleId = item.id;
              }
            });

            // patch values
            let selectedRoles = [];
            let selectedFslo = '';
            var selectedGm: number;

            this.user.roles.forEach(role => {
              selectedRoles.push(role.name);
              if (role.name === 'FSLO_USER') {
                selectedFslo = String(this.user.branchCode);
              }
              if (role.name === 'GM_NETWORK') {
                selectedGm = this.user.networkCode;
              }
            });

            this.form.patchValue({ roles: selectedRoles, fslo: selectedFslo, network: selectedGm });
          },
          rolesError => {
            this.isFetchingUserDetails = false;
            this.fetchedUserDetails = true;
            this.msg.error(rolesError?.error?.detail ? rolesError.error.detail : 'An error occured. Please try after sometime.');
          }
        );

        this.isFetchingUserDetails = false;
        this.fetchedUserDetails = true;
      },
      error => {
        this.msg.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.');
        this.isFetchingUserDetails = false;
      }
    );
  }

  onRoleChanges(): void {


    this.form.get('roles').valueChanges.subscribe(val => {
      let contains = false;
      if (this.fetchedUserDetails) {
        val.forEach(role => {
          if (role === 'FSLO_USER') {
            contains = true;
          }
        });
      }
      const fsloControl = this.form.get('fslo');
      if (contains) {
        this.loadingFslos = true;
        this.userService.fslos().subscribe(
          data => {
            this.fslos = data;
            fsloControl.enable();
            fsloControl.setValidators([Validators.required]);
            this.loadingFslos = false;
            fsloControl.updateValueAndValidity();
          },
          error => {
            this.loadingFslos = false;
            this.msg.error('Error while loading FSLOs list');
          }
        );
      } else {
        fsloControl.disable();
        fsloControl.setValidators([]);
      }
    });
  }

  displayFslos(): boolean {
    this.form.value.roles.forEach(role => {
      if (role === this.fsloRoleId) {
        return true;
      }
    });
    return false;
  }

  submit(): void {
    if (this.form.valid) {
      this.submitting = true;

      if (this.isEdit()) {
        this.userService.update(this.form.value).subscribe(
          user => {
            this.submitting = false;
            //this.msg.success('User information updated successfully!');
            this.msg.success('User Information Updated. Pending for Approval.!');
            this.router.navigate(['/users']);
          },
          () => {
            this.submitting = false;
            this.msg.error('Error while saving user information');
          }
        );
      } else {
        this.userService.create(this.form.value).subscribe(
          user => {
            this.submitting = false;
            this.msg.success('User Information Saved. Pending for Approval.!');
            this.router.navigate(['/users']);
          },
          () => {
            this.submitting = false;
            this.msg.error('Error while saving user information');
          }
        );
      }
    }
  }

  roleDisabled(role: any): boolean {
    if (this.form && this.form.get('roles')) {
      let selectedRoles = this.form.get('roles').value;

      if (selectedRoles && selectedRoles.length > 0) {
        if (selectedRoles.indexOf(role.name) !== -1) {
          return false;
        }

        let hasFsloRole = selectedRoles.indexOf('FSLO_USER') !== -1;
        let hasCircleAdminRole = selectedRoles.indexOf('CIRCLE_ADMIN') !== -1;

        if (hasFsloRole) {
          return role.name !== 'CIRCLE_ADMIN' || role.name === 'FSLO_USER';
        }
        if (hasCircleAdminRole) {
          return role.name !== 'FSLO_USER' || role.name === 'CIRCLE_ADMIN';
        }

        return selectedRoles.indexOf(role.name) === -1;
      }
    }

    return false;
  }

  onPfIdChanges(): void {
    this.pfIdSub = this.form.get('pfId').valueChanges.subscribe(() => {
      if (this.fetchedUserDetails) {
        this.fetchedUserDetails = false;
      }
    });
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }

    if (this.pfIdSub) {
      this.pfIdSub.unsubscribe();
    }
  }

  isEdit(): boolean {
    if (this.user?.approved && !this.user?.deleted) {
      return true;
    }
    return false;
  }
}
