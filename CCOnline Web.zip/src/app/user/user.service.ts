import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { User } from '../core/auth/user';
import { UserRole } from '../core/auth/user-role';
import { Branch } from '../core/interface/branch';
import { Page } from '../core/interface/page';
import { Network } from '../shared/models/network.model';
import { UserCriteria } from './user-criteria';

@Injectable({ providedIn: 'root' })
export class UserService {
  private resourceUrl = `${environment.apiUrl}/users`;

  constructor(private http: HttpClient, private log: NGXLogger) {}

  get(id: number): Observable<User> {
    return this.http.get<User>(`${this.resourceUrl}/${id}`);
  }

  create(data: any): Observable<User> {
    return this.http.post<User>(this.resourceUrl, data);
  }

  update(data: any): Observable<User> {
    return this.http.put<User>(this.resourceUrl, data);
  }

  enable(id: number): Observable<any> {
    return this.http.post(`${this.resourceUrl}/enable`, { id });
  }

  disable(id: number): Observable<any> {
    return this.http.post(`${this.resourceUrl}/disable`, { id });
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.resourceUrl}/${id}`);
  }

  approve(id: number): Observable<any> {
    return this.http.post(`${this.resourceUrl}/approve`, { id });
  }

  reject(id: number, remarks: string): Observable<any> {
    return this.http.post(`${this.resourceUrl}/reject`, { id, remarks });
  }

  query(criteria?: UserCriteria): Observable<Page<User>> {
    let params = new HttpParams();
    if (criteria) {
      params = params.append('page', String(criteria.page));
      params = params.append('size', String(criteria.size));

      // TODO: add sort, filter
      if (criteria.sort) {
        params = params.append('sort', criteria.sort);
      }

      if (criteria.userPfId) {
        params = params.append('userPfId', criteria.userPfId);
      }

      if (criteria.name) {
        params = params.append('name', criteria.name);
      }

      if (criteria.requestStatus) {
        params = params.append('requestStatus', criteria.requestStatus);
      }

      if (criteria.role) {
        params = params.append('role', criteria.role);
      }
    }

    this.log.trace('params: ', params.toString());
    return this.http.get<Page<User>>(this.resourceUrl, { params: params });
  }

  roles(): Observable<UserRole[]> {
    return this.http.get<UserRole[]>(`${environment.apiUrl}/roles/canAdd`);
  }

  fslos(): Observable<Branch[]> {
    return this.http.get<Branch[]>(`${environment.apiUrl}/fslos`);
  }

  getNetworksByBranchCode(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getNetworksByBranchCode`,formData);
  }
}
