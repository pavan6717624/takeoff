export interface UserCriteria {
  page: number;
  size: number;
  sort?: string;
  requestStatus?: string;
  userPfId?: string;
  name?: string;
  enabled?: boolean;
  activated?: boolean;
  role?: string;
}
