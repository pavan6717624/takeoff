import { NgModule } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserEditComponent } from './user-edit/user-edit.component';
import { SharedModule } from '../shared/shared.module';
import { UserRequestComponent } from './user-request/user-request.component';

const route: Routes = [
  {
    path: '',
    component: UserComponent,
    children: [
      { path: '', component: UserListComponent },
      { path: ':id', component: UserEditComponent },
    ],
  },
];

@NgModule({
  declarations: [UserComponent, UserListComponent, UserEditComponent, UserRequestComponent],
  imports: [CommonModule, RouterModule.forChild(route), SharedModule],
  providers: [TitleCasePipe],
})
export class UserModule {}
