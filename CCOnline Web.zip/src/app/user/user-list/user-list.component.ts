import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NGXLogger } from 'ngx-logger';
import { AuthService } from 'src/app/core/auth/auth.service';
import { User } from 'src/app/core/auth/user';
import { UserRole } from 'src/app/core/auth/user-role';
import { Page } from 'src/app/core/interface/page';
import { UserCriteria } from '../user-criteria';
import { UserRequestComponent } from '../user-request/user-request.component';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styles: [
    `
      .text-right {
        text-align: right !important;
      }
    `,
  ],
})
export class UserListComponent implements OnInit {
  loading = false;
  expandForm = false;

  loggedInUserId: number;

  q = <UserCriteria>{
    page: 1,
    size: 10,
  };
  sortMap: any = {};

  data = <Page<User>>{
    totalElements: 0,
    content: [],
  };

  roles: UserRole[];

  constructor(
    private userService: UserService,
    private message: NzMessageService,
    private modalService: NzModalService,
    private authService: AuthService,
    private log: NGXLogger,
    private titleCasePipe: TitleCasePipe
  ) {}

  ngOnInit(): void {
    this.authService.getPrincipal().subscribe(
      principal => {
        this.loggedInUserId = principal.id;
        this.log.debug('loggedInUserId: ', this.loggedInUserId);

        this.load();
      },
      () => {
        this.message.error('Error while getting logged in user details. Please logout and login again to continue.');
      }
    );
  }

  clear(): void {
    this.sortMap = {};
    this.q = <UserCriteria>{
      page: 1,
      size: this.q.size,
    };
    this.load();
  }

  load(): void {
    this.loading = true;

    const c = Object.assign({}, this.q);
    c.page = this.q.page - 1 < 0 ? 0 : this.q.page - 1;

    this.userService.query(c).subscribe(
      data => {
        this.loading = false;
        this.data = data;

        this.userService.roles().subscribe(data => {
          this.roles = data;
        });
      },
      error => {
        this.loading = false;
        this.message.error('Error loading data');
      }
    );
  }

  viewRequest(user: User): void {
    this.modalService.create({
      nzTitle: `${this.titleCasePipe.transform(user?.userRequest?.requestType)} Request`,
      nzContent: UserRequestComponent,
      nzComponentParams: {
        user: user,
        loggedInUserId: this.loggedInUserId,
      },
      nzWidth: 740,
      nzOnOk: () => {
        this.load();
      },
    });
  }

  disable(user: User): void {
    this.modalService.confirm({
      nzTitle: 'Do you want to?',
      nzContent: `Disable user ${user?.name} (${user?.id})`,
      nzOnOk: () => {
        this.userService.disable(user.id).subscribe(data => {
          this.load();
          this.message.success(`Disable request success for user ${user?.name} (${user?.id})`);
        });
      },
    });
  }

  enable(user: User): void {
    this.modalService.confirm({
      nzTitle: 'Do you want to?',
      nzContent: `Enable user ${user?.name} (${user?.id})`,
      nzOnOk: () => {
        this.userService.enable(user.id).subscribe(data => {
          this.load();
          this.message.success(`Enable request success for user ${user?.name} (${user?.id})`);
        });
      },
    });
  }

  delete(user: User): void {
    this.modalService.confirm({
      nzTitle: 'Do you want to?',
      nzContent: `Delete user ${user?.name} (${user?.id})`,
      nzOnOk: () => {
        this.userService.delete(user.id).subscribe(data => {
          this.load();
          this.message.success(`User ${user?.name} (${user?.id}) details deleted, pending for approval`);
        });
      },
    });
  }

  isRequestPending(u: User): boolean {
    if (u?.userRequest && u.userRequest?.id) {
      return u.userRequest?.requestStatus === 'PENDING';
    }
    return false;
  }

  isRequestRejected(u: User): boolean {
    if (u?.userRequest && u.userRequest?.id) {
      return u.userRequest?.requestStatus === 'REJECTED';
    }
    return false;
  }

  formatRoles(roles: UserRole[]): string {
    let roleDesc = [];
    roles.forEach(item => roleDesc.push(item.description));
    return roleDesc.join(', ');
  }

  canApproveOrReject(user: User): boolean {
    if (user && user.userRequest && this.loggedInUserId) {
      if (user.userRequest.requestStatus === 'REJECTED') {
        return false;
      }

      return user.userRequest.requestedBy !== this.loggedInUserId;
    }
    return false;
  }

  hasRequest(user: User): boolean {
    if (user && user.userRequest && user.userRequest.id) {
      return true;
    }
    return false;
  }

  enableDisableAction(user: User): boolean {
    if (user?.enabled) {
      if (this.isRequestPending(user)) {
        return false;
      }
      if (this.isRequestRejected(user)) {
        if (user?.userRequest?.requestType !== 'CREATE') {
          return true;
        }
        return false;
      }
      return true;
    } else {
      return false;
    }
  }

  enableEnableAction(user: User): boolean {
    if (this.isRequestPending(user)) {
      return false;
    }

    if (this.isRequestRejected(user)) {
      if (user?.userRequest?.requestType !== 'CREATE') {
        return false;
      }
    }

    if (user?.enabled) {
      return false;
    }

    return true;
    // if (user?.enabled) {
    //   return false;
    // } else {
    //   if (this.isRequestPending(user)) {
    //     return false;
    //   }

    //   if (this.isRequestRejected(user)) {
    //     if (user?.userRequest?.requestType !== 'CREATE') {
    //       return true;
    //     }
    //     return true;
    //   }
    // }
  }
}
