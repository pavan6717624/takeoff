import { TitleCasePipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { User } from 'src/app/core/auth/user';
import { UserRole } from 'src/app/core/auth/user-role';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-request',
  templateUrl: './user-request.component.html',
})
export class UserRequestComponent implements OnInit {
  @Input() user: User;
  @Input() loggedInUserId: number;
  form: FormGroup;

  constructor(
    private modal: NzModalRef,
    private fb: FormBuilder,
    private modalService: NzModalService,
    private message: NzMessageService,
    private userService: UserService,
    private titleCasePipe: TitleCasePipe
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      remarks: [
        { value: this.user?.userRequest?.requestMessage, disabled: !this.showActions() },
        [Validators.required, Validators.minLength(5), Validators.maxLength(100)],
      ],
    });
  }

  closeModal(): void {
    this.modal.destroy();
  }

  approve(user: User): void {
    this.modalService.confirm({
      nzTitle: 'Do you want to approve?',
      nzContent: `${this.titleCasePipe.transform(user?.userRequest.requestType)} user ${user?.name} (${user?.id})`,
      nzOnOk: () => {
        this.userService.approve(user.id).subscribe(data => {
          this.message.success('Approved successfully');
          this.modal.triggerOk();
          this.modal.close();
        });
      },
    });
  }

  reject(user: User): void {
    if (this.form.valid) {
      this.modalService.confirm({
        nzTitle: 'Do you want to reject?',
        nzContent: `${this.titleCasePipe.transform(user?.userRequest.requestType)} user ${user?.name} (${user?.id})`,
        nzOnOk: () => {
          this.userService.reject(user.id, this.form.value.remarks).subscribe(data => {
            this.message.success('Rejected successfully');
            this.modal.triggerOk();
            this.modal.close();
          });
        },
      });
    }
  }

  formatRoles(roles: UserRole[]): string {
    let roleDesc = [];
    roles.forEach(item => roleDesc.push(item.description));
    return roleDesc.join(', ');
  }

  hasFsloRole(roles: UserRole[]): boolean {
    if (roles.filter(r => r.name === 'FSLO_USER').length > 0) {
      return true;
    }
    return false;
  }

  showActions(): boolean {
    if (this.user && this.user.userRequest && this.loggedInUserId) {
      if (this.user.userRequest.requestStatus === 'REJECTED' || this.user.userRequest.requestStatus === 'APPROVED') {
        return false;
      }
      return this.user.userRequest.requestedBy !== this.loggedInUserId;
    }
    return false;
  }
}
