import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { STColumn, STComponent, STData, STPage, STRes } from '@delon/abc/st';
import { NGXLogger } from 'ngx-logger';

import { VerificationBlock, VerificationBlocks } from 'src/app/circle-admin/identify-vo/assign-vo-models';
import { IdentifyVoService } from 'src/app/circle-admin/identify-vo/identify-vo.service';
import { VerificationUtilService } from 'src/app/verification/service/verification-util.service';
import { VerificationService } from 'src/app/verification/service/verification.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-quarterly-verification',
  templateUrl: './quarterly-verification.component.html',
})
export class QuarterlyVerificationComponent implements OnInit {
  loading = false;

  verificationType = 'quarterly';

  verificationBlocks: VerificationBlocks;
  selectedBlock: VerificationBlock;

  responseMapping: STRes = { reName: { list: 'content', total: 'totalElements' } };
  pagerConfig: STPage = { zeroIndexed: true, showSize: true, pageSizes: [10, 20, 30, 40, 50, 100, 200] };

  columns: STColumn[] = [
    { title: 'Branch Code', index: 'branchCode', className: 'text-right' },
    { title: 'Branch Name', index: 'branchName' },
    {
      title: '',
      buttons: [
        { text: 'Start Verification', iif: r => !r.verification, click: record => this.startVerification(record) },
        {
          text: 'Continue Verification',
          iif: r => this.verificationUtilService.isContinueVerification(r),
          click: record => this.continueVerification(record),
        },
        {
          text: 'Verification Report',
          iif: r => this.isVerificationFinished(r),
          click: r => this.verificationUtilService.downloadReport(r.verification.id),
        },
      ],
    },
  ];

  @ViewChild('st', { static: false }) private st: STComponent;

  constructor(
    private router: Router,
    private assignVoService: IdentifyVoService,
    private verificationService: VerificationService,
    private verificationUtilService: VerificationUtilService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    this.loadBlocks();
  }

  dataUrl(): string {
    if (this.selectedBlock && this.selectedBlock.blockFrom && this.selectedBlock.blockTo) {
      return `${environment.apiUrl}/verifications/${this.verificationType}`;
    }
    return '';
  }

  requestParams(): any {
    if (this.selectedBlock) {
      return { blockFrom: this.selectedBlock.blockFrom, blockTo: this.selectedBlock.blockTo };
    }
  }

  loadBlocks(): void {
    this.assignVoService.getVerificationBlocks(this.verificationType).subscribe(res => {
      this.verificationBlocks = res;
      if (this.verificationBlocks && this.verificationBlocks.blocks) {
        this.selectedBlock = this.verificationBlocks.blocks[0];
      }
      this.loading = false;
    });
  }

  changeBlock(e: any): void {
    this.verificationBlocks.blocks.forEach(blk => {
      if (blk.id === e) {
        this.selectedBlock = blk;
        this.st.reset(this.requestParams());
      }
    });
  }

  startVerification(branch: any): void {
    this.verificationService.startVerification(branch.branchCode, this.selectedBlock.id).subscribe(res => {
      this.router.navigate(['/controller/verification/' + res.id]);
    });
  }

  continueVerification(branch: STData): void {
    this.router.navigate(['/controller/verification/' + branch.verification.id]);
  }

  isContinueVerification(data: STData): boolean {
    if (data.verification) {
      if (data.verification.status) {
        return data.verification.status === 'IN_PROGRESS';
      }
      return true;
    }
    return false;
  }

  isVerificationFinished(data: STData): boolean {
    return this.verificationUtilService.isVerificationFinished(data);
  }
}
