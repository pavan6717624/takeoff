import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControllerVistRmComponent } from './controller-vist-rm.component';

describe('ControllerVistRmComponent', () => {
  let component: ControllerVistRmComponent;
  let fixture: ComponentFixture<ControllerVistRmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControllerVistRmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControllerVistRmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
