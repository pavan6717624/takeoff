import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { STColumn, STData } from '@delon/abc/st';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-scrutiny',
  templateUrl: './scrutiny.component.html',
})
export class ScrutinyComponent implements OnInit {
  loading = false;

  tabs: Tab[] = [
    {
      id: 1,
      title: 'Bi-Monthly',
      key: 'bi-monthly',
      assignable: true,
    },
    {
      id: 2,
      title: 'Quarterly',
      key: 'quarterly',
      assignable: false,
    },
    {
      id: 3,
      title: 'Half-Yearly',
      key: 'half-yearly',
      assignable: true,
    },
    {
      id: 4,
      title: 'DGM & CFO (Old)',
      key: 'dgm-cfo',
      assignable: false,
    },
    {
      id: 5,
      title: 'Security Officer',
      key: 'security-officer',
      assignable: false,
    },
    {
      id: 6,
      title: 'Controller (RM/DGM) Visit',
      key: 'rm-dgm-controller-visit',
      assignable: false,
    },
    {
      id: 7,
      title: 'DGM (B&O) Visit',
      key: 'dgm-bo-module-head-visit',
      assignable: false,
    },
    {
      id: 8,
      title: 'DGM CFO Visit (New)',
      key: 'dgm-cfo-visit',
      assignable: false,
    },
    {
      id: 9,
      title: 'GM Network Visit',
      key: 'gm-network-visit',
      assignable: false,
    },
    {
      id: 10,
      title: 'CGM Visit',
      key: 'cgm-visit',
      assignable: false,
    },

  ];

  activeTab: Tab = { id: 1, key: 'bi-monthly', title: 'Bi-Monthly', assignable: true };
  year: Date = new Date();
  cstatus:number=0;
  checked: boolean=true;
  heading: string=" - Pending";
  columns: STColumn[] = [
    { title: 'Type', index: 'type' },
    { title: 'Period', index: 'period' },
    { title: 'Circle Name', index: 'circleName' },
    { title: 'NW', index: 'networkCode' },
    { title: 'Module', index: 'moduleName' },
    { title: 'Reg', index: 'regionCode' },
    { title: 'Br. Code', index: 'branchCode', className: 'text-right' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'Status', index: 'status' },
    { title: '', buttons: [{ text: 'View', click: r => this.start(r) }] },
  ];

  constructor(private router: Router) {}

  ngOnInit(): void {

    if(this.checked)
    this.cstatus=0;

  }

  to(tab: Tab): void {
    //  this.loading = true;
      this.activeTab = tab;
      console.log(this.activeTab.id);
     
    }
  
    dataUrl(): string {
     
      var id=this.activeTab.id;
      var year=0;
      var cstatus=this.cstatus;
      var pending=0;
  
      if(id==null || id==0)
      id=1;
      if(this.year == null)
      year=new Date().getFullYear();
      else
      {
        year =  this.year.getFullYear();
      }
      if(cstatus==null)
      cstatus=0;

      if(this.checked)
      pending=1;

      return `${environment.apiUrl}/verifications/scrutiny`+"/"+id+"/"+year+"/"+cstatus+"/"+pending;
    }


 // dataUrl(): string {
  //  return `${environment.apiUrl}/verifications/scrutiny`;
 // }

  start(data: STData): void {
    this.router.navigate(['/controller/compliance/' + data.id]);
  }

  displayPending(): void
  {
    if(this.checked)
    this.cstatus=0;
  }
  selectChange(): void
  {
    if(this.cstatus!=0)
    this.checked=false;
  }
}
