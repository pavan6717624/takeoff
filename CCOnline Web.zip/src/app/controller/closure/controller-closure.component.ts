import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

@Component({
  selector: 'app-controller-closure',
  template: `<app-verification-closure [startUrl]="startUrl" [tabs]="tabs" [activeTab]="activeTab"></app-verification-closure>`,
})
export class ControllerClosureComponent implements OnInit {
  startUrl = '/controller/compliance/';

  tabs: Tab[] = [
    {
      id: 1,
      title: 'Quarterly',
      key: 'quarterly',
      assignable: false,
    },
  ];

  activeTab: Tab = {
    id: 1,
    title: 'Quarterly',
    key: 'quarterly',
    assignable: false,
  };

  constructor(private router: Router) {}

  ngOnInit(): void {}
}
