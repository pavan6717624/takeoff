import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/app/core/services/alert.service';
import { CcProfileService } from '../cc-profile.service';
import { CcProfile } from '../model/cc-profile.model';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { Router } from '@angular/router';
import { NGXLogger } from 'ngx-logger'
import { EmployeeDetailsService } from 'src/app/core/services/employee-details.service';
import { EmployeeDetails } from 'src/app/shared/models/employee-details.model';
import { EMAIL_REGEX, MOBILE_NO_PATTERN, PF_ID_PATTERN } from 'src/app/core/constants/validation.constants';


interface CenterType {
  id: string;
  description: string;
}
interface BranchType {
  id: string;
  description: string;
}
interface coinVendingMachineAvailable {
  id: boolean;
  description: string;
}
interface chestClass {
  id: string;
  description: string;
}

@Component({
  selector: 'app-cc-profile-edit',
  templateUrl: './cc-profile-edit.component.html',
  styleUrls: ['./cc-profile-edit.component.less'],
})
export class CcProfileEditComponent implements OnInit {

  fetchedUserDetails = false;
  isFetchingUserDetails = false;

  fetchedCoDetails = false;
  isFetchingCoDetails = false;

  fetchedBmDetails = false;
  isFetchingBmDetails = false;

  fetchedCmCRDetails = false;
  isFetchingCmCRDetails = false;

  fetchedRmDetails = false;
  isFetchingRmDetails = false;

  fetchedFsloAgmDetails = false;
  isFetchingFsloAgmDetails = false;

  fetchedFsloOffDetails = false;
  isFetchingFsloOffDetails = false;

  employeeDetails: EmployeeDetails;
  employeeCoDetails: EmployeeDetails;
  employeeBmDetails: EmployeeDetails;

  employeeCmCRDetails: EmployeeDetails;
  employeeRmDetails: EmployeeDetails;

  employeeFsloAgmDetails: EmployeeDetails;
  employeeFsloOffDetails: EmployeeDetails;

  centerTypes: CenterType[] = [
    { id: 'DIST_HQ', description: 'District HQ' },
    { id: 'SUB_DIV_HQ', description: 'Sub Div HQ' },
  ];

  branchTypes: BranchType[] = [
    { id: 'RECEIPTS', description: 'Receipts' },
    { id: 'PAYMENTS', description: 'Payments' },
  ];

  // coinVendingMachineAvailableAvl: coinVendingMachineAvailable[] = [
  //   { id: 1, description: 'Yes' },
  //   { id: 0, description: 'No' },
  // ];

  coinVendingMachineAvailableAvl: coinVendingMachineAvailable[] = [
    { id: true, description: 'Yes' },
    { id: false, description: 'No' },
  ];

  ccCategories: chestClass[] = [
    { id: 'A', description: 'A' },
    { id: 'B', description: 'B' },
    { id: 'C', description: 'C' },
  ];

  constructor(
    private ccProfileService: CcProfileService,
    private fb: FormBuilder,
    private alertService: AlertService,
    private notification: NzNotificationService,
    private router: Router,    
    private empDetailsService: EmployeeDetailsService,    
    private log: NGXLogger,
  ) {
    console.log('constructed');
  }
  ccProfile: CcProfile = new CcProfile();
  branchDetailsForm: FormGroup;
  dateFormat = DATE_FORMAT;

  today = new Date();

  disabledDate = (current: Date): boolean => {
    return differenceInCalendarDays(current, this.today) > 0;
  };

  get centerName() {
    return this.branchDetailsForm.get('centerName');
  }
  // get ccCode() {
  //   return this.branchDetailsForm.get('ccCode');
  // }
  get policeStation() {
    return this.branchDetailsForm.get('policeStation');
  }
  get strongRoomSize() {
    return this.branchDetailsForm.get('strongRoomSize');
  }
  get cashProcessingArea() {
    return this.branchDetailsForm.get('cashProcessingArea');
  }
  get cashBalanceLimit() {
    return this.branchDetailsForm.get('cashBalanceLimit');
  }
  get capacityToStoreCashInBundles() {
    return this.branchDetailsForm.get('capacityToStoreCashInBundles');
  }
  get totalStaff() {
    return this.branchDetailsForm.get('totalStaff');
  }
  get cashDeptStaff() {
    return this.branchDetailsForm.get('cashDeptStaff');
  }
  get accountantDateOfTakingOver() {
    return this.branchDetailsForm.get('accountantDateOfTakingOver');
  }
  get accountantMobileNo() {
    return this.branchDetailsForm.get('accountantMobileNo');
  }
  get coDateOfTakingOver() {
    return this.branchDetailsForm.get('coDateOfTakingOver');
  }
  get coMobileNo() {
    return this.branchDetailsForm.get('coMobileNo');
  }
  get noOfGuardsPosted() {
    return this.branchDetailsForm.get('noOfGuardsPosted');
  }
  get linked_branch_code() {
    return this.branchDetailsForm.get('linked_branch_code');
  }
  get noOfOtherBankBranchesLinked() {
    return this.branchDetailsForm.get('noOfOtherBankBranchesLinked');
  }
  get noOfBinsAvailable() {
    return this.branchDetailsForm.get('noOfBinsAvailable');
  }
  get noOfCCsMappedinCBS() {
    return this.branchDetailsForm.get('noOfCCsMappedinCBS');
  }
  get holdingCapacityOfBins() {
    return this.branchDetailsForm.get('holdingCapacityOfBins');
  }
  get cmCrName() {
    return this.branchDetailsForm.get('cmCrName');
  }
  get cmCrMobileNo() {
    return this.branchDetailsForm.get('cmCrMobileNo');
  }
  get noOf4plus1TypeNSM() {
    return this.branchDetailsForm.get('noOf4plus1TypeNSM');
  }
  get noOf3plus1TypeNSM() {
    return this.branchDetailsForm.get('noOf3plus1TypeNSM');
  }
  get noOf2plus1TypeNSM() {
    return this.branchDetailsForm.get('noOf2plus1TypeNSM');
  }
  get noOf1plus1TypeNSM() {
    return this.branchDetailsForm.get('noOf1plus1TypeNSM');
  }
  ngOnInit(): void {
    console.log('intialized');

    // 1. get data from server (data model)
    // 2. populate form group
    // 3. bind data to form group (optional)
    // 4. get values from form group
    // 5. validate/save
    // 6. further process

    this.branchDetailsForm = this.fb.group({
      centerName: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      centerType: ['', [Validators.required]],
      ccCode: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.maxLength(5)]],
      policeStation: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      dateOfOpening: ['', [Validators.required]],
      branchType: ['', [Validators.required]],
      validityDateofStrongRoomFitnessCertificate: ['', [Validators.required]],
      strongRoomSize: ['', [Validators.required, Validators.pattern('^[0-9.]{1,20}$')]],
      cashProcessingArea: ['', [Validators.required, Validators.pattern('^[0-9.]{1,20}$')]],
      chestClass: ['', [Validators.required]],
      cashBalanceLimit: ['', [Validators.required, Validators.pattern('^[0-9.]{1,20}$')]],
      capacityToStoreCashInBundles: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      totalStaff: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.maxLength(3)]],
      cashDeptStaff: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.maxLength(3)]],
      accountantId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      accountantName: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      accountantDateOfTakingOver: ['', [Validators.required]],
      accountantMobileNo: ['', [Validators.required,Validators.pattern(MOBILE_NO_PATTERN)]],
      coId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      coName: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      coDateOfTakingOver: ['', [Validators.required]],
      coMobileNo: ['', [Validators.required, Validators.pattern(MOBILE_NO_PATTERN)]],
      bmId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      bmName: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      bmMobileNo: ['', [Validators.required, Validators.pattern(MOBILE_NO_PATTERN)]],
      noOfGuardsPosted: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.maxLength(2)]],
      linked_branch_code: ['', [Validators.required, Validators.pattern('^[0-9 ,]*$')]],
      noOfOtherBankBranchesLinked: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.maxLength(3)]],
      noOfBinsAvailable: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      noOfCCsMappedinCBS: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      holdingCapacityOfBins: ['', [Validators.required, Validators.pattern('^[0-9.]{1,20}$')]],
      coinVendingMachineAvailable: ['', [Validators.required]],
      cmCrPfId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      cmCrName: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      cmCrMobileNo: ['', [Validators.required, Validators.pattern(MOBILE_NO_PATTERN)]],
      rmPfId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      rmName: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 .,+-?()%&@]*$')]],
      rmMobileNo: ['', [Validators.required, Validators.pattern(MOBILE_NO_PATTERN)]],
      noOf4plus1TypeNSM: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      noOf3plus1TypeNSM: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      noOf2plus1TypeNSM: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      noOf1plus1TypeNSM: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      fsloAgmPfId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      fsloOffPfId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      
    });

    // 1. get data from server
    this.ccProfileService.getCCProfileEdit().subscribe(
      value => {
        // this.ccProfile = value;

        this.branchDetailsForm.patchValue(value);

        if (value.coinVendingMachineAvailable) {
          this.branchDetailsForm.get('coinVendingMachineAvailable').setValue('true');
        } else {
          this.branchDetailsForm.get('coinVendingMachineAvailable').setValue('false');
        }
        console.log('Edit Component Values: ', value);
      },
      error => {
        console.log('error: ', error);
      }
    );
  }

  data = [
    {
      title: 'Accountant',
    },
    {
      title: 'Cash Officer',
    },
  ];
  data1 = [
    {
      title: 'CM (C&R)',
    },
  ];

  CCProfileSave(): void {
    console.log('On save-ts file', this.branchDetailsForm);
    // this.mapFormValuesToCcprofileModel();

    this.ccProfileService.postCcProfile(this.branchDetailsForm.value).subscribe(
      res => {
        console.log('success:', res);
        //this.alertService.set({ type: 'success', messages: ['Data Saved Successfully'] });
        this.notification.success('Data Saved Successfully', '');
      },
      error => {
        console.log('error:', error);
        //this.alertService.set({ type: 'error', messages: ['Data not Saved, Please Check'] });
        this.notification.error('Data not Saved, Please Check', '');
      },
      () => console.log('completed')
    );
  }

  loading = false;

  CCProfileSubmit() {
    
    console.log('On submit-ts file', this.branchDetailsForm);
    if (this.branchDetailsForm.invalid) {
      console.log('Form Submitted to Checker!');
    }
    this.loading=true;
    this.ccProfileService.postSubmitCcProfile(this.branchDetailsForm.value).subscribe(
      res => {
        this.loading=false;
        console.log('success:', res);
        //this.alertService.set({ type: 'success', messages: ['Data Submitted Successfully'] });
        this.notification.success('Data Submitted Successfully', '');
        this.router.navigate(['branch/cc-profile']);
      },
      error => {
        this.loading=false;
        console.log('error:', error);
        //this.alertService.set({ type: 'error', messages: ['Problem in Data Submission, Please Check'] });
        this.notification.error('Problem in Data Submission, Please Check', '');
      },
      () => console.log('completed')
    );
  }

  fetchUserDetails(pfId: number): void {
    console.log("PF ID: ", pfId);

    this.isFetchingUserDetails = true;

    this.empDetailsService.getEmployeeDetails(pfId).subscribe(
      res => {
        this.log.debug(res);
        this.employeeDetails = res;
        this.branchDetailsForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));
        //this.log.debug(this.assignOfficerForm.value);
        this.fetchedUserDetails = true;
      },
      error => {
        this.notification.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.', '');
        this.isFetchingUserDetails = false;
      },
      () => (this.isFetchingUserDetails = false)
    );
  }

  fetchCoDetails(pfId: number): void {
    console.log("PF ID: ", pfId);

    this.isFetchingCoDetails = true;

    this.empDetailsService.getEmployeeDetails(pfId).subscribe(
      res => {
        this.log.debug(res);
        this.employeeCoDetails = res;
        this.branchDetailsForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));
        //this.log.debug(this.assignOfficerForm.value);
        this.fetchedCoDetails = true;
      },
      error => {
        this.notification.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.', '');
        this.isFetchingCoDetails = false;
      },
      () => (this.isFetchingCoDetails = false)
    );
  }

  fetchBmDetails(pfId: number): void {
    console.log("PF ID: ", pfId);

    this.isFetchingBmDetails = true;

    this.empDetailsService.getEmployeeDetails(pfId).subscribe(
      res => {
        this.log.debug(res);
        this.employeeBmDetails = res;
        this.branchDetailsForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));
        //this.log.debug(this.assignOfficerForm.value);
        this.fetchedBmDetails = true;
      },
      error => {
        this.notification.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.', '');
        this.isFetchingBmDetails = false;
      },
      () => (this.isFetchingBmDetails = false)
    );
  }

  fetchCmCRDetails(pfId: number): void {
    console.log("PF ID: ", pfId);

    this.isFetchingCmCRDetails = true;

    this.empDetailsService.getEmployeeDetails(pfId).subscribe(
      res => {
        this.log.debug(res);
        this.employeeCmCRDetails = res;
        this.branchDetailsForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));
        //this.log.debug(this.assignOfficerForm.value);
        this.fetchedCmCRDetails = true;
      },
      error => {
        this.notification.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.', '');
        this.isFetchingCmCRDetails = false;
      },
      () => (this.isFetchingCmCRDetails = false)
    );
  }

  fetchRmDetails(pfId: number): void {
    console.log("PF ID: ", pfId);

    this.isFetchingRmDetails = true;

    this.empDetailsService.getEmployeeDetails(pfId).subscribe(
      res => {
        this.log.debug(res);
        this.employeeRmDetails = res;
        this.branchDetailsForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));
        //this.log.debug(this.assignOfficerForm.value);
        this.fetchedRmDetails = true;
      },
      error => {
        this.notification.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.', '');
        this.isFetchingRmDetails = false;
      },
      () => (this.isFetchingRmDetails = false)
    );
  }

  fetchFsloAgmDetails(pfId: number): void {
    console.log("PF ID: ", pfId);

    this.isFetchingFsloAgmDetails = true;

    this.empDetailsService.getEmployeeDetails(pfId).subscribe(
      res => {
        this.log.debug(res);
        this.employeeFsloAgmDetails = res;
        this.branchDetailsForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));
        //this.log.debug(this.assignOfficerForm.value);
        this.fetchedFsloAgmDetails = true;
      },
      error => {
        this.notification.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.', '');
        this.isFetchingFsloAgmDetails = false;
      },
      () => (this.isFetchingFsloAgmDetails = false)
    );
  }

  fetchFsloOffDetails(pfId: number): void {
    console.log("PF ID: ", pfId);

    this.isFetchingFsloOffDetails = true;

    this.empDetailsService.getEmployeeDetails(pfId).subscribe(
      res => {
        this.log.debug(res);
        this.employeeFsloOffDetails = res;
        this.branchDetailsForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));
        //this.log.debug(this.assignOfficerForm.value);
        this.fetchedFsloOffDetails = true;
      },
      error => {
        this.notification.error(error?.error?.detail ? error.error.detail : 'An error occured. Please try after sometime.', '');
        this.isFetchingFsloOffDetails = false;
      },
      () => (this.isFetchingFsloOffDetails = false)
    );
  }

}
