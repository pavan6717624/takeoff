export class CcProfileEdit {
  name: string;
  designation: string;
  contactNo: string;
}
