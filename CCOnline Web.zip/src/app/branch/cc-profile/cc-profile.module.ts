import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { SharedModule } from 'src/app/shared/shared.module';
import { CcProfileViewComponent } from './cc-profile-view/cc-profile-view.component';
import { CcProfileEditComponent } from './cc-profile-edit/cc-profile-edit.component';

const routes: Routes = [
  {
    path: '',
    component: CcProfileViewComponent,
  },
  {
    path: 'view',
    component: CcProfileViewComponent,
  },
  {
    path: 'edit',
    component: CcProfileEditComponent,
  },
];

@NgModule({
  declarations: [CcProfileViewComponent, CcProfileEditComponent],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule, FormsModule, ReactiveFormsModule],
})
export class CcProfileModule {}
