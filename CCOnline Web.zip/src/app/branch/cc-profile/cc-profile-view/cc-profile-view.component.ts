import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/auth/auth.service';
import { AlertService } from 'src/app/core/services/alert.service';
import { Role } from 'src/app/shared/constants/role.constants';
import { CcProfileService } from '../cc-profile.service';
import { RootObject } from '../model/cc-profile-checker.model';
import { CcProfile } from '../model/cc-profile.model';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';

import { CcPositionService } from 'src/app/branch/cc-position/cc-position.service';

import { NGXLogger } from 'ngx-logger';
import { NzNotificationService } from 'ng-zorro-antd/notification';

@Component({
  selector: 'app-cc-profile-view',
  templateUrl: './cc-profile-view.component.html',
  styleUrls: ['./cc-profile-view.component.less'],
})
export class CcProfileViewComponent implements OnInit {
  constructor(
    private ccProfileService: CcProfileService,
    private authService: AuthService,
    private ccPositionService: CcPositionService,
    private alertService: AlertService,
    private log: NGXLogger,
    private notification: NzNotificationService
  ) { }
  isLoading = true;
  ccProfile: CcProfile = new CcProfile();
  fullAddress: string;
  isChecker: boolean = true;
  ccProfileChecker: RootObject = null;
  formData = new FormData();
  displayBGLData: any = '';
  displayAvgBGLData: any = {};
  dateFormat = DATE_FORMAT;

  loading=false;

  ngOnInit(): void {
    this.isChecker = this.authService.hasRoleDirect(Role.BRANCH_HEAD);

    // get data from server
    this.ccProfileService.getCcProfile().subscribe(
      value => {
        console.log(value);
        this.ccProfile = value;
        this.fullAddress =
          this.ccProfile.address.line1 +
          ', ' +
          this.ccProfile.address.line2 +
          ', ' +
          this.ccProfile.address.line3 +
          ', ' +
          this.ccProfile.address.pincode +
          ', ' +
          this.ccProfile.address.district +
          ', ' +
          this.ccProfile.address.telephone;
        this.loading=true;
        this.ccProfileService.getCcCheckerProfile().subscribe(res => {
          this.loading=false;
          this.ccProfileChecker = res;
          this.log.debug('checker profile: ', res);
          this.log.debug('ccProfileChecker: ', this.ccProfileChecker);
        });
      },
      error => {
        this.loading=false;
        console.log('error: ', error);
      },
      () => (this.isLoading = false)
    );

    // Fetching BGL balances and total deposits and withdrawals from chest
    this.formData = new FormData();

    this.ccPositionService.processDifferenceForProfile().subscribe(
      res => {
        console.log(res);
        this.displayBGLData = res;
      },
      err => {
        this.displayBGLData = 'error';
      }
    );

    this.ccPositionService.displayDifferenceReportForProfile().subscribe(
      res => {
        console.log(res);
        this.displayAvgBGLData = res;
      },
      err => {
        this.displayAvgBGLData = 'error';
      }
    );
  }
  CCProfileApprove(): void {
    this.loading=true;
    this.ccProfileService.approveCcProfile().subscribe(
      res => {
        this.loading=false;
        console.log('success:', res);
        //this.alertService.set({ type: 'success', messages: ['Data Approved Successfully'] });
        this.notification.success('Data Approved Successfully', '');
        this.ccProfileChecker.ccProfileStatus = null;
      },
      error => {
        this.loading=false;
        console.log('error:', error);
        //this.alertService.set({ type: 'error', messages: ['Problem in Data Approval, Please Check'] });
        this.notification.error('Problem in Data Approval, Please Check', '');
      }
    );
  }

  CCProfileReject(): void {
    this.loading=true;
    this.ccProfileService.rejectCcProfile().subscribe(
      res => {
        this.loading=false;
        console.log('success:', res);
        //this.alertService.set({ type: 'success', messages: ['Data Rejected successfully'] });
        this.notification.success('Data Rejected successfully', '');
        this.ccProfileChecker.ccProfileStatus = null;
      },
      error => {
        this.loading=false;
        console.log('error:', error);
        //this.alertService.set({ type: 'error', messages: ['Problem in Data Rejection, Please Check'] });
        this.notification.error('Problem in Data Rejection, Please Check', '');
      }
    );
  }

  displayChangesForChecker(data: any): string {
    if (this.isChecker && data) {
      return data;
    }
    return '';
  }

  // isModified(old: any, changed: any): boolean {
  //   //this.log.debug(`old: ${old} | changes: ${changed} | result: ${old !== changed}`);

  //   if (old && changed) {
  //     return old !== changed;
  //   }
  //   return false;
  // }

  /*
   * old: null, changed: null -> false
   * old: null, changed: value -> true
   * old: value, changed: null -> false
   * old: value, changed: value -> (both values are different -> true)
   */
  isModified(old: any, changed: any): boolean {
  
    if (!old && changed) { return true; }
    if (old && changed) { return old !== changed; }
    return false;
  }
  

  isModifiedBoolean(old: any, changed: any): boolean {
    if(changed === null){
      changed = old;    }

    //this.log.debug(`old: ${old} | changes: ${changed} | result: ${old !== changed}`);
    return old !== changed;
  }
}
