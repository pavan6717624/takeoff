import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Data } from '@angular/router';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { RootObject } from './model/cc-profile-checker.model';

import { CcProfile } from './model/cc-profile.model';

@Injectable({ providedIn: 'root' })
export class CcProfileService {
  constructor(private http: HttpClient) { }

  getCcProfile(): Observable<CcProfile> {
    return this.http.get<CcProfile>(`${environment.apiUrl}/ccprofile`);
  }

  getCCProfileEdit(): Observable<any> {
    return this.http.get<any>(`${environment.apiUrl}/ccprofile/edit`);
  }

  postCcProfile(data: any): Observable<any> {
    console.log('Service Data:', data);
    return this.http.post(`${environment.apiUrl}/ccprofile/save`, data);
  }
  postSubmitCcProfile(data: any): Observable<any> {
    console.log('Submit Data:', data);
    return this.http.post(`${environment.apiUrl}/ccprofile/submit`, data);
  }

  getCcCheckerProfile(): Observable<RootObject> {
    return this.http.get<RootObject>(`${environment.apiUrl}/cccheckerprofile`);
  }

  // approveCcProfile(data: Data): Observable<any> {
  //   return this.http.post(`${environment.apiUrl}/cccheckerapprove`, data);
  // }
  approveCcProfile(): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cccheckerapprove`, null);
  }

  rejectCcProfile(): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cccheckerreject`, null);
  }
}
