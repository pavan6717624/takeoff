export interface State {
  code: number;
  name: string;
}

export interface Address {
  line1: string;
  line2: string;
  line3: string;
  line4: string;
  pincode: number;
  district: string;
  telephone: string;
  state: State;
  centerName: string;
  centerType: string;
  policeStation: string;
  populationGroup: string;
}

export enum CcEmployeeType {
  CASH_OFFICER,
  ACCOUNTANT,
  BRANCH_MANAGER,
}

export interface CcEmployee {
  id: number;
  name: string;
  designation: string;
  dateOfTakingOver: Date;
  mobileNumber: number;
  type: CcEmployeeType;
}
export interface CcEmployeeDetails {
  accountantId: number;
  accountantName: string;
  accountantDateOfTakingOver: Date;
  accountantMobileNo: number;  
  coId: number;
  coName: string;
  coDateOfTakingOver: Date;
  coMobileNo: number; 
  bmId: number;
  bmName: string;
  bmDateOfTakingOver: Date;
  bmMobileNo: number; 
}

export interface Circle {
  circleCode: number;
  circleName: string;
}

export interface Network {
  networkCode: number;
  circle: Circle;
}

export interface Module {
  moduleCode: number;
  moduleName: string;
  network: Network;
}

export interface Region {
  regionCode: number;
  cmCrPfId: number;
  cmCrName: string;
  cmCrMobileNo: number;
  rmPfId: number;
  rmName: string;
  rmMobileNo: number;
  module: Module;
}

export interface FsloStaff {
  pfId: number;
  name: string;
  emailId: string;
  mobileNo: string;
}

export class Fslo {
  branchCode: number;
  branchName: string;
  agm: FsloStaff;
  otherOfficer: FsloStaff;
  region: Region;
}

export interface LinkedBranch {
  code: number;
  name: string;
}

export interface CurrencyChest {
  region: Region;
  branchCode: number;
  branchName: string;
  currencyChestFlag: string;
  ccCode: number;
  dateOfOpening: Date;
  branchType: string;
  validityDateOfStrongRoomFitnessCertificate: Date;
  chestClass: string;
  cashBalanceLimit: number;
  capacityToStoreCashInBundles: number;
  averageDailyReciepts: number;
  averageDailyPayments: number;
  totalStaff: number;
  cashDeptStaff: number;
  noOfGuardsPosted: number;
  noOfOtherBankBranchesLinked: number;
  noOfBinsAvailable: number;
  noOfCCsMappedinCBS: number;
  holdingCapacityOfBins: number;
  coinVendingMachineAvailable: boolean;
  address: Address;
  incumbency: number;
  strongRoomSize: number;
  cashProcessingArea: number;
  noOf4plus1TypeNSM: number;
  noOf3plus1TypeNSM: number;
  noOf2plus1TypeNSM: number;
  noOf1plus1TypeNSM: number;
  fslo: Fslo;
  ccEmployees: CcEmployee[];
  ccEmployeeDetails: CcEmployeeDetails;
  linkedBranches: LinkedBranch;
  verifications?: any;
}

export interface Data {
  centerName: string;
  centerType: string;
  ccCode: number;
  policeStation: string;
  dateOfOpening: Date;
  branchType: string;
  validityDateofStrongRoomFitnessCertificate: Date;
  strongRoomSize: number;
  cashProcessingArea: number;
  chestClass: string;
  cashBalanceLimit: number;
  capacityToStoreCashInBundles: number;
  totalStaff: number;
  cashDeptStaff: number;
  accountantId: number;
  accountantName: string;
  accountantDateOfTakingOver: Date;
  accountantMobileNo: number;  
  coId: number;
  coName: string;
  coDateOfTakingOver: Date;
  coMobileNo: number; 
  bmId: number;
  bmName: string;
  bmMobileNo: number; 
  noOfGuardsPosted: number;
  linked_branch_code: string;
  noOfOtherBankBranchesLinked: number;
  noOfBinsAvailable: number;
  noOfCCsMappedinCBS: number;
  holdingCapacityOfBins: number;
  coinVendingMachineAvailable: boolean;
  cmCrPfId: number;
  cmCrName: string;
  cmCrMobileNo: number;
  rmPfId: number;
  rmName: string;
  rmMobileNo: number;
  noOf4plus1TypeNSM: number;
  noOf3plus1TypeNSM: number;
  noOf2plus1TypeNSM: number;
  noOf1plus1TypeNSM: number;
  fsloAgmPfId: number;
  fsloAgmName: string;
  fsloAgmMobileNo: number;
  fsloOffPfId: number;
  fsloOffName: string;
  fsloOffMobileNo: number;
}

export class RootObject {
  id: number;
  currencyChest: CurrencyChest;
  data: Data;
  ccProfileStatus: string;
}