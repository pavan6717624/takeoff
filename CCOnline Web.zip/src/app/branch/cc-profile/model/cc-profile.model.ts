//import { Circle } from 'src/app/shared/models/circle.model';
// import { Network } from 'src/app/shared/models/network.model';
// import { Module } from 'src/app/shared/models/module.model';
//import { Region } from 'src/app/shared/models/region.model';

export interface Circle {
  circleCode: number;
  circleName: string;
}

export interface Network {
  networkCode: number;
  circle: Circle;
}

export interface Module {
  moduleCode: number;
  moduleName: string;
  network: Network;
}

export interface Region {
  regionCode: number;
  cmCrPfId: number;
  cmCrName: string;
  cmCrMobileNo: number;
  rmPfId: number;
  rmName: string;
  rmMobileNo: number;
  module: Module;
}

export interface LinkedBranch {
  code: number;
  name: string;
}

export interface Circle {
  code: number;
  name: string;
}

export interface FsloStaff {
  pfId: number;
  name: string;
  emailId: string;
  mobileNo: string;
}

export class Fslo {
  branchCode: number;
  branchName: string;
  agm: FsloStaff;
  otherOfficer: FsloStaff;
  region: Region;
}

export interface State {
  code: number;
  name: string;
}

export interface Address {
  line1: string;
  line2: string;
  line3: string;
  pincode: number;
  district: string;
  telephone: string;
  policeStation: string;
  populationGroup: string;
  centerName: string;
  centerType: string;

  state: State;
}

export interface CubicArea {
  length: number;
  width: number;
  height: number;
}

export interface SquareFeetArea {
  length: number;
  width: number;
}

export enum CcEmployeeType {
  CASH_OFFICER,
  ACCOUNTANT,
  BRANCH_MANAGER,
}

export interface CcEmployee {
  id: number;
  name: string;
  designation: string;
  dateOfTakingOver: Date;
  mobileNumber: number;
  type: CcEmployeeType;
}

export interface CcEmployeeDetails {
  accountantId: number;
  accountantName: string;
  accountantDateOfTakingOver: Date;
  accountantMobileNo: number;  
  coId: number;
  coName: string;
  coDateOfTakingOver: Date;
  coMobileNo: number; 
  bmId: number;
  bmName: string;
  bmDateOfTakingOver: Date;
  bmMobileNo: number; 
}

export enum NsmType {
  ONE_PLUS_ONE,
  TWO_PLUS_ONE,
  THREE_PLUS_ONE,
  FOUR_PLUS_ONE,
}

export interface Nsm {
  id: number;
  make: string;
  model: string;
  nsmType: NsmType;
}

export interface CcNsm {
  id: number;
  yearOfPurchase: string;
  nsm: Nsm;
}

export class CcProfile {
  circle: Circle;
  network: Network;
  module: Module;
  region: Region;

  branchCode: number;
  branchName: string;
  currencyChestFlag: string;
  ccCode: number;
  dateOfOpening: Date;
  ccType: string;
  validityDateOfStrongRoomFitnessCertificate: Date;
  chestClass: string;
  cashBalanceLimit: number;
  capacityToStoreCashInBundles: number;
  averageDailyReciepts: number;
  averageDailyPayments: number;
  totalStaff: number;
  cashDeptStaff: number;
  noOfGuardsPosted: number;
  noOfOtherBankBranchesLinked: number;
  noOfBinsAvailable: number;
  noOfCCsMappedinCBS: number;
  holdingCapacityOfBins: number;
  coinVendingMachineAvailable: boolean;
  incumbency: number;
  strongRoomSize: number;
  cashProcessingArea: number;
  noOf4plus1TypeNSM: number;
  noOf3plus1TypeNSM: number;
  noOf2plus1TypeNSM: number;
  noOf1plus1TypeNSM: number;

  address: Address;
  state: State;
  fslo: Fslo;
  cubicArea: CubicArea;
  squareFeetArea: SquareFeetArea;
  //ccEmployees: CcEmployee[];
  ccEmployeeDetails: CcEmployeeDetails;
  linkedBranches: LinkedBranch[];
  ccNsm: CcNsm[];
}
