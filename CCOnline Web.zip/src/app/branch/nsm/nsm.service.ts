import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { CcNsmList } from './model/cc-nsm-list.model';
import { Nsm } from './model/nsm.model';

@Injectable({
  providedIn: 'root',
})
export class NsmService {
  constructor(private http: HttpClient) {}

  getCcNsmList(): Observable<CcNsmList> {
    return this.http.get<CcNsmList>(`${environment.apiUrl}/nsms/branch`);
  }

  // Getting data from NSM Master list
  getCcNsmMasterDetails(): Observable<Nsm[]>{
    return this.http.get<Nsm[]>(`${environment.apiUrl}/nsms/branch/addNsm`);

  }

  markNsmStatus(id: number): Observable<any>{
    
    return this.http.post(`${environment.apiUrl}/nsms/branch/markNsm`, id); 
  }
  
  postSubmitAddNsm(data: any): Observable<any> {
    console.log('Submit Data:', data);
    return this.http.post(`${environment.apiUrl}/nsms/branch/addNsm/submit`, data);
  }
}
