import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNsmDrawerComponent } from './add-nsm-drawer.component';

describe('AddNsmDrawerComponent', () => {
  let component: AddNsmDrawerComponent;
  let fixture: ComponentFixture<AddNsmDrawerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddNsmDrawerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNsmDrawerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
