import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { Router } from '@angular/router';
import { NzDrawerRef } from 'ng-zorro-antd/drawer';
import { NsmService } from '../nsm.service';
import { Nsm } from '../model/nsm.model';
import differenceInCalendarYears from 'date-fns/differenceInCalendarDays';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';

@Component({
  selector: 'app-add-nsm-drawer',
  templateUrl: './add-nsm-drawer.component.html',
  styleUrls: ['./add-nsm-drawer.component.less']
})
export class AddNsmDrawerComponent implements OnInit {

  nsms: Nsm[];

  //constructor(private drawerRef: NzDrawerRef<string>) { }
  constructor(private nsmService: NsmService ,
    private fb: FormBuilder,
    private notification: NzNotificationService,
    private router: Router,
    ) { }

    addNsmForm: FormGroup;

    dateFormat = DATE_FORMAT;

    today = new Date();
  
    disabledDate = (current: Date): boolean => {
      return differenceInCalendarYears(current, this.today) > 0;
    };

  @Input() value = '';
  ngOnInit(): void {
    this.addNsmForm = this.fb.group({
      id: ['', [Validators.required]],
      yearOfPurchase: ['', [Validators.required, Validators.pattern('^[1-2][0-9]{3}$'), Validators.minLength(4), Validators.maxLength(4)]],
      
      
    });

    this.nsmService.getCcNsmMasterDetails().subscribe(
      value => {
        // this.ccProfile = value;
        this.nsms = value;
        this.addNsmForm.patchValue(value);
      
        console.log('NSM Master List: ', value);
      },
      error => {
        console.log('error: ', error);
      }
    );

    
  }

  close(): void {
    //this.drawerRef.close(this.value);
  }

  AddNsmSubmit(){
    console.log('On submit-ts file', this.addNsmForm);
    for (const i in this.addNsmForm.controls) {
      this.addNsmForm.controls[i].markAsDirty();
      this.addNsmForm.controls[i].updateValueAndValidity();
    }
    this.nsmService.postSubmitAddNsm(this.addNsmForm.value).subscribe(
      res => {
        console.log('success:', res);
        this.notification.success('Data Added Successfully', '');
        this.router.navigate(['branch/nsm-maintenance']);
      },
      error => {
        console.log('error:', error);
        this.notification.error('Problem in adding the NSM, Please Check', '');
      },
      () => console.log('completed')
    );
  }

}