import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NsmProcessingComponent } from './nsm-processing.component';

describe('NsmProcessingComponent', () => {
  let component: NsmProcessingComponent;
  let fixture: ComponentFixture<NsmProcessingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NsmProcessingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NsmProcessingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
