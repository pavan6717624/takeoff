import { TestBed } from '@angular/core/testing';

import { NsmProcessingService } from './nsm-processing.service';

describe('NsmProcessingService', () => {
  let service: NsmProcessingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NsmProcessingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
