import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { DatePipe } from '@angular/common';
import {NsmProcessingService} from './nsm-processing.service'
import { NzMessageService } from 'ng-zorro-antd/message';
export class CcNsmModal
{
  id: number;
  yearOfPurchase: number;
  branchCode: number;
  nsm: NSM;
  status: string;
}
export class NSM
{
id: number;
nsmType: string;
make: string;
model: string;
}

export class SaveData
{
  denomination: Denomination[];
  nsmData: CcNsmModal;
  date: string;
  count: number[];
  status: string;
}

export class SavedData
{
  denomination: Denomination;
  nsmData: CcNsmModal;
  date: string;
  count: number;
  status: string;
}



export class Denomination
{
  id: number;
    value: number;
 description: string;
   type: string;
}
@Component({
  selector: 'app-nsm-processing',
  templateUrl: './nsm-processing.component.html',
  styleUrls: ['./nsm-processing.component.less']
})
export class NsmProcessingComponent implements OnInit {

  constructor(private nsmProcessingService:NsmProcessingService, private message:NzMessageService) { }

  status: boolean =  false;
  month: number = 0;
 nsmData: CcNsmModal[];
 loading: boolean = false;
nsmDataEntry: CcNsmModal;
visible: boolean = false;
denominations: Denomination[];
nsmValue: number[];
savedNsmValue : number[];
saving: boolean = false;
submitStatus: boolean = false;
selectedNsm: number;

saveData:SaveData;
savedData:SavedData[];

  ngOnInit(): void {
  }

  open(i)
  {
    this.nsmDataEntry=this.nsmData[i];
    this.selectedNsm = i;
    this.visible = true;
    this. saving = false;
    this. submitStatus = false;
    this.loading=true;
    this.getNSMSavedData();
    
    

  }

  RequestSave()
  {
if(this.checkAll())
{
  this.saveNSMData();   
}
  }

  RequestSubmit()
  {
    if(this.checkAll())
    {
      this.submitNSMData();
    }
  }


  getNSMSavedData()
  {
   
    this.saveData = new SaveData();
    this.saveData.nsmData =  this.nsmDataEntry;

    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.month, 'MM/yyyy');

    this.saveData.date =date;
    
    this.nsmProcessingService.getNSMSavedData(this.saveData).subscribe(
      res => {
      this.savedData = res;
      if(this.savedData && this.savedData[0] && this.savedData[0].status == 'Submit')
      this.submitStatus =  true;
      console.log(res);
      this.getDenominationData();
      },
      err => {

        this.savedData = [];
         console.log(err);
      }
    );
  }

  submitNSMData()
  {
    this.message.create("warning","Please wait...Processing....");
    this.saving=true;
    this.submitStatus=false;
    this.saveData = new SaveData();
    this.saveData.denomination = this.denominations;
    this.saveData.count =this.nsmValue;
    this.saveData.nsmData =  this.nsmDataEntry;

    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.month, 'MM/yyyy');

    this.saveData.date =date;
    
    this.nsmProcessingService.submitNSMData(this.saveData).subscribe(
      res => {
        this.saving=false;
        this.submitStatus = true;
        this.nsmData[this.selectedNsm].status='Submitted';
        this.message.create("success",res.message);
       console.log(res);
      },
      err => {
        this.saving=false;
        this.message.create("error","Error Occured. Try Again.")
         console.log(err);
      }
    );
  }

  checkAll()
  {
    for(var i=0;i<this.nsmValue.length;i++)
    {
      if((this.nsmValue[i]+"") == (''))
{
  this.message.create("error","Please Provide Value for Denomination " + this.denominations[i].value);
  return false;
}

    }
   return true;
  }
  
  saveNSMData()
  {
    this.message.create("warning","Please wait...Processing....");
    this.saving=true;
    this.saveData = new SaveData();
    this.saveData.denomination = this.denominations;
    this.saveData.count =this.nsmValue;
    this.saveData.nsmData =  this.nsmDataEntry;

    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.month, 'MM/yyyy');

    this.saveData.date =date;
    
    this.nsmProcessingService.saveNSMData(this.saveData).subscribe(
      res => {
        this.saving=false;
        this.nsmData[this.selectedNsm].status='Saved';
        this.message.create("success",res.message);
       console.log(res);
      },
      err => {
        this.saving=false;
        this.message.create("error","Error Occured. Try Again.")
         console.log(err);
      }
    );
  }

  getDenominationData()
  {
   
    this.nsmProcessingService.getDenominationData().subscribe(
      res => {
        this.loading=false;
        console.log(res);
        this.denominations = res;
        this.nsmValue = [];
        

        for( var i =0; i<this.denominations.length;i++)
        {
         if(this.savedData[i] && this.savedData[i].count)
         {
                    this.nsmValue[i]=this.savedData[i].count;
         }
          else
          this.nsmValue[i]=0;
         }
      },
      err => {
        this.loading=false;
        this.denominations = [];
        this.nsmValue = [];
      
        console.log(err);
      }
    );
  }
 
  close(): void {
    this.visible = false;
  }
  onChange()
  {
    if(this.month == 0 || this.month==null)
    return;

    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.month, 'MM/yyyy');

     var formData = new FormData();
 formData.set("date",date);

this.status=true;
    this.nsmProcessingService.getNSMData(formData).subscribe(
      res => {
        this.status=false;
        console.log(res);
        this.nsmData = res;

        if(this.nsmData && this.nsmData.length == 0 || this.nsmData == null)
        {
          this.message.create("error","No Active NSMs Found.")
        }

      },
      err => {
        this.status=false;
        this.nsmData = [];
        console.log(err);
      }
    );

  }

}
