import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {Denomination, CcNsmModal,SaveData} from './nsm-processing.component'

@Injectable({
  providedIn: 'root'
})
export class NsmProcessingService {

  constructor(private http: HttpClient, private log: NGXLogger) { }

  getNSMData(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getNSMData`, formData);
  }

  getDenominationData(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/getDenominationData`);
  }
 
  saveNSMData(saveData:SaveData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/saveNSMData`, saveData);
  }

  submitNSMData(saveData:SaveData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/submitNSMData`, saveData);
  }

  getNSMSavedData(saveData:SaveData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getNSMSavedData`, saveData);
  }


}


