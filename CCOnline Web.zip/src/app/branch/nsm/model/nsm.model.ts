export interface Nsm {
  id: number;
  nsmType: string;
  make: string;
  model: string;
}
