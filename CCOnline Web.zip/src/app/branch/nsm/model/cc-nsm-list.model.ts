import { Nsm } from './nsm.model';

export interface CcNsmList {
  id: number;
  yearOfPurchase: number;
  nsm: Nsm;
  active: boolean;
}
