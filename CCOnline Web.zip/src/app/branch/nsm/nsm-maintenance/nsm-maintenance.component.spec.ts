import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NsmMaintenanceComponent } from './nsm-maintenance.component';

describe('NsmMaintenanceComponent', () => {
  let component: NsmMaintenanceComponent;
  let fixture: ComponentFixture<NsmMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NsmMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NsmMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
