import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddNsmDrawerComponent } from '../add-nsm-drawer/add-nsm-drawer.component';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { CcNsmList } from '../model/cc-nsm-list.model';
import { NsmService } from '../nsm.service';

@Component({
  selector: 'app-nsm-maintenance',
  templateUrl: './nsm-maintenance.component.html',
  styleUrls: ['./nsm-maintenance.component.less']
})

export class NsmMaintenanceComponent implements OnInit {
  data: CcNsmList;
  switchValue = true;
  //ccNsmList: CcNsmList = new CcNsmList();

  constructor(private nsmService: NsmService, private router: Router, private notification: NzNotificationService,) { }

  ngOnInit(): void {
     // get data from server
     this.nsmService.getCcNsmList().subscribe(
      value => {
        console.log(value);
        this.data = value;
       
      },
      error => {
        console.log('error: ', error);
      },
      
    );
  }

  openComponent() {
    this.router.navigate(["./branch/add-nsm"]);
  }
 
  toggle(id) {

  

    this.nsmService.markNsmStatus(id).subscribe(
      res => {
        console.log('success:', res);
        //this.notification.success('NSM Marked Successfully', '');
       
      },
      error => {
        console.log('error:', error);
        //this.notification.error('Problem in marking the NSM, Please Check', '');
      },
      () => console.log('completed')
    );
  }

}
