import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddNsmDrawerComponent } from './add-nsm-drawer/add-nsm-drawer.component';
import { SharedModule } from 'src/app/shared/shared.module';
@NgModule({
  declarations: [AddNsmDrawerComponent],
  imports: [CommonModule,  SharedModule],
})
export class NsmModule {}
