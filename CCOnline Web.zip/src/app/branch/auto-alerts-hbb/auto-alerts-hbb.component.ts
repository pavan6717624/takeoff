import { Component, OnInit } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { AuthService } from 'src/app/core/auth/auth.service';
import { Role } from 'src/app/shared/constants/role.constants';
import { EmployeeDetails } from 'src/app/shared/models/employee-details.model';
import { AutoAlertDetails } from '../auto-alerts/auto-alerts.component';
import { AutoAlertsHbbService } from './auto-alerts-hbb.service';


@Component({
  selector: 'app-auto-alerts-hbb',
  templateUrl: './auto-alerts-hbb.component.html',
  styleUrls: ['./auto-alerts-hbb.component.less']
})
export class AutoAlertsHbbComponent implements OnInit {

  constructor(private notification: NzNotificationService, private authService: AuthService, private autoAlertsService: AutoAlertsHbbService) { }


  isAbdUser: boolean;
  isAoUser: boolean;
  isCircleUser: boolean;
  isFsloUser: boolean;
  isRegionUser: boolean;
  isBranchUser: boolean;
  message: string = '';

  pfid: number;
  email: string = '';
  userBranchCode: number = 0;


  alertDetails: AutoAlertDetails[] = [];
  entryVisible = false;
  employeeDetails: EmployeeDetails;
  validUser = false;
  tableLoading = false;

  ngOnInit(): void {


    this.isAbdUser = this.authService.hasAnyRolesDirect([Role.ABD_USER]);
    this.isAoUser = this.authService.hasAnyRolesDirect([Role.AGM_GB, Role.DGM_BO]);
    this.isCircleUser = this.authService.hasAnyRolesDirect([Role.CIRCLE_ADMIN]);
    this.isFsloUser = this.authService.hasAnyRolesDirect([Role.FSLO_USER]);
    this.isRegionUser = this.authService.hasAnyRolesDirect([Role.REGIONAL_MAGER, Role.CM_CR]);
    this.isBranchUser = this.authService.hasAnyRolesDirect([Role.BRANCH_HEAD, Role.BRANCH_USER]);


    this.getAutoAlertSettings();

  }

  selectedDetails: AutoAlertDetails = new AutoAlertDetails();

  closeWindow() {
    this.entryVisible = false;
    this.employeeDetails = null;
    this.pfid = null;

    this.validUser = false;

  }

  editDetails(details: AutoAlertDetails) {
    this.selectedDetails = details;
    this.entryVisible = true;
  }

  getAutoAlertSettings() {

    this.tableLoading = true;
    this.autoAlertsService.getAutoAlertSettings().subscribe(
      (res: any) => {
        this.alertDetails = res;
        console.log(res);

        if (!this.isBranchUser) {
          this.email = '';
        }



        this.getAccount();

      },
      err => {
        this.tableLoading = false;
        console.log(err);
      }
    );
  }

  loading = false;
  
  getAccount() {
    this.authService.getAccount().subscribe(

      (res: any) => {
        this.userBranchCode = res.branchCode;

        if (this.isBranchUser) {
          let branchCode = this.userBranchCode + "";
          for (var i = branchCode.length; i < 5; i++)
            branchCode = "0" + branchCode;
          this.email = "sbi." + branchCode;

        }

        this.tableLoading = false;
        console.log(res);

      },
      (err) => {
        this.tableLoading = false;
        console.log(err);
      }

    );
  }

  updateLoading = false;

  updateSettings() {
    var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,<>\/?]+/;

    //  console.log(this.email.trim().length +" "+ this.email.indexOf("@") +" "+ format.test(this.email) + " " + this.email.lastIndexOf('.') +" "+this.email.length);

    if (this.email.trim().length == 0 || this.email.indexOf("@") != -1 || format.test(this.email) || this.email.lastIndexOf('.') == (this.email.length - 1)) {
      this.notification.create("error", "Invalid Email", "Provide Valid Email");
      return;
    }


    let updateAlertSettings = new AutoAlertDetails();

    if (this.isRegionUser || this.isAbdUser || this.isAoUser || this.isCircleUser || this.isFsloUser) {
      updateAlertSettings.pfid = 0;
      updateAlertSettings.brcode = this.userBranchCode;
      updateAlertSettings.designation = '';
      updateAlertSettings.email = this.email + "@sbi.co.in";
      updateAlertSettings.mobile = 0;
      updateAlertSettings.name = '';
      updateAlertSettings.role = this.selectedDetails.role;
      updateAlertSettings.roleId = this.selectedDetails.roleId;
    }

  
    let checkSum: number =0;

    checkSum+=updateAlertSettings.pfid+updateAlertSettings.brcode+updateAlertSettings.mobile+updateAlertSettings.roleId;

    for(var i=0;i<updateAlertSettings.designation.length;i++)
    checkSum+=updateAlertSettings.designation.charCodeAt(i);

    for(var i=0;i<updateAlertSettings.email.length;i++)
    checkSum+=updateAlertSettings.email.charCodeAt(i);

    for(var i=0;i<updateAlertSettings.name.length;i++)
    checkSum+=updateAlertSettings.name.charCodeAt(i);

    
    for(var i=0;i<updateAlertSettings.role.length;i++)
    checkSum+=updateAlertSettings.role.charCodeAt(i);

    updateAlertSettings.checkSum=checkSum;



    console.log(updateAlertSettings);

    this.updateLoading = true;
    this.autoAlertsService.updateAutoAlertSettings(updateAlertSettings).subscribe(
      (res: any) => {
        if (res.status) {
          this.notification.create('success', 'Updated Successfully', '');
        }
        else {
          this.notification.create('error', 'Error Occured', res.message);
        }
        this.getAutoAlertSettings();
        console.log(res);
        this.updateLoading = false;
        this.closeWindow();

      },
      err => {
        this.updateLoading = false;
        console.log(err);
        this.closeWindow();
      }
    );

  }

}
