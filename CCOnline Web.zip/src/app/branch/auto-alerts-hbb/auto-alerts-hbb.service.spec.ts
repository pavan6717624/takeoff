import { TestBed } from '@angular/core/testing';

import { AutoAlertsHbbService } from './auto-alerts-hbb.service';

describe('AutoAlertsHbbService', () => {
  let service: AutoAlertsHbbService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AutoAlertsHbbService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
