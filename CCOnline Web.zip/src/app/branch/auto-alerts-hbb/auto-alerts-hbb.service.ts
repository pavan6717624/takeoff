import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { environment } from 'src/environments/environment';
import { AutoAlertDetails } from '../auto-alerts/auto-alerts.component';


@Injectable({
  providedIn: 'root'
})
export class AutoAlertsHbbService {
  getAutoAlertSettings() {
    return this.http.get(`${environment.apiUrl}/getAutoAlertHbbSettings`);
  }

  updateAutoAlertSettings(autoAlertDetails: AutoAlertDetails) {
    return this.http.post(`${environment.apiUrl}/updateAutoAlertHbbSettings`,autoAlertDetails);
  }

  constructor(private http: HttpClient, private log: NGXLogger) { }
}
