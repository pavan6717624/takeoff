import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoAlertsHbbComponent } from './auto-alerts-hbb.component';

describe('AutoAlertsHbbComponent', () => {
  let component: AutoAlertsHbbComponent;
  let fixture: ComponentFixture<AutoAlertsHbbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoAlertsHbbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoAlertsHbbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
