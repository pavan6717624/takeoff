import { TestBed } from '@angular/core/testing';

import { ViewChestSlipService } from './view-chest-slip.service';

describe('ViewChestSlipService', () => {
  let service: ViewChestSlipService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewChestSlipService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
