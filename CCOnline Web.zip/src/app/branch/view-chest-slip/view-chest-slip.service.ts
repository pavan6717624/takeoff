import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ViewChestSlipService {

  constructor(private http: HttpClient) { }

  viewChestSlip(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/cc-position/view-chest-slip`, formData);
  }

  exportToExcel(formData: FormData): Observable<any>
  {
    return this.http.post(`${environment.apiUrl}/cc-position/exportChestSlip`, formData,{responseType: 'blob'});
  }

}
