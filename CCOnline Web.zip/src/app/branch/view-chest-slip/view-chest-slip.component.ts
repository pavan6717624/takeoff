import { Component, OnInit } from '@angular/core';
import { CcPositionService } from 'src/app/branch/cc-position/cc-position.service';
import { DatePipe } from '@angular/common';
import { ViewChestSlipService} from './view-chest-slip.service';
import { en_US, NzI18nService, zh_CN } from "ng-zorro-antd/i18n";
import { NzMessageService } from 'ng-zorro-antd/message';
import { PDFDocument } from '../cc-position/cc-position.component';

@Component({
  selector: 'app-view-chest-slip',
  templateUrl: './view-chest-slip.component.html',
  styleUrls: ['./view-chest-slip.component.less']
})
export class ViewChestSlipComponent implements OnInit {

  constructor( private ccPositionService: CcPositionService, private i18n: NzI18nService, private message: NzMessageService,private viewChestSlipService:ViewChestSlipService) {
    this.i18n.setLocale(en_US);
    this.getBranchProfile();
   
  }

  date: Date;
  brcode: number = 0;
 
  branchprofile: any = '';
  formData: FormData;
  pdfDocument: PDFDocument;
  status: boolean =  false;
  ngOnInit(): void {
  }

  getBranchProfile() {
    this.ccPositionService.getBranchProfile().subscribe(
      res => {
        this.branchprofile = res;
        this.branchprofile=this.branchprofile.filter(cc => cc.isClosed!=1);

      },
      err => {
        this.branchprofile = '';
      }
    );
  }
  onChange()
  {
 
    if(this.brcode == null || this.brcode ==0 )
   {
    this.message.create('error',"Please select the Branch.");
    return;
    }
    
    if(this.date == null )
    return;

    var datePipe = new DatePipe('en-US');
    let value = datePipe.transform(this.date, 'dd/MM/yyyy');
    this.formData = new FormData();
    this.formData.set("date",value);
    this.formData.set("brcode",this.brcode+"");
    this.status = true;
    this.viewChestSlipService.viewChestSlip(this.formData).subscribe(
        (res) => {
          
          this.pdfDocument = res;
          if(this.pdfDocument.status == "No Data Found")
          this.message.create("error","No Data Found");
          this.status=false;
          console.log(res);
        },
        (err) => {
          this.status=false;
          console.log(err);
        }
      );

  }

export()
{
  this.formData=new FormData();
  this.formData.set("date",this.pdfDocument.date+"");
  this.formData.set("brcode",this.pdfDocument.brCode+"");

  if(this.pdfDocument.date.toString() < '2021-05-01')
{
this.message.create('error','Download option is available only for the chest slips dated on or after 2021-05-01');
return;
}
  this.viewChestSlipService.exportToExcel(this.formData).subscribe(res => {
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(new Blob([res], { type: 'text/csv' }));
    link.download = (this.pdfDocument.date+"").replace('/','')+'_'+this.pdfDocument.brCode+'_ChestSlip.pdf';
    link.click();
    link.remove();
  });
}


}
