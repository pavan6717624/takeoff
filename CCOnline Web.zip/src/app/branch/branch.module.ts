import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { VerificationsComponent } from './verifications/verifications.component';
import { SectionsComplianceComponent } from '../compliance/sections/sections-compliance.component';
import { ValueStatementsComponent } from '../compliance/value-statements/value-statements.component';
import { SharedModule } from '../shared/shared.module';
import { ComplianceModule } from '../compliance/compliance.module';
import { ChestSlipNotUploadedBranchesComponent } from '../abd/chest-slip-not-uploaded-branches/chest-slip-not-uploaded-branches.component';
import { ChestSlipUploadedBranchesComponent } from '../abd/chest-slip-uploaded-branches/chest-slip-uploaded-branches.component';
import { ChestBranchesAboveCglComponent } from '../abd/chest-branches-above-cgl/chest-branches-above-cgl.component';
import { BglCcDifferenceComponent } from '../abd/bgl-cc-difference/bgl-cc-difference.component';
import { NsmMaintenanceComponent } from './nsm/nsm-maintenance/nsm-maintenance.component';
import { MonthlyCertificateComponent } from './monthly-certificate/monthly-certificate.component';
import { AddNsmDrawerComponent } from './nsm/add-nsm-drawer/add-nsm-drawer.component';
import { CustomReportsComponent } from '../abd/custom-reports/custom-reports.component';
import { NsmProcessingComponent } from './nsm/nsm-processing/nsm-processing.component';
import { AutoAlertsComponent } from './auto-alerts/auto-alerts.component';
import { AutoAlertsHbbComponent } from './auto-alerts-hbb/auto-alerts-hbb.component';
import { ChestBranchesAboveCglConsecutiveComponent } from '../abd/chest-branches-above-cgl-consecutive/chest-branches-above-cgl-consecutive.component';
const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        redirectTo: 'cc-position',
        pathMatch: 'full',
      },
      {
        path: 'cc-position',
        loadChildren: () => import('./cc-position/cc-position.module').then(m => m.CcPositionModule),
      },
      {
        path: 'cc-profile',
        loadChildren: () => import('./cc-profile/cc-profile.module').then(m => m.CcProfileModule),
      },
      { path: 'compliance', component: VerificationsComponent },
      { path: 'compliance/:verificationId', component: SectionsComplianceComponent },
      { path: 'compliance/:verificationId/value-statements/:sectionId', component: ValueStatementsComponent },
      {
        path: 'view-chest-slip',
        loadChildren: () => import('./view-chest-slip/view-chest-slip.module').then(m => m.ViewChestSlipModule),
      },
      {
        path: 'chest-slip-not-uploaded-branches',
        component: ChestSlipNotUploadedBranchesComponent,
      },
      {
        path: 'chest-slip-uploaded-branches',
        component: ChestSlipUploadedBranchesComponent,
      },
      {
        path: 'chest-branches-above-cbl',
        component: ChestBranchesAboveCglComponent,
      },
      {
        path: 'consecutiveDaysReport',
        component: ChestBranchesAboveCglConsecutiveComponent,
      },
      {
        path: 'bgl-cc-difference',
        component: BglCcDifferenceComponent,
      },
      {
        path: 'monthly-certificate',
        component: MonthlyCertificateComponent,
      },

      {
        path: 'custom-reports',
        component: CustomReportsComponent,
      },

      {
        path: 'nsm-processing',
        component: NsmProcessingComponent,
      },
      {
        path: 'autoAlertSettings',
        component: AutoAlertsComponent,
      },
      {
        path: 'autoAlertSettingsHbb',
        component: AutoAlertsHbbComponent,
      },

      // {
      //   path: 'nsm',
      //   loadChildren: () => import('./nsm/nsm.module').then(m => m.NsmModule),
      // },
      { path: 'nsm-maintenance', component: NsmMaintenanceComponent },
       { path: 'add-nsm', component: AddNsmDrawerComponent },
    ],
  },
];

@NgModule({
  declarations: [VerificationsComponent, MonthlyCertificateComponent, NsmMaintenanceComponent, AddNsmDrawerComponent,NsmProcessingComponent, AutoAlertsComponent, AutoAlertsHbbComponent],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule, ComplianceModule],
})
export class BranchModule {}
