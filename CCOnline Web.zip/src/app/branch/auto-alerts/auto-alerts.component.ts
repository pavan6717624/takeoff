import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/auth/auth.service';
import { EmployeeDetailsService } from 'src/app/core/services/employee-details.service';
import { Role } from 'src/app/shared/constants/role.constants';
import { AutoAlertsService } from './auto-alerts.service';
import { EmployeeDetails } from 'src/app/shared/models/employee-details.model';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { th } from 'date-fns/locale';
export class AutoAlertDetails {
  role: string = '';
  pfid: number = 0;
  brcode: number = 0;
  name: string = '';
  mobile: number = 0;
  email: string = '';
  roleId: number = 0;
  designation: string = '';
  checkSum: number = 0;
}

@Component({
  selector: 'app-auto-alerts',
  templateUrl: './auto-alerts.component.html',
  styleUrls: ['./auto-alerts.component.less']
})
export class AutoAlertsComponent implements OnInit {

  constructor(private notification: NzNotificationService, private authService: AuthService, private autoAlertsService: AutoAlertsService, private hrmsApi: EmployeeDetailsService) { }


  isAbdUser: boolean;
  isAoUser: boolean;
  isCircleUser: boolean;
  isFsloUser: boolean;
  isRegionUser: boolean;
  isBranchUser: boolean;
  message: string = '';

  pfid: number;
  email: string = '';
  userBranchCode: number = 0;


  alertDetails: AutoAlertDetails[] = [];
  entryVisible = false;
  employeeDetails: EmployeeDetails;
  validUser = false;
  tableLoading = false;

  ngOnInit(): void {


    this.isAbdUser = this.authService.hasAnyRolesDirect([Role.ABD_USER]);
    this.isAoUser = this.authService.hasAnyRolesDirect([Role.AGM_GB, Role.DGM_BO]);
    this.isCircleUser = this.authService.hasAnyRolesDirect([Role.CIRCLE_ADMIN]);
    this.isFsloUser = this.authService.hasAnyRolesDirect([Role.FSLO_USER]);
    this.isRegionUser = this.authService.hasAnyRolesDirect([Role.REGIONAL_MAGER, Role.CM_CR]);
    this.isBranchUser = this.authService.hasAnyRolesDirect([Role.BRANCH_HEAD, Role.BRANCH_USER]);


    this.getAutoAlertSettings();

  }

  selectedDetails: AutoAlertDetails = new AutoAlertDetails();

  closeWindow() {
    this.entryVisible = false;
    this.employeeDetails = null;
    this.pfid = null;

    this.validUser = false;

  }

  editDetails(details: AutoAlertDetails) {
    this.selectedDetails = details;
    this.entryVisible = true;
  }

  getAutoAlertSettings() {

    this.tableLoading = true;
    this.autoAlertsService.getAutoAlertSettings().subscribe(
      (res: any) => {
        this.alertDetails = res;
        console.log(res);

        if (!this.isBranchUser) {
          this.email = '';
        }



        this.getAccount();

      },
      err => {
        this.tableLoading = false;
        console.log(err);
      }
    );
  }

  loading = false;
  getEmployeeDetails() {





    this.employeeDetails = null;

    if (!((this.pfid + "").length > 5 && (this.pfid + "").length < 9 && Number(this.pfid) == this.pfid)) {
      this.notification.create("error", "Invalid PFID", "Provide Valid PFID");
      return;
    }


    this.loading = true;
    this.hrmsApi.getEmployeeDetails(this.pfid).subscribe(

      (res: any) => {
        this.employeeDetails = res;
        console.log(res);

        if (this.userBranchCode != this.employeeDetails.branchCode) {
          this.message = "<b>Not a Valid User - " + this.pfid + '.<br>Please Provide User from Your Branch.</b>';
          this.notification.create('error', 'Not a Valid User - ' + this.pfid, 'Please Provide User from Your Branch.');
          this.validUser = false;
        }
        else {

          if (this.employeeDetails.employeeGroup === "O" || this.employeeDetails.employeeGroup === "S") {
            this.message = "<b>Valid User</b>";
            this.validUser = true;

          }
          else
          {
            this.message = "<b>Not a Valid User - " + this.pfid + '.<br>Please Provide Only Officers from Your Branch.</b>';
            this.notification.create('error', 'Not a Valid User - ' + this.pfid, 'Please Provide Only Officers from Your Branch.');
            this.validUser = false;
          }
        }
        this.loading = false;


      },
      err => {
        this.loading = false;
        console.log(err);
      }
    );


  }

  getAccount() {
    this.authService.getAccount().subscribe(

      (res: any) => {
        this.userBranchCode = res.branchCode;

        if (this.isBranchUser) {
          let branchCode = this.userBranchCode + "";
          for (var i = branchCode.length; i < 5; i++)
            branchCode = "0" + branchCode;
          this.email = "sbi." + branchCode;

        }

        this.tableLoading = false;
        console.log(res);

      },
      (err) => {
        this.tableLoading = false;
        console.log(err);
      }

    );
  }

  updateLoading = false;

  updateSettings() {
    var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,<>\/?]+/;

    //  console.log(this.email.trim().length +" "+ this.email.indexOf("@") +" "+ format.test(this.email) + " " + this.email.lastIndexOf('.') +" "+this.email.length);

    if (this.email.trim().length == 0 || this.email.indexOf("@") != -1 || format.test(this.email) || this.email.lastIndexOf('.') == (this.email.length - 1)) {
      this.notification.create("error", "Invalid Email", "Provide Valid Email");
      return;
    }


    let updateAlertSettings = new AutoAlertDetails();

    if (this.isAbdUser || this.isAoUser || this.isCircleUser || this.isFsloUser) {
      updateAlertSettings.pfid = 0;
      updateAlertSettings.brcode = this.userBranchCode;
      updateAlertSettings.designation = '';
      updateAlertSettings.email = this.email + "@sbi.co.in";
      updateAlertSettings.mobile = 0;
      updateAlertSettings.name = '';
      updateAlertSettings.role = this.selectedDetails.role;
      updateAlertSettings.roleId = this.selectedDetails.roleId;
    }

    else if (this.isBranchUser || this.isRegionUser) {
      updateAlertSettings.pfid = this.employeeDetails.pfId;
      updateAlertSettings.brcode = this.employeeDetails.branchCode;
      updateAlertSettings.designation = this.employeeDetails.designation;
      updateAlertSettings.email = this.email + "@sbi.co.in";
      updateAlertSettings.mobile = this.employeeDetails.mobileNo;
      updateAlertSettings.name = this.employeeDetails.name;
      updateAlertSettings.role = this.selectedDetails.role;
      updateAlertSettings.roleId = this.selectedDetails.roleId;
    }


    console.log(updateAlertSettings);

    this.updateLoading = true;
    this.autoAlertsService.updateAutoAlertSettings(updateAlertSettings).subscribe(
      (res: any) => {
        if (res) {
          this.notification.create('success', 'Updated Successfully', '');
        }
        else {
          this.notification.create('error', 'Error Occured', 'Could not Update the Details. Try Again.');
        }
        this.getAutoAlertSettings();
        console.log(res);
        this.updateLoading = false;
        this.closeWindow();

      },
      err => {
        this.updateLoading = false;
        console.log(err);
        this.closeWindow();
      }
    );

  }


}
