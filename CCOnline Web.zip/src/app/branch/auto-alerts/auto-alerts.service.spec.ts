import { TestBed } from '@angular/core/testing';

import { AutoAlertsService } from './auto-alerts.service';

describe('AutoAlertsService', () => {
  let service: AutoAlertsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AutoAlertsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
