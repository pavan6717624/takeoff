import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoAlertsComponent } from './auto-alerts.component';

describe('AutoAlertsComponent', () => {
  let component: AutoAlertsComponent;
  let fixture: ComponentFixture<AutoAlertsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoAlertsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoAlertsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
