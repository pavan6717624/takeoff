import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { STColumn, STData } from '@delon/abc/st';

import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';
import { VerificationService } from 'src/app/verification/service/verification.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-verifications',
  templateUrl: './verifications.component.html',
})
export class VerificationsComponent implements OnInit {
  constructor(private router: Router, private verificationService: VerificationService) {}

  loading: true;

  tabs: Tab[] = [
    {
      id: 1,
      title: 'Bi-Monthly',
      key: 'bi-monthly',
      assignable: true,
    },
    {
      id: 2,
      title: 'Quarterly',
      key: 'quarterly',
      assignable: false,
    },
    {
      id: 3,
      title: 'Half-Yearly',
      key: 'half-yearly',
      assignable: true,
    },
    {
      id: 4,
      title: 'DGM & CFO (Old)',
      key: 'dgm-cfo',
      assignable: false,
    },
    {
      id: 5,
      title: 'Security Officer',
      key: 'security-officer',
      assignable: false,
    },
    {
      id: 6,
      title: 'Controller (RM/DGM) Visit',
      key: 'rm-dgm-controller-visit',
      assignable: false,
    },
    {
      id: 7,
      title: 'DGM (B&O) Visit',
      key: 'dgm-bo-module-head-visit',
      assignable: false,
    },
    {
      id: 8,
      title: 'DGM CFO Visit (New)',
      key: 'dgm-cfo-visit',
      assignable: false,
    },
    {
      id: 9,
      title: 'GM Network Visit',
      key: 'gm-network-visit',
      assignable: false,
    },
    {
      id: 10,
      title: 'CGM Visit',
      key: 'cgm-visit',
      assignable: false,
    },
  ];

  columns: STColumn[] = [
    { title: 'Type', index: 'type' },
    { title: 'Period', index: 'period' },
    { title: 'Status', index: 'status' },
    {
      title: 'Report (In PDF)',
      buttons: [
        { text: 'Verification Report', click: data => this.downloadVerificationReport(data.id) },
        { text: 'Compliance Report', click: data => this.complianceReport(data.id) },
      ],
    },
    {
      title: 'View (for submitting)',
      buttons: [{ text: 'View', click: r => this.startCompliance(r) }],
    },
  ];

  activeTab: Tab = { id: 1, key: 'bi-monthly', title: 'Bi-Monthly', assignable: true };
  year: Date = new Date();
  cstatus: number = 0;
  displayOnlyPending: boolean = true;
  heading: string = ' - Pending';

  ngOnInit(): void {
    if (this.displayOnlyPending) this.cstatus = 0;
  }

  to(tab: Tab): void {
    this.activeTab = tab;
    console.log(this.activeTab.id);
  }

  dataUrl(): string {
    var id = this.activeTab.id;
    var year = 0;
    var cstatus = this.cstatus;
    var pending = 0;

    if (id == null || id == 0) {
      id = 1;
    }

    if (this.year == null) {
      year = new Date().getFullYear();
    } else {
      year = this.year.getFullYear();
    }

    if (cstatus == null) {
      cstatus = 0;
    }

    if (this.displayOnlyPending) {
      pending = 1;
    }

    return `${environment.apiUrl}/compliance/verifications` + '/' + id + '/' + year + '/' + cstatus + '/' + pending;
  }

  startCompliance(r: STData): void {
    this.router.navigate(['/branch/compliance/' + r.id]);
  }

  displayPending(): void {
    if (this.displayOnlyPending) this.cstatus = 0;
  }

  selectChange(): void {
    if (this.cstatus != 0) this.displayOnlyPending = false;
  }

  downloadVerificationReport(id: number): void {
    this.verificationService.downloadReport(id);
  }

  complianceReport(id: number): void {
    this.verificationService.downloadComplianceReport(id);
  }
}
