import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';

// TODO: refactor for any to inteface
@Injectable({
  providedIn: 'root',
})
export class CcPositionService {
  constructor(private http: HttpClient, private log: NGXLogger) {}

  getDifferenceReport(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/displaydifferencereport`, formData);
  }

  // branches
  getBranchProfile(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/cc-position/branches`);
  }

  processDifference(formData: FormData): Observable<any> {
    
    return this.http.post(`${environment.apiUrl}/cc-position/difference`, formData);
  }

  
  processDifferenceForProfile(): Observable<any> {
    
    return this.http.get(`${environment.apiUrl}/cc-position/bglbalances`);
  }

  displayDifferenceReportForProfile(): Observable<any> {
    
    return this.http.get(`${environment.apiUrl}/cc-position/avg-payments-reciepts`);
  }

  beforeUpload(formData: FormData): Observable<any> {
    this.log.debug('beforeUpload()', formData);
    return this.http.post(`${environment.apiUrl}/cc-upload/request`, formData);
  }

  beforeUploadAdmin(formData: FormData): Observable<any> {
   // this.log.debug('beforeUpload()', formData);
    return this.http.post(`${environment.apiUrl}/cc-upload/requestAdmin`, formData);
  }


  generatedPDF(formData: FormData): Observable<any> {
    // this.log.debug('beforeUpload()', formData);
     return this.http.post(`${environment.apiUrl}/generatedPDF`, formData);
   }

  confirm(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/savechestslip`, formData);
  }
}
