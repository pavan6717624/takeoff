import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { SharedModule } from 'src/app/shared/shared.module';
import { CcPositionComponent } from './cc-position.component';

const routes: Routes = [
  {
    path: '',
    component: CcPositionComponent,
  },
];

@NgModule({
  declarations: [CcPositionComponent],
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  exports: [CcPositionComponent],
})
export class CcPositionModule {}
