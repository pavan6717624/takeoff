import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';

import { NzMessageService } from 'ng-zorro-antd/message';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';

import { CcPositionService } from './cc-position.service';

export class PDFTable
{
  particulars: string[];
  denominations: string[];

    data: string[][];
    size: number;
}

export class PDFDocument
{
  date : Date;
  ccCode: number;
  ccName: string;

   notesTable:PDFTable;
  coinsTable: PDFTable;

   status: string="";
   message: string;
   uploadDate:string;
   fileName: string;
   printDetails: string;

   brCode: number;
}

export class DisplayDifference
{
  bgl98958balance: number;
   bgl98908balance: number;
   ccnotesclosing: number;
   cccoinsclosing: number;
   ccnotesdeposit: number;
 ccnoteswithdrawal: number;
  cccoinsdeposit: number;
   cccoinswithdrawal: number;
   bgl98958Date: Date;
   bgl98908Date: Date;
  ccDate: Date;
  status: string="";
  brCode: number;
  brName: string;

}

export class DifferenceReport
{
  date :Date;
  bglBalance: number;
  ccBalance: number;
  file: string;
  report: string;
  
}



@Component({
  selector: 'app-cc-position',
  templateUrl: './cc-position.component.html',
  styleUrls: ['./cc-position.component.less'],
})
export class CcPositionComponent {
  readonly DATE_FORMAT = 'dd/MM/yyyy';

  isVisible = false;
  brcode = null;
  uploaded = false;
  error = false;
  message = '';
  date = null;
  today = new Date();

  pdfDocument: PDFDocument;

  file: any = '';

  loading = false;

  displaydifference: DisplayDifference;

  branchprofile: any = '';

  latestUploadDate: Date;

  differencereport:DifferenceReport[];

  displaybgl = '';

  differencereportstatus=true;

  formData = new FormData();

  constructor(private msg: NzMessageService, private ccPositionService: CcPositionService) {
    this.getBranchProfile();
   
  }



  showModal(bgl): void {
    this.getDifferenceReport(bgl);
    this.isVisible = true;
  }

  handleOk(): void {
    console.log('Button ok clicked!');
    this.isVisible = false;
  }

  handleCancel(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  disabledDate = (current: Date): boolean => {

    return (
      differenceInCalendarDays(current, this.today) > 0 ||
      (this.latestUploadDate && differenceInCalendarDays(current, this.latestUploadDate) < 0)
    );
  };

  beforeUpload = (file: any) => {
    if (this.brcode == null || this.brcode == '') {
      this.pdfDocument = new PDFDocument();
      this.pdfDocument.status = 'Error';
      this.error = true;
      this.message = 'Please select Branch Code.';
      return false;
    }

    if (this.date == null || this.date == '') {
      this.pdfDocument = new PDFDocument();
      this.pdfDocument.status = 'Error';
      this.error = true;
      this.message = 'Please select Date.';
      return false;
    }

    this.loading = true;
    this.formData.set('file', file);

    var datePipe = new DatePipe('en-US');
    let value = datePipe.transform(this.date, 'dd/MM/yyyy');

    this.formData.set('date', value);

    this.file = file;
    this.ccPositionService.beforeUpload(this.formData).subscribe(
      res => {
        this.processResponse(res, false);
      },
      err => {
        this.processError(err);
      }
    );
    return false;
  };

  getDifferenceReport(bgl) {
    this.formData = new FormData();
    this.formData.set('brcode', this.brcode + '');
    this.formData.set('bgl', bgl);
    this.differencereport = [];
    
    this.differencereportstatus=true;

    this.ccPositionService.getDifferenceReport(this.formData).subscribe(
      res => {
        console.log(res);
        this.differencereport = res;

        if(this.differencereport.length == 0)
        {
          this.differencereportstatus=false;
        return;
        }
        this.displaybgl = this.differencereport[0].report;
        this.differencereportstatus=false;
      },
      err => {
        this.differencereport = [];
        this.differencereportstatus=false;
      }
    );
  }

  getBranchProfile() {
    this.ccPositionService.getBranchProfile().subscribe(
      res => {
        this.branchprofile = res;
        this.branchprofile=this.branchprofile.filter(cc => cc.isClosed!=1);

        
      },
      err => {
        this.branchprofile = '';
      }
    );
  }

  processDifference() {
    this.formData = new FormData();
   
    if(this.brcode == null || this.brcode == "" || this.brcode ==0 )
    return;
    this.formData.set('brcode', this.brcode + '');
    

    this.ccPositionService.processDifference(this.formData).subscribe(
      res => {
        console.log(res);
        this.displaydifference = res;
        if (res != null) {
          this.latestUploadDate = new Date(this.displaydifference.ccDate);
        }
      },
      err => {
        this.displaydifference.status = 'error';
      }
    );
  }

  processError(err) {
    this.pdfDocument.status = 'Error';
    this.error = true;
    this.message = 'Error Occured. Please try Again...';
    this.loading = false;
  }

  processResponse(res, uploaded) {
    console.log(res);
    this.pdfDocument = res;

    if (this.pdfDocument.status == 'Success' || this.pdfDocument.status == 'Warning') {
      this.error = false;
      this.uploaded = uploaded;
      this.message = this.pdfDocument.message;
    } else if (this.pdfDocument.status == 'Failed') {
      this.error = true;
      this.uploaded = false;
      this.message = this.pdfDocument.message;
    }

    this.loading = false;
    this.processDifference();
  }

  RequestCancel() {
    this.pdfDocument = new PDFDocument();
    this.file = '';
    this.date = '';
    this.message = '';
    this.error = false;
  }
onClose()
{

  this.error=false;
}
  RequestConfirm() {
    var datePipe = new DatePipe('en-US');
    let value = datePipe.transform(this.date, 'dd/MM/yyyy');
    let pdfDate = datePipe.transform(this.pdfDocument.date,'dd/MM/yyyy');
   
    if (value != pdfDate) {
      this.error = true;
      this.message = 'Dates Mismatch. Please select the appropriate Date.';
      return false;
    }

    if (this.date == null || this.date == '') {
      this.pdfDocument.status = 'Error';
      this.error = true;
      this.message = 'Please select Date First.';
      return false;
    }

    this.loading = true;
    this.formData.set('file', this.file);

    this.formData.set('date', value);

    this.ccPositionService.confirm(this.formData).subscribe(res => {
      this.processResponse(res, true);
    });
  }
}
