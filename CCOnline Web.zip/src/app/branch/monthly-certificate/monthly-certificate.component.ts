import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { NGXLogger } from 'ngx-logger';

import { MonthlyCertificateService } from './monthly-certificate.service';
import { MonthlyCertificateStmt } from './monthly-certificate.model';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { Option } from 'src/app/shared/models/option.model';

@Component({
  selector: 'app-monthly-certificate',
  templateUrl: './monthly-certificate.component.html',
  styleUrls: ['./monthly-certificate.component.less'],
})
export class MonthlyCertificateComponent implements OnInit {
  constructor(
    private monthlyCertificateService: MonthlyCertificateService,
    private notification: NzNotificationService,
    private log: NGXLogger,
    private fb: FormBuilder
  ) { }
  loading = true;
  saving = false;
  dateFormat = DATE_FORMAT;
  months: Option[];
  month: string;
  monthlyCertificateStmts: MonthlyCertificateStmt[];
  form: FormGroup = new FormGroup({});
  saved: boolean;

  //get data from server
  ngOnInit(): void {
    this.monthlyCertificateService.getMonths().subscribe(monthsRes => {
      this.log.debug('monthsRes: {}', monthsRes);
      this.months = monthsRes;
      if (monthsRes && monthsRes.length > 0) {
        this.loadStatements(monthsRes[0].value);
      }
    });
  }

  loadStatements(month: string): void {
    this.monthlyCertificateService.getMonthlyCertificateStmts(month).subscribe(value => {
      console.log(value);
      this.monthlyCertificateStmts = value.monthlyCertificateStmts;
      this.saved = value.saved;

      const group: any = {};
      this.monthlyCertificateStmts.forEach(item => {
        if (!item?.statement?.isHeaderOnly) {
          if (item?.statement.inputType === 'YES_NO') {
            group[item?.statement?.id] = this.fb.control({ value: item?.optionInput, disabled: this.saved }, [Validators.required]);
          } else if (item?.statement?.inputType === 'DATE') {
            group[item?.statement?.id] = this.fb.control({ value: item?.dateInput, disabled: this.saved }, [Validators.required]);
          }
        }
      });
      this.form = new FormGroup(group);
      this.month = month;
      this.loading = false;
    }, err => { this.loading = false; });
  }

  MonthlyCertificateSubmit(): void {
    this.saving = true;
    console.log('On Submit-ts file', this.form);

    if (this.form.invalid) {
      console.log('Form is invalid!');
    }

    this.log.debug('form data:', this.month, this.form.value);

    this.monthlyCertificateService.postMonthlyCertificateStmts(this.month, this.form.value).subscribe(
      res => {
        console.log('success:', res);
        this.notification.success('Data Submitted Successfully', '');
        this.saved = true;
        this.saving = false;
      },
      error => {
        console.log('error:', error);
        this.notification.error('Problem in Data Submission, Please Check if all the statements are selected/inputted', '');
        this.saving = false;
      }
    );
  }

  monthChanged(e: any): void {
    // console.log('Selected Month: ', month);
    // this.loadStatements(month);
    this.log.debug("month changed: ", e);
    this.loading = true;
    this.loadStatements(e);
  }
}
