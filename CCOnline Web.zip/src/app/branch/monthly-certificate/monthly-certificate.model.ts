// export interface MonthlyCertificateStmts {
//   statement: Statement;
//   dateInput: string;
//   optionInput: string;
// }

// export interface Statement {
//   id: number;
//   displayNo: string;
//   displayOrder: number;
//   isHeaderOnly: boolean;
//   description: string;
//   inputType: string;
// }

// export interface MonthlyCertificateStmt {
//   statement: Statement;
//   isSaved?: any;
//   optionInput: string;
//   dateInput: string;
// }



  export interface Statement {
      id: number;
      displayNo: string;
      displayOrder: number;
      isHeaderOnly: boolean;
      description: string;
      inputType: string;
  }

  export interface MonthlyCertificateStmt {
      statement: Statement;
      isSaved?: any;
      optionInput: string;
      dateInput: string;
  }

  export interface MonthlyCertificateStmtsAndStatus {
      monthlyCertificateStmts: MonthlyCertificateStmt[];
      saved: boolean;
  }


