import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Option } from 'src/app/shared/models/option.model';
import { environment } from 'src/environments/environment';

import { MonthlyCertificateStmtsAndStatus } from './monthly-certificate.model';

@Injectable({ providedIn: 'root' })
export class MonthlyCertificateService {
  constructor(private http: HttpClient) {}

  getMonths(): Observable<Option[]> {
    return this.http.get<Option[]>(`${environment.apiUrl}/monthlycertificate/months`);
  }

  getMonthlyCertificateStmts(month: string): Observable<MonthlyCertificateStmtsAndStatus> {
    return this.http.get<MonthlyCertificateStmtsAndStatus>(`${environment.apiUrl}/monthlycertificate`, {
      params: new HttpParams().append('month', month),
    });
  }

  postMonthlyCertificateStmts(month: string, data: any): Observable<any> {
    console.log('Submit Data:', data);
    return this.http.post(`${environment.apiUrl}/monthlycertificate/submit`, { month, data });
  }
}
