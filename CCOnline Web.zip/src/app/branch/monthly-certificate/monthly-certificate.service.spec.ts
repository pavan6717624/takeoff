import { TestBed } from '@angular/core/testing';

import { MonthlyCertificateService } from './monthly-certificate.service';

describe('MonthlyCertificateService', () => {
  let service: MonthlyCertificateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MonthlyCertificateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
