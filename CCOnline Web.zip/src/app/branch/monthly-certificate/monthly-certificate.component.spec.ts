import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlyCertificateComponent } from './monthly-certificate.component';

describe('MonthlyCertificateComponent', () => {
  let component: MonthlyCertificateComponent;
  let fixture: ComponentFixture<MonthlyCertificateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MonthlyCertificateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthlyCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
