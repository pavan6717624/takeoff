import { Component, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { AuthService } from '../core/auth/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less'],
})
export class HomeComponent implements OnInit {
  loggingIn = false;
  loginFailed = false;
  loginFailureMessage = '';

  constructor(private authService: AuthService, private log: NGXLogger) {}

  IE: boolean = /(msie|trident)/i.test(navigator.userAgent);

  ngOnInit(): void {
    console.log('initialized HomeComponent');

    this.authService.getPrincipal().subscribe(
      principal => {
        if (principal) {
          console.log('principal exists; redirecting to user home page');
          this.authService.redirectToUserHomePage();
        } else {
          console.log("principal doesn't exists");
          if (this.authService.isLoginFailed()) {
            this.loginFailed = true;
            this.loginFailureMessage = this.authService.getLoginFailureMessage();
          }
        }
      },
      error => {
        /* Do nothing */
        console.log('error while fetching principal', error);
        if (this.authService.isLoginFailed()) {
          this.log.debug('login failed');

          this.loginFailed = true;
          this.loginFailureMessage = this.authService.getLoginFailureMessage();
        }
      }
    );
  }

  login(): void {
    console.log('clicked on login');
    this.loggingIn = true;
    this.authService.login(); // redirect to API
  }
}
