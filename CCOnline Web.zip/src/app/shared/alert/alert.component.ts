import { Component, OnDestroy, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';

import { Alert, AlertService } from 'src/app/core/services/alert.service';

@Component({
  selector: 'app-alert',
  template: ` <nz-alert *ngFor="let msg of alert?.messages" [nzType]="alert.type" [nzMessage]="msg" nzCloseable></nz-alert> `,
  styles: [
    `
      nz-alert {
        margin-bottom: 15px;
      }
    `,
  ],
})
export class AlertComponent implements OnInit, OnDestroy {
  sub: Subscription;

  alert: Alert;

  constructor(private log: NGXLogger, private alertService: AlertService) {}

  ngOnInit(): void {
    this.sub = this.alertService.get().subscribe(
      res => (this.alert = res),
      err => this.log.error(err)
    );
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}
