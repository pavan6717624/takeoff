import { FormatEnumPipe } from './format-enum.pipe';

describe('FormatEnumPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatEnumPipe();
    expect(pipe).toBeTruthy();
  });
});
