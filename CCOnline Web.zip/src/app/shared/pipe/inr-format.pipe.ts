import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'inrFormat' })
export class InrFormatPipe implements PipeTransform {
  transform(value: any): string {
    var n = parseFloat(value);
    if (isNaN(n)) {
      return value;
    }

    var t, i;
    if (typeof n != 'number') {
      return n;
    }
    t = String(n).split('');
    t.reverse();
    var u = t.indexOf('.'),
      f = u + 1,
      r = 3;
    for (i = f; i < t.length; i++, r--) {
      if (t[i] == '-') {
        r++;
        continue;
      }
      r || (t.splice(i, 0, ','), i++, (r = 2));
    }
    return t.reverse().join('');
  }
}
