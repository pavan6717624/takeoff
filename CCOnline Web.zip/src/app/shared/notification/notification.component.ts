import { Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { Subscription } from 'rxjs';

import { AlertService } from 'src/app/core/services/alert.service';

@Component({
  selector: 'app-notification',
  template: `
    <ng-template let-data="data">
      <h4><span nz-icon nzType="close-circle" style="font-size: 20px; color: #D30909; padding-right: 5px;"></span> {{ data.title }}</h4>
      <ul>
        <li *ngFor="let msg of data.messages">{{ msg }}</li>
      </ul>
    </ng-template>
  `,
  styles: [],
})
export class NotificationComponent implements OnInit, OnDestroy {
  @ViewChild(TemplateRef, { static: false }) template?: TemplateRef<{}>;

  sub: Subscription;

  constructor(private alertService: AlertService, private notificationService: NzNotificationService) {}

  ngOnInit(): void {
    this.sub = this.alertService.get().subscribe(data => {
      this.notificationService.template(this.template, { nzData: data, nzDuration: 0 });
    });
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}
