export const DATE_FORMAT = 'dd-MM-yyyy';
export const DATE_TIME_FORMAT = 'DD-MM-YYYY HH:mm';
export const DATE_JACKSON_FORMAT = 'yyyy-MM-dd';
