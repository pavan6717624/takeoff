export interface SectionAndStatus {
  displayOrder: number;
  displayNo: string;
  name: string;
  isSaved?: any;
  isHeader?: boolean;
  isValueStatementSection?: boolean;
  route: string;
}
