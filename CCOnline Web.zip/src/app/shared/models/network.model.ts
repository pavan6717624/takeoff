import { Circle } from 'src/app/branch/cc-profile/model/cc-profile.model';

export interface Network {
  circle?: Circle;
  networkCode: number;
}
