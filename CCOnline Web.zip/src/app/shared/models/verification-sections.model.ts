import { ComplianceRole } from './compliance-role.enum';
import { Section } from './section.model';

export interface Action {
  label: string;
}

export enum VerificationStatus {
  IN_PROGRESS,
  SUBMITTED,
  CMP_SUBMITTED_BY_BR_MAKER,
  CMP_REJECTED_BY_BR_HEAD,
  CMP_SUBMITTED_BY_BR_HEAD,
  CMP_REJECTED_BY_SCRUTINIZER,
  CMP_SUBMITTED_BY_SCRUTINIZER,
  CMP_VERIFIED_BY_VO,
  CMP_REJECTED_BY_CA,
  CMP_CLOSED,
}

export interface VerificationSectionsVM {
  verificationType: string;
  branchCode: number;
  branchName: string;
  block: string;
  sections: Section[];
  isEditable?: boolean;
  userRole?: ComplianceRole;
  rejectAction?: Action;
  submitAction?: Action;
  status?: VerificationStatus;
  statusDescription: string;
  verificationOfficerComments?: string;
  branchHeadComments?: string;
  scrutinizerComments?: string;
  verificationOfficerComplianceComments?: string;
  closureComments?: string;
  securityOfficer: boolean;
  blockFrom: string;
  blockTo: string;
  certificateText: string;
}
