export interface EmployeeDetails {
  pfId?: number;
  name?: string;
  branchCode?: number;
  branchName?: string;
  designation?: string;
  emailId?: string;
  mobileNo?: number;
  employeeGroup?: string;
}
