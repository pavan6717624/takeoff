import { CurrencyChest, VerificationType } from 'src/app/circle-admin/identify-vo/model/verification.model';
import { VerificationOfficer } from './verification-officer.model';

export interface Verification {
  id: number;
  type: VerificationType;
  periodFrom: string;
  periodTo: string;
  currencyChest: CurrencyChest;
  officer?: VerificationOfficer;
  toBeCompletedBefore?: string;
  status?: any;
  ccBalancesAsOn?: any;
  branchProfile?: any;
  complianceStatus?: any;
}
