export enum CcType {
  RECIEPT,
  PAYMENT,
}
