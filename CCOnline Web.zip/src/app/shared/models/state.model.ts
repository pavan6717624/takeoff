export interface State {
  code: number;
  name: string;
}
