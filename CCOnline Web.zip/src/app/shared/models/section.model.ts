export interface Section {
  id?: number;
  displayOrder: number;
  displayNo: string;
  name: string;
  isValueStatementSection?: boolean;
  isHeader?: boolean;
  route: string;
  isSaved?: any;
  pending?: number;
  total?: number;
}
