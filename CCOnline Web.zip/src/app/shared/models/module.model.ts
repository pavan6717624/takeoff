import { Network } from 'src/app/branch/cc-profile/model/cc-profile.model';

export interface Module {
  network?: Network;
  moduleCode: number;
  moduleName: string;
}
