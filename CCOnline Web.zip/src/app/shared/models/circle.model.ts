export interface Circle {
  circleCode: number;
  circleName: string;
}
