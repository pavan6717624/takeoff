import { IdNameDesc } from './id-name-desc.model';

export interface VerificationBranchProfileInput {
  incumbency?: any;
  incumbencySince?: any;
  ccType?: any;
  totalStaff?: any;
  cashDeptStaff?: any;
  ccBalanceReportedInCyM?: any;
  balanceOfSoiledNotesAvailableInCc?: any;
  lastBiMonthlyVerification?: any;
  lastQuarterlyVerification?: any;
  lastHalfYearlyVerification?: any;
  lastSecurityOfficerVist?: any;
  strongRoomFitnessCertExpiryDate?: any;
}

export interface VerificationBranchProfileView {
  branchCode: number;
  branchName: string;
  circleCode: number;
  circleName: string;
  networkCode: number;
  moduleCode: number;
  moduleName: string;
  regionCode: number;
  strongRoomSize?: any;
  cashBalanceLimit?: any;
  //holdingCapacityOfBins?: any;
  capacityToStoreCashInBundles?: any;
  averageDailyReciepts?: any;
  averageDailyPayments?: any;
  bgl98958Balance?: any;
  soiledNotesBalanceReported?: any;
}

export interface VerificationBranchProfile {
  inputModel: VerificationBranchProfileInput;
  viewModel: VerificationBranchProfileView;
  ccTypes: IdNameDesc[];
  securityOfficer: boolean;
  balancesUpdatedLater: boolean;
  topOfficialsVisit: boolean ;
}
