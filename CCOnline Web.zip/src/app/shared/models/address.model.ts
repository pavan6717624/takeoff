import { State } from 'src/app/branch/cc-profile/model/cc-profile.model';

export interface Address {
  line1?: string;
  line2?: string;
  line3?: string;
  pincode?: number;
  district?: string;
  telephone?: string;
  state?: State;
  centerName?: any;
  centerType?: any;
  policeStation?: any;
  populationGroup?: string;
}
