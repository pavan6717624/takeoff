export interface VerificationOfficer {
  id: number;
  pfId: number;
  title?: any;
  name: string;
  designation: string;
  mobileNo: number;
  emailId: string;
  branchCode: number;
  branchName: string;
}
