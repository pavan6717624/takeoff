export interface IdNameDesc {
  id: string;
  name: string;
  description?: string;
}
