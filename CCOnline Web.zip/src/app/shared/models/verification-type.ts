export interface VerificationType {
  id: number;
  key: string;
  name: string;
}
