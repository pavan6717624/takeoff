import { Address } from 'cluster';
import { Region } from 'src/app/branch/cc-profile/model/cc-profile.model';

export interface CurrencyChest {
  region?: Region;
  branchCode: number;
  branchName: string;
  ccCode?: number;
  dateOfOpening?: string;
  ccType?: string;
  validityDateOfStrongRoomFitnessCertificate?: any;
  chestClass?: string;
  cashBalanceLimit?: any;
  averageDailyReciepts?: any;
  averageDailyPayments?: any;
  totalStaff?: any;
  cashDeptStaff?: any;
  noOfGuardsPosted?: any;
  noOfOtherBankBranchesLinked?: any;
  noOfBinsAvailable?: any;
  holdingCapacityOfBins?: any;
  coinVendingMachineAvailable?: any;
  address?: Address;
  incumbency?: number;
  strongRoomSize?: any;
  cashProcessingArea?: any;
  fslo?: any;
  ccEmployees?: any;
  linkedBranches?: any;
  verifications?: any;
}
