import { Module } from 'src/app/branch/cc-profile/model/cc-profile.model';

export interface Region {
  module?: Module;
  regionCode: number;
  cmCrPfId?: any;
  cmCrName?: any;
  cmCrMobileNo?: any;
  rmPfId?: any;
  rmName?: any;
  rmMobileNo?: any;
}
