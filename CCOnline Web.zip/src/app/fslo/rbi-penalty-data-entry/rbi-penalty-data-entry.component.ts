import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { DatePipe } from '@angular/common';
import {RbiPenaltyDataEntryService} from './rbi-penalty-data-entry.service'
import { CcPositionService } from 'src/app/branch/cc-position/cc-position.service'
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import { PenaltyDisposal } from '../rbi-penalty-disposal/rbi-penalty-disposal.component';
import { PenaltyRowData } from 'src/app/abd/rbi-penalty-upload/rbi-penalty-upload.component';

export class PenaltyReason
{
  id: number;
  type: PenaltyDebitType;
  reason: string;
}

export class PenaltySubReason
{
  id: number;
  reason: PenaltyReason;
  subReason: string;
}
export class PenaltyDebitType
{
  id: number;
  type: string;
}

export class PenaltyUpdation
{
  subReason: PenaltySubReason;
  reason: PenaltyReason;
  narration: PenaltyRowData;
  branchCode: number;
  amount: number;
  status: string;
  disposal: PenaltyDisposal;
  id: number;
  updatedDate: Date;
}

@Component({
  selector: 'app-rbi-penalty-data-entry',
  templateUrl: './rbi-penalty-data-entry.component.html',
  styleUrls: ['./rbi-penalty-data-entry.component.less']
})




export class RbiPenaltyDataEntryComponent implements OnInit {

  constructor(private modal: NzModalService, private rbiPenaltyDataEntryService: RbiPenaltyDataEntryService, private ccPositionService: CcPositionService, private message: NzMessageService) {

    this.getBranchProfile();
this.getPenaltyDebitType();
this.penaltyUpdation = [];
     }


     getPenaltyDebitType()
     {
      this.rbiPenaltyDataEntryService.getPenaltyDebitType().subscribe(
        res => {
       //   console.log(res);
          this.penaltyDebitType = res;
        },
        err => {
        //  console.log(err);
          this.penaltyDebitType = new PenaltyDebitType();
        }
      );
     }
  ngOnInit(): void {
  }



  date: Date;
  brname: string="";
  status: boolean =  false;
  penaltyData: PenaltyRowData[];
  penaltyDataEntry: PenaltyRowData;
  penaltyReason: PenaltyReason[];
  penaltySubReason: PenaltySubReason[];
  penaltyUpdation: PenaltyUpdation[];
  visible = false;
  branchprofile: any = '';
  penaltyDebitType: PenaltyDebitType;
  brcode: number=0;
  debitType: number=0;
  reason: number=0;
  subreason: number=0;
  narration: number=0;
  penaltyEnteredAmount = '';
  title = 'Input a number';
  total: number=0;
  submitStatus: boolean = false;
  loading: boolean = false;
  saving: boolean=false;
  @ViewChild('inputElement', { static: false }) inputElement?: ElementRef;


  open(i): void {

        this.narration = i;
        this.penaltyDataEntry=this.penaltyData[i];
        this.visible = true;
        this.brcode =0;
        this.debitType =0;
        this.reason =0;
        this.subreason =0;
        this.penaltyEnteredAmount='';
        this.submitStatus= false;
        this.total=0;
        this.loading=false;
        this.getPenaltyProvidedData();

        
  }

  getPenaltyProvidedData()
  {
    this.loading=true;
    this.rbiPenaltyDataEntryService.getPenaltyProvidedData(this.penaltyDataEntry).subscribe(
      res => {
       // console.log("saved "+res);
        this.penaltyUpdation = res;
        for(var i=0;i<this.penaltyUpdation.length;i++)
        this.total+=this.penaltyUpdation[i].amount;
        this.total=Math.round(this.total * 100) / 100;
        if(this.penaltyUpdation.length > 0 && this.penaltyUpdation[0].status == 'Submitted')
        this.submitStatus=true;
        this.loading=false;
      },
      err => {
        this.penaltyUpdation=[];
        this.loading=false;
      }
    );
  }


  close(): void {
    this.visible = false;
  }

  onChangeNumber(value: string): void
  {
    this.updateValue(value);
  }

  onBlur()
{
  if (this.penaltyEnteredAmount.charAt(this.penaltyEnteredAmount.length - 1) === '.' || this.penaltyEnteredAmount === '-') {
    this.updateValue(this.penaltyEnteredAmount.slice(0, -1));
  }
}

updateValue(value: string): void {
  const reg = /^-?(0|[1-9][0-9]*)(\.[0-9]*)?$/;
  if ((!isNaN(+value) && reg.test(value)) || value === '' || value === '-') {
    this.penaltyEnteredAmount = value;
  }
  this.inputElement!.nativeElement.value = this.penaltyEnteredAmount;
  this.updateTitle();
}

updateTitle(): void {
  this.title = (this.penaltyEnteredAmount !== '-' ? this.formatNumber(this.penaltyEnteredAmount) : '-') || 'Input a number';
}

formatNumber(value: string): string {
 /* const stringValue = `${value}`;
  const list = stringValue.split('.');
  const prefix = list[0].charAt(0) === '-' ? '-' : '';
  let num = prefix ? list[0].slice(1) : list[0];
  let result = '';
  while (num.length > 3) {
    result = `,${num.slice(-3)}${result}`;
    num = num.slice(0, num.length - 3);
  }
  if (num) {
    result = num + result;
  }*/
  return Number(value).toLocaleString('en-IN');
}

  getPenaltyReasons()
  {

   // console.log(this.brcode+" "+this.debitType);
    this.reason = 0;

     var branchProfile=this.branchprofile.filter(cc => cc.branchCode == this.brcode);

     if(branchProfile.length > 0)
     this.brname = branchProfile[0].branchName;
     else
     this.brname='';

    if(this.brcode == null || this.brcode == 0 ||  this.debitType==null || this.debitType==0)
    {
      this.penaltyReason = [];
      this.penaltySubReason = [];
      return;
    }



    this.rbiPenaltyDataEntryService.getPenaltyReasons( this.penaltyDebitType[this.debitType-1]).subscribe(
      res => {
      //  console.log(res);
        this.penaltyReason = res;
      },
      err => {
     //   console.log(err);
        this.penaltyReason = [];
        this.penaltySubReason = [];
      }
    );
  }
  
  getPenaltySubReasons()
  {

    this.subreason = 0;
    if(this.brcode == null || this.brcode == 0 ||  this.debitType==null || this.debitType==0 || this.reason==null || this.reason == 0)
    {
      this.penaltySubReason = [];
      return;
    }


  //  console.log(this.reason +" "+this.penaltyReason[this.reason-1]);

    this.rbiPenaltyDataEntryService.getPenaltySubReasons( this.penaltyReason[this.reason-1]).subscribe(
      res => {
     
        this.penaltySubReason = res;
       let others = this.penaltySubReason.filter(o=>o.subReason === 'Others');
       this.penaltySubReason = this.penaltySubReason.filter(o=>o.subReason != 'Others');
       this.penaltySubReason.push(others[0]);

       
      },
      err => {
      //  console.log(err);
        this.penaltySubReason = [];
      }
    );
  }

  getBranchProfile() {
    this.ccPositionService.getBranchProfile().subscribe(
      res => {
        this.branchprofile = res;
       // this.branchprofile=this.branchprofile.filter(cc => cc.isClosed!=1);

      },
      err => {
        this.branchprofile = '';
      }
    );
  }

  delete(i)
  {
    this.total-=this.penaltyUpdation[i].amount;
    this.total=Math.round(this.total * 100) / 100;
    this.penaltyUpdation.splice(i,1);
    
    if(this.penaltyUpdation.length == 0)
    {
      
        this.modal.confirm({
          nzTitle: '<i>There are no Items Present. Do you Want to Save with no Items?</i>',
          nzOnOk: () => {this.saveWithNoItems();}
        });
      
    }
  }

  saveWithNoItems()
  {
    var penaltyUpdation = new PenaltyUpdation();
    penaltyUpdation.narration = this.penaltyData[this.narration];
    
    this.rbiPenaltyDataEntryService.saveWithNoItems([penaltyUpdation]).subscribe(
      res => {
        this.message.create(res.status,res.message)
      },
      err => {
        this.message.create('error','Error Occured. Please try Again.')
      }
    );
  
  }

  RequestSave()
  {
    this.saving=true;
    this.message.create("warning","Please wait...Processing");
    this.rbiPenaltyDataEntryService.savePenaltyData(this.penaltyUpdation).subscribe(
      res => {
        this.saving=false;
        this.message.create(res.status,res.message)
      },
      err => {
        this.saving=false;
        this.message.create('error','Error Occured. Please try Again.')
      }
    );
  }

  RequestSubmit()
  {
    this.saving=true;
    this.message.create("warning","Please wait...Processing");
    this.rbiPenaltyDataEntryService.submitPenaltyData(this.penaltyUpdation).subscribe(
      res => {
        this.saving=false;
        this.penaltyData[this.narration].postedStatus='Submitted';
        this.message.create(res.status,res.message);
        this.submitStatus=true;
      },
      err => {
        this.saving=false;
        this.message.create('error','Error Occured. Please try Again.');
      }
    );
  }


  RequestAdd()
  {
    if((Math.round((this.total+Number(this.penaltyEnteredAmount)) * 100) / 100) > this.penaltyData[this.narration].debit)
    {
      this.message.create('error','Total Value exceeded the Penalty Amount.')
        return;
    }
    var penaltyUpdation = new PenaltyUpdation();
    penaltyUpdation.reason = this.penaltyReason[this.reason-1];
    if(this.subreason!=0)
    penaltyUpdation.subReason = this.penaltySubReason[this.subreason-1];
    penaltyUpdation.branchCode =  this.brcode;
    penaltyUpdation.narration = this.penaltyData[this.narration];
    penaltyUpdation.amount = Number(this.penaltyEnteredAmount);
    this.penaltyUpdation.push(penaltyUpdation);
   // console.log(this.penaltyUpdation);
    this.total+=penaltyUpdation.amount;
    this.total=Math.round(this.total * 100) / 100;
    this.penaltyEnteredAmount='';
  }

  onChange()
  {
    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.date, 'MM/yyyy');
  //  console.log('date: ', date);
    var formData = new FormData();
    formData.set("date",date);
    this.penaltyData=[];
    if(date!= null)
    {
      this.status = true;
      this.rbiPenaltyDataEntryService.getPenaltyDataOnDate(formData).subscribe(
        (res) => {
          this.penaltyData = res;
          this.status=false;
     //   console.log(res);
        },
        (err) =>
        {
          this.status=false;
          this.penaltyData=[];
        //  console.log(err);
        }
       
      );
    }

  }

  today=new Date();

  disabledDate = (current: Date): boolean => {
    

    return (
      differenceInCalendarDays(current, this. today) > 0 );
  };

}
