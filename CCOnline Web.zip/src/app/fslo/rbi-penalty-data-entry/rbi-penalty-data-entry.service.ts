import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { PenaltyRowData } from 'src/app/abd/rbi-penalty-upload/rbi-penalty-upload.component';

import { environment } from 'src/environments/environment';
import { PenaltyDebitType, PenaltyReason,PenaltyUpdation } from './rbi-penalty-data-entry.component';

@Injectable({
  providedIn: 'root'
})
export class RbiPenaltyDataEntryService {

  constructor(private http: HttpClient, private log: NGXLogger) {}


  getPenaltyDataOnDate(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getPenaltyDataOnDate`, formData);
  }

  getPenaltyDebitType(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/getPenaltyDebitType`);
  }

  getPenaltyReasons(penalty_debit_type: PenaltyDebitType): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getPenaltyReasons`, penalty_debit_type);
  }

  getPenaltySubReasons(penalty_reason: PenaltyReason): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getPenaltySubReasons`, penalty_reason);
  }

  savePenaltyData(penalty_updation: PenaltyUpdation[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/savePenaltyData`, penalty_updation);
  }

  saveWithNoItems(penalty_updation: PenaltyUpdation[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/saveWithNoItems`, penalty_updation);
  }

  submitPenaltyData(penalty_updation: PenaltyUpdation[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/submitPenaltyData`, penalty_updation);
  }
  
  getPenaltyProvidedData(penalty_data: PenaltyRowData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getPenaltyProvidedData`, penalty_data);
  }


}
