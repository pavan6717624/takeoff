import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RbiPenaltyDataEntryComponent } from './rbi-penalty-data-entry.component';

describe('RbiPenaltyDataEntryComponent', () => {
  let component: RbiPenaltyDataEntryComponent;
  let fixture: ComponentFixture<RbiPenaltyDataEntryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RbiPenaltyDataEntryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RbiPenaltyDataEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
