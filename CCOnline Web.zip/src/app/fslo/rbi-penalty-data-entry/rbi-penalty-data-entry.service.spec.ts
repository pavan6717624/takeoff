import { TestBed } from '@angular/core/testing';

import { RbiPenaltyDataEntryService } from './rbi-penalty-data-entry.service';

describe('RbiPenaltyDataEntryService', () => {
  let service: RbiPenaltyDataEntryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RbiPenaltyDataEntryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
