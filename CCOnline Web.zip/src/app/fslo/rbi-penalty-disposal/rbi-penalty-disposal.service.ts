import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { PenaltyRowData } from 'src/app/abd/rbi-penalty-upload/rbi-penalty-upload.component';
import { environment } from 'src/environments/environment';
import { PenaltyUpdation } from '../rbi-penalty-data-entry/rbi-penalty-data-entry.component';

@Injectable({
  providedIn: 'root'
})
export class RbiPenaltyDisposalService {
  splitPenaltyAmount(formData: FormData) {
    return this.http.post(`${environment.apiUrl}/splitPenaltyAmount`, formData);
  }

  constructor(private http: HttpClient, private log: NGXLogger) {}

  getPenaltyDisposal(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getPenaltyDisposal`, formData);
  }

  savePenaltyDisposal(penalty_updation: PenaltyUpdation): Observable<any> {
    return this.http.post(`${environment.apiUrl}/savePenaltyDisposal`, penalty_updation);
  }
 
  
  getDisposalData(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/getDisposalData`);
  }
 
}
