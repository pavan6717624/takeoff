import { TestBed } from '@angular/core/testing';

import { RbiPenaltyDisposalService } from './rbi-penalty-disposal.service';

describe('RbiPenaltyDisposalService', () => {
  let service: RbiPenaltyDisposalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RbiPenaltyDisposalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
