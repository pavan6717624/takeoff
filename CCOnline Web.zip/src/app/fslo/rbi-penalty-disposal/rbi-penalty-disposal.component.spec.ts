import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RbiPenaltyDisposalComponent } from './rbi-penalty-disposal.component';

describe('RbiPenaltyDisposalComponent', () => {
  let component: RbiPenaltyDisposalComponent;
  let fixture: ComponentFixture<RbiPenaltyDisposalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RbiPenaltyDisposalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RbiPenaltyDisposalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
