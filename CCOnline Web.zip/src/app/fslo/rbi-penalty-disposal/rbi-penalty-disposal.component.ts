import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RbiPenaltyDisposalService } from './rbi-penalty-disposal.service';
import { PenaltyRowData } from 'src/app/abd/rbi-penalty-upload/rbi-penalty-upload.component';
import { RbiPenaltyDataEntryService } from 'src/app/fslo/rbi-penalty-data-entry/rbi-penalty-data-entry.service'
import { PenaltyUpdation } from '../rbi-penalty-data-entry/rbi-penalty-data-entry.component'
import { NzMessageService } from 'ng-zorro-antd/message';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
export class PenaltyDisposal {
  id: number;
  disposal: string;
}


@Component({
  selector: 'app-rbi-penalty-disposal',
  templateUrl: './rbi-penalty-disposal.component.html',
  styleUrls: ['./rbi-penalty-disposal.component.less']
})
export class RbiPenaltyDisposalComponent implements OnInit {

  constructor(private rbiPenaltyDisposalService: RbiPenaltyDisposalService, private rbiPenaltyDataEntryService: RbiPenaltyDataEntryService, private message: NzMessageService) { }
  status: boolean = false;
  month: number = 0;
  penaltyData: PenaltyRowData[];
  penaltyDisposalEntry: PenaltyRowData;
  penaltyProvidedData: PenaltyUpdation[];
  penaltyDisposalData: PenaltyDisposal[];
  loading1: boolean = false;
  loading2: boolean = false;
  saving: boolean = false;
  visible: boolean = false;
  disposalData: number[];

  splitVisible = false;
  amount1: number = 0;
  amount2: number = 0;


  ngOnInit(): void {
  }

  onChange() {

    if (this.month == 0 || this.month == null)
      return;

    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.month, 'MM/yyyy');

    console.log(date);

    var formData = new FormData();
    formData.set("date", date);

    this.status = true;
    this.rbiPenaltyDisposalService.getPenaltyDisposal(formData).subscribe(
      res => {
        this.status = false;
        this.penaltyData = res;
        console.log(res);
      },
      err => {
        this.status = false;
        this.penaltyData = [];
        console.log(err);
      }
    );

  }

  selectedPenaltyData = 0;

  open(i): void {

    this.penaltyDisposalEntry = this.penaltyData[i];
    this.selectedPenaltyData = i;
    this.visible = true;
    this.loading1 = false;
    this.loading2 = false;

    this.getPenaltyUpdatedData();
    this.getDisposalData();

  }


  getDisposalData() {
    this.loading2 = true;
    this.rbiPenaltyDisposalService.getDisposalData().subscribe(
      res => {
        this.loading2 = false;
        this.penaltyDisposalData = res;
        console.log(res);
      },
      err => {
        this.loading2 = false;
        this.penaltyDisposalData = [];
        console.log(err);
      }
    );
  }

  selectedDisposal: number = 0;

  getPenaltyUpdatedData() {

    this.status = true;
    this.loading1 = true;
    this.loading2 = true;
    this.rbiPenaltyDataEntryService.getPenaltyProvidedData(this.penaltyDisposalEntry).subscribe(
      res => {
        this.status = false;
        this.loading1 = false;
        this.penaltyProvidedData = res;
        this.disposalData = [];
        console.log(res);
      },
      err => {
        this.status = false;
        this.loading1 = false;
        this.penaltyProvidedData = [];
        console.log(err);
      }
    );

  }
  close(): void {
    this.visible = false;
  }
  RequestSave(i) {

    if (this.disposalData[i] && this.disposalData[i] > 0) {
      this.saving = true;
      this.message.create("warning", "Please Wait...Processing..");
      console.log(this.penaltyDisposalData[this.disposalData[i] - 1].disposal + " " + i);
      this.penaltyProvidedData[i].disposal = this.penaltyDisposalData[this.disposalData[i] - 1];

      this.rbiPenaltyDisposalService.savePenaltyDisposal(this.penaltyProvidedData[i]).subscribe(
        res => {
          this.saving = false;
          this.message.create(res.status, res.message);
          this.onChange();
          console.log(res);
        },
        err => {
          this.saving = false;
          this.message.create('error', 'Error Occured. Please try Again.')
          console.log(err);
        }
      );

    }
    else
    {
      this.message.error('Please provide Penalty Disposal Action');
    }
  }

  selectedDisposalId = 0;

  split(i) {
    this.selectedDisposalId = i;
    this.selectedDisposal = this.penaltyProvidedData[i].id;
    this.splitVisible = true;
    this.amount2 = this.penaltyProvidedData[this.selectedDisposalId].amount - this.amount1;
  }

  checkAmount() {

    if (this.penaltyProvidedData[this.selectedDisposalId].amount < this.amount1) {
      this.amount1 = 0;
    }
    this.amount2 = this.penaltyProvidedData[this.selectedDisposalId].amount - this.amount1;
  }
  splitAmount() {
    console.log(this.amount1);
    if (this.amount1 <= 0 || this.amount1 == this.penaltyProvidedData[this.selectedDisposalId].amount || !this.checkNum(this.amount1)) {
      this.amount1=0;
      this.amount2 = this.penaltyProvidedData[this.selectedDisposalId].amount - this.amount1;
      this.message.error("Invalid Split Amount Provided.")
      return;
    }
    this.loading1 = true;
    this.loading2 = true;

    var formData = new FormData();
    formData.set("id", this.selectedDisposal + "");
    formData.set("amount", this.amount1 + "");


    this.rbiPenaltyDisposalService.splitPenaltyAmount(formData).subscribe(
      (res) => {

        if (res) {
          this.message.success("Penalty Amount got Split Succesfully.");
        }
        else {
          this.message.success("Unable to Split Penalty Amount. Contact Admin.");
        }
        this.loading1 = false;
        this.loading2 = false;
        this.splitVisible = false;
        this.open(this.selectedPenaltyData);
        console.log(res);
        this.amount1 = 0;
        this.amount2 = 0;
      },
      (err) => {
        this.loading1 = false;
        this.loading2 = false;
        this.splitVisible = false;
        console.log(err);
        this.amount1 = 0;
        this.amount2 = 0;
      }
    );


  }


  today=new Date();

  disabledDate = (current: Date): boolean => {
    

    return (
      differenceInCalendarDays(current, this. today) > 0 );
  };

  
  checkNum(val: any)
  {
    let isnum = /^\d+$/.test((val+"").replace(".",""));
    console.log(val+" "+isnum);
    return isnum;
  }


}
