import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-chest-slip',
  templateUrl: './upload-chest-slip.component.html',
  styleUrls: ['./upload-chest-slip.component.less'],
})
export class UploadChestSlipComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
