import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { UploadChestSlipComponent } from './upload-chest-slip.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CcPositionModule } from 'src/app/branch/cc-position/cc-position.module';

const routes: Routes = [
  {
    path: '',
    component: UploadChestSlipComponent,
  },
];

@NgModule({
  declarations: [UploadChestSlipComponent],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule, CcPositionModule],
})
export class UploadChestSlipModule {}
