import { TestBed } from '@angular/core/testing';

import { RbiPenaltyUpdationStatusService } from './rbi-penalty-updation-status.service';

describe('RbiPenaltyUpdationStatusService', () => {
  let service: RbiPenaltyUpdationStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RbiPenaltyUpdationStatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
