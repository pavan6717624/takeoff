import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { PenaltyReport } from './rbi-penalty-updation-status.component';


@Injectable({
  providedIn: 'root'
})
export class RbiPenaltyUpdationStatusService {

  constructor(private http: HttpClient) { }

  getCircles(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/getCirclesList`);
  }

  getFslos(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getFslos`, formData);
  }

  getPenaltyReports(formData: FormData): Observable<any> {
    return this.http.post(`${environment.apiUrl}/getPenaltyReports`, formData);
  }

  downloadPenaltyReports(penaltyReport: PenaltyReport): Observable<any> {
    return this.http.post(`${environment.apiUrl}/downloadPenaltyReport`, penaltyReport,{responseType: 'blob'});
  }

}


