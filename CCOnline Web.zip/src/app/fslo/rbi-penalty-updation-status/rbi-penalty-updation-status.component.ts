import { Component, OnInit } from '@angular/core';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { DatePipe } from '@angular/common';
import {RbiPenaltyUpdationStatusService} from './rbi-penalty-updation-status.service';
import { NzMessageService } from 'ng-zorro-antd/message';
export class PenaltyReport
{
  data: string[][];
  headers: string[];
}

@Component({
  selector: 'app-rbi-penalty-updation-status',
  templateUrl: './rbi-penalty-updation-status.component.html',
  styleUrls: ['./rbi-penalty-updation-status.component.less']
})
export class RbiPenaltyUpdationStatusComponent implements OnInit {


  fromdate: Date;
  todate: Date;
  status: boolean = false;
  report: string='';
  reportName: string='';
  penaltyReport: PenaltyReport;
  circles: string[];
  circle: string;
  fslos: string[];
  fslo: string;
  
  constructor(private rbiPenaltyUpdationStatusService: RbiPenaltyUpdationStatusService,private message:NzMessageService) { }



  today=new Date();

  disabledDate1 = (current: Date): boolean => {
    

    return (
      differenceInCalendarDays(current, this. today) > 0 );
  };



  disabledDate = (current: Date): boolean => {

    return (
      differenceInCalendarDays(current, this. today) > 0 ||  differenceInCalendarDays(current, this.fromdate) < 0 || differenceInCalendarDays(current, this.fromdate) < 0 || differenceInCalendarDays(current,this.fromdate) > 365);
  };

  getCircles()
  {
    this.status=true;
    this.rbiPenaltyUpdationStatusService.getCircles().subscribe(
      (res) => {
        this.status=false;
        this.circles=res;
        this.circle = this.circles[0];
        console.log(res);
        this.getFslos();
      },
      (err) =>
      {
        this.status=false;
        this.circles=null;
        console.log(err);
      }
     
    );
  }

  ngOnInit(): void {
    this.getCircles();
   
  }
  onFsloChange()
{
  this.penaltyReport=null;
}
onCircleChange()
{
  this.penaltyReport=null;
  this.getFslos();
}

getFslos()
  {
    this.status=true;
    var formData = new FormData();
    
   console.log(this.circle);
    formData.set("circle",this.circle);
    this.rbiPenaltyUpdationStatusService.getFslos(formData).subscribe(
      (res) => {
        this.status=false;
        this.fslos=res;
        this.fslo=this.fslos[0];
       
        console.log(res);
     
      },
      (err) =>
      {
        this.status=false;
        this.fslos=null;
        console.log(err);
      }
     
    );
  }

  download()
  {
    this.rbiPenaltyUpdationStatusService.downloadPenaltyReports(this.penaltyReport).subscribe(
      (res) => {
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(new Blob([res], {type: 'text/csv'}));
        link.download =  this.report+'.csv';
        link.click();
        link.remove();
      });
  }
onChangeFromDate()
{
  this.penaltyReport=null;
  this.todate=null;
}

onChangeToDate()
{
  this.penaltyReport=null;
}

onChangeReport()
{
  this.penaltyReport=null;
  this.fromdate=null;
  this.todate=null;
}
  generateReport()
  {
  var formData = new FormData();
  var datePipe = new DatePipe('en-US');
  formData.set("fromdate",datePipe.transform(this.fromdate, 'dd/MM/yyyy'));
  formData.set("todate",datePipe.transform(this.todate, 'dd/MM/yyyy'));
  formData.set("report",this.report);
  formData.set("circle",this.circle);
  formData.set("fslo",this.fslo);

  if(this.report == null || this.report=="")
  {
this.message.create("error","Please Select Report Name.");
  }
  if(this.fromdate== null)
  {
this.message.create("error","Please Select From Date.");
  }
  if(this.todate== null)
  {
this.message.create("error","Please Select To Date.");
  }
  if(this.circle==null)
  {
    this.message.create("error","Please Select Circle.");
  }
  if(this.fslo==null)
  {
    this.message.create("error","Please Select FSLO.");
  }



  if(this.fromdate!= null && this.todate!=null && this.report != null && this.circle!=null && this.fslo!=null)
  {
    this.status=true;
    this.rbiPenaltyUpdationStatusService.getPenaltyReports(formData).subscribe(
      (res) => {
        this.status=false;
        this.penaltyReport=res;
        if(this.penaltyReport == null || this.penaltyReport.data == null || this.penaltyReport.data.length == 0)
        {
          this.message.create("error","No Records Found.")
        }
        console.log(res);
     
      },
      (err) =>
      {
        this.status=false;
        this.penaltyReport=null;
        console.log(err);
      }
     
    );
  }
  

  }

}
