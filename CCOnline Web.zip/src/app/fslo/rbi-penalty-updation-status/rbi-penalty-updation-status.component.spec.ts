import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RbiPenaltyUpdationStatusComponent } from './rbi-penalty-updation-status.component';

describe('RbiPenaltyUpdationStatusComponent', () => {
  let component: RbiPenaltyUpdationStatusComponent;
  let fixture: ComponentFixture<RbiPenaltyUpdationStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RbiPenaltyUpdationStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RbiPenaltyUpdationStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
