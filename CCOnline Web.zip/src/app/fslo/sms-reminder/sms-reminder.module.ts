import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SmsReminderComponent } from './sms-reminder.component';
import { RouterModule, Routes } from '@angular/router';
import { CblExceededComponent } from './cbl-exceeded/cbl-exceeded.component';
import { CcBalanceComponent } from './cc-balance/cc-balance.component';
import { CcNetComponent } from './cc-net/cc-net.component';
import { CsNotUploadedComponent } from './cs-not-uploaded/cs-not-uploaded.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ReminderListComponent } from './reminder-list/reminder-list.component';
import { InrFormatPipe } from 'src/app/shared/pipe/inr-format.pipe';

const route: Routes = [
  {
    path: '',
    component: SmsReminderComponent,
    children: [
      { path: '', component: ReminderListComponent },
      { path: 'bgl98908', component: CcNetComponent },
      { path: 'bgl98958', component: CcBalanceComponent },
      { path: 'cbl', component: CblExceededComponent },
      { path: 'cs-pending', component: CsNotUploadedComponent },
    ],
  },
];

@NgModule({
  declarations: [
    SmsReminderComponent,
    CblExceededComponent,
    CcBalanceComponent,
    CcNetComponent,
    CsNotUploadedComponent,
    ReminderListComponent,
  ],
  imports: [CommonModule, RouterModule.forChild(route), SharedModule],
  providers: [InrFormatPipe],
})
export class SmsReminderModule {}
