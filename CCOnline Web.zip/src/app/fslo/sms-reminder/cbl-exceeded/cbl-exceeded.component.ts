import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { CblExceededModel } from '../cbl-exceeded-model';
import { SmsReminderService } from '../sms-reminder.service';

@Component({
  selector: 'app-cbl-exceeded',
  templateUrl: './cbl-exceeded.component.html',
  styles: [
    `
      .send-request {
        margin-bottom: 16px;
        text-align: right;
      }

      .send-request span {
        margin-right: 8px;
      }
    `,
  ],
})
export class CblExceededComponent implements OnInit, OnDestroy {
  loading = false;
  checked = false;
  indeterminate = false;

  fetchingData = false;
  fetchedData = false;
  exccededBy: number;

  private exccededBySub: Subscription;
  form: FormGroup;

  data: CblExceededModel[];
  currentPageData: CblExceededModel[];

  selectedBranches = new Set<number>();

  constructor(private message: NzMessageService, private smsService: SmsReminderService, private log: NGXLogger, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      exceededBy: ['', [Validators.required, Validators.min(50), Validators.max(100), Validators.pattern('\\d{2,3}')]],
    });

    // when the value changes after data has been fetched, reset the states
    this.exccededBySub = this.form.get('exceededBy').valueChanges.subscribe(value => {
      if (this.fetchedData) {
        this.fetchedData = false;
        this.data = [];
        this.currentPageData = [];
        this.selectedBranches.clear();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.exccededBySub) {
      this.exccededBySub.unsubscribe();
    }
  }

  updatedSelectedBranches(branch: number, checked: boolean): void {
    if (checked) {
      this.selectedBranches.add(branch);
    } else {
      this.selectedBranches.delete(branch);
    }
  }

  refreshCheckedStatus(): void {
    const listOfEnabledData = this.currentPageData.filter(({ smsSent }) => !smsSent);
    this.checked = listOfEnabledData.every(({ branchCode }) => this.selectedBranches.has(branchCode));
    this.indeterminate = listOfEnabledData.some(({ branchCode }) => this.selectedBranches.has(branchCode)) && !this.checked;
  }

  onItemChecked(branchCode: number, checked: boolean): void {
    this.updatedSelectedBranches(branchCode, checked);

    this.log.debug('selected branches:', this.selectedBranches);

    this.refreshCheckedStatus();
  }

  onAllChecked(checked: boolean): void {
    this.currentPageData.filter(({ smsSent }) => !smsSent).forEach(({ branchCode }) => this.updatedSelectedBranches(branchCode, checked));
    this.refreshCheckedStatus();
  }

  onCurrentPageDataChange(currentPageData: CblExceededModel[]): void {
    this.currentPageData = currentPageData;
    this.refreshCheckedStatus();
  }

  fetchData(): void {
    this.log.debug('>> fetchData()');
    if (this.form.valid) {
      this.fetchingData = true;
      this.smsService.cblExceeded(this.form.get('exceededBy').value).subscribe(
        data => {
          this.data = data;
          this.fetchedData = true;
          this.fetchingData = false;
          this.selectedBranches.clear();
        },
        () => (this.fetchingData = false)
      );
    }
  }

  sendSms(): void {
    if (this.selectedBranches.size > 0) {
      this.loading = true;
      const requestData = this.data.filter(i => this.selectedBranches.has(i.branchCode));

      const by = this.form.get('exceededBy').value;
      let branchesArray = [];
      requestData.forEach(item => branchesArray.push(item.branchCode));

      this.smsService.cblExceededSubmit(by, branchesArray).subscribe(
        data => {
          this.message.success(data.message);
          this.loading = false;
          this.fetchData();
        },
        () => {
          this.loading = false;
        }
      );
    } else {
      this.message.warning('No branches selected');
    }
  }
}
