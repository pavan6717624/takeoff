export interface CblExceededModel {
  branchCode: number;
  branchName?: string;
  cashBalanceLimit?: number;
  accountantMobileNo?: number;
  coMobileNo?: number;
  bmMobileNo?: number;
  exceededBy?: number;
  cymClosingBalance?: number;
  smsSent?: boolean;
}
