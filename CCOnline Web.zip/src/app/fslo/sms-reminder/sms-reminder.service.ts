import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { CblExceededModel } from './cbl-exceeded-model';
import { BglDiff } from './model/bgl-diff.model';
import { CsNotUploaded } from './model/cs-not-uploaded.model';

@Injectable({ providedIn: 'root' })
export class SmsReminderService {
  constructor(private http: HttpClient) {}

  cblExceeded(by: number): Observable<CblExceededModel[]> {
    return this.http.get<CblExceededModel[]>(`${environment.apiUrl}/sms/cbl/${by}`);
  }

  cblExceededSubmit(exceededBy: number, branches: number[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/sms/cbl`, { exceededBy, branches });
  }

  csNotUploaded(): Observable<CsNotUploaded[]> {
    return this.http.get<CsNotUploaded[]>(`${environment.apiUrl}/sms/chest-slip`);
  }

  csNotUploadedSend(branches: number[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/sms/chest-slip`, { branches });
  }

  bgl98908diff(): Observable<BglDiff[]> {
    return this.http.get<BglDiff[]>(`${environment.apiUrl}/sms/net-diff`);
  }

  bgl98908diffSend(branches: number[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/sms/net-diff`, { branches });
  }

  bgl98958diff(): Observable<BglDiff[]> {
    return this.http.get<BglDiff[]>(`${environment.apiUrl}/sms/cb-diff`);
  }

  bgl98958diffSend(branches: number[]): Observable<any> {
    return this.http.post(`${environment.apiUrl}/sms/cb-diff`, { branches });
  }
}
