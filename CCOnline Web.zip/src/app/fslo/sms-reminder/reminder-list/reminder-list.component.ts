import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reminder-list',
  templateUrl: './reminder-list.component.html',
  styleUrls: ['./reminder-list.component.less'],
})
export class ReminderListComponent implements OnInit {
  gridStyle = {
    width: '25%',
    textAlign: 'center',
  };

  constructor() {}

  ngOnInit(): void {}
}
