export interface CsNotUploaded {
  branchCode: number;
  branchName: string;
  bmMobileNo: any;
  accountantMobileNo?: number;
  coMobileNo?: number;
  lastUploadedOn: string;
  smsSent?: boolean;
}
