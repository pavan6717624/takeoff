export interface BglDiff {
  branchName: string;
  branchCode: number;
  bglValue: number;
  cymValue: any;
  difference: any;
  bmMobileNo?: any;
  coMobileNo?: number;
  accountantMobileNo?: number;
  smsSent?: boolean;
}
