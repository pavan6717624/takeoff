import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NGXLogger } from 'ngx-logger';
import { BglDiff } from '../model/bgl-diff.model';
import { SmsReminderService } from '../sms-reminder.service';

@Component({
  selector: 'app-cc-balance',
  templateUrl: './cc-balance.component.html',
  styles: [
    `
      .send-request {
        margin-bottom: 16px;
        text-align: right;
      }

      .send-request span {
        margin-right: 8px;
      }
    `,
  ],
})
export class CcBalanceComponent implements OnInit {
  loading = false;
  checked = false;
  indeterminate = false;

  data: BglDiff[];
  currentPageData: BglDiff[];

  selectedBranches = new Set<number>();

  constructor(private message: NzMessageService, private smsService: SmsReminderService, private log: NGXLogger, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.fetchData();
  }

  updatedSelectedBranches(branch: number, checked: boolean): void {
    if (checked) {
      this.selectedBranches.add(branch);
    } else {
      this.selectedBranches.delete(branch);
    }
  }

  refreshCheckedStatus(): void {
    const listOfEnabledData = this.currentPageData.filter(({ smsSent }) => !smsSent);
    this.checked = listOfEnabledData.every(({ branchCode }) => this.selectedBranches.has(branchCode));
    this.indeterminate = listOfEnabledData.some(({ branchCode }) => this.selectedBranches.has(branchCode)) && !this.checked;
  }

  onItemChecked(branchCode: number, checked: boolean): void {
    this.updatedSelectedBranches(branchCode, checked);

    this.log.debug('selected branches:', this.selectedBranches);

    this.refreshCheckedStatus();
  }

  onAllChecked(checked: boolean): void {
    this.currentPageData.filter(({ smsSent }) => !smsSent).forEach(({ branchCode }) => this.updatedSelectedBranches(branchCode, checked));
    this.refreshCheckedStatus();
  }

  onCurrentPageDataChange(currentPageData: BglDiff[]): void {
    this.currentPageData = currentPageData;
    this.refreshCheckedStatus();
  }

  fetchData(): void {
    this.log.debug('>> fetchData()');
    this.loading = true;
    this.smsService.bgl98958diff().subscribe(
      data => {
        this.data = data;
        this.loading = false;
        this.selectedBranches.clear();
      },
      () => (this.loading = false)
    );
  }

  sendSms(): void {
    if (this.selectedBranches.size > 0) {
      this.loading = true;
      const requestData = this.data.filter(i => this.selectedBranches.has(i.branchCode));
      console.log('Request data:', requestData, this.selectedBranches);

      let branchesArray = [];
      requestData.forEach(item => branchesArray.push(item.branchCode));

      this.smsService.bgl98958diffSend(branchesArray).subscribe(
        data => {
          this.message.success(data.message);
          this.loading = false;
          this.fetchData();
        },
        () => {
          this.loading = false;
        }
      );
    } else {
      this.message.warning('No branches selected');
    }
  }
}
