import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-reminder',
  templateUrl: './sms-reminder.component.html',
  styleUrls: ['./sms-reminder.component.less'],
})
export class SmsReminderComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {}
}
