import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { DownloadEkuberStmtComponent } from './download-ekuber-stmt/download-ekuber-stmt.component';
import { ChestSlipNotUploadedBranchesComponent } from 'src/app/abd/chest-slip-not-uploaded-branches/chest-slip-not-uploaded-branches.component';
import { ChestSlipUploadedBranchesComponent } from '../abd/chest-slip-uploaded-branches/chest-slip-uploaded-branches.component';
import { ChestBranchesAboveCglComponent } from '../abd/chest-branches-above-cgl/chest-branches-above-cgl.component';
import { BglCcDifferenceComponent } from '../abd/bgl-cc-difference/bgl-cc-difference.component';
import { RbiPenaltyDataEntryComponent } from './rbi-penalty-data-entry/rbi-penalty-data-entry.component';
import { RbiPenaltyDisposalComponent } from './rbi-penalty-disposal/rbi-penalty-disposal.component';
import { CustomReportsComponent } from '../abd/custom-reports/custom-reports.component';
import { RbiPenaltyUpdationStatusComponent } from './rbi-penalty-updation-status/rbi-penalty-updation-status.component';
import { MonthlyCertificateComponent } from './monthly-certificate/monthly-certificate.component';
import { VsSummaryComponent } from './monthly-certificate/vs-summary/vs-summary.component';
import { DisplayVsListModalComponent } from './monthly-certificate/display-vs-list-modal/display-vs-list-modal.component';
import { NsmReportComponent } from './nsm-report/nsm-report.component';
import { CcBranchesComponent } from '../abd/cc-branches/cc-branches.component';
import { BrSummaryComponent } from '../abd/cc-branches/br-summary/br-summary.component';
import { ClosedBranchesComponent } from '../abd/cc-branches/closed-branches/closed-branches.component';
import { CcClosureComponent } from '../abd/cc-closure/cc-closure.component';
import { AutoAlertsComponent } from '../branch/auto-alerts/auto-alerts.component';
import { ChestBranchesAboveCglConsecutiveComponent } from '../abd/chest-branches-above-cgl-consecutive/chest-branches-above-cgl-consecutive.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        redirectTo: 'upload-chest-slip',
        pathMatch: 'full',
      },
      {
        path: 'upload-chest-slip',
        loadChildren: () => import('./upload-chest-slip/upload-chest-slip.module').then(m => m.UploadChestSlipModule),
      },
      {
        path: 'view-chest-slip',
        loadChildren: () => import('./view-chest-slip/view-chest-slip.module').then(m => m.ViewChestSlipModule),
      },
      {
        path: 'download-ekuber-stmt',
        component: DownloadEkuberStmtComponent,
      },
      {
        path: 'cc-closure',
        component: CcClosureComponent,
      },
      {
        path: 'chest-slip-not-uploaded-branches',
        component: ChestSlipNotUploadedBranchesComponent,
      },
      {
        path: 'chest-slip-uploaded-branches',
        component: ChestSlipUploadedBranchesComponent,
      },
      {
        path: 'chest-branches-above-cbl',
        component: ChestBranchesAboveCglComponent,
      },
      {
        path: 'consecutiveDaysReport',
        component: ChestBranchesAboveCglConsecutiveComponent,
      },
      {
        path: 'bgl-cc-difference',
        component: BglCcDifferenceComponent,
      },
      {
        path: 'rbi-penalty-data-entry',
        component: RbiPenaltyDataEntryComponent,
      },
      {
        path: 'rbi-penalty-disposal',
        component: RbiPenaltyDisposalComponent,
      },
      {
        path: 'custom-reports',
        component: CustomReportsComponent,
      },
      {
        path: 'penalty-reports',
        component: RbiPenaltyUpdationStatusComponent,
      },

      { path: 'autoAlertSettings', component: AutoAlertsComponent},
      
      {
        path: 'monthly-certificate-reports',
        // component: MonthlyCertificateComponent,
        children: [
          { path: '', redirectTo: 'summary', pathMatch: 'full' },
          { path: 'summary', component: MonthlyCertificateComponent },
          { path: 'vs-summary', component: VsSummaryComponent },
        ],
      },
      {
        path: 'nsm-reports',
        component: NsmReportComponent,
      },
      {
        path: 'cc-branches',
        children: [
          { path: '', redirectTo: 'branches', pathMatch: 'full' },
          { path: 'branches', component: CcBranchesComponent },
        ],
      },
      {
        path: 'sms',
        loadChildren: () => import('./sms-reminder/sms-reminder.module').then(m => m.SmsReminderModule),
      },
    ],
  },
];

@NgModule({
  declarations: [
    DownloadEkuberStmtComponent,
    RbiPenaltyDataEntryComponent,
    RbiPenaltyDisposalComponent,
    RbiPenaltyUpdationStatusComponent,
    MonthlyCertificateComponent,
    VsSummaryComponent,
    DisplayVsListModalComponent,
    NsmReportComponent,
    CcClosureComponent,
  ],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule],
})
export class FsloModule {}
