import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadEkuberStmtComponent } from './download-ekuber-stmt.component';

describe('DownloadEkuberStmtComponent', () => {
  let component: DownloadEkuberStmtComponent;
  let fixture: ComponentFixture<DownloadEkuberStmtComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DownloadEkuberStmtComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadEkuberStmtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
