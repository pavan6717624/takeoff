import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import {DownloadEkuberStmtService} from './download-ekuber-stmt.service'
import { environment } from 'src/environments/environment';
import { NzMessageService } from 'ng-zorro-antd/message';
export class FlsoEkuberFile
{
ct: number;
deposit: number;
withdrawal: number;
filePath: string;
fsloCode: number;
fsloName: string;
date: Date;
}



@Component({
  selector: 'app-download-ekuber-stmt',
  templateUrl: './download-ekuber-stmt.component.html',
  styleUrls: ['./download-ekuber-stmt.component.less']
})
export class DownloadEkuberStmtComponent implements OnInit {

  server = `${environment.apiUrl}`;
  date: Date;
  flsoEkuberFile: FlsoEkuberFile;
  status: boolean= false;
  constructor(private downloadEkuberStmtService: DownloadEkuberStmtService,private message: NzMessageService ) { }

  ngOnInit(): void {
  }
 
  onChange(): void {
    var datePipe = new DatePipe('en-US');
    var date = datePipe.transform(this.date, 'dd/MM/yyyy');
    console.log('date: ', date);
    var formData = new FormData();
    formData.set("date",date);
    if(date!= null)
    {
      this.status = true;
      this.downloadEkuberStmtService.getRBIBGLStatement(formData).subscribe(
        (res) => {
        this.flsoEkuberFile = res;
        if(this.flsoEkuberFile.fsloCode == null)
        this.message.create("error","No Data Found");
        this.status = false;
        },
        (err) =>
        {
          this.message.create("error","Error Occued. Please try Again");
          this.status = false;
        }
       
      );
    }

  }




}
