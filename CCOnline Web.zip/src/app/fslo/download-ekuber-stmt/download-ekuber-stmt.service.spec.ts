import { TestBed } from '@angular/core/testing';

import { DownloadEkuberStmtService } from './download-ekuber-stmt.service';

describe('DownloadEkuberStmtService', () => {
  let service: DownloadEkuberStmtService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DownloadEkuberStmtService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
