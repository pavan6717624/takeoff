import { Component, Input, OnInit } from '@angular/core';
import { MonthlyCertificateService } from '../monthly-certificate.service';

interface InputData {
  selectedMonth: string;
  displayOrder: number;
  yes: boolean;
}

@Component({
  selector: 'app-display-vs-list-modal',
  templateUrl: './display-vs-list-modal.component.html',
  styleUrls: ['./display-vs-list-modal.component.less']
})
export class DisplayVsListModalComponent implements OnInit {
  @Input() data: InputData;

  constructor(
    private monthlyCertificateService: MonthlyCertificateService,
  ) { }

  details: any[];
  
  ngOnInit(): void {
    this.monthlyCertificateService.getVsYesList(this.data.selectedMonth, this.data.displayOrder, this.data.yes ).subscribe(
        value => {
          console.log('Details:', value);
          this.details = value;
          //this.loaded = true;
        },
        error => {
          console.log(' Detailed Report error: ', error);
        }
      );
  }

}
