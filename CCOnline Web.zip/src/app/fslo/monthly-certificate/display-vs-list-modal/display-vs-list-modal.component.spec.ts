import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayVsListModalComponent } from './display-vs-list-modal.component';

describe('DisplayVsListModalComponentComponent', () => {
  let component: DisplayVsListModalComponent;
  let fixture: ComponentFixture<DisplayVsListModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayVsListModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayVsListModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
