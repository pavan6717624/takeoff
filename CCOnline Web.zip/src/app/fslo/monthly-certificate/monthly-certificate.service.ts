import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Option } from 'src/app/shared/models/option.model';
import { environment } from 'src/environments/environment';
import { MonthlyCertificateSubmissionSummary, MonthlyCertificateDetailedReport, MonthlyCertificateVsSummary, MonthlyCertificateVsYesList } from './monthly-certificate.model';

@Injectable({ providedIn: 'root' })
export class MonthlyCertificateService {
  constructor(private http: HttpClient) {}

  getMonths(): Observable<Option[]> {
    return this.http.get<Option[]>(`${environment.apiUrl}/monthlycertificate/months`);
  }

  getSummary(month: string): Observable<MonthlyCertificateSubmissionSummary>{
    let params = new HttpParams();
    params = params.append('month', month);
    return this.http.get<MonthlyCertificateSubmissionSummary>(`${environment.apiUrl}/monthlycertificate/summary`, { params: params })
  }

  getDetails(month: string): Observable<MonthlyCertificateDetailedReport[]>{
    let params = new HttpParams();
    params = params.append('month', month);
    console.log('Params:', month);
    return this.http.get<MonthlyCertificateDetailedReport[]>(`${environment.apiUrl}/monthlycertificate/details`, { params: params })
  }

  getVsSummary(month: string): Observable<MonthlyCertificateVsSummary[]>{
    let params = new HttpParams();
    params = params.append('month', month);
    console.log('Params:', month);
    return this.http.get<MonthlyCertificateVsSummary[]>(`${environment.apiUrl}/monthlycertificate/vssummary`, { params: params })
  }
  
  getVsYesList(month: string, displayOrder: number, yes: boolean): Observable<MonthlyCertificateVsYesList[]>{
    console.log('month :', month + ' displayOrder: ', displayOrder + ' option: ', yes);

    let params = new HttpParams();
    params = params.append('month', month);
    params = params.append('displayOrder', String(displayOrder));
    params = params.append('yes', String(yes));
    
    return this.http.get<MonthlyCertificateVsYesList[]>(`${environment.apiUrl}/monthlycertificate/vslistyes`, { params: params })
  }
}
