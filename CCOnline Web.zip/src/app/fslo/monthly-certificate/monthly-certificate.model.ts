export interface MonthlyCertificateSubmissionSummary{
    notSubmitted: number;
    submitted: number;
}

export interface MonthlyCertificateDetailedReport{
    circleCode: number;
    circleName: String;
    networkCode: number;
    moduleCode: number;
    moduleName: String;
    regionCode: number;
    branchCode: number;
    branchName: String;
    submitted: String;
}

export interface MonthlyCertificateVsSummary {
    displayNo: String;
    displayOrder: number;
    headerOnly: boolean;
    description: String;
    inputYes: number;
    inputNo: number;
    
}

export interface MonthlyCertificateVsYesList {
    circleCode: number;
    circleName: String;
    networkCode: number;
    moduleCode: number;
    moduleName: String;
    regionCode: number;
    branchCode: number;
    branchName: String;    
}