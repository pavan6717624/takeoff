import { Component, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { MonthlyCertificateService } from '../monthly-certificate.service';
import { Option } from 'src/app/shared/models/option.model';
import { ModalHelper } from '@delon/theme';
import { DisplayVsListModalComponent } from '../display-vs-list-modal/display-vs-list-modal.component';

@Component({
  selector: 'app-vs-summary',
  templateUrl: './vs-summary.component.html',
  styleUrls: ['./vs-summary.component.less']
})
export class VsSummaryComponent implements OnInit {

  constructor(
    private monthlyCertificateService: MonthlyCertificateService,
    private notification: NzNotificationService,
    private log: NGXLogger,
    private modalHelper: ModalHelper,
  ) { }

  months: Option[];
  month: string;
  loaded = false;
  details: any[];
  selectedMonth: string;
  isLoading = false;

  ngOnInit(): void {
    this.monthlyCertificateService.getMonths().subscribe(monthsRes => {
      this.log.debug('monthsRes: {}', monthsRes);
      this.months = monthsRes;
     
    });
  }

  monthChanged(e: any): void {
    this.log.debug('month changed: ', e);
    this.selectedMonth = e;
    this.isLoading = true;
    this.loadSummary(e);
  }

  loadSummary(month: string): void {
    this.monthlyCertificateService.getVsSummary(month).subscribe(
      value => {
        console.log('Details:', value);
        this.details = value;
        this.loaded = true;
      },
      error => {
        console.log(' Detailed Report error: ', error);
      },
      () => (this.isLoading = false)
    );
  }

  displayVsYesListModal(displayOrder: number, yes: boolean): void {
    console.log('Ts: displayOrder: ', displayOrder);
    console.log('Ts: Option: ', yes);
    console.log('Ts: Month: ', this.selectedMonth);
    this.modalHelper
      .create(DisplayVsListModalComponent, { data: { selectedMonth: this.selectedMonth, displayOrder, yes} }, { size: 'lg' })
      .subscribe(res => {
        this.log.debug(res);
      });

    // this.monthlyCertificateService.getVsYesList(this.selectedMonth, displayNo).subscribe(
    //   value => {
    //     console.log('Details:', value);
    //     this.details = value;
    //     //this.loaded = true;
    //   },
    //   error => {
    //     console.log(' Detailed Report error: ', error);
    //   }
    // );

  }

}
