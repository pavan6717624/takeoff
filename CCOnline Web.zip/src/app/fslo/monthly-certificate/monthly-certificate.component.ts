import { Component, OnInit, ViewChild } from '@angular/core';

import { NGXLogger } from 'ngx-logger';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { MonthlyCertificateService } from './monthly-certificate.service';
import { Option } from 'src/app/shared/models/option.model';
import { MonthlyCertificateSubmissionSummary, MonthlyCertificateDetailedReport } from './monthly-certificate.model';
import { environment } from 'src/environments/environment';
import { STColumn, STComponent, STPage } from '@delon/abc/st';

@Component({
  selector: 'app-monthly-certificate_mis',
  templateUrl: './monthly-certificate.component.html',
  styleUrls: ['./monthly-certificate.component.less'],
})
export class MonthlyCertificateComponent implements OnInit {
  constructor(
    private monthlyCertificateService: MonthlyCertificateService,
    private notification: NzNotificationService,
    private log: NGXLogger
  ) {}
  months: Option[];
  month: string;
  summary: MonthlyCertificateSubmissionSummary;
  loaded = false;
  details: any[];

  selectedMonth: string;
  isLoading = false;

  pagerConfig: STPage = { front: true, simple: true };

  @ViewChild('st', { static: false }) private st: STComponent;

  columns: STColumn[] = [
    { title: 'Circle', index: 'circleName' },
    { title: 'Network', index: 'networkCode', className: 'text-center' },
    { title: 'Module Code', index: 'moduleCode', className: 'text-center' },
    { title: 'Module Name', index: 'moduleName' },
    { title: 'Region Code', index: 'regionCode', className: 'text-center' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-center' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'Submitted', index: 'submitted', className: 'text-center' },
  ];

  //get data from server
  ngOnInit(): void {
    this.monthlyCertificateService.getMonths().subscribe(monthsRes => {
      this.log.debug('monthsRes: {}', monthsRes);
      this.months = monthsRes;
      
    });
  }

  // dataUrl(): string {
  //   if (this.selectedMonth) {
  //     return `${environment.apiUrl}/monthlycertificate/details`;
  //   }
  //   return '';
  // }

  requestParams(): any {
    if (this.selectedMonth) {
      return { month: this.selectedMonth };
    }
  }

  monthChanged(e: any): void {
    this.log.debug('month changed: ', e);
    this.selectedMonth = e;
    this.isLoading = true;
    this.loadSummary(e);
  }

  loadSummary(month: string): void {
    this.monthlyCertificateService.getSummary(month).subscribe(
      value => {
        console.log('Summary:', value);
        this.summary = value;
        this.loaded = true;
      },
      error => {
        console.log(' summary error: ', error);
      },
      () => (this.isLoading = false)
    );

    this.monthlyCertificateService.getDetails(month).subscribe(
      value => {
        console.log('Details:', value);
        this.details = value;
        this.loaded = true;
      },
      error => {
        console.log(' Detailed Report error: ', error);
      },
      () => (this.isLoading = false)
    );
  }
}
