import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-chest-slip',
  templateUrl: './view-chest-slip.component.html',
  styleUrls: ['./view-chest-slip.component.less']
})
export class ViewChestSlipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
