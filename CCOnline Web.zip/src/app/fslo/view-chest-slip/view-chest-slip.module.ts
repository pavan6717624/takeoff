import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ViewChestSlipComponent } from './view-chest-slip.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ViewChestSlipModule as ccChestSlipModule } from 'src/app/branch/view-chest-slip/view-chest-slip.module';

const routes: Routes = [
  {
    path: '',
    component: ViewChestSlipComponent,
  },
];


@NgModule({
  declarations: [ViewChestSlipComponent],
  imports: [
    CommonModule, RouterModule.forChild(routes), SharedModule, ccChestSlipModule],
  
})
export class ViewChestSlipModule { }



