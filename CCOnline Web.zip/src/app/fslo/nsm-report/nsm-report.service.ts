import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Option } from 'src/app/shared/models/option.model';
import { environment } from 'src/environments/environment';
import { NsmSubmissionSummary, NsmReport } from './nsm-report.model'

@Injectable({ providedIn: 'root' })
export class  NsmReportService{
  constructor(private http: HttpClient) {}

  getMonths(): Observable<Option[]> {
    return this.http.get<Option[]>(`${environment.apiUrl}/monthlycertificate/months`);
  }

  getSummary(month: string): Observable<NsmSubmissionSummary>{
    let params = new HttpParams();
    params = params.append('month', month);
    return this.http.get<NsmSubmissionSummary>(`${environment.apiUrl}/nsms/reportSummary`, { params: params })
  }

  getDetails(month: string): Observable<NsmReport[]>{
    let params = new HttpParams();
    params = params.append('month', month);
    console.log('Params:', month);
    return this.http.get<NsmReport[]>(`${environment.apiUrl}/nsms/report`, { params: params })
  }

}
