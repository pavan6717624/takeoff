import { Component, OnInit, ViewChild } from '@angular/core';
import { STColumn, STComponent, STPage } from '@delon/abc/st';
import { Option } from 'src/app/shared/models/option.model';
import { environment } from 'src/environments/environment';
import { NGXLogger } from 'ngx-logger';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NsmReportService } from './nsm-report.service';
import { NsmSubmissionSummary } from './nsm-report.model';

@Component({
  selector: 'app-nsm-report',
  templateUrl: './nsm-report.component.html',
  styleUrls: ['./nsm-report.component.less']
})
export class NsmReportComponent implements OnInit {

  constructor(
    private nsmReportService: NsmReportService,
    private notification: NzNotificationService,
    private log: NGXLogger
  ) { }

  months: Option[];
  month: string;
  loaded = false;
  selectedMonth: string;
  details: any[];
  summary: NsmSubmissionSummary;
  pagerConfig: STPage = { front: true, simple: true };
  isLoading = false;

  @ViewChild('st', { static: false }) private st: STComponent;

  columns: STColumn[] = [
    { title: 'Circle', index: 'circleName' },
    { title: 'Network', index: 'networkCode', className: 'text-center' },
    { title: 'Module Code', index: 'moduleCode', className: 'text-center' },
    { title: 'Module Name', index: 'moduleName' },
    { title: 'Region Code', index: 'regionCode', className: 'text-center' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-center' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'Submitted', index: 'submitted', className: 'text-center'},
  ];

  //get data from server
  ngOnInit(): void {
    this.nsmReportService.getMonths().subscribe(monthsRes => {
      this.log.debug('monthsRes: {}', monthsRes);
      this.months = monthsRes;
    });
  }

  monthChanged(e: any): void {
    this.log.debug('month changed: ', e);
    this.selectedMonth = e;
    this.isLoading = true;
    this.loadSummary(e);
  }

  loadSummary(month: string): void {
    this.nsmReportService.getSummary(month).subscribe(
      value => {
        console.log('Summary:', value);
        this.summary = value;
        this.loaded = true;
      },
      error => {
        console.log(' summary error: ', error);
      },
      () => (this.isLoading = false)
    );

    this.nsmReportService.getDetails(month).subscribe(
      value => {
        console.log('Details:', value);
        this.details = value;
        this.loaded = true;
      },
      error => {
        console.log(' Detailed Report error: ', error);
      },
      () => (this.isLoading = false)
    );
  }
  
  requestParams(): any {
    if (this.selectedMonth) {
      return { month: this.selectedMonth };
    }
  }

}
