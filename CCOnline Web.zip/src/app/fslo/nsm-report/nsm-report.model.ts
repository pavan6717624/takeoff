export interface NsmSubmissionSummary{
    notSubmitted: number;
    submitted: number;
}

export interface NsmReport{
    circleCode: number;
    circleName: String;
    networkCode: number;
    moduleCode: number;
    moduleName: String;
    regionCode: number;
    branchCode: number;
    branchName: String;
    submitted: String;
}