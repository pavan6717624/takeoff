import { Component, Input, OnInit } from '@angular/core';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { NGXLogger } from 'ngx-logger';
import { Section } from 'src/app/shared/models/section.model';
import { VerificationService } from 'src/app/verification/service/verification.service';

interface InputData {
  verificationId: number;
  section: Section;
}

@Component({
  selector: 'app-display-section-modal',
  templateUrl: './display-section-modal.component.html',
  styleUrls: ['./display-section-modal.component.less'],
})
export class DisplaySectionModalComponent implements OnInit {
  @Input() data: InputData;

  constructor(private ref: NzModalRef, private log: NGXLogger, private verificationService: VerificationService) {}

  ngOnInit(): void {
    this.log.debug('input data:', this.data);
  }

  ok(): void {
    this.ref.close();
  }
}
