import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import { NzModalService } from 'ng-zorro-antd/modal';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { ModalHelper } from '@delon/theme';

import { Section } from 'src/app/shared/models/section.model';
import { VerificationSectionsVM } from 'src/app/shared/models/verification-sections.model';
import { VerificationService } from 'src/app/verification/service/verification.service';
import { DisplaySectionModalComponent } from '../display-section-modal/display-section-modal.component';

@Component({
  selector: 'app-sections-compliance',
  templateUrl: './sections-compliance.component.html',
  styles: [
    `
      nz-form-label {
        font-weight: 700;
      }
    `,
  ],
})
export class SectionsComplianceComponent implements OnInit, OnDestroy {
  gridStyle = {
    width: '25%',
    textAlign: 'center',
  };

  verificationId: number;
  model!: VerificationSectionsVM;
  commentsFrom: FormGroup = new FormGroup({});

  private routerParamSub: Subscription;

  sectionWisePending: { [key: number]: number } = {};

  constructor(
    private route: ActivatedRoute,
    private verificationService: VerificationService,
    private modalService: NzModalService,
    private modalHelper: ModalHelper,
    private notification: NzNotificationService,
    private fb: FormBuilder,
    public log: NGXLogger
  ) {}

  ngOnInit(): void {
    this.loadAndInitialize();
  }

  ngOnDestroy(): void {
    if (this.routerParamSub) {
      this.routerParamSub.unsubscribe();
    }
  }

  loadAndInitialize(): void {
    this.commentsFrom = this.fb.group({
      comments: ['', [Validators.required, Validators.maxLength(400)]],
    });

    this.routerParamSub = this.route.params.subscribe(params => {
      this.verificationId = params.verificationId;

      // get sections data from API
      this.verificationService.complianceSections(this.verificationId).subscribe(res => {
        this.model = res;

        //#region track section wise pending count (WIP)
        this.model.sections.forEach(section => {
          if (!section.isHeader && section.isValueStatementSection) {
            this.sectionWisePending[section.id + ''] = section.pending;
          }
        });
        this.log.debug('sectionWisePending:', this.sectionWisePending);
        //#endregion

        this.log.debug('compliance role: ', this.model.userRole);
        if (this.model?.userRole?.toString() === 'BRANCH_HEAD') {
          this.commentsFrom.controls.comments.setValue(this.model.branchHeadComments);
        } else if (this.model?.userRole?.toString() === 'SCRUTINIZER') {
          this.commentsFrom.controls.comments.setValue(this.model.scrutinizerComments);
        } else if (this.model?.userRole?.toString() === 'VERIFICATION_OFFICER') {
          this.commentsFrom.controls.comments.setValue(this.model.verificationOfficerComplianceComments);
        } else if (this.model?.userRole?.toString() === 'CLOSURE_AUTHORITY') {
          this.commentsFrom.controls.comments.setValue(this.model.closureComments);
        }
        this.gridStyle.width = 100 / this.model.sections.filter(s => !s.isValueStatementSection).length + '%';
      });

      this.log.debug('verification id from route: ', this.verificationId);
    });
  }

  sectionsForCards() {
    return this.model?.sections.filter(section => !section.isValueStatementSection);
  }

  displaySectionModal(section: Section): void {
    this.modalHelper
      .create(DisplaySectionModalComponent, { data: { verificationId: this.verificationId, section } }, { size: 'lg' })
      .subscribe(res => {
        this.log.debug(res);
      });
  }

  reject(): void {
    this.modalService.confirm({
      nzTitle: 'Are you sure?',
      nzContent: this.model?.rejectAction?.label,
      nzOnOk: () => {
        this.rejectConfirm();
      },
    });
  }

  private rejectConfirm(): void {
    if (this.model.isEditable && this.model.userRole.toString() !== 'BRANCH_MAKER') {
      this.verificationService.rejectCompliance(this.verificationId, this.commentsFrom.get('comments').value).subscribe(
        res => {
          this.notification.success('', `${res.message} Successful`);
          this.loadAndInitialize();
        },
        err => this.notification.error(this.model.rejectAction.label, err.error?.detail || 'An error occured')
      );
    }
  }

  submit(): void {
    this.modalService.confirm({
      nzTitle: 'Are you sure?',
      nzContent: this.model?.submitAction?.label,
      nzOnOk: () => {
        this.submitConfirm();
      },
    });
  }

  private submitConfirm(): void {
    if (this.model.isEditable && this.model.userRole.toString() === 'BRANCH_MAKER') {
      this.verificationService.submitCompliance(this.verificationId, '').subscribe(res => {
        this.notification.success('', `${res.message} Successful`);
        this.loadAndInitialize();
      });
    } else {
      if (this.commentsFrom.valid) {
        const comments = this.commentsFrom.get('comments').value;
        this.verificationService.submitCompliance(this.verificationId, comments).subscribe(res => {
          this.notification.success('', `${res.message} Successful`);
          this.loadAndInitialize();
        });
      }
    }
  }

  submitButtonDisabled(): boolean {
    if (this.model?.isEditable && this.model?.userRole?.toString() === 'BRANCH_MAKER') {
      let pendingCount = 0;
      this.model.sections.forEach(item => {
        if (item.isValueStatementSection && !item.isHeader) {
          pendingCount += item.pending;
        }
      });
      return pendingCount > 0;
    } else {
      return true;
    }
  }

  sectionPending(sectionId: number): boolean {
    this.log.debug('pending:', this.sectionWisePending[sectionId + '']);
    if (this.sectionWisePending[sectionId + ''] > 0) {
      return true;
    }
    return false;
  }

  updatePending($event): void {
    this.log.debug('updatePending', $event);
  }

  editingEnabled(): boolean {
    if (this.model.isEditable && this.model.userRole.toString() === 'BRANCH_MAKER') {
      return true;
    }
    return false;
  }

  actionsEnabled(): boolean {
    if (this.model.isEditable) {
      if (this.model.userRole.toString() !== 'BRANCH_MAKER' && this.commentsFrom && this.commentsFrom.get('comments')) {
        return this.commentsFrom.valid;
      } else {
        return true;
      }
    }
    return false;
  }
}
