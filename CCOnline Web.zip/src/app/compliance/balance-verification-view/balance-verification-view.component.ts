import { Component, Input, OnInit } from '@angular/core';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { Stock } from 'src/app/verification/balance-verification/balance-verification.component';
import { BalanceVerificationDetails } from 'src/app/verification/model/balance-verification-details.model';
import { VerificationService } from 'src/app/verification/service/verification.service';

@Component({
  selector: 'app-balance-verification-view',
  templateUrl: './balance-verification-view.component.html',
})
export class BalanceVerificationViewComponent implements OnInit {
  @Input() verificationId: number;
  dateFormat = DATE_FORMAT;
  balanceVerificationDetails!: BalanceVerificationDetails;
  stock: Stock;

  constructor(private verificationService: VerificationService) {}

  ngOnInit(): void {
    this.verificationService.getBalanceVerificationDetails(this.verificationId).subscribe(res => {
      this.balanceVerificationDetails = res;
      this.verificationService.getBalancesAsOn(this.verificationId, this.balanceVerificationDetails.balancesAsOn).subscribe(res2 => {
        this.stock = res2;
      });
    });
  }
}
