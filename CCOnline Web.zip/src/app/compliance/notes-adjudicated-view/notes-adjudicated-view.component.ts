import { Component, Input, OnInit } from '@angular/core';
import { NotesAdjudicatedDetails } from 'src/app/verification/notes-adjudicated/notes-adjudicated.component';
import { VerificationService } from 'src/app/verification/service/verification.service';

@Component({
  selector: 'app-notes-adjudicated-view',
  templateUrl: './notes-adjudicated-view.component.html',
  styleUrls: ['./notes-adjudicated-view.component.less'],
})
export class NotesAdjudicatedViewComponent implements OnInit {
  @Input() verificationId: number;
  data: NotesAdjudicatedDetails[];

  constructor(private verificationService: VerificationService) {}

  ngOnInit(): void {
    this.verificationService.notesAdjudicatedDetails(this.verificationId).subscribe(res => {
      this.data = res;
    });
  }
}
