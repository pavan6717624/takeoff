import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';
import { ValueStatementsComponent } from './value-statements/value-statements.component';
import { SectionsComplianceComponent } from './sections/sections-compliance.component';
import { BalanceVerificationViewComponent } from './balance-verification-view/balance-verification-view.component';
import { BranchProfileViewComponent } from './branch-profile-view/branch-profile-view.component';
import { NotesAdjudicatedViewComponent } from './notes-adjudicated-view/notes-adjudicated-view.component';
import { NotesVerificationViewComponent } from './notes-verification-view/notes-verification-view.component';
import { DisplaySectionModalComponent } from './display-section-modal/display-section-modal.component';
import { ValueStatementsViewComponent } from './value-statements/value-statements-view/value-statements-view.component';

@NgModule({
  declarations: [
    ValueStatementsComponent,
    SectionsComplianceComponent,
    BalanceVerificationViewComponent,
    BranchProfileViewComponent,
    NotesAdjudicatedViewComponent,
    NotesVerificationViewComponent,
    DisplaySectionModalComponent,
    ValueStatementsViewComponent,
  ],
  imports: [CommonModule, SharedModule, FormsModule, ReactiveFormsModule],
  exports: [
    ValueStatementsComponent,
    ValueStatementsViewComponent,
    SectionsComplianceComponent,
    BalanceVerificationViewComponent,
    BranchProfileViewComponent,
    NotesAdjudicatedViewComponent,
    NotesVerificationViewComponent,
  ],
})
export class ComplianceModule {}
