import { Component, Input, OnInit } from '@angular/core';
import { VerificationService } from 'src/app/verification/service/verification.service';
import { DenominationWiseDetailedVerification } from 'src/app/verification/notes-verification/notes-verification.component';

@Component({
  selector: 'app-notes-verification-view',
  templateUrl: './notes-verification-view.component.html',
  styleUrls: ['./notes-verification-view.component.less'],
})
export class NotesVerificationViewComponent implements OnInit {
  @Input() verificationId: number;
  denominationWiseDetails: DenominationWiseDetailedVerification[];

  constructor(private verificationService: VerificationService) {}

  ngOnInit(): void {
    this.verificationService.notesVerificationDetails(this.verificationId).subscribe(res => {
      this.denominationWiseDetails = res;
    });
  }
}
