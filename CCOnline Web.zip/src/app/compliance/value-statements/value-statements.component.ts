import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import { NGXLogger } from 'ngx-logger';

import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { ValueStatementCompliance } from 'src/app/verification/model/value-statement';
import { VerificationService } from '../../verification/service/verification.service';
import { FormGroup } from '@angular/forms';
import { VsControlServiceService } from 'src/app/verification/service/vs-control-service.service';
import { ValueStatementVerificationService } from 'src/app/verification/service/value-statement-verification.service';

export enum Compliance {
  YES = 'Yes',
  NO = 'No',
  NA = 'Not Applicable',
}

@Component({
  selector: 'app-comp-vs',
  templateUrl: './value-statements.component.html',
  styles: [
    `
      [nz-radio] {
        display: block;
        height: 32px;
        line-height: 32px;
      }
    `,
  ],
})
export class ValueStatementsComponent implements OnInit, OnDestroy {
  //#region global data
  dateFormat = DATE_FORMAT;
  //#endregion

  //#region subscriptions
  private router$!: Subscription;
  //#endregion

  //#region loaders
  loading = true;
  showOnlyNotComplied = false;
  //#endregion

  //#region input data
  @Input() verificationId: number;
  @Input() sectionId: number;
  @Input() edit: boolean;
  //#endregion

  @Output() pendingEvent = new EventEmitter<any>();

  //#region form related
  form: FormGroup = new FormGroup({});
  formChangesSub: Subscription;
  formInitialState: any;
  savedStatus = new Map<string, boolean>();
  //#endregion

  //#region data
  totalData: ValueStatementCompliance[] = [];
  valueStatements: ValueStatementCompliance[] = [];
  //#endregion

  constructor(
    private route: ActivatedRoute,
    private verificationService: VerificationService,
    private vsvs: ValueStatementVerificationService,
    private vscs: VsControlServiceService,
    private log: NGXLogger
  ) {}

  ngOnInit(): void {
    this.log.trace('input params', this.verificationId, this.sectionId, this.edit);

    this.verificationService.valueStatementWithCompliance(this.verificationId, this.sectionId).subscribe(res => {
      this.totalData = res;
      this.valueStatements = res;

      this.form = this.vscs.toComplianceFormGroup(this.valueStatements);

      this.formInitialState = this.form.value;

      Object.keys(this.form.controls).forEach(key => {
        if (this.form.controls[key].value.branchCompliance) {
          this.savedStatus.set(key, true);
        } else {
          this.savedStatus.set(key, false);
        }
      });

      this.formChangesSub = this.form.valueChanges.subscribe(change => {
        this.handleFormChanges(change);
      });

      this.loading = false;
    });

    this.loading = false;
  }

  ngOnDestroy(): void {
    if (this.router$) {
      this.router$.unsubscribe();
    }
    if (this.formChangesSub) {
      this.formChangesSub.unsubscribe();
    }
  }

  handleFormChanges(changes: any): void {
    Object.keys(changes).forEach(item => {
      if (
        this.formInitialState[item].branchCompliance !== changes[item].branchCompliance ||
        this.formInitialState[item].branchComments !== changes[item].branchComments
      ) {
        this.log.trace('data changes for ' + item, this.formInitialState[item], changes[item]);
        this.savedStatus.set(item, false);
      }
    });
    this.formInitialState = changes;
  }

  displayForm(vsc: ValueStatementCompliance): boolean {
    if (vsc.compliance) {
      return vsc.compliance === 'NOT_COMPLIED';
    }
    return false;
  }

  save(vsId: number): void {
    const current = this.form.get(vsId + '');
    if (current.valid) {
      this.vsvs
        .saveCompliance(this.verificationId, this.sectionId, vsId, current.value.branchCompliance, current.value.branchComments)
        .subscribe(res => {
          this.savedStatus.set(vsId + '', true);
          this.updatePending(res.message);
        });
    }
  }

  updatePending(pending: number): void {
    this.pendingEvent.emit({ sectionId: this.sectionId, pending });
  }

  toggle(): void {
    if (this.showOnlyNotComplied) {
      this.valueStatements = this.totalData.filter(vs => vs.compliance === 'NOT_COMPLIED');
    } else {
      this.valueStatements = this.totalData;
    }
  }
}
