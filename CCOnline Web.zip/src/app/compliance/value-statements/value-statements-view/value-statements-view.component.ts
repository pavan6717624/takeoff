import { Component, Input, OnInit } from '@angular/core';
import { ValueStatementVerification } from 'src/app/verification/model/value-statement';
import { VerificationService } from 'src/app/verification/service/verification.service';

@Component({
  selector: 'app-value-statements-view',
  templateUrl: './value-statements-view.component.html',
})
export class ValueStatementsViewComponent implements OnInit {
  loading = true;
  @Input() verificationId: number;
  @Input() sectionId: number;

  valueStatements: ValueStatementVerification[] = [];

  constructor(private verificationService: VerificationService) {}

  ngOnInit(): void {
    this.verificationService.valueStatementWithVerification(this.verificationId, this.sectionId).subscribe(res => {
      this.valueStatements = res;
      this.loading = false;
    });
  }
}
