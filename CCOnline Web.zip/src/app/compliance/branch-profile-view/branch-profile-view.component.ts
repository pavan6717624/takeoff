import { Component, Input, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';

import { VerificationBranchProfile, VerificationBranchProfileView } from 'src/app/shared/models/verification-branch-profile.model';
import { VerificationService } from 'src/app/verification/service/verification.service';

@Component({
  selector: 'app-branch-profile-view',
  templateUrl: './branch-profile-view.component.html',
})
export class BranchProfileViewComponent implements OnInit {
  dateFormat = DATE_FORMAT;

  @Input() verificationId: number;

  loading = false;

  view: VerificationBranchProfileView;
  profile: VerificationBranchProfile;

  oneThirdGridStyle = {
    width: '33.33%',
    textAlign: 'center',
  };

  oneHalfGridStyle = {
    width: '50%',
    textAlign: 'center',
  };

  constructor(private log: NGXLogger, private verificationService: VerificationService) {}

  ngOnInit(): void {
    this.loading = true;
    this.verificationService.branchProfile(this.verificationId).subscribe(
      res => {
        this.profile = res;
        this.view = res.viewModel;
        this.loading = false;
      },
      () => (this.loading = false)
    );
  }
}
