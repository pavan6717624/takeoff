import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import en from '@angular/common/locales/en-IN';
import { registerLocaleData } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { en_US, NZ_I18N } from 'ng-zorro-antd/i18n';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeModule } from './home/home.module';
import { LayoutModule } from './layout/layout.module';
import { CoreModule } from './core/core.module';
import { NgxWebstorageModule } from 'ngx-webstorage';
import { AuthInterceptor } from './core/interceptors/auth.interceptor';
import { AuthExpiredInterceptor } from './core/interceptors/auth-expired.interceptor';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { AlainConfig, ALAIN_CONFIG } from '@delon/util';

registerLocaleData(en);

const LANG_PROVIDERS = [{ provide: NZ_I18N, useValue: en_US }];

const INTERCEPTOR_PROVIDERS = [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true,
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthExpiredInterceptor,
    multi: true,
  },
];

const alainConfig: AlainConfig = {
  xlsx: { url: 'assets/xlsx/xlsx.full.min.js' },
};

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CoreModule,
    HomeModule,
    LayoutModule,
    NgxWebstorageModule.forRoot({ prefix: 'cco', separator: '_' }),
    LoggerModule.forRoot({ level: NgxLoggerLevel.DEBUG }),
  ],
  providers: [INTERCEPTOR_PROVIDERS, LANG_PROVIDERS, { provide: ALAIN_CONFIG, useValue: alainConfig }],
  bootstrap: [AppComponent],
})
export class AppModule {}
