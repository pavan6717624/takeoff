import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChestSlipNotUploadedBranchesComponent } from '../abd/chest-slip-not-uploaded-branches/chest-slip-not-uploaded-branches.component';
import { ChestSlipUploadedBranchesComponent } from '../abd/chest-slip-uploaded-branches/chest-slip-uploaded-branches.component';
import { ChestBranchesAboveCglComponent } from '../abd/chest-branches-above-cgl/chest-branches-above-cgl.component';
import { BglCcDifferenceComponent } from '../abd/bgl-cc-difference/bgl-cc-difference.component';
import { RouterModule, Routes } from '@angular/router';
import { CustomReportsComponent } from '../abd/custom-reports/custom-reports.component';
import { MonthlyCertificateComponent } from '../fslo/monthly-certificate/monthly-certificate.component';
import { VsSummaryComponent } from '../fslo/monthly-certificate/vs-summary/vs-summary.component';
import { NsmReportComponent } from '../fslo/nsm-report/nsm-report.component';
import { CcBranchesComponent } from '../abd/cc-branches/cc-branches.component';
import { BrSummaryComponent } from '../abd/cc-branches/br-summary/br-summary.component';
import { ClosedBranchesComponent } from '../abd/cc-branches/closed-branches/closed-branches.component';
import { RbiPenaltyUpdationStatusComponent } from '../fslo/rbi-penalty-updation-status/rbi-penalty-updation-status.component';
import { AutoAlertsComponent } from '../branch/auto-alerts/auto-alerts.component';
import { AutoAlertsHbbComponent } from '../branch/auto-alerts-hbb/auto-alerts-hbb.component';
import { ChestBranchesAboveCglConsecutiveComponent } from '../abd/chest-branches-above-cgl-consecutive/chest-branches-above-cgl-consecutive.component';

const routes: Routes = [
  { path: '', redirectTo: 'verification', pathMatch: 'full' },
  { path: 'verification', loadChildren: () => import('./identify-vo/identify-vo.module').then(m => m.IdentifyVoModule) },
  { path: 'chest-slip-not-uploaded-branches', component: ChestSlipNotUploadedBranchesComponent },
  { path: 'chest-slip-uploaded-branches', component: ChestSlipUploadedBranchesComponent },
  { path: 'chest-branches-above-cbl', component: ChestBranchesAboveCglComponent },
  {
    path: 'consecutiveDaysReport',
    component: ChestBranchesAboveCglConsecutiveComponent,
  },
  { path: 'bgl-cc-difference', component: BglCcDifferenceComponent },
  { path: 'custom-reports', component: CustomReportsComponent },
  { path: 'penalty-reports', component: RbiPenaltyUpdationStatusComponent},
  { path: 'autoAlertSettings', component: AutoAlertsComponent},
  {
    path: 'autoAlertSettingsHbb',
    component: AutoAlertsHbbComponent,
  },
  {
    path: '',
    children: [
      {
      path: 'monthly-certificate-reports',
        // component: MonthlyCertificateComponent,
        children: [
          { path: '', redirectTo: 'summary', pathMatch: 'full' },
          { path: 'summary', component: MonthlyCertificateComponent },
          { path: 'vs-summary', component: VsSummaryComponent },
        ],
      },
      {
        path: 'nsm-reports',
        component: NsmReportComponent,
      },
      // {
      //   path: 'cc-branches',
      //   children: [
      //     { path: '', redirectTo: 'branches', pathMatch: 'full' },
      //     { path: 'branches', component: CcBranchesComponent },
      //   ],
      // },
    ],
  },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)],
})
export class CircleAdminModule {}
