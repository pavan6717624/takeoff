export interface Filters {
  circles?: Array<{ text: string; value: string }>;
  networks?: Array<{ text: string; value: string }>;
  modules?: Array<{ text: string; value: string }>;
  regions?: Array<{ text: string; value: string }>;
}
