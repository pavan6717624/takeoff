export interface CurrencyChest {
  branchCode: number;
  branchName: string;
}

export enum VerificationStatus {
  IN_PROGRESS,
  SUBMITTED,
}

export interface VerificationType {
  id: number;
  key: string;
  name: string;
}

export interface IVerification {
  id: number;
  type: VerificationType;
  periodFrom: string;
  periodTo: string;
  currencyChest?: CurrencyChest;
  officer: VerificationOfficer;
  toBeCompletedBefore?: Date;
  status?: VerificationStatus;
  ccBalancesAsOn?: any;
  branchProfile?: any;
  complianceStatus?: any;
}

export interface VerificationOfficer {
  id: number;
  pfId: number;
  name: string;
  designation: string;
  mobileNo?: number;
  emailId: string;
  branchCode?: number;
  branchName: string;
}
