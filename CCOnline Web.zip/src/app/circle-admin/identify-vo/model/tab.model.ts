export interface Tab {
  id: number;
  title: string;
  key: string;
  assignable?: boolean;
  count?: number;
}
