export interface VerificationCriteria {
  circle?: number;
  network?: number;
  module?: number;
  region?: number;
  branchCode?: number;
  status?: string;
  voPfId?: number;
}
