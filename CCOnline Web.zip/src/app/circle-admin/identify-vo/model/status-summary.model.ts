export interface StatusSummary {
  pendingAtCompliance: number;
  circle?: string;
  network?: number;
  module?: string;
  region: number;
  totalCcs: number;
  voNotIdentified: number;
  notStarted: number;
  inProgress: number;
  voReportSubmitted: number;
  pendingAtBranch: number;
  pendingAtController: number;
  awaitingForClosure: number;
  closed: number;
}
