export enum Action {
  ASSIGN,
  PRINT_LETTER,
  CHANGE,
}
