export interface VerificationBlock {
  id: string;
  description?: string;
  blockFrom: Date | string;
  blockTo: Date | string;
  isPastBlock: boolean;
}

export interface VerificationBlocks {
  blocks: VerificationBlock[];
}

export interface AssignVerificationOfficer {
  branchCode: number;
  block: string;
  assignedOfficerId: number;
  mobileNo?: number;
  emailId?: number;
  toBeCompletedBefore: Date | string;
}

export enum Level {
  BANK,
  CIRCLE,
  MODULE,
  REGION,
}
