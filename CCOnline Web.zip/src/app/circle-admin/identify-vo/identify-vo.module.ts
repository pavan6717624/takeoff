import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { IdentifyVoComponent } from './identify-vo.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { DelonLocaleService, DELON_LOCALE, en_US } from '@delon/theme';
import { VoDetailsModalComponent } from './vo-details-modal/vo-details-modal.component';
import { AssignResultComponent } from './assign-result/assign-result.component';
import { StatusSummaryModalComponent } from './status-summary-modal/status-summary-modal.component';

const routes: Routes = [{ path: '', component: IdentifyVoComponent }];

@NgModule({
  declarations: [IdentifyVoComponent, VoDetailsModalComponent, AssignResultComponent, StatusSummaryModalComponent],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule],
  exports: [IdentifyVoComponent, VoDetailsModalComponent, AssignResultComponent],
  providers: [DelonLocaleService, { provide: DELON_LOCALE, useValue: en_US }],
})
export class IdentifyVoModule {}
