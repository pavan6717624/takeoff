import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';

import { STChange, STColumn, STComponent, STData, STPage, STRes } from '@delon/abc/st';
import { DelonLocaleService, DELON_LOCALE, DrawerHelper, en_US, ModalHelper } from '@delon/theme';
import { NzMessageService } from 'ng-zorro-antd/message';
import { FileSaverService } from 'ngx-filesaver';
import { NGXLogger } from 'ngx-logger';

import { VerificationBlock, VerificationBlocks } from './assign-vo-models';
import { IdentifyVoService } from './identify-vo.service';
import { environment } from 'src/environments/environment';
import { VoDetailsModalComponent } from './vo-details-modal/vo-details-modal.component';
import { AssignResultComponent } from './assign-result/assign-result.component';
import { AuthService } from 'src/app/core/auth/auth.service';
import { Role } from 'src/app/shared/constants/role.constants';
import { Filters } from './model/filters.model';
import { Tab } from './model/tab.model';
import { FILE_NAME_FILTER_REGEX } from 'src/app/core/constants/validation.constants';
import { Action, VerificationService } from 'src/app/verification/service/verification.service';
import { StatusSummaryModalComponent } from './status-summary-modal/status-summary-modal.component';
import { VerificationCriteria } from './model/verification-criteria.model';
import { Circle } from 'src/app/shared/models/circle.model';
import { Network } from 'src/app/shared/models/network.model';
import { Module } from 'src/app/shared/models/module.model';
import { Region } from 'src/app/shared/models/region.model';

@Component({
  selector: 'app-identify-vo',
  templateUrl: './identify-vo.component.html',
  providers: [DelonLocaleService, { provide: DELON_LOCALE, useValue: en_US }],
  styles: [
    `
      .ant-advanced-search-form {
        padding: 24px;
        background: #fbfbfb;
        border: 1px solid #d9d9d9;
        border-radius: 6px;
      }
    `,
  ],
})
export class IdentifyVoComponent implements OnInit {
  tabs: Tab[] = [
    {
      id: 1,
      title: 'Bi-Monthly',
      key: 'bi-monthly',
      assignable: true,
    },
    {
      id: 2,
      title: 'Quarterly',
      key: 'quarterly',
      assignable: false,
    },
    {
      id: 3,
      title: 'Half-Yearly',
      key: 'half-yearly',
      assignable: true,
    },
    {
      id: 4,
      title: 'DGM & CFO',
      key: 'dgm-cfo',
      assignable: false,
    },
    {
      id: 5,
      title: 'Security Officer',
      key: 'security-officer',
      assignable: false,
    },
    {
      id: 6,
      title: 'Controller (RM/DGM) Visit',
      key: 'rm-dgm-controller-visit',
      assignable: false,
    },
    {
      id: 7,
      title: 'DGM (B&O) Visit',
      key: 'dgm-bo-module-head-visit',
      assignable: false,
    },
    {
      id: 8,
      title: 'DGM CFO Visit (New)',
      key: 'dgm-cfo-visit',
      assignable: false,
    },
    {
      id: 9,
      title: 'GM Network Visit',
      key: 'gm-network-visit',
      assignable: false,
    },
    {
      id: 10,
      title: 'CGM Visit',
      key: 'cgm-visit',
      assignable: false,
    },
  ];

  activeTab: Tab = { id: 1, key: 'bi-monthly', title: 'Bi-Monthly', assignable: true };

  //#region loading
  loading = false;
  downloadingLetter = false;
  exporting = false;
  //#endregion

  verificationBlocks: VerificationBlocks;
  selectedBlock: VerificationBlock;

  responseMapping: STRes = { reName: { list: 'content', total: 'totalElements' } };
  pagerConfig: STPage = { zeroIndexed: true, showSize: true, pageSizes: [10, 20, 30, 40, 50, 100, 200] };

  @ViewChild('st', { static: false }) private st: STComponent;

  columns: STColumn[] = [];

  filters: Filters;

  circles: Circle[];
  networks: Network[];
  modules: Module[];
  regions: Region[];

  q = <VerificationCriteria>{};
  cq = <VerificationCriteria>{};

  displayCircleFilter = false;
  displayNetworkFilter = false;
  displayModuleFilter = false;
  displayRegionFilter = false;

  constructor(
    private log: NGXLogger,
    private modalHelper: DrawerHelper,
    private resultModalHelper: DrawerHelper,
    private msgService: NzMessageService,
    private assignVoService: IdentifyVoService,
    private http: HttpClient,
    private fileSaverService: FileSaverService,
    private authService: AuthService,
    private verificationService: VerificationService,
    private summaryModalHelper: ModalHelper
  ) {}

  ngOnInit(): void {
    this.loading = true;

    if (this.authService.hasAnyRolesDirect([Role.ABD_DGM, Role.ABD_USER])) {
      this.displayCircleFilter = true;
      this.displayNetworkFilter = true;
      this.displayModuleFilter = true;
      this.displayRegionFilter = true;
    }

    if (this.authService.hasAnyRolesDirect([Role.CIRCLE_ADMIN])) {
      this.displayNetworkFilter = true;
      this.displayModuleFilter = true;
      this.displayRegionFilter = true;
    }

    if (this.authService.hasAnyRolesDirect([Role.AGM_GB, Role.AO_OFFICER])) {
      this.displayRegionFilter = true;
    }

    this.columns = this.prepareColumns();
    this.loadBlocks();
  }

  prepareColumns(): STColumn[] {
    const cols: STColumn[] = [];

    if (this.authService.hasAnyRolesDirect([Role.ABD_DGM, Role.ABD_USER])) {
      cols.push({ title: 'Circle', index: 'circleName' });
    }

    if (this.authService.hasAnyRolesDirect([Role.ABD_USER, Role.CIRCLE_ADMIN])) {
      cols.push({ title: 'NW.', index: 'networkCode', type: 'number' });
      cols.push({ title: 'Module', index: 'moduleName' });
    }

    if (this.authService.hasAnyRolesDirect([Role.ABD_DGM, Role.ABD_USER, Role.CIRCLE_ADMIN, Role.AO_OFFICER, Role.AGM_GB])) {
      cols.push({ title: 'Reg.', index: 'regionCode', type: 'number' });
    }

    cols.push({ title: 'Br. Code', index: 'branchCode', className: 'text-right' }, { title: 'Branch Name', index: 'branchName' });
    cols.push({
      title: 'Assigned To',
      index: 'verification.officer.name',
      iif: () => this.activeTab.assignable,
      format: item => `${item.verification?.officer ? `${item.verification.officer.name} (${item.verification.officer.pfId})` : '--'}`,
    });

    cols.push({ title: 'Status', index: 'verificationStatus', className: 'text-center' });

    const assignableUser = this.authService.hasAnyRolesDirect([Role.CIRCLE_ADMIN, Role.REGIONAL_MAGER, Role.AGM_GB, Role.CM_CR]);

    if (this.activeTab.assignable && assignableUser) {
      cols.push(
        { title: 'To be Completed By', index: 'verification.toBeCompletedBefore', type: 'date', dateFormat: 'dd-MM-yyyy' },
        {
          title: '',
          buttons: [
            {
              text: 'Assign Verification Officer',
              iif: data => this.verificationService.displayAction(data, this.selectedBlock, Action.ASSIGN),
              iifBehavior: 'hide',
              click: v => this.assign(v),
            },
            {
              text: 'Download Letter',
              iif: data => this.verificationService.displayAction(data, this.selectedBlock, Action.PRINT_LETTER),
              iifBehavior: 'hide',
              click: record => this.downloadLetter(record),
            },
            {
              text: 'Change',
              iif: data => this.verificationService.displayAction(data, this.selectedBlock, Action.CHANGE),
              iifBehavior: 'hide',
              children: [
                {
                  text: 'Modify Verification Officer',
                  click: record => this.assign(record),
                },
                {
                  text: 'Withdraw Verification Officer',
                  click: record => this.withdraw(record),
                },
              ],
            },
          ],
        }
      );
    }

    cols.push({
      title: 'Report Submitted On',
      index: 'verification.reportSubmittedOn',
      type: 'date',
      dateFormat: 'dd-MM-yyyy',
    });

    cols.push({
      title: 'Verification Report',
      buttons: [
        {
          text: 'View Report',
          iif: data => this.verificationService.displayAction(data, this.selectedBlock, Action.DOWNLOAD_REPORT),
          click: v => this.downloadReport(v),
        },
      ],
    });

    cols.push({
      title: 'Compliance Report',
      buttons: [
        {
          text: 'View Report',
          iif: data => this.verificationService.displayAction(data, this.selectedBlock, Action.DOWNLOAD_REPORT),
          click: v => this.downloadComplianceReport(v),
        },
      ],
    });

    return cols;
  }

  load(): void {
    if (this.activeTab.key && this.selectedBlock) {
      // load circles
      this.assignVoService.circles(this.activeTab.key, this.selectedBlock).subscribe(circles => {
        this.circles = circles;
        if (!this.displayCircleFilter) {
          this.assignVoService.networks(this.activeTab.key, this.selectedBlock).subscribe(networks => {
            this.networks = networks;
          });

          if (!this.displayModuleFilter) {
            this.assignVoService.regions(this.activeTab.key, this.selectedBlock).subscribe(regions => {
              this.regions = regions;
            });
          }
        }
        this.st.resetColumns({ columns: this.prepareColumns(), emitReload: true });
      });
    }
  }

  loadFilters(type: string, block: VerificationBlock): Observable<Filters> {
    return this.assignVoService.getFilters(type, block.blockFrom, block.blockTo);
  }

  loadBlocks(): void {
    this.assignVoService.getVerificationBlocks(this.activeTab.key).subscribe(res => {
      this.verificationBlocks = res;
      if (this.verificationBlocks && this.verificationBlocks.blocks) {
        this.selectedBlock = this.verificationBlocks.blocks[0];
      }
      this.loading = false;
      this.load();
    });
  }

  changeBlock(e: any): void {
    this.verificationBlocks.blocks.forEach(value => {
      if (value.id === e) {
        this.selectedBlock = value;
        this.st.reset(this.requestParams());
      }
    });
  }

  to(tab: Tab): void {
    this.loading = true;
    this.activeTab = tab;
    this.filterClear();
    this.loadBlocks();
  }

  requestParams(): any {
    if (this.selectedBlock) {
      var params: any = {};
      params.blockFrom = this.selectedBlock.blockFrom;
      params.blockTo = this.selectedBlock.blockTo;

      if (this.cq.circle) {
        params.circle = this.cq.circle;
      }

      if (this.cq.network) {
        params.network = this.cq.network;
      }

      if (this.cq.module) {
        params.module = this.cq.module;
      }

      if (this.cq.region) {
        params.region = this.cq.region;
      }

      if (this.cq.branchCode) {
        params.branchCode = this.cq.branchCode;
      }

      if (this.cq.status) {
        params.status = this.cq.status;
      }

      if (this.cq.voPfId) {
        params.voPfId = this.cq.voPfId;
      }
      return params;
    }
  }

  dataUrl(): string {
    if (this.activeTab?.key && this.selectedBlock) {
      return `${environment.apiUrl}/verifications/${this.activeTab.key}/`;
    }
    return '';
  }

  assign(branch: any): void {
    this.modalHelper
      .create(
        `Assign official for ${this.activeTab.title} verification`,
        VoDetailsModalComponent,
        {
          record: {
            branchCode: branch.branchCode,
            branchName: branch.branchName,
            block: this.selectedBlock,
            activeTab: this.activeTab,
            verification: branch.verification || null,
          },
        },
        {
          size: 'xl',
          drawerOptions: { nzWidth: 600, nzKeyboard: false, nzMaskClosable: false },
        }
      )
      .subscribe(res => {
        this.st.reload();

        if (res) {
          this.resultModalHelper
            .create(
              'Assigned verification official',
              AssignResultComponent,
              { data: res },
              { size: 'lg', drawerOptions: { nzKeyboard: false, nzMaskClosable: false } }
            )
            .subscribe(() => {
              // result modal closed
            });
        }
      });
  }

  withdraw(branch: STData): void {
    this.assignVoService.withdrawVerificationOfficer(branch.verification.officer.id).subscribe(
      res => {
        this.msgService.success(res.message);
        this.st.reload();
      },
      err => this.msgService.error('An error occured while withdrawing')
    );
  }

  downloadLetter(branch: any): void {
    if (!this.downloadingLetter) {
      this.downloadingLetter = true;
      const msgId = this.msgService.loading('Please wait while file is being downloaded').messageId;
      if (branch && branch.verification) {
        const filename = `${branch.branchCode}_${branch.branchName}_${branch.verification.type.key}.pdf`;
        this.http
          .get(`${environment.apiUrl}/verification/${branch.verification.id}/letter`, { observe: 'response', responseType: 'blob' })
          .subscribe(
            res => {
              this.fileSaverService.save(res.body, filename);
            },
            err => {
              this.downloadingLetter = false;
              this.msgService.remove(msgId);
              this.msgService.error('An error occured while downloading letter');
            },
            () => {
              this.downloadingLetter = false;
              this.msgService.remove(msgId);
            }
          );
      }
    }
  }

  export(): void {
    if (this.activeTab?.key && this.selectedBlock) {
      this.exporting = true;
      this.assignVoService.verificationsListForDownload(this.activeTab.key, this.selectedBlock, this.cq, 999999).subscribe(
        data => {
          console.log('data:', data);
          this.st.export(data.content, {
            filename: `${this.activeTab.key}_${this.selectedBlock.id}.xlsx`.replace(FILE_NAME_FILTER_REGEX, '_'),
            sheetname: this.activeTab.key,
          });
          this.exporting = false;
        },
        () => {
          this.exporting = false;
        }
      );
    }
  }

  exportNew(): void {
    this.exporting = true;

    let params = new HttpParams();
    params = params.append('blockFrom', String(this.selectedBlock.blockFrom));
    params = params.append('blockTo', String(this.selectedBlock.blockTo));

    if (this.cq.circle) {
      params = params.append('circle', String(this.cq.circle));
    }

    if (this.cq.network) {
      params = params.append('network', String(this.cq.network));
    }

    if (this.cq.module) {
      params = params.append('module', String(this.cq.module));
    }

    if (this.cq.region) {
      params = params.append('region', String(this.cq.region));
    }

    if (this.cq.branchCode) {
      params = params.append('branchCode', String(this.cq.branchCode));
    }

    if (this.cq.status) {
      params = params.append('status', this.cq.status);
    }

    if (this.cq.voPfId) {
      params = params.append('voPfId', String(this.cq.voPfId));
    }

    this.http
      .get(`${environment.apiUrl}/verifications/${this.activeTab.key}/export`, {
        observe: 'response',
        responseType: 'blob',
        params: params,
      })
      .subscribe(
        res => {
          this.fileSaverService.save(res.body, 'export.csv');
          this.exporting = false;
        },
        () => {
          this.exporting = false;
        }
      );
  }

  downloadReport(branch: STData): void {
    if (!this.downloadingLetter) {
      this.downloadingLetter = true;
      const msgId = this.msgService.loading('Please wait while file is being downloaded').messageId;
      if (branch && branch.verification) {
        const filename = `${branch.branchCode}_${branch.branchName}_${branch.verification.type.key}.pdf`;
        this.http
          .get(`${environment.apiUrl}/verification/${branch.verification.id}/report`, { observe: 'response', responseType: 'blob' })
          .subscribe(
            res => {
              this.fileSaverService.save(res.body, filename);
            },
            err => {
              this.downloadingLetter = false;
              this.msgService.remove(msgId);
              this.msgService.error(JSON.stringify(err)); // TODO: do proper error handling
            },
            () => {
              this.downloadingLetter = false;
              this.msgService.remove(msgId);
            }
          );
      }
    }
  }

  downloadComplianceReport(branch: STData): void {
    if (!this.downloadingLetter) {
      this.downloadingLetter = true;
      const msgId = this.msgService.loading('Please wait while file is being downloaded').messageId;
      if (branch && branch.verification) {
        const filename = `${branch.branchCode}_${branch.branchName}_${branch.verification.type.key}_compliance.pdf`;
        this.http
          .get(`${environment.apiUrl}/verification/${branch.verification.id}/complianceReport`, {
            observe: 'response',
            responseType: 'blob',
          })
          .subscribe(
            res => {
              this.fileSaverService.save(res.body, filename);
            },
            err => {
              this.downloadingLetter = false;
              this.msgService.remove(msgId);
              this.msgService.error(JSON.stringify(err)); // TODO: do proper error handling
            },
            () => {
              this.downloadingLetter = false;
              this.msgService.remove(msgId);
            }
          );
      }
    }
  }

  onChange(e: STChange): void {
    console.log('change', e);

    if (e.type === 'filter') {
      if (e.filter.filter.key === 'circle') {
        // circle selected
        console.log('circle selected');
        console.log('ST request', this.st.req);
      }
    } else if (e.type == 'loaded') {
      // circle selected
      console.log('loaded');
      console.log('ST request', this.st.req);
    }
  }

  displaySummary(): void {
    this.summaryModalHelper
      .create(
        StatusSummaryModalComponent,
        {
          record: {
            block: this.selectedBlock,
            type: this.activeTab,
            q: this.cq,
            abdLevel: this.authService.hasAnyRolesDirect([Role.ABD_DGM, Role.ABD_USER]),
          },
        },
        { size: 'xl' }
      )
      .subscribe(res => {});
  }

  filterFetch(): void {
    console.log('in filter fetch');
    console.log('criteria', this.q);

    this.cq = { ...this.q };

    this.st.reset(this.requestParams());
  }

  filterClear(): void {
    this.cq = <VerificationCriteria>{};
    this.st.reset(this.requestParams());
  }

  onCircleChange(circle: any): void {
    console.log('circle changed', circle);

    this.networks = [];
    this.modules = [];
    this.regions = [];

    this.q.network = null;
    this.q.module = null;
    this.q.region = null;

    this.log.debug(circle, this.activeTab.key, this.selectedBlock);
    if (circle && this.activeTab.key && this.selectedBlock) {
      // load networks
      this.log.debug('loading networks');
      this.assignVoService.networks(this.activeTab.key, this.selectedBlock, circle).subscribe(networks => {
        this.networks = networks;
      });
    }
  }

  onNetworkChange(network: any): void {
    console.log('network changed', network);

    this.modules = [];
    this.regions = [];

    this.q.module = null;
    this.q.region = null;

    if (network && this.activeTab.key && this.selectedBlock) {
      this.assignVoService.modules(this.activeTab.key, this.selectedBlock, network, this.q.circle).subscribe(modules => {
        this.modules = modules;
        this.regions = [];
      });
    }
  }

  onModuleChange(module: any): void {
    this.regions = [];
    this.q.region = null;

    if (module && this.activeTab.key && this.selectedBlock) {
      this.assignVoService.regions(this.activeTab.key, this.selectedBlock, module, this.q.network, this.q.circle).subscribe(regions => {
        this.regions = regions;
      });
    }
  }
}
