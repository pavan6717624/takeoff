import { Component, Input, OnInit } from '@angular/core';
import { NzDrawerRef } from 'ng-zorro-antd/drawer';
import { NGXLogger } from 'ngx-logger';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-assign-result',
  templateUrl: './assign-result.component.html',
  styleUrls: ['./assign-result.component.less'],
})
export class AssignResultComponent implements OnInit {
  @Input() data: any;

  constructor(private ref: NzDrawerRef, private log: NGXLogger) {}

  ngOnInit(): void {
    this.log.debug('data', this.data);
  }

  cancel(): void {
    this.ref.close();
  }

  letterUrl(): string {
    if (this.data && this.data.id) {
      return `${environment.apiUrl}/verification/${this.data.id}/letter`;
    }
    return '';
  }

  pre(e: any): void {
    this.log.debug('file download starting');
  }

  success(): void {
    this.log.debug('file download successful');
  }

  error(): void {
    this.log.debug('file download error');
  }
}
