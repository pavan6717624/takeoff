import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { NzDrawerRef } from 'ng-zorro-antd/drawer';
import { NGXLogger } from 'ngx-logger';

import { EmployeeDetailsService } from 'src/app/core/services/employee-details.service';
import { EmployeeDetails } from 'src/app/shared/models/employee-details.model';
import { IdentifyVoService } from '../identify-vo.service';
import { AssignVerificationOfficer, VerificationBlock } from '../assign-vo-models';
import { DATE_FORMAT, DATE_JACKSON_FORMAT } from 'src/app/shared/constants/input.constants';
import { IVerification } from '../model/verification.model';
import { EMAIL_REGEX, MOBILE_NO_PATTERN, PF_ID_PATTERN } from 'src/app/core/constants/validation.constants';
import { format, isWithinInterval } from 'date-fns';
import { DateUtilsService } from 'src/app/core/services/date-utils.service';
import { Tab } from '../model/tab.model';

interface Selected {
  branchCode: number;
  branchName: string;
  block: VerificationBlock;
  activeTab: Tab;
  verification?: IVerification;
}
@Component({
  selector: 'app-vo-details-modal',
  templateUrl: './vo-details-modal.component.html',
  providers: [IdentifyVoService],
})
export class VoDetailsModalComponent implements OnInit {
  @Input() record: Selected;
  readonly dateFormat = DATE_FORMAT;

  fetchedUserDetails = false;
  isModify = false;
  assigning = false;
  isFetchingUserDetails = false;

  assignOfficerForm: FormGroup;
  employeeDetails: EmployeeDetails;
  violations: [];

  blockFrom: Date;
  blockTo: Date;

  constructor(
    private ref: NzDrawerRef,
    private fb: FormBuilder,
    private assignVoService: IdentifyVoService,
    private log: NGXLogger,
    private empDetailsService: EmployeeDetailsService,
    private dateUtils: DateUtilsService
  ) {}

  ngOnInit(): void {
    this.log.debug('record', this.record);
    this.log.debug('blockFrom', this.record.block.blockFrom);
    this.log.debug('blockFrom type', typeof this.record.block.blockFrom);
    this.blockFrom = this.dateUtils.parseDate(this.record.block.blockFrom as string, DATE_JACKSON_FORMAT);
    this.blockTo = this.dateUtils.parseDate(this.record.block.blockTo as string, DATE_JACKSON_FORMAT);

    this.assignOfficerForm = this.fb.group({
      pfId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      // emailId: [{ value: '', disabled: true }, [Validators.required, Validators.email, Validators.pattern(EMAIL_REGEX)]],
      // mobileNo: [{ value: '', disabled: true }, [Validators.required, Validators.pattern(MOBILE_NO_PATTERN)]],
      toBeCompletedBefore: [null, [Validators.required]],
    });

    if (this.record.verification?.officer) {
      this.log.debug('verification officer assinged');
      this.employeeDetails = {
        pfId: this.record.verification.officer.pfId,
        name: this.record.verification.officer.name,
        branchCode: this.record.verification.officer.branchCode,
        branchName: this.record.verification.officer.branchName,
        designation: this.record.verification.officer.designation,
        emailId: this.record.verification.officer.emailId,
        mobileNo: this.record.verification.officer.mobileNo,
      };

      this.assignOfficerForm.patchValue({
        pfId: this.employeeDetails.pfId,
        emailId: this.employeeDetails.emailId,
        mobileNo: this.employeeDetails.mobileNo,
        toBeCompletedBefore: this.record.verification.toBeCompletedBefore,
      });

      this.fetchedUserDetails = true;
      this.isModify = true;
    }
    this.onPfIdChanges();
  }

  assignEnabled(): boolean {
    this.log.debug('assignOfficerFormValid:', this.assignOfficerForm.valid);
    this.log.debug(JSON.stringify(this.assignOfficerForm.errors));
    return true;
  }

  assign(): void {
    this.assigning = true;

    const toBeCompletedBefore = format(this.assignOfficerForm.get('toBeCompletedBefore').value, 'yyyy-MM-dd');

    const details: AssignVerificationOfficer = {
      branchCode: this.record.branchCode,
      block: this.record.block.id,
      assignedOfficerId: this.assignOfficerForm.get('pfId').value,
      // mobileNo: this.assignOfficerForm.get('mobileNo').value,
      // emailId: this.assignOfficerForm.get('emailId').value,
      toBeCompletedBefore: toBeCompletedBefore,
    };

    this.log.trace('toBeCompletedBefore:', this.assignOfficerForm.get('toBeCompletedBefore').value);

    this.assignVoService.assignVerificationOfficer(this.record.activeTab.key, details).subscribe(
      res => {
        this.log.debug('assigned success', res);
        this.assigning = false;
        this.ref.close(res);
      },
      error => {
        this.log.error(error);
        this.assigning = false;
      },
      () => {
        this.log.debug('completed');
        this.assigning = false;
      }
    );
  }

  cancel(): void {
    this.ref.close();
  }

  fetchUserDetails(pfIdFormControl: AbstractControl): void {
    console.log(pfIdFormControl);

    this.isFetchingUserDetails = true;

    this.empDetailsService.getEmployeeDetails(pfIdFormControl.value).subscribe(
      res => {
        this.log.debug(res);
        this.employeeDetails = res;
        // this.assignOfficerForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));

        // this.assignOfficerForm.get('emailId').markAsTouched();
        // this.assignOfficerForm.get('mobileNo').markAsTouched();

        this.log.debug(this.assignOfficerForm.value);
        this.fetchedUserDetails = true;
      },
      error => {
        this.isFetchingUserDetails = false;
      },
      () => (this.isFetchingUserDetails = false)
    );
  }

  showUserDetails(): boolean {
    return this.fetchedUserDetails && this.assignOfficerForm.get('pfId').pristine;
  }

  onPfIdChanges(): void {
    this.assignOfficerForm.get('pfId').valueChanges.subscribe(val => {
      if (this.fetchedUserDetails) {
        this.fetchedUserDetails = false;
        this.assignOfficerForm.get('toBeCompletedBefore').reset();
        // this.assignOfficerForm.get('emailId').reset();
        // this.assignOfficerForm.get('mobileNo').reset();
      }
    });
  }

  isPresentOrFuture(dc: Date): boolean {
    return dc.setHours(0, 0, 0, 0) >= new Date().setHours(0, 0, 0, 0);
  }

  disabledDate = (current: Date): boolean => {
    current.setHours(0, 0, 0, 0); // normalizing hours fixing issue with last date

    var blockFrom = this.blockFrom;
    blockFrom.setHours(0, 0, 0, 0);

    const blockTo = this.blockTo;
    blockTo.setHours(0, 0, 0, 0);

    this.log.trace('past, future', this.isPresentOrFuture(current));
    this.log.trace(
      'isWithinInterval(current, { start: blockFrom, end: blockTo })',
      isWithinInterval(current, { start: blockFrom, end: blockTo }),
      current,
      blockFrom,
      blockTo
    );

    if (this.isPresentOrFuture(current) && isWithinInterval(current, { start: blockFrom, end: blockTo })) {
      return false;
    }
    return true;
  };
}
