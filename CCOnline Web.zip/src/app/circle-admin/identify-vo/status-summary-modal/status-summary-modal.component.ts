import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { STColumn, STComponent, STData } from '@delon/abc/st';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { VerificationBlock } from '../assign-vo-models';
import { IdentifyVoService } from '../identify-vo.service';
import { Tab } from '../model/tab.model';
import { VerificationCriteria } from '../model/verification-criteria.model';

interface SummaryInput {
  block: VerificationBlock;
  type: Tab;
  q: VerificationCriteria;
  abdLevel: boolean;
}

@Component({
  selector: 'app-status-summary-modal',
  templateUrl: './status-summary-modal.component.html',
})
export class StatusSummaryModalComponent implements OnInit {
  @Input() record: SummaryInput;
  loading = true;

  circleSummaryColumns: STColumn[] = [];
  circleSummaryData: STData[];

  @ViewChild('st', { static: false }) st: STComponent;

  sum = {
    totalCcs: 0,
    voNotIdentified: 0,
    notStarted: 0,
    inProgress: 0,
    voReportSubmitted: 0,
    pendingAtBranch: 0,
    pendingAtController: 0,
    awaitingForClosure: 0,
    closed: 0,
    pendingAtCompliance: 0,
  };

  constructor(private ref: NzModalRef, private service: IdentifyVoService) { }

  ngOnInit(): void {
    this.circleSummaryColumns.push({ title: 'Circle', index: 'circle' });

    if (this.displayAdditionalColumns()) {
      this.circleSummaryColumns.push({ title: 'Network', type: 'number', index: 'network' });
      this.circleSummaryColumns.push({ title: 'Module', index: 'module' });
      this.circleSummaryColumns.push({ title: 'Region', type: 'number', index: 'region' });
    }

    this.circleSummaryColumns.push({ title: 'Total CCs', type: 'number', index: 'totalCcs' });

    if (this.record.type.key === 'bi-monthly' || this.record.type.key === 'half-yearly') {
      this.circleSummaryColumns.push({
        title: 'Verification',
        children: [
          { title: 'VO Not Identified', type: 'number', index: 'voNotIdentified' },
          { title: 'Not Started', type: 'number', index: 'notStarted' },
          { title: 'In-Progress', type: 'number', index: 'inProgress' },
          { title: 'Report Submitted', type: 'number', index: 'voReportSubmitted' },
        ],
      });
    }
    else
    {
      this.circleSummaryColumns.push({
        title: 'Verification',
        children: [
         // { title: 'VO Not Identified', type: 'number', index: 'voNotIdentified' },
          { title: 'Not Started', type: 'number', index: 'notStarted' },
          { title: 'In-Progress', type: 'number', index: 'inProgress' },
          { title: 'Report Submitted', type: 'number', index: 'voReportSubmitted' },
        ],
      });
    }

    if(this.record.type.key === 'bi-monthly' || this.record.type.key === 'half-yearly')
    {
    this.circleSummaryColumns.push({
      title: 'Compliance',
      children: [
        { title: 'At Branch', type: 'number', index: 'pendingAtBranch' },
        { title: 'At Scrutinizer', type: 'number', index: 'pendingAtController' },
        { title: 'At Compliance', type: 'number', index: 'pendingAtCompliance' },
        { title: 'For Closure', type: 'number', index: 'awaitingForClosure' },
        { title: 'Closed', type: 'number', index: 'closed' },
      ],
    });
  }
  else
  {
    this.circleSummaryColumns.push({
      title: 'Compliance',
      children: [
        { title: 'At Branch', type: 'number', index: 'pendingAtBranch' },
        { title: 'At Scrutinizer', type: 'number', index: 'pendingAtController' },
     //   { title: 'At Compliance', type: 'number', index: 'pendingAtCompliance' },
        { title: 'For Closure', type: 'number', index: 'awaitingForClosure' },
        { title: 'Closed', type: 'number', index: 'closed' },
      ],
    });
  }

    this.service.statusSummary(this.record.type.key, this.record.block, this.record.q).subscribe(res => {
      res.forEach(item => {

        if (!(this.record.type.key === 'bi-monthly' || this.record.type.key === 'half-yearly')) {
          item.notStarted += item.voNotIdentified;
          item.voNotIdentified = 0;
        }

        this.sum.totalCcs += item.totalCcs;
        this.sum.voNotIdentified += item.voNotIdentified;
        this.sum.notStarted += item.notStarted;
        this.sum.inProgress += item.inProgress;
        this.sum.voReportSubmitted += item.voReportSubmitted;
        
        this.sum.pendingAtBranch += item.pendingAtBranch;
        this.sum.pendingAtController += item.pendingAtController;
        this.sum.pendingAtCompliance+=item.pendingAtCompliance;

        this.sum.awaitingForClosure += item.awaitingForClosure;
        this.sum.closed += item.closed;
      });

      this.circleSummaryData = res;

      this.loading = false;
    });
  }

  displayAdditionalColumns(): boolean {
    if (this.record.q.circle || this.record.q.network || this.record.q.module || this.record.q.region || !this.record.abdLevel) {
      return true;
    }
    return false;
  }

  close(): void {
    this.ref.close(true);
  }
}
