import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { Module } from 'src/app/shared/models/module.model';
import { Network } from 'src/app/shared/models/network.model';
import { Region } from 'src/app/shared/models/region.model';

import { environment } from 'src/environments/environment';
import { EmployeeDetailsService } from '../../core/services/employee-details.service';
import { EmployeeDetails } from '../../shared/models/employee-details.model';
import { AssignVerificationOfficer, Level, VerificationBlock } from './assign-vo-models';
import { Filters } from './model/filters.model';
import { StatusSummary } from './model/status-summary.model';
import { VerificationCriteria } from './model/verification-criteria.model';

@Injectable({ providedIn: 'root' })
export class IdentifyVoService {
  constructor(private http: HttpClient, private employeeDetailsService: EmployeeDetailsService, private log: NGXLogger) {}

  getEmployeeDetails(pfId: number): Observable<EmployeeDetails> {
    return this.employeeDetailsService.getEmployeeDetails(pfId);
  }

  getVerificationBlocks(verificationType: string): Observable<any> {
    return this.http.get(`${environment.apiUrl}/verification/blocks/${verificationType}`);
  }

  assignVerificationOfficer(verificationType: string, details: AssignVerificationOfficer): Observable<any> {
    this.log.debug('assignVerificationOfficer()', verificationType, details);
    return this.http.post(`${environment.apiUrl}/verificationOfficer/assign/${verificationType}`, details);
  }

  withdrawVerificationOfficer(verificationId: number): Observable<any> {
    return this.http.post<any>(`${environment.apiUrl}/verification/withdraw`, { verificationId });
  }

  getFilters(type: string, blockFrom: any, blockTo: any): Observable<Filters> {
    let params = new HttpParams();
    params = params.append('blockFrom', blockFrom);
    params = params.append('blockTo', blockTo);

    return this.http.get<Filters>(`${environment.apiUrl}/verifications/${type}/filters`, { params: params });
  }

  verificationsListForDownload(type: string, selectedBlock: VerificationBlock, q: VerificationCriteria, total: number): Observable<any> {
    let params = new HttpParams();
    params = params.append('blockFrom', String(selectedBlock.blockFrom));
    params = params.append('blockTo', String(selectedBlock.blockTo));
    params = params.append('page', '0');
    params = params.append('size', String(total));

    if (q.circle) {
      params = params.append('circle', String(q.circle));
    }

    if (q.network) {
      params = params.append('network', String(q.network));
    }

    if (q.module) {
      params = params.append('module', String(q.module));
    }

    if (q.region) {
      params = params.append('region', String(q.region));
    }

    if (q.branchCode) {
      params = params.append('branchCode', String(q.branchCode));
    }

    if (q.status) {
      params = params.append('status', q.status);
    }

    if (q.voPfId) {
      params = params.append('voPfId', String(q.voPfId));
    }

    return this.http.get(`${environment.apiUrl}/verifications/${type}`, { params: params });
  }

  statusSummary(type: string, selectedBlock: VerificationBlock, q: VerificationCriteria): Observable<StatusSummary[]> {
    let params = new HttpParams();
    params = params.append('blockFrom', String(selectedBlock.blockFrom));
    params = params.append('blockTo', String(selectedBlock.blockTo));

    if (q.circle) {
      params = params.append('circle', String(q.circle));
    }

    if (q.network) {
      params = params.append('network', String(q.network));
    }

    if (q.module) {
      params = params.append('module', String(q.module));
    }

    if (q.region) {
      params = params.append('region', String(q.region));
    }

    return this.http.get<StatusSummary[]>(`${environment.apiUrl}/verifications/${type}/summary`, { params: params });
  }

  circles(type: string, selectedBlock: VerificationBlock): Observable<any> {
    let params = new HttpParams();
    params = params.append('blockFrom', String(selectedBlock.blockFrom));
    params = params.append('blockTo', String(selectedBlock.blockTo));

    return this.http.get<any>(`${environment.apiUrl}/verifications/${type}/circles`, { params: params });
  }

  networks(type: string, selectedBlock: VerificationBlock, circle?: number): Observable<Network[]> {
    let params = new HttpParams();
    params = params.append('blockFrom', String(selectedBlock.blockFrom));
    params = params.append('blockTo', String(selectedBlock.blockTo));
    if (circle) {
      params = params.append('circle', String(circle));
    }

    return this.http.get<Network[]>(`${environment.apiUrl}/verifications/${type}/networks`, { params: params });
  }

  modules(type: string, selectedBlock: VerificationBlock, network?: number, circle?: number): Observable<Module[]> {
    let params = new HttpParams();
    params = params.append('blockFrom', String(selectedBlock.blockFrom));
    params = params.append('blockTo', String(selectedBlock.blockTo));
    if (circle) {
      params = params.append('circle', String(circle));
    }
    if (network){
      params = params.append('network', String(network));
    }
    
    return this.http.get<Module[]>(`${environment.apiUrl}/verifications/${type}/modules`, { params: params });
  }

  regions(type: string, selectedBlock: VerificationBlock, module?: number, network?: number, circle?: number): Observable<Region[]> {
    let params = new HttpParams();
    params = params.append('blockFrom', String(selectedBlock.blockFrom));
    params = params.append('blockTo', String(selectedBlock.blockTo));

    if (circle) {
      params = params.append('circle', String(circle));
    }
    if (network) {
      params = params.append('network', String(network));
    }
    if (module) {
      params = params.append('module', String(module));
    }

    return this.http.get<Region[]>(`${environment.apiUrl}/verifications/${type}/regions`, { params: params });
  }
}
