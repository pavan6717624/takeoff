import { Component } from '@angular/core';
import { App, AppSettingsService } from 'src/app/core/services/app-settings.service';

@Component({
  selector: 'app-layout-header',
  templateUrl: './header.component.html',
})
export class HeaderComponent {
  get app(): App {
    return this.settings.app;
  }

  constructor(private settings: AppSettingsService) {}

  get collapsed(): boolean {
    return this.settings.layout.collapsed;
  }

  toggleCollapsedSidebar(): void {
    this.settings.setLayout('collapsed', !this.settings.layout.collapsed);
  }
}
