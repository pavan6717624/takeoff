import { Component, OnInit } from '@angular/core';

export interface User {
  name: string;
  email: string;
}

@Component({
  selector: 'app-layout-sidebar',
  templateUrl: './sidebar.component.html',
})
export class SidebarComponent implements OnInit {
  get user(): User {
    return {
      name: 'Administrator',
      email: 'admin@email.com',
    };
  }

  constructor() {}

  ngOnInit(): void {}
}
