import { Component, OnInit } from '@angular/core';
import { Menu } from '@delon/theme';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NGXLogger } from 'ngx-logger';

import { AuthService } from 'src/app/core/auth/auth.service';
import { User } from 'src/app/core/auth/user';
import { Role } from 'src/app/shared/constants/role.constants';

const userWiseMenus: { [key: string]: Menu[] } = {
  branch: [
    {
      text: 'Branch User',
      group: true,
      children: [
        { text: 'Upload Chest Slip', link: '/branch/cc-position' },
        { text: 'View Chest Slip', link: '/branch/view-chest-slip' },
        { text: 'View/Edit Branch Profile', link: '/branch/cc-profile' },
        { text: 'Compliance for Verification', link: '/branch/compliance' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/branch/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/branch/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/branch/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/branch/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/branch/bgl-cc-difference' },
        { text: 'Monthly Certificate', link: '/branch/monthly-certificate' },
        { text: 'NSM Maintenance', link: '/branch/nsm-maintenance' },
        { text: 'NSM Processing', link: '/branch/nsm-processing' },
        { text: 'Reports', link: '/branch/custom-reports' },
        { text: 'Auto Alerts Settings', link: '/branch/autoAlertSettings' },
      
      ],
    },
  ],
  controllerMaker: [
    {
      text: 'Controller',
      group: true,
      children: [
        { text: 'Verifications', link: '/controller/verifications' },
        { text: 'Quarterly Verification', link: '/controller/quarterly' },
        { text: 'Verification Scrutiny', link: '/controller/scrutiny' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/controller/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/controller/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/controller/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/controller/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/controller/bgl-cc-difference' },
        { text: 'Reports', link: '/controller/custom-reports' },
        { text: 'Monthly Cert. Status', link: '/controller/monthly-certificate-reports' },
        { text: 'NSM Status', link: '/controller/nsm-reports' },
        { text: 'Currency Chest Branches', link: '/controller/cc-branches' },
     //   { text: 'Auto Alerts Settings', link: '/controller/autoAlertSettings' },

     {
      text: 'Auto Alerts Settings',
      group: true,
      children: [
        { text: 'Currency Chests', link: '/controller/autoAlertSettings' },
        { text: 'Hand Balance Branches', link: '/controller/autoAlertSettingsHbb' },
        ],
    },

        {
          text: 'Verification Reports',
          group: true,
          children: [
            { text: 'Consolidated Branch Wise', link: '/mis/consolidated-branch-wise' },
            { text: 'Ver. Statistics', link: '/mis/statistics' },
            { text: 'Repetition of Observations', link: '/mis/repetition-observations' },
          ],
        },
      ],
    },
  ],
  controllerChecker: [
    {
      text: 'Controller',
      group: true,
      children: [
        { text: 'Verifications', link: '/controller/verifications' },
        { text: 'Verification Scrutiny', link: '/controller/scrutiny' },
        { text: 'Verification Closure', link: '/controller/closure' },
        { text: 'Controller Visit', link: '/controller/controllerVisit' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/controller/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/controller/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/controller/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/controller/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/controller/bgl-cc-difference' },
        { text: 'Reports', link: '/controller/custom-reports' },
        { text: 'Monthly Cert. Status', link: '/controller/monthly-certificate-reports' },
        { text: 'NSM Status', link: '/controller/nsm-reports' },
        { text: 'Currency Chest Branches', link: '/controller/cc-branches' },
      //  { text: 'Auto Alerts Settings', link: '/controller/autoAlertSettings' },
      {
        text: 'Auto Alerts Settings',
        group: true,
        children: [
          { text: 'Currency Chests', link: '/controller/autoAlertSettings' },
          { text: 'Hand Balance Branches', link: '/controller/autoAlertSettingsHbb' },
          ],
      },
        {
          text: 'Verification Reports',
          group: true,
          children: [
            { text: 'Consolidated Branch Wise', link: '/mis/consolidated-branch-wise' },
            { text: 'Ver. Statistics', link: '/mis/statistics' },
            { text: 'Repetition of Observations', link: '/mis/repetition-observations' },
          ],
        },
      ],
    },
  ],
  fslo: [
    {
      text: 'FSLO',
      group: true,
      children: [
        { text: 'Upload Chest Slip', link: '/fslo/upload-chest-slip' },
        { text: 'Download TrickleFeed Files', link: '/fslo/download-ekuber-stmt' },
        { text: 'View Chest Slip', link: '/fslo/view-chest-slip' },
        { text: 'RBI Penalty Data Entry', link: '/fslo/rbi-penalty-data-entry' },
        { text: 'RBI Penalty Disposal', link: '/fslo/rbi-penalty-disposal' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/fslo/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/fslo/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/fslo/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/fslo/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/fslo/bgl-cc-difference' },
        { text: 'Reports', link: '/fslo/custom-reports' },
        { text: 'Penalty Reports', link: '/fslo/penalty-reports' },
        { text: 'Monthly Cert. Status', link: '/fslo/monthly-certificate-reports' },
        { text: 'NSM Status', link: '/fslo/nsm-reports' },
        { text: 'Currency Chest Branches', link: '/fslo/cc-branches' },
        { text: 'SMS Reminder', link: '/fslo/sms' },
        { text: 'Auto Alerts Settings', link: '/fslo/autoAlertSettings' },
      ],
    },
  ],
  circleAdmin: [
    {
      text: 'Circle Admin',
      group: true,
      children: [
        { text: 'Verifications', link: '/circle-admin/verification' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/circle-admin/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/circle-admin/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/circle-admin/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/circle-admin/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/circle-admin/bgl-cc-difference' },
        { text: 'Reports', link: '/circle-admin/custom-reports' },
        { text: 'Penalty Reports', link: '/circle-admin/penalty-reports' },
        { text: 'Monthly Cert. Status', link: '/circle-admin/monthly-certificate-reports' },
        { text: 'NSM Status', link: '/circle-admin/nsm-reports' },
        { text: 'Currency Chest Branches', link: '/abd/cc-branches' },
        { text: 'User Management', link: '/users' },
    //    { text: 'Auto Alerts Settings', link: '/circle-admin/autoAlertSettings' },
    {
      text: 'Auto Alerts Settings',
      group: true,
      children: [
        { text: 'Currency Chests', link: '/circle-admin/autoAlertSettings' },
        { text: 'Hand Balance Branches', link: '/circle-admin/autoAlertSettingsHbb' },
        ],
    },
        {
          text: 'Verification Reports',
          group: true,
          children: [
            { text: 'Consolidated Branch Wise', link: '/mis/consolidated-branch-wise' },
            { text: 'Ver. Statistics', link: '/mis/statistics' },
            { text: 'Repetition of Observations', link: '/mis/repetition-observations' },
          ],
        },
      ],
    },
  ],
  securityOfficer: [
    {
      text: 'Security Officer',
      group: true,
      children: [{ text: 'Verification', link: '/security-officer/verification' }],
    },
  ],

  dgmBo: [
    {
      text: 'DGM (B&O)',
      group: true,
      children: [
        { text: 'Assign Compl. Verification', link: '/dgm-bo/assign-comp-vo' },
        { text: 'Controller Visit (Direct Brs.)', link: '/dgm-bo/controllerVisitDirectBrs' },
        { text: 'Module Head Visit', link: '/dgm-bo/controllerVisitModuleHead' },
        { text: 'Verification Closure', link: '/dgm-bo/closure' },
    //    { text: 'Auto Alerts Settings', link: '/dgm-bo/autoAlertSettings' },
    {
      text: 'Auto Alerts Settings',
      group: true,
      children: [
        { text: 'Currency Chests', link: '/dgm-bo/autoAlertSettings' },
        { text: 'Hand Balance Branches', link: '/dgm-bo/autoAlertSettingsHbb' },
        ],
    },
      ],
    },
  ],

  cgmCircle: [
    {
      text: 'CGM CIRCLE',
      group: true,
      children: [
        { text: 'CGM Visit', link: '/cgm-circle/controllerVisit' },
        { text: 'Verification Closure', link: '/cgm-circle/closure' },
      ],
    },
  ],
  gmNw: [
    {
      text: 'GM NETWORK',
      group: true,
      children: [
        { text: 'GM Network Visit', link: '/gm-nw/controllerVisit' },
        { text: 'Verification Closure', link: '/gm-nw/closure' },
      ],
    },
  ],
  dgmCfo: [
    {
      text: 'DGM & CFO',
      group: true,
      children: [
        { text: 'Verification Closure', link: '/dgm-cfo/closure' },
        { text: 'DGM CFO Visit', link: '/dgm-cfo/controllerVisit' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/dgm-cfo/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/dgm-cfo/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/dgm-cfo/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/dgm-cfo/consecutiveDaysReport' },
        
        { text: 'BGL CC Difference', link: '/dgm-cfo/bgl-cc-difference' },
        { text: 'Reports', link: '/dgm-cfo/custom-reports' },
        { text: 'Penalty Reports', link: '/dgm-cfo/penalty-reports' },
      ],
    },
  ],
  abd: [
    {
      text: 'ABD User',
      group: true,
      children: [
        { text: 'Verifications', link: '/abd/verifications' },
        { text: 'Upload e-Kuber Statement', link: '/abd/upload-ekuber-stmt' },
        { text: 'Upload RBI Penalty', link: '/abd/rbi-penalty-upload' },
        { text: 'Adjust Chest Slip', link: '/abd/adjustChestSlip' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/abd/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/abd/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/abd/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/abd/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/abd/bgl-cc-difference' },
        { text: 'Closed Branches with Non-Zero BGL Balance', link: '/abd/exception-report' },
        { text: 'Branches with Zero Closing Balance', link: '/abd/zero-balance-ccs' },
        { text: 'Reports', link: '/abd/custom-reports' },
        { text: 'NSM Maintenance', link: '/abd/nsm-master-list' },
        { text: 'User Management', link: '/users' },
        { text: 'Penalty Reports', link: '/abd/penalty-reports' },
        { text: 'Currency Chest Branches', link: '/abd/cc-branches' },
        { text: 'CC Closure', link: '/abd/cc-closure' },
        { text: 'Email Reminder', link: '/abd/email' },
   //     { text: 'Auto Alerts Settings', link: '/abd/autoAlertSettings' },
   {
    text: 'Auto Alerts Settings',
    group: true,
    children: [
      { text: 'Currency Chests', link: '/abd/autoAlertSettings' },
      { text: 'Hand Balance Branches', link: '/abd/autoAlertSettingsHbb' },
      ],
  },
        {
          text: 'Verification Reports',
          group: true,
          children: [
            { text: 'Consolidated Branch Wise', link: '/mis/consolidated-branch-wise' },
            { text: 'Consolidated Circle Wise', link: '/mis/consolidated-circle-wise' },
            { text: 'Ver. Statistics', link: '/mis/statistics' },
            { text: 'Repetition of Observations', link: '/mis/repetition-observations' },
            { text: 'Month Wise Verification', link: '/abd/month-wise-verifications' },
          ],
        },
      ],
    },
  ],
  abd_dgm: [
    {
      text: 'ABD DGM',
      group: true,
      children: [
        { text: 'Verifications', link: '/abd/verifications' },
        { text: 'Verification Closure', link: '/abd/closure' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/abd/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/abd/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/abd/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/abd/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/abd/bgl-cc-difference' },
        { text: 'Closed Branches with Non-Zero BGL Balance', link: '/abd/exception-report' },
        { text: 'Branches with Zero Closing Balance', link: '/abd/zero-balance-ccs' },
        { text: 'Reports', link: '/abd/custom-reports' },
        { text: 'Penalty Reports', link: '/abd/penalty-reports' },
      { text: 'Auto Alerts Settings', link: '/abd/autoAlertSettings' },


   
        {
          text: 'Verification Reports',
          group: true,
          children: [
            { text: 'Consolidated Branch Wise', link: '/mis/consolidated-branch-wise' },
            { text: 'Consolidated Circle Wise', link: '/mis/consolidated-circle-wise' },
            { text: 'Ver. Statistics', link: '/mis/statistics' },
            { text: 'Repetition of Observations', link: '/mis/repetition-observations' },
            { text: 'Month Wise Verification', link: '/abd/month-wise-verifications' },
          ],
        },
      ],
    },
  ],
  verificationOfficer: [
    {
      text: 'Verification Officer',
      group: true,
      children: [
        { text: 'Verifications', link: '/verification-officer/assigned' },
        { text: 'Compliance Verification', link: '/verification-officer/compliance/verification' },
      ],
    },
  ],
  rboDeskOfficer: [
    {
      text: 'RBO Desk Officer',
      group: true,
      children: [
        { text: 'Verifications', link: '/controller/verifications' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/controller/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/controller/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/controller/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/controller/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/controller/bgl-cc-difference' },
        { text: 'Reports', link: '/controller/custom-reports' },
        { text: 'Monthly Cert. Status', link: '/controller/monthly-certificate-reports' },
        { text: 'NSM Status', link: '/controller/nsm-reports' },
        { text: 'Currency Chest Branches', link: '/controller/cc-branches' },
        {
          text: 'Verification Reports',
          group: true,
          children: [
            { text: 'Consolidated Branch Wise', link: '/mis/consolidated-branch-wise' },
            { text: 'Ver. Statistics', link: '/mis/statistics' },
            { text: 'Repetition of Observations', link: '/mis/repetition-observations' },
          ],
        },
      ],
    },
  ],
  aoOfficer: [
    {
      text: 'AO Officer',
      group: true,
      children: [
        { text: 'Verifications', link: '/controller/verifications' },
        { text: 'Chest Slip Not Uploaded Branches', link: '/controller/chest-slip-not-uploaded-branches' },
        { text: 'Chest Slip Uploaded Branches', link: '/controller/chest-slip-uploaded-branches' },
        { text: 'CC Branches Exceeding CBL', link: '/controller/chest-branches-above-cbl' },
        { text: 'CBL Exceeding Days Report', link: '/controller/consecutiveDaysReport' },
        { text: 'BGL CC Difference', link: '/controller/bgl-cc-difference' },
        { text: 'Reports', link: '/controller/custom-reports' },
        { text: 'Monthly Cert. Status', link: '/controller/monthly-certificate-reports' },
        { text: 'NSM Status', link: '/controller/nsm-reports' },
        { text: 'Currency Chest Branches', link: '/controller/cc-branches' },
        {
          text: 'Verification Reports',
          group: true,
          children: [
            { text: 'Consolidated Branch Wise', link: '/mis/consolidated-branch-wise' },
            { text: 'Ver. Statistics', link: '/mis/statistics' },
            { text: 'Repetition of Observations', link: '/mis/repetition-observations' },
          ],
        },
      ],
    },
  ],
};

@Component({
  selector: 'app-layout',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.less'],
})
export class LayoutDefaultComponent implements OnInit {
  isCollapsed = false;
  loggingOut = false;

  menus: Menu[] = [];
  user: User;

  constructor(private authService: AuthService, private log: NGXLogger, private message: NzMessageService) {}

  IE: boolean = /(msie|trident)/i.test(navigator.userAgent);

  ngOnInit(): void {
    this.authService.getPrincipal().subscribe(principal => {
      if (this.authService.hasAnyRolesDirect([Role.BRANCH_USER, Role.BRANCH_HEAD])) {
        this.menus = userWiseMenus.branch;
      } else if (this.authService.hasAnyRolesDirect([Role.CM_CR, Role.AGM_GB])) {
        this.menus = userWiseMenus.controllerMaker;
      } else if (this.authService.hasAnyRolesDirect([Role.REGIONAL_MAGER])) {
        this.menus = userWiseMenus.controllerChecker;
      } else if (this.authService.hasRoleDirect(Role.FSLO_USER) && this.authService.hasRoleDirect(Role.CIRCLE_ADMIN)) {
        this.menus = userWiseMenus.circleAdmin.concat(userWiseMenus.fslo);
      } else if (this.authService.hasRoleDirect(Role.FSLO_USER)) {
        this.menus = userWiseMenus.fslo;
      } else if (this.authService.hasRoleDirect(Role.CIRCLE_ADMIN)) {
        this.menus = userWiseMenus.circleAdmin;
      } else if (this.authService.hasRoleDirect(Role.SECURITY_OFFICER)) {
        this.menus = userWiseMenus.securityOfficer;
      } else if (this.authService.hasRoleDirect(Role.DGM_CFO)) {
        this.menus = userWiseMenus.dgmCfo;
      } else if (this.authService.hasAnyRolesDirect([Role.ABD_USER])) {
        this.menus = userWiseMenus.abd;
      } else if (this.authService.hasRoleDirect(Role.ABD_DGM)) {
        this.menus = userWiseMenus.abd_dgm;
      } else if (this.authService.hasRoleDirect(Role.RBO_DESK_OFFICER)) {
        this.menus = userWiseMenus.rboDeskOfficer;
      } else if (this.authService.hasRoleDirect(Role.AO_OFFICER)) {
        this.menus = userWiseMenus.aoOfficer;
      } else if (this.authService.hasRoleDirect(Role.DGM_BO)) {
        this.menus = userWiseMenus.dgmBo;
      } else if (this.authService.hasRoleDirect(Role.CGM_CIRCLE)) {
        this.menus = userWiseMenus.cgmCircle;
      } else if (this.authService.hasRoleDirect(Role.GM_NW)) {
        this.menus = userWiseMenus.gmNw;
      } else {
        this.message.info("User doesn't have any assigned roles");
      }

      if (this.authService.hasAnyRolesDirect([Role.VERIFICATION_OFFICER])) {
        this.menus = this.menus.concat(userWiseMenus.verificationOfficer);
      }

      this.user = principal;
    });
  }

  logout(): void {
    this.log.debug('logging out');
    this.loggingOut = true;
    this.authService.logoutAndRedirect();
  }
}
