import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { LayoutDefaultComponent } from './default/default.component';
import { SidebarComponent } from './default/sidebar/sidebar.component';
import { HeaderComponent } from './default/header/header.component';
import { HeaderTaskComponent } from './default/header/components/task.component';
import { HeaderUserComponent } from './default/header/components/user.component';

@NgModule({
  declarations: [LayoutDefaultComponent, SidebarComponent, HeaderComponent, HeaderTaskComponent, HeaderUserComponent],
  imports: [CommonModule, SharedModule],
})
export class LayoutModule {}
