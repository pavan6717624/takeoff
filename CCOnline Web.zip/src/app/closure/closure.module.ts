import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VerificationClosureComponent } from './verification-closure.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [VerificationClosureComponent],
  imports: [CommonModule, SharedModule],
  exports: [VerificationClosureComponent],
})
export class ClosureModule {}
