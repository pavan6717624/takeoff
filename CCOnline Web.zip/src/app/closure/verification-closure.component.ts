import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { STColumn, STComponent, STData } from '@delon/abc/st';
import { NGXLogger } from 'ngx-logger';

import { environment } from 'src/environments/environment';
import { Tab } from '../circle-admin/identify-vo/model/tab.model';

@Component({
  selector: 'app-verification-closure',
  templateUrl: 'verification-closure.component.html',
})
export class VerificationClosureComponent implements OnInit {
  constructor(private router: Router, private log: NGXLogger) {}

  @Input() startUrl: string;
  @Input() tabs: Tab[];
  @Input() activeTab: Tab;

  loading = false;

  year: Date = new Date();
  status: string;
  checked: boolean = true;
  heading: string = ' - Pending';

  columns: STColumn[] = [
    { title: 'Period', index: 'period' },
    { title: 'Circle Name', index: 'circleName' },
    { title: 'NW', index: 'networkCode' },
    { title: 'Module', index: 'moduleName' },
    { title: 'Reg', index: 'regionCode' },
    { title: 'Br. Code', index: 'branchCode' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'Status', index: 'statusDescription' },
    { title: '', buttons: [{ text: 'View', click: r => this.start(r) }] },
  ];

  @ViewChild('st', { static: false }) private st: STComponent;

  ngOnInit(): void {
    this.log.trace('startUrl: ', this.startUrl);
  }

  to(tab: Tab): void {
    this.activeTab = tab;
    console.log(this.activeTab.id);

    this.year = new Date();
    this.status = '';
    this.checked = true;

    this.st.reload(this.requestParams());
  }

  dataUrl(): string {
    return `${environment.apiUrl}/verifications/closure`;
  }

  requestParams(): any {
    var params: any = {};

    params.type = this.activeTab.key;

    if (this.status) {
      params.status = this.status;
    }

    if (this.checked) {
      params.onlyActionRequired = true;
    }

    if (this.year) {
      params.year = this.year.getFullYear();
    } else {
      params.year = new Date().getFullYear();
    }

    return params;
  }

  start(data: STData): void {
    this.log.trace('navigating to:', [this.startUrl + data.verificationId]);
    this.router.navigate([this.startUrl + data.verificationId]);
  }

  onDisplayPendingChange(): void {
    if (this.checked) {
      this.status = '';
    }
    this.st.reload(this.requestParams());
  }

  onStatusChange(): void {
    if (this.status) {
      this.checked = false;
    }
    this.st.reload(this.requestParams());
  }

  onYearChange(): void {
    this.st.reload(this.requestParams());
  }
}
