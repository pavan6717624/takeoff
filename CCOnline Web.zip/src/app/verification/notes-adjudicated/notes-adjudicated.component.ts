import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { PIECES_VALIDATOR_REQUIRED } from 'src/app/core/constants/validation.constants';

import { VerificationService } from 'src/app/verification/service/verification.service';

interface Denomination {
  id: number;
  value: number;
  description: string;
}

export interface NotesAdjudicatedDetails {
  fullValuePieces?: number;
  halfValuePieces?: number;
  rejectedPieces?: number;
  denominationType: string;
  denominationValue: number;
  denominationId: number;
}

@Component({
  selector: 'app-notes-adjudicated',
  templateUrl: './notes-adjudicated.component.html',
})
export class NotesAdjudicatedComponent implements OnInit {
  loading = false;
  saving = false;

  isChecker = false;

  private router$!: Subscription;

  verificationId: number;

  notesAdjudicatedForm: FormGroup = new FormGroup({});
  data: NotesAdjudicatedDetails[];

  constructor(
    private route: ActivatedRoute,
    private verificationService: VerificationService,
    private fb: FormBuilder,
    private log: NGXLogger,
    private msgService: NzMessageService,
    private notification: NzNotificationService
  ) {}

  ngOnInit(): void {
    this.router$ = this.route.params.subscribe(params => {
      this.verificationId = +params.verificationId;

      this.verificationService.notesAdjudicatedDetails(this.verificationId).subscribe(res => {
        this.data = res;

        // prepare form based on data
        this.notesAdjudicatedForm = this.prepareForm(this.data);
      });
    });
  }

  prepareForm(data: NotesAdjudicatedDetails[]): FormGroup {
    const group: any = {};
    data.forEach(item => {
      group[item.denominationId] = this.fb.group({
        fullValuePieces: [item.fullValuePieces, PIECES_VALIDATOR_REQUIRED],
        halfValuePieces: [item.halfValuePieces, [Validators.required, Validators.min(0)]],
        rejectedPieces: [item.rejectedPieces, [Validators.required, Validators.min(0)]],
      });
    });
    return new FormGroup(group);
  }

  save(): void {
    this.saving = true;
    this.log.debug('saving...', this.notesAdjudicatedForm.value);
    this.verificationService.saveNotesAdjudicatedDetails(this.verificationId, this.notesAdjudicatedForm.value).subscribe(
      () => {
        this.notification.success('Saved', '');
        this.saving = false;
      },
      () => (this.saving = false)
    );
  }

  fullValueValue(denominationId, value): number {
    if (denominationId && this.notesAdjudicatedForm && this.notesAdjudicatedForm.get(denominationId + '')) {
      const noOfPieces = this.notesAdjudicatedForm.get(denominationId + '').value.fullValuePieces;
      return +noOfPieces * +value;
    }
    return 0;
  }

  halfValueValue(denominationId, value): string | number {
    if (denominationId && this.notesAdjudicatedForm && this.notesAdjudicatedForm.get(denominationId + '')) {
      const noOfPieces = this.notesAdjudicatedForm.get(denominationId + '').value.halfValuePieces;
      return +noOfPieces * +value;
    }
    return '';
  }

  rejectedValueValue(denominationId, value): string | number {
    if (denominationId && this.notesAdjudicatedForm && this.notesAdjudicatedForm.get(denominationId + '')) {
      const noOfPieces = this.notesAdjudicatedForm.get(denominationId + '').value.rejectedPieces;
      return +noOfPieces * +value;
    }
    return '';
  }
}
