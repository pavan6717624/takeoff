import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Subscription } from 'rxjs';

import { Section } from 'src/app/shared/models/section.model';
import { VerificationSectionsVM } from 'src/app/shared/models/verification-sections.model';
import { VerificationService } from '../service/verification.service';

@Component({
  selector: 'app-sections',
  templateUrl: './sections.component.html',
})
export class SectionsComponent implements OnInit, OnDestroy {
  private sub: any;
  private routeDataSub: Subscription;

  userRoutePrefix: string;
  verificationId: number;
  model: VerificationSectionsVM;

  constructor(private route: ActivatedRoute, private verificationService: VerificationService) {}

  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      this.verificationId = +params.verificationId;

      this.routeDataSub = this.route.data.subscribe(data => {
        this.userRoutePrefix = data.userRoutePrefix;
        this.verificationService.sections(this.verificationId).subscribe(res => (this.model = res));
      });
    });
  }

  link(section: Section): any {
    if (section.isHeader) {
      return null;
    }
    if (section.isValueStatementSection) {
      return ['/' + this.userRoutePrefix + '/verification/' + this.verificationId + '/' + section.route, section.id];
    }
    return ['/' + this.userRoutePrefix + '/verification/' + this.verificationId + '/' + section.route];
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }

    if (this.routeDataSub) {
      this.routeDataSub.unsubscribe();
    }
  }

  previewDisabled(): boolean {
    let unSavedCount = 0;
    if (this.model?.sections) {
      this.model.sections.forEach(item => {
        if (!item.isHeader) {
          if (!item.isSaved) {
            unSavedCount += 1;
          }
        }
      });
      return unSavedCount > 0;
    }
    return false;
  }

  preview(): string {
    return '/' + this.userRoutePrefix + '/verification/' + this.verificationId + '/preview';
  }
}
