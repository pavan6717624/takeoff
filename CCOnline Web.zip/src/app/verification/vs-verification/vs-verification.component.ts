import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { NGXLogger } from 'ngx-logger';

import { InputType, ValueStatementVerification } from '../model/value-statement';

/* tslint:disable:component-selector */
@Component({
  selector: '[app-vs-verification]',
  templateUrl: './vs-verification.component.html',
  styleUrls: ['./vs-verification.component.less'],
})
export class VsVerificationComponent implements OnInit {
  @Input() vs: ValueStatementVerification;
  @Input() form: FormGroup;
  inputTypes = InputType;

  constructor(private log: NGXLogger) {}

  ngOnInit(): void {
    this.log.debug('vsVerification', this.vs);
    this.log.debug('form', this.form);
  }
}
