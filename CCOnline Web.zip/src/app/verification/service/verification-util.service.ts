import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { STData } from '@delon/abc/st';
import { FileSaverService } from 'ngx-filesaver';
import { NGXLogger } from 'ngx-logger';

import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class VerificationUtilService {
  constructor(private log: NGXLogger, private http: HttpClient, private fileSaverService: FileSaverService) {}

  isContinueVerification(data: STData): boolean {
    if (data.verification) {
      if (data.verification.status) {
        return data.verification.status === 'IN_PROGRESS';
      }
      return true;
    }
    return false;
  }

  isVerificationFinished(data: STData): boolean {
    if (data.verification) {
      if (data.verification.status) {
        return data.verification.status !== 'IN_PROGRESS';
      }
      return false;
    }
    return false;
  }

  downloadReport(id: number): void {
    this.http.get(`${environment.apiUrl}/verification/${id}/report`, { observe: 'response', responseType: 'blob' }).subscribe(res => {
      this.fileSaverService.save(res.body);
    });
  }
}
