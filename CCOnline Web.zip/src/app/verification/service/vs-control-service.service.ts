import { Injectable } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';

import { ValueStatementCompliance, ValueStatementVerification } from '../model/value-statement';

@Injectable({ providedIn: 'root' })
export class VsControlServiceService {
  constructor(private fb: FormBuilder) {}

  toFormGroup(valueStatements: ValueStatementVerification[]): FormGroup {
    const group: any = {};

    valueStatements.forEach(vs => {
      let requireCommentsFor = [];

      if (!vs.valueStatement.inputType) {
        requireCommentsFor = [];
      } else if (vs.valueStatement.inputType.toString() === 'YES_NO') {
        requireCommentsFor.push('NO');
      } else if (vs.valueStatement.inputType.toString() === 'NO_YES') {
        requireCommentsFor.push('YES');
      } else if (vs.valueStatement.inputType.toString() === 'YES_NO_NA') {
        requireCommentsFor = ['NO', 'NA'];
      } else if (vs.valueStatement.inputType.toString() === 'YES_NO_NCD') {
        requireCommentsFor = ['NO', 'NCD'];
      } else if (vs.valueStatement.inputType.toString() === 'ONLY_COMMENTS') {
        requireCommentsFor = ['YES', 'NO'];
      }

      group[vs.valueStatement.id + ''] = this.fb.group(
        {
          selectedOption: [vs.optionInput || vs.numberInput || vs.dateInput, [Validators.required]],
          comments: [vs.comments],
        },
        { validator: commentsRequired(requireCommentsFor) }
      );
    });

    return new FormGroup(group);
  }

  toComplianceFormGroup(valueStatements: ValueStatementCompliance[]): FormGroup {
    const group: any = {};

    valueStatements.forEach(vs => {
      group[vs.valueStatement.id + ''] = this.fb.group({
        branchCompliance: [vs.branchCompliance || '', [Validators.required]],
        branchComments: [vs.branchComments || '', [Validators.required, Validators.maxLength(250)]],
      });
    });
    return new FormGroup(group);
  }
}

/**
 * Custom validator to check whether comments are required
 */
export function commentsRequired(requireComments: Array<string>): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const selectedOptionValue = control.get('selectedOption').value;
    const comments = control.get('comments').value;
    const isCommentsRequired = requireComments.indexOf(selectedOptionValue) > -1;

    if (requireComments.length === 0) {
      return null;
    }

    if (isCommentsRequired && !comments) {
      return { commentsRequired: true };
    }
    return null;
  };
}
