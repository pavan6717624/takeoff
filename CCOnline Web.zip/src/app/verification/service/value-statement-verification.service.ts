import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class ValueStatementVerificationService {
  constructor(private log: NGXLogger, private http: HttpClient) {}

  save(verificationId: number, sectionId: number, vsId: number, selectedOption: string, comments: string): Observable<any> {
    return this.http.post<any>(`${environment.apiUrl}/verification/value-statement/save`, {
      verificationId,
      sectionId,
      vsId,
      selectedOption,
      comments,
    });
  }

  saveCompliance(verificationId: number, sectionId: number, vsId: number, branchCompliance: any, branchComments: string): Observable<any> {
    return this.http.post<any>(`${environment.apiUrl}/compliance/value-statement/save`, {
      verificationId,
      sectionId,
      vsId,
      branchCompliance,
      branchComments,
    });
  }
}
