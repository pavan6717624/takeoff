import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { STData } from '@delon/abc/st';
import { NzMessageService } from 'ng-zorro-antd/message';
import { FileSaverService } from 'ngx-filesaver';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { VerificationBlock } from 'src/app/circle-admin/identify-vo/assign-vo-models';

import { VerificationBranchProfile, VerificationBranchProfileInput } from 'src/app/shared/models/verification-branch-profile.model';
import { VerificationSectionsVM } from 'src/app/shared/models/verification-sections.model';
import { Verification } from 'src/app/shared/models/verification.model';
import { environment } from 'src/environments/environment';
import { Stock } from '../balance-verification/balance-verification.component';
import { BalanceVerificationDetails } from '../model/balance-verification-details.model';
import { ValueStatementCompliance, ValueStatementVerification } from '../model/value-statement';
import { SubmitVM } from '../preview-for-submission/preview-for-submission.component';

export enum Action {
  ASSIGN,
  PRINT_LETTER,
  CHANGE,
  DOWNLOAD_REPORT,
}

@Injectable({ providedIn: 'root' })
export class VerificationService {
  constructor(
    private log: NGXLogger,
    private http: HttpClient,
    private fileSaverService: FileSaverService,
    private msgService: NzMessageService
  ) {}

  assignedVerifications(verificationType: string): Observable<Verification[]> {
    return this.http.get<Verification[]>(`${environment.apiUrl}/verifications/${verificationType}/assigned`);
  }

  sections(verificationId: number): Observable<VerificationSectionsVM> {
    return this.http.get<VerificationSectionsVM>(`${environment.apiUrl}/verification/${verificationId}/sections`);
  }

  complianceSections(verificationId: number): Observable<VerificationSectionsVM> {
    return this.http.get<VerificationSectionsVM>(`${environment.apiUrl}/compliance/${verificationId}/sections`);
  }

  branchProfile(verificationId: number): Observable<VerificationBranchProfile> {
    return this.http.get<VerificationBranchProfile>(`${environment.apiUrl}/verification/branch-profile/${verificationId}`);
  }

  valueStatementWithVerification(verificationId: number, sectionId: number): Observable<ValueStatementVerification[]> {
    return this.http.get<ValueStatementVerification[]>(
      `${environment.apiUrl}/verification/${verificationId}/value-statements/${sectionId}`
    );
  }

  saveBranchProfile(verificationId: number, input: VerificationBranchProfileInput): Observable<any> {
    return this.http.post(`${environment.apiUrl}/verification/${verificationId}/branch-profile`, input);
  }

  notesAdjudicatedDetails(verificationId: number): Observable<any> {
    return this.http.get(`${environment.apiUrl}/notes-adjudicated/${verificationId}`);
  }

  saveNotesAdjudicatedDetails(verificationId: number, data: any): Observable<any> {
    return this.http.post(`${environment.apiUrl}/notes-adjudicated/${verificationId}/save`, data);
  }

  /* Balance verification */

  getBalanceVerificationDetails(verificationId: number): Observable<BalanceVerificationDetails> {
    return this.http.get(`${environment.apiUrl}/balance-verification/${verificationId}`);
  }

  getBalancesAsOn(verificatonId: number, balancesAsOn: Date): Observable<any> {
    return this.http.post(`${environment.apiUrl}/balance-verification/fetch-balances`, {
      verificationId: verificatonId,
      balancesAsOn: balancesAsOn,
    });
  }

  saveBalanceVerification(verificationId: number, data: any): Observable<any> {
    return this.http.post(`${environment.apiUrl}/balance-verification/${verificationId}/save`, data);
  }

  /* Notes verification */

  notesVerificationDetails(verificationId: number): Observable<any> {
    return this.http.get(`${environment.apiUrl}/detailed-verification/${verificationId}`);
  }

  saveDetailedVerification(verificationId: number, data: any): Observable<any> {
    return this.http.post(`${environment.apiUrl}/detailed-verification/save/${verificationId}`, data);
  }

  fetchBalances(verificationId: number, balancesAsOn: Date): Observable<Stock> {
    return this.http.post<Stock>(`${environment.apiUrl}/balance-verification/fetch-balances`, { verificationId, balancesAsOn });
  }

  submitVerification(data: SubmitVM): Observable<any> {
    return this.http.post(`${environment.apiUrl}/verification/submit`, data);
  }

  /* Compliance */
  valueStatementWithCompliance(verificationId: number, sectionId: number): Observable<ValueStatementCompliance[]> {
    return this.http.get<ValueStatementCompliance[]>(`${environment.apiUrl}/compliance/${verificationId}/value-statements/${sectionId}`);
  }

  // start verification
  // To differentiate DGM B&O as Controller Visit and Module Head Visit
  startVerification(branchCode: number, block: string, dgmOfDirectBrs: boolean = false): Observable<any> {
    console.log('dgmOfDirectBrs: ', dgmOfDirectBrs);
    return this.http.post(`${environment.apiUrl}/verification/start`, { branchCode, block, dgmOfDirectBrs });
  }

  submitCompliance(verificationId: number, comments: string, isVerificationOfficer = false): Observable<any> {
    return this.http.post(`${environment.apiUrl}/compliance/submit`, { verificationId, comments, isVerificationOfficer });
  }

  rejectCompliance(verificationId: number, comments: string, isVerificationOfficer = false): Observable<any> {
    return this.http.post(`${environment.apiUrl}/compliance/reject`, { verificationId, comments, isVerificationOfficer });
  }

  displayAction(data: STData, block: VerificationBlock, action: Action): boolean {
    if (block && !block.isPastBlock) {
      if (action === Action.ASSIGN) {
        return !data.verification || !data.verification?.officer;
      }
      if (action === Action.PRINT_LETTER || action === Action.CHANGE) {
        return data.verification && data.verification.officer && !data.verification.status;
      }
    }
    if (action === Action.DOWNLOAD_REPORT) {
      return data?.verification?.status && data?.verification?.status !== 'IN_PROGRESS';
    }
    return false;
  }

  // download report
  downloadReport(verificationId: number, filename?: string): void {
    this.msgService.info('Please wait while report being fetched');
    this.http
      .get(`${environment.apiUrl}/verification/${verificationId}/report`, { observe: 'response', responseType: 'blob' })
      .subscribe(res => {
        var fileNameFromServer = res.headers.get('x-filename');
        this.fileSaverService.save(res.body, fileNameFromServer);
      });
  }

  downloadComplianceReport(verificationId: number, filename?: string): void {
    this.msgService.info('Please wait while report being fetched');
    this.http
      .get(`${environment.apiUrl}/verification/${verificationId}/complianceReport`, { observe: 'response', responseType: 'blob' })
      .subscribe(res => {
        var fileNameFromServer = res.headers.get('x-filename');
        this.fileSaverService.save(res.body, fileNameFromServer);
      });
  }
}
