export enum InputType {
  YES_NO,
  YES_NO_NA,
  YES_NO_NCD,
  DATE,
  NUMBER,
  TEXT,
}

export enum OptionCompliance {
  COMPLIED,
  NOT_COMPLIED,
  NOT_APPLICABLE,
}

export enum BranchCompliance {
  COMPLIED,
  NOT_COMPLIED,
}

export class ValueStatement {
  id: number;
  section?: any;
  displayOrder: number;
  displayNumber: string;
  description: string;
  infoText?: string;
  onlyAsHeader?: boolean;
  isOnlyAsHeader?: boolean;
  inputType: InputType;
  indentLevel?: number;
  subValueStatements?: ValueStatement[];
}

export class ValueStatementVerification {
  valueStatement: ValueStatement;
  comments?: string;
  optionInput?: string;
  dateInput?: string;
  numberInput?: number;

  constructor(
    options: {
      valueStatement?: ValueStatement;
      comments?: string;
      optionInput?: string;
      dateInput?: string;
      numberInput?: number;
    } = {}
  ) {
    this.valueStatement = options.valueStatement;
    this.comments = options.comments || '';
    this.optionInput = options.optionInput || '';
    this.dateInput = options.dateInput || undefined;
    this.numberInput = options.numberInput || 0;
  }
}

export class ValueStatementCompliance {
  valueStatement: ValueStatement;
  comments?: string;
  optionInput?: string;
  compliance?: string;
  dateInput?: string;
  numberInput?: number;
  branchCompliance?: any;
  branchComments: string;

  constructor(
    options: {
      valueStatement?: ValueStatement;
      comments?: string;
      optionInput?: string;
      compliance?: string;
      dateInput?: string;
      numberInput?: number;
      branchCompliance?: any;
      branchComments?: string;
    } = {}
  ) {
    this.valueStatement = options.valueStatement;
    this.comments = options.comments || '';
    this.optionInput = options.optionInput || '';
    this.compliance = options.compliance || null;
    this.dateInput = options.dateInput || null;
    this.numberInput = options.numberInput || 0;
    this.branchCompliance = options.branchCompliance || '';
    this.branchComments = options.branchComments || '';
  }
}
