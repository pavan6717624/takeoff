export interface BalanceVerificationDetailsVerification {
  blockFrom: Date;
  blockTo: Date;
}
export interface BalanceVerificationDetails {
  balancesAsOn?: Date;
  hasDiscrepancy?: boolean;
  discrepancyDetails?: string;
  verification?: BalanceVerificationDetailsVerification;
}
