export enum VerificationStatus {
  IN_PROGRESS,
  SUBMITTED = 'Verification Report Submitted',
  CMP_SUBMITTED_BY_BR_MAKER = 'Compliance submitted by branch maker',
  CMP_REJECTED_BY_BR_HEAD = 'Compliance rejected by branch head',
  CMP_SUBMITTED_BY_BR_HEAD = 'Compliance submitted by branch head',
  CMP_REJECTED_BY_SCRUTINIZER = 'Compliance rejected by scrutinizer',
  CMP_SUBMITTED_BY_SCRUTINIZER = 'Compliance submitted by scrutinizer',
  CMP_VERIFIED_BY_VO = 'Compliance verified by Verification officer',
  CMP_REJECTED_BY_CA = 'Compliance rejected by closure authority',
  CMP_CLOSED = 'Closure',
}
