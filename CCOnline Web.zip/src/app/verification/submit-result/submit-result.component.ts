import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-submit-result',
  template: ` <nz-alert
      nzType="info"
      nzMessage="Verification report can be saved in PDF by using 'Download Report' button, and also can be viewed from Verification page."
      nzShowIcon
    ></nz-alert>
    <nz-result nzStatus="success" nzTitle="Verification/Visit Report Submitted Successfully">
      <div nz-result-extra>
        <button nz-button nzType="primary" fileSaver method="GET" [url]="reportUrl()" fileName="verification-report.pdf">Download Report</button>
        <button nz-button [routerLink]="['/' + userRoutePrefix + '/verifications']">Back to Verifications</button>
      </div>
    </nz-result>`,
})
export class SubmitResultComponent implements OnInit {
  private sub: Subscription;
  private routeDataSub: Subscription;

  verificationId: number;
  userRoutePrefix: string;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      this.verificationId = params.verificationId;
      this.routeDataSub = this.route.data.subscribe(data => {
        this.userRoutePrefix = data.userRoutePrefix;
      });
    });
  }

  reportUrl(): string {
    return `${environment.apiUrl}/verification/${this.verificationId}/report`;
  }
}
