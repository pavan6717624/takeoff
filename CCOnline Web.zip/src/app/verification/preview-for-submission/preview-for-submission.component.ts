import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { isAfter, isBefore, parseISO, set } from 'date-fns';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { VerificationSectionsVM } from 'src/app/shared/models/verification-sections.model';
import { VerificationService } from '../service/verification.service';

export interface SubmitVM {
  verificationId: number;
  verificationOfficerComments: string;
  certify: boolean;
  verificationDate: Date;
}

@Component({
  selector: 'app-preview-for-submission',
  templateUrl: './preview-for-submission.component.html',
})
export class PreviewForSubmissionComponent implements OnInit, OnDestroy {
  loading = false;

  dateFormat = DATE_FORMAT;

  private sub: Subscription;
  private routeDataSub: Subscription;

  certified: false;

  userRoutePrefix: string;

  verificationId: number;
  model!: VerificationSectionsVM;
  form!: FormGroup;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private verificationService: VerificationService,
    private fb: FormBuilder,
    private modalService: NzModalService,
    private log: NGXLogger
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      verificationOfficerComments: ['', [Validators.required, Validators.maxLength(1000)]],
      certify: [false, [Validators.requiredTrue]],
      verificationDate: ['', [Validators.required]],
    });

    this.sub = this.route.params.subscribe(params => {
      this.verificationId = params.verificationId;

      this.routeDataSub = this.route.data.subscribe(data => {
        this.userRoutePrefix = data.userRoutePrefix;
        this.verificationService.sections(this.verificationId).subscribe(res => {
          this.model = res;

          this.log.debug("model?.sections", this.model.sections);
        });
      });
    });
  }

  ngOnDestroy(): void {
    if (this.routeDataSub) {
      this.routeDataSub.unsubscribe();
    }

    if (this.sub) {
      this.sub.unsubscribe();
    }
  }

  submit(): void {
    if (this.form.valid) {
      this.modalService.confirm({
        nzTitle: 'Are you sure you want to submit the verification/visit report?',
        nzContent: 'Once submitted, report cannot be modified',
        nzOnOk: () => this.submitConfirm(),
      });
    }
  }

  submitConfirm(): void {
    this.loading = true;
    this.verificationService
      .submitVerification({
        verificationId: this.verificationId,
        verificationOfficerComments: this.form.get('verificationOfficerComments').value,
        certify: this.form.get('certify').value,
        verificationDate: this.form.get('verificationDate').value,
      })
      .subscribe(
        () => {
          this.loading = false;
          this.router.navigate(['../submitted'], { relativeTo: this.route });
        },
        () => (this.loading = false)
      );
  }

  disabledDate = (current: Date): boolean => {
    const currentNew = set(current, { hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
    if (this.model && this.model.blockFrom && this.model.blockTo) {
      // this.log.trace('current: ', currentNew);
      // this.log.trace('blockFrom: ', parseISO(this.model.blockFrom));
      // this.log.trace('blockTo: ', parseISO(this.model.blockTo));

      if (isBefore(currentNew, parseISO(this.model.blockFrom)) || isAfter(currentNew, parseISO(this.model.blockTo))) {
        return true;
      }
    }
    return false;
  };
}
