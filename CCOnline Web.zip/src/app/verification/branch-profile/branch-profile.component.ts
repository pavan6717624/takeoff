import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { isFuture } from 'date-fns';
import { NzNotificationService } from 'ng-zorro-antd/notification';

import { NGXLogger } from 'ngx-logger';
import { STAFF_COUNT_VALIDATOR } from 'src/app/core/constants/validation.constants';

import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { IdNameDesc } from 'src/app/shared/models/id-name-desc.model';
import { VerificationBranchProfile, VerificationBranchProfileView } from 'src/app/shared/models/verification-branch-profile.model';
import { VerificationService } from '../service/verification.service';

@Component({
  selector: 'app-branch-profile',
  templateUrl: './branch-profile.component.html',
})
export class BranchProfileComponent implements OnInit, OnDestroy {
  readonly dateFormat = DATE_FORMAT;

  loading = false;
  saving = false;
  
  branchProfileForm: FormGroup;

  private sub: any;
  verificationId: number;
  profile: VerificationBranchProfile;
  view: VerificationBranchProfileView;
  ccTypes: IdNameDesc[];

  constructor(
    private route: ActivatedRoute,
    private log: NGXLogger,
    private fb: FormBuilder,
    private verificationService: VerificationService,
    private notification: NzNotificationService
  ) {}

  ngOnInit(): void {
    this.branchProfileForm = this.fb.group({
      incumbency: ['', [Validators.required]],
      incumbencySince: ['', [Validators.required]],
      ccType: ['', [Validators.required]],
      totalStaff: this.fb.group({
        award: ['', STAFF_COUNT_VALIDATOR],
        supervisory: ['', STAFF_COUNT_VALIDATOR],
      }),
      cashDeptStaff: this.fb.group({
        award: ['', STAFF_COUNT_VALIDATOR],
        supervisory: ['', STAFF_COUNT_VALIDATOR],
      }),
      ccBalanceReportedInCyM: ['', [Validators.required, Validators.min(0), Validators.max(999999999999999), Validators.pattern('\\d+')]],
      balanceOfSoiledNotesAvailableInCc: [
        '',
        [Validators.required, Validators.min(0), Validators.max(999999999999999), Validators.pattern('\\d+')],
      ],
      lastBiMonthlyVerification: [null, [Validators.required]],
      lastQuarterlyVerification: [null, []],
      lastHalfYearlyVerification: [null, [Validators.required]],
      lastSecurityOfficerVist: [null, [Validators.required]],
      strongRoomFitnessCertExpiryDate: [null, [Validators.required]],
    });

    this.sub = this.route.params.subscribe(params => {
      this.verificationId = +params.verificationId;

      // load sections from API
      this.loading = true;
      this.verificationService.branchProfile(this.verificationId).subscribe(
        res => {
          this.profile = res;
          this.view = res.viewModel;
          this.ccTypes = res.ccTypes;

          let inputModel = this.profile.inputModel;

          if (this.profile.securityOfficer) {
            this.branchProfileForm.removeControl('ccBalanceReportedInCyM');
            this.branchProfileForm.removeControl('balanceOfSoiledNotesAvailableInCc');
            this.branchProfileForm.removeControl('lastBiMonthlyVerification');
            this.branchProfileForm.removeControl('lastQuarterlyVerification');
            this.branchProfileForm.removeControl('lastHalfYearlyVerification');

            delete inputModel.ccBalanceReportedInCyM;
            delete inputModel.balanceOfSoiledNotesAvailableInCc;
            delete inputModel.lastBiMonthlyVerification;
            delete inputModel.lastQuarterlyVerification;
            delete inputModel.lastHalfYearlyVerification;
          } else {
            this.branchProfileForm.removeControl('lastSecurityOfficerVist');
            delete inputModel.lastSecurityOfficerVist;
          }

          /* For Top officials visit */
          if (this.profile.topOfficialsVisit) {
            this.branchProfileForm.removeControl('incumbency');
            this.branchProfileForm.removeControl('incumbencySince')
            this.branchProfileForm.removeControl('ccType');
            this.branchProfileForm.removeControl('totalStaff');
            this.branchProfileForm.removeControl('cashDeptStaff');
                       
            this.branchProfileForm.removeControl('ccBalanceReportedInCyM');
            this.branchProfileForm.removeControl('balanceOfSoiledNotesAvailableInCc');
            this.branchProfileForm.removeControl('lastBiMonthlyVerification');
            this.branchProfileForm.removeControl('lastQuarterlyVerification');
            this.branchProfileForm.removeControl('lastHalfYearlyVerification');
            this.branchProfileForm.removeControl('lastSecurityOfficerVist');
            this.branchProfileForm.removeControl('strongRoomFitnessCertExpiryDate');

            delete inputModel.incumbency;
            delete inputModel.incumbencySince;
            delete inputModel.ccType;
            delete inputModel.totalStaff;
            delete inputModel.cashDeptStaff;

            delete inputModel.ccBalanceReportedInCyM;
            delete inputModel.balanceOfSoiledNotesAvailableInCc;
            delete inputModel.lastBiMonthlyVerification;
            delete inputModel.lastQuarterlyVerification;
            delete inputModel.lastHalfYearlyVerification;
            delete inputModel.lastSecurityOfficerVist;
            delete inputModel.strongRoomFitnessCertExpiryDate;
          } else {
            //this.branchProfileForm.removeControl('lastSecurityOfficerVist');
            //delete inputModel.lastSecurityOfficerVist;
          }
          this.branchProfileForm.patchValue(inputModel);
          this.loading = false;
        },
        () => (this.loading = false)
      );
    });
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }

  disabledDate(d: Date): boolean {
    return isFuture(d);
  }

  save(): void {
    this.log.debug('saving...', this.branchProfileForm.value);
    this.saving = true;
    this.verificationService.saveBranchProfile(this.verificationId, this.branchProfileForm.value).subscribe(
      () => {
        this.saving = false;
        this.notification.success('Data saved successfully', '');
      },
      () => (this.saving = false)
    );
  }
}
