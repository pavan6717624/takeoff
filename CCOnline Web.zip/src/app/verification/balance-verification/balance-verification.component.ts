import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';
import { BalanceVerificationDetails } from '../model/balance-verification-details.model';
import { VerificationService } from '../service/verification.service';

export interface StockInfo {
  denominationId: number;
  denominationValue: number;
  noOfPieces: number;
}

export interface Stock {
  notes: StockInfo[];
  coins: StockInfo[];
}

@Component({
  selector: 'app-balance-verification',
  templateUrl: './balance-verification.component.html',
})
export class BalanceVerificationComponent implements OnInit {
  dateFormat = DATE_FORMAT;

  constructor(
    private log: NGXLogger,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private verificationService: VerificationService,
    private msgService: NzMessageService
  ) {}

  private sub: Subscription;

  //#region trackers
  loading = true;
  isFetchingBalances = false;
  fetchedBalances = false;
  saving = false;
  //#endregion

  stock: Stock;

  verificationId: number;
  balancesAsOn = '';
  balanceVerificationDetails!: BalanceVerificationDetails;

  balancesAsOnForm!: FormGroup;
  discrepancyForm!: FormGroup;

  ngOnInit(): void {
    this.balancesAsOnForm = this.fb.group({
      balancesAsOn: ['', [Validators.required]],
    });

    this.discrepancyForm = this.fb.group(
      {
        hasDiscrepancy: [false, [Validators.required]],
        discrepancyDetails: ['', [Validators.maxLength(250)]],
      },
      { validator: discrepancyDetailsRequired() }
    );

    // fetch details
    this.sub = this.route.params.subscribe(params => {
      this.verificationId = +params.verificationId;

      this.verificationService.getBalanceVerificationDetails(this.verificationId).subscribe(res => {
        this.balanceVerificationDetails = res;

        if (this.balanceVerificationDetails && this.balanceVerificationDetails.balancesAsOn) {
          this.balancesAsOnForm.patchValue({
            balancesAsOn: this.balanceVerificationDetails.balancesAsOn,
          });

          this.discrepancyForm.patchValue({
            hasDiscrepancy: this.balanceVerificationDetails.hasDiscrepancy,
            discrepancyDetails: this.balanceVerificationDetails.discrepancyDetails,
          });

          if (this.balanceVerificationDetails?.balancesAsOn) {
            this.isFetchingBalances = true;
            this.verificationService.getBalancesAsOn(this.verificationId, this.balanceVerificationDetails.balancesAsOn).subscribe(
              stockRes => {
                this.stock = stockRes;
                this.fetchedBalances = true;
                this.isFetchingBalances = false;
              },
              () => (this.isFetchingBalances = false)
            );
          }
        }
      });
    });
  }

  fetchBalances(): void {
    this.isFetchingBalances = true;
    this.verificationService.fetchBalances(this.verificationId, this.balancesAsOnForm.get('balancesAsOn').value).subscribe(
      res => {
        this.stock = res;
        this.fetchedBalances = true;
        this.isFetchingBalances = false;
      },
      err => (this.isFetchingBalances = false),
      () => (this.isFetchingBalances = false)
    );
  }

  onDateChange(): void {
    this.balancesAsOnForm.get('balancesAsOn').valueChanges.subscribe(val => {
      if (this.fetchedBalances) {
        this.fetchedBalances = false;
      }
    });
  }

  isDateDisabled = (current: Date): boolean => {
    var selected = new Date(current);
    selected.setHours(0);
    selected.setMinutes(0);
    selected.setSeconds(0);
    selected.setMilliseconds(0);

    var now = new Date();
    now.setHours(0);
    now.setMinutes(0);
    now.setSeconds(0);
    now.setMilliseconds(0);

    if (selected > now) {
      return true;
    }

    if (
      this.balanceVerificationDetails &&
      this.balanceVerificationDetails?.verification?.blockFrom &&
      this.balanceVerificationDetails?.verification?.blockTo
    ) {
      var periodFrom = new Date(this.balanceVerificationDetails.verification.blockFrom);
      periodFrom.setHours(0);
      periodFrom.setMinutes(0);
      periodFrom.setSeconds(0);
      periodFrom.setMilliseconds(0);

      var periodTo = new Date(this.balanceVerificationDetails.verification.blockTo);
      periodTo.setHours(0);
      periodTo.setMinutes(0);
      periodTo.setSeconds(0);
      periodTo.setMilliseconds(0);

      if (selected < periodFrom || selected > periodTo) {
        return true;
      }
    }

    return false;
  };

  toggledHasDiscrepancy(): void {
    this.discrepancyForm.get('discrepancyDetails').setValue('');
  }

  save(): void {
    this.saving = true;
    if (this.fetchedBalances && this.discrepancyForm.valid) {
      this.verificationService
        .saveBalanceVerification(this.verificationId, {
          balancesAsOn: this.balancesAsOnForm.get('balancesAsOn').value,
          hasDiscrepancy: this.discrepancyForm.get('hasDiscrepancy').value,
          discrepancyDetails: this.discrepancyForm.get('discrepancyDetails').value,
        })
        .subscribe(
          res => {
            this.msgService.success('Data saved successfully');
          },
          err => (this.saving = false),
          () => (this.saving = false)
        );
    }
  }
}

/**
 * Custom validator to check whether comments are required
 */
export function discrepancyDetailsRequired(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const hasDiscrepancy = control.get('hasDiscrepancy').value;
    const discrepancyDetails = control.get('discrepancyDetails').value;

    if (hasDiscrepancy && !discrepancyDetails) {
      return { discrepancyDetailsRequired: true };
    }

    return null;
  };
}
