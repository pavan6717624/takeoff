import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { Subscription } from 'rxjs';
import { DATE_FORMAT } from 'src/app/shared/constants/input.constants';

import { InputType, ValueStatementVerification } from '../model/value-statement';
import { ValueStatementVerificationService } from '../service/value-statement-verification.service';
import { VerificationService } from '../service/verification.service';
import { VsControlServiceService } from '../service/vs-control-service.service';

@Component({
  selector: 'app-value-statements',
  templateUrl: './value-statements.component.html',
  styles: [
    `
      .td-nowrap {
        white-space: nowrap;
      }

      .saved {
        background: #fcfff5 !important;
        color: #2c662d !important;
      }

      .not-saved {
        background: #fff6f6 !important;
        color: #9f3a38 !important;
        font-weight: 500;
      }
    `,
  ],
})
export class ValueStatementsComponent implements OnInit, OnDestroy {
  dateFormat = DATE_FORMAT;
  loading = false;
  verificationId: number;
  sectionId: number;
  private router$!: Subscription;

  valueStatements: ValueStatementVerification[] = [];
  section: any;
  form: FormGroup = new FormGroup({});
  inputTypes = InputType;
  formChangesSub: Subscription;

  formInitialState: any;
  savedStatus = new Map<string, boolean>();

  constructor(
    private route: ActivatedRoute,
    private vsvs: ValueStatementVerificationService,
    private verificationService: VerificationService,
    private vscs: VsControlServiceService,
    private log: NGXLogger,
    private notification: NzNotificationService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    this.router$ = this.route.params.subscribe(params => {
      this.verificationId = +params.verificationId;
      this.sectionId = +params.sectionId;

      this.log.debug('sectionid & verificationid', this.sectionId, this.verificationId);

      this.verificationService.valueStatementWithVerification(this.verificationId, this.sectionId).subscribe(
        res => {
          this.valueStatements = res;
          if (this.valueStatements.length > 0) {
            this.section = this.valueStatements[0].valueStatement.section;
          }
          this.form = this.vscs.toFormGroup(this.valueStatements);

          this.formInitialState = this.form.value;

          Object.keys(this.form.controls).forEach(key => {
            if (this.form.controls[key].value.selectedOption) {
              this.savedStatus.set(key, true);
            } else {
              this.savedStatus.set(key, false);
            }
          });

          this.formChangesSub = this.form.valueChanges.subscribe(change => {
            this.handleFormChanges(change);
          });

          this.loading = false;

          this.notification.info('Please Note', 'Comment have to be saved for individual value statement', { nzPlacement: 'topRight' });
        },
        () => (this.loading = false)
      );
    });
  }

  ngOnDestroy(): void {
    if (this.router$) {
      this.router$.unsubscribe();
    }
    if (this.formChangesSub) {
      this.formChangesSub.unsubscribe();
    }
  }

  save(vsId: number): void {
    const current = this.form.get(vsId + '');
    if (current.valid) {
      this.vsvs.save(this.verificationId, this.sectionId, vsId, current.value.selectedOption, current.value.comments).subscribe(res => {
        this.savedStatus.set(vsId + '', true);
      });
    }
  }

  savedButtonDisabled(id: number): boolean {
    return true;
  }

  handleFormChanges(changes: any): void {
    Object.keys(changes).forEach(item => {
      if (
        this.formInitialState[item].selectedOption !== changes[item].selectedOption ||
        this.formInitialState[item].comments !== changes[item].comments
      ) {
        this.savedStatus.set(item, false);
      }
    });
    this.formInitialState = changes;
  }
}
