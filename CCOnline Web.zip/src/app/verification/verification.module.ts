import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BranchProfileComponent } from './branch-profile/branch-profile.component';
import { SharedModule } from '../shared/shared.module';
import { DelonLocaleService } from '@delon/theme';
import { DELON_LOCALE, en_US } from '@delon/theme';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SectionsComponent } from './sections/sections.component';
import { BalanceVerificationComponent } from './balance-verification/balance-verification.component';
import { NotesVerificationComponent } from './notes-verification/notes-verification.component';
import { ValueStatementsComponent } from './value-statements/value-statements.component';
import { NotesAdjudicatedComponent } from './notes-adjudicated/notes-adjudicated.component';
import { VsVerificationComponent } from './vs-verification/vs-verification.component';
import { PreviewForSubmissionComponent } from './preview-for-submission/preview-for-submission.component';
import { ComplianceModule } from '../compliance/compliance.module';
import { SubmitResultComponent } from './submit-result/submit-result.component';

const routes: Routes = [
  {
    path: ':verificationId/sections',
    component: SectionsComponent,
  },
  {
    path: ':verificationId/branch-profile',
    component: BranchProfileComponent,
  },
  {
    path: 'balance-verification',
    component: BalanceVerificationComponent,
  },
  {
    path: 'notes-verification',
    component: NotesVerificationComponent,
  },
  {
    path: 'notes-adjudicated',
    component: NotesAdjudicatedComponent,
  },
  {
    path: ':verificationId/value-statements/:sectionId',
    component: ValueStatementsComponent,
  },
];

@NgModule({
  declarations: [
    BranchProfileComponent,
    SectionsComponent,
    BalanceVerificationComponent,
    NotesVerificationComponent,
    ValueStatementsComponent,
    NotesAdjudicatedComponent,
    VsVerificationComponent,
    PreviewForSubmissionComponent,
    SubmitResultComponent,
  ],
  imports: [CommonModule, SharedModule, FormsModule, ReactiveFormsModule, ComplianceModule],
  exports: [
    BranchProfileComponent,
    SectionsComponent,
    BalanceVerificationComponent,
    NotesVerificationComponent,
    NotesAdjudicatedComponent,
    ValueStatementsComponent,
    PreviewForSubmissionComponent,
    SubmitResultComponent,
  ],
  providers: [DelonLocaleService, { provide: DELON_LOCALE, useValue: en_US }],
})
export class VerificationModule {}
