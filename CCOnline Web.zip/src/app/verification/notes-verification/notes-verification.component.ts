import { templateJitUrl } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { Observable, of, Subscription } from 'rxjs';
import { PIECES_VALIDATOR, PIECES_VALIDATOR_REQUIRED } from 'src/app/core/constants/validation.constants';
import { VerificationService } from '../service/verification.service';

enum DiscrepancyType {
  SHORTAGE,
  EXCESS,
}

enum DenominationType {
  COIN,
  NOTE,
}

interface Denomination {
  id?: number;
  value?: number;
  description?: string;
  type?: DenominationType;
}

export interface DenominationWiseDetailedVerification {
  denominationId: number;
  denominationValue: number;
  noOfPieces?: number;
  discrepancyType?: DiscrepancyType;
  discrepancyPieces?: number;
  ficn?: number;
  soiledWronglyClassified?: number;
  mutilatedWronglyClassified?: number;
}

@Component({
  selector: 'app-notes-verification',
  templateUrl: './notes-verification.component.html',
  styleUrls: ['./notes-verification.component.less'],
})
export class NotesVerificationComponent implements OnInit {
  //#region trackers
  loading = true;
  saving = false;
  //#endregion

  verificationId: number;

  private sub: Subscription;

  denominationWiseDetails: DenominationWiseDetailedVerification[];
  form: FormGroup = new FormGroup({});

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private verificationService: VerificationService,
    private log: NGXLogger,
    private notification: NzNotificationService
  ) {}

  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      this.verificationId = +params.verificationId;

      this.verificationService.notesVerificationDetails(this.verificationId).subscribe(res => {
        this.denominationWiseDetails = res;

        this.form = this.getNotesFormControl(this.denominationWiseDetails);
      });
    });
  }

  getNotesFormControl(denomWise: DenominationWiseDetailedVerification[]): FormGroup {
    const group: any = {};

    denomWise.forEach(item => {
      group[item.denominationId] = this.fb.group(
        {
          noOfPieces: [item.noOfPieces, PIECES_VALIDATOR_REQUIRED],
          discrepancyType: [item.discrepancyType],
          discrepancyPieces: [item.discrepancyPieces, PIECES_VALIDATOR],
          ficn: [item.ficn, PIECES_VALIDATOR],
          soiledWronglyClassified: [item.soiledWronglyClassified, PIECES_VALIDATOR],
          mutilatedWronglyClassified: [item.mutilatedWronglyClassified, PIECES_VALIDATOR],
        },
        { validators: discrepancyDetailsRequired }
      );
    });
    return new FormGroup(group);
  }

  sort(denomWise: DenominationWiseDetailedVerification[]): Observable<any> {
    const notes = denomWise;
    return of(notes.sort((a, b) => a.denominationValue - b.denominationValue));
  }

  save(): void {
    this.saving = true;
    this.log.debug('saving data...', this.form.value);
    this.verificationService.saveDetailedVerification(this.verificationId, this.form.value).subscribe(
      res => {
        this.log.debug(res);
        this.notification.success('Data Saved Successfully', '');
      },
      err => {
        this.saving = false;
      },
      () => (this.saving = false)
    );
  }
}

export const discrepancyDetailsRequired: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
  const discrepancyType = control.get('discrepancyType');
  if (discrepancyType.value) {
    const discrepancyPieces = control.get('discrepancyPieces');
    return discrepancyPieces ? null : { discrepancyDetailsRequired: true };
  }
  return null;
};
