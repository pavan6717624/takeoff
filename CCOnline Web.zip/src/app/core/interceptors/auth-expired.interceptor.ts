import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { tap } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { AuthService } from '../auth/auth.service';

@Injectable()
export class AuthExpiredInterceptor implements HttpInterceptor {
  constructor(private notificationService: NzNotificationService, private authService: AuthService, private log: NGXLogger) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      tap(null, (err: HttpErrorResponse) => {
        if (err.status === 401 && err.url && !err.url.includes('api/account')) {
          this.notificationService.error('401: Unauthorized', 'Please logout and login again to continue');
          this.authService.authExpired();
        }
      })
    );
  }
}
