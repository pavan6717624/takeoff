import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { NGXLogger } from 'ngx-logger';

import { AlertService } from '../services/alert.service';

/**
 * Interceptor for handling server errors
 */
@Injectable()
export class ErrorHandlerInterceptor implements HttpInterceptor {
  constructor(private log: NGXLogger, private alertService: AlertService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.error instanceof ErrorEvent) {
          this.log.debug('client side error');
          this.alertService.set({ type: 'error', title: 'An error occured', messages: [error.error.message] });
        } else {
          this.log.debug('server side error', error);
          if (!(error.status === 401 && (error.message === '' || (error.url && error.url.includes('api/account'))))) {
            if (error.status === 0) {
              this.alertService.set({
                type: 'error',
                title: 'Network error',
                messages: ['Cannot reach Server. Please check network connectivity.'],
              });
            } else if (error.status === 500) {
              this.log.error('500 error', error);
              this.alertService.set({
                type: 'error',
                messages: [error.error?.detail || error.error.title || 'Server error. Please contact helpdesk'],
              });
            } else if (error.status === 400) {
              if (error?.error?.type === 'https://zalando.github.io/problem/constraint-violation' && error.error?.violations) {
                let violations = '';
                error.error.violations.forEach((item, index) => {
                  this.log.debug(item, item.field);
                  violations = violations + item.field + ': ' + item.message + (error.error.violations.length === index ? '' : ', ');
                  this.log.debug(violations);
                });
                this.alertService.set({ type: 'error', title: error.error.title, messages: [violations] }, true);
              } else if (error?.error?.type === 'https://cconline.sbi/help/problem/validation-problem') {
                let errs = error?.error?.errors;
                if (errs && errs.length > 0) {
                  this.alertService.set({ type: 'error', title: error?.error?.detail || error?.error?.title, messages: errs }, true);
                } else {
                  this.alertService.set({ type: 'error', title: error?.error?.detail || error?.error?.title, messages: [] }, true);
                }
              } else {
                this.alertService.set({
                  type: 'error',
                  title: '400: Bad Request',
                  messages: [error.error.detail || error.error.title || JSON.stringify(error)],
                });
              }
            } else if (error.status === 401) {
              this.alertService.set({
                type: 'error',
                messages: [error.error?.detail || error.error.title || 'Unauthorized'],
              });
            } else if (error.status === 404) {
              console.log('404 error:', error.error);

              if (error.error instanceof Blob) {
                error.error
                  .text()
                  .then(value => {
                    const errorDetails = JSON.parse(value);
                    this.alertService.set({
                      type: 'error',
                      title: errorDetails.title || 'Not Found',
                      messages: [errorDetails.detail || 'Resource you are looking for is not found'],
                    });
                  })
                  .catch(err => {
                    this.alertService.set({ type: 'error', title: 'Not Found', messages: ['Resource you are looking for is not found'] });
                  });
              } else {
                this.alertService.set({
                  type: 'error',
                  title: error.error.title || 'Not Found',
                  messages: [error.error?.detail || 'Resource you are looking for is not found'],
                });
              }
            } else {
              this.alertService.set({
                type: 'error',
                //title: `${error.status}: error`,
                messages: [error.error.detail || error.error.title || 'Unknown error'],
              });
            }
          }
        }
        return throwError(error);
      })
    );
  }
}
