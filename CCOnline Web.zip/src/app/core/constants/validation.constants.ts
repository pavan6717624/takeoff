import { Validators } from '@angular/forms';

export const EMAIL_REGEX = /[a-z0-9_.]+@sbi.co.in/i;
export const PF_ID_PATTERN = '\\d{7,10}';
export const MOBILE_NO_PATTERN = '^[6-9]\\d{9}$';
export const PIECES_VALIDATOR = [Validators.min(0), Validators.max(999999999999999)];
export const PIECES_VALIDATOR_REQUIRED = [Validators.required, Validators.pattern('^[0-9]{1,15}$')];
export const STAFF_COUNT_VALIDATOR = [Validators.required, Validators.pattern('\\d+'), Validators.min(1), Validators.max(50)];

export const PF_ID_VALIDATOR = [
  Validators.required,
  Validators.pattern(PF_ID_PATTERN),
  Validators.min(1000000),
  Validators.max(9999999999),
];

export const FILE_NAME_FILTER_REGEX = '/[/\\?%*:|"<>]/g';
