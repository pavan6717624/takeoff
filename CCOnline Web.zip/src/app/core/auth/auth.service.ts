import { DOCUMENT } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { SessionStorageService } from 'ngx-webstorage';
import { of, Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';

import { UserRole } from './user-role';
import { User } from './user';
import { environment } from '../../../environments/environment';
import { Role } from 'src/app/shared/constants/role.constants';
import { Level } from './level.model';
import { NGXLogger } from 'ngx-logger';
import { StateStorageService } from './state-storage.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  public static readonly TOKEN_KEY = 'authenticationToken';
  public static readonly LOGIN_FAILURE_MESSAGE = 'loginFailureMessage';

  principal: User;
  authenticated = false;
  authenticationState = new Subject<User>();

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private http: HttpClient,
    private stateStorageService: StateStorageService,
    private sessionStorage: SessionStorageService,
    private router: Router,
    private log: NGXLogger
  ) {}

  login(): void {
    this.log.debug('redirecting to app login page');
    this.document.location.href = `${environment.apiUrl}/login`;
  }

  logout(): Observable<any> {
    this.log.trace('>> logout()');
    return new Observable(observer => {
      this.sessionStorage.clear(AuthService.TOKEN_KEY);
      this.authenticate(null);
      observer.complete();
    });
  }

  logoutAndRedirect(): void {
    this.http.post(`${environment.apiUrl}/logout`, {}).subscribe(res => {
      this.sessionStorage.clear(AuthService.TOKEN_KEY);
      this.authenticate(null);
      if (environment.apiLogout) {
        this.document.location.href = `${environment.apiUrl}/logout`;
      } else {
        this.router.navigate(['']);
      }
    });
  }

  authExpired(): void {
    this.sessionStorage.clear(AuthService.TOKEN_KEY);
    this.authenticate(null);
    if (environment.apiLogout) {
      this.document.location.href = `${environment.apiUrl}/logout`;
    } else {
      this.router.navigate(['']);
    }
  }

  isAuthenticated(): boolean {
    return this.authenticated;
  }

  getAuthenticationState(): Observable<User> {
    return this.authenticationState.asObservable();
  }

  getToken(): string {
    return this.sessionStorage.retrieve(AuthService.TOKEN_KEY);
  }

  setToken(token: string): void {
    this.sessionStorage.store(AuthService.TOKEN_KEY, token);
    this.sessionStorage.clear(AuthService.LOGIN_FAILURE_MESSAGE);
  }

  getAccount(): Observable<User> {
    return this.http.get<User>(`${environment.apiUrl}/account`);
  }

  authenticate(principal: User): void {
    this.principal = principal;
    this.authenticated = principal !== null;
    this.authenticationState.next(this.principal);
  }

  getPrincipal(force?: boolean): Observable<User> {
    if (force === true) {
      this.principal = undefined;
    }

    if (this.principal) {
      return of(this.principal);
    }
    return this.getAccount().pipe(
      map(
        account => {
          if (account) {
            this.authenticate(account);
          } else {
            this.authenticate(null);
          }
          return this.principal;
        },
        error => {
          this.log.debug(error);
          this.authenticate(null);
          return null;
        }
      )
    );
  }

  hasRole(role: string): Observable<boolean> {
    this.log.debug('hasRole: ', role);
    if (!this.authenticated) {
      return of(false);
    }

    return this.getPrincipal().pipe(
      map(
        princial => {
          if (princial.roles) {
            const foundRole = princial.roles.find(r => r.name === role);
            this.log.debug(`foundRole: ${foundRole}`);

            if (foundRole) {
              return true;
            }
          }
        },
        () => {
          return false;
        }
      )
    );
  }

  hasRoleDirect(role: string): boolean {
    if (!this.authenticated || !this.principal || !this.principal.roles) {
      return false;
    }

    if (this.principal.roles.find(r => r.name === role)) {
      return true;
    }

    return false;
  }

  hasAnyRole(roles: string[]): Observable<boolean> {
    if (!this.authenticated) {
      return of(false);
    }

    return this.getPrincipal().pipe(
      map(
        principal => {
          if (!principal.roles) {
            return false;
          }
          for (const role of roles) {
            if (principal.roles.find(r => r.name === role)) {
              return true;
            }
          }
          return false;
        },
        () => {
          return false;
        }
      )
    );
  }

  hasAnyRolesDirect(roles: string[]): boolean {
    if (!this.authenticated || !this.principal || !this.principal.roles) {
      return false;
    }

    for (let i = 0; i < roles.length; i++) {
      if (this.principal.roles.find(r => r.name === roles[i])) {
        return true;
      }
    }

    return false;
  }

  getAllRoles(): UserRole[] {
    if (!this.authenticated) {
      return [];
    }
    return this.principal.roles;
  }

  isLoginFailed(): boolean {
    if (this.getLoginFailureMessage()) {
      return true;
    }
    return false;
  }

  getLoginFailureMessage(): string {
    const msg = this.sessionStorage.retrieve(AuthService.LOGIN_FAILURE_MESSAGE) || '';
    return msg;
  }

  redirectToUserHomePage(): void {
    this.log.trace('>> redirectToUserHomePage()');

    if (this.authenticated) {
      /**
       * Branch: Chest Position
       * Circle Admin: circle-admin
       * FSLO: fslo
       * ABD: abd
       * Verification Officer: /verification
       */
      let userHomePageRoute = '';
      if (this.hasRoleDirect(Role.CIRCLE_ADMIN)) {
        userHomePageRoute = 'circle-admin';
      } else if (this.hasRoleDirect(Role.BRANCH_HEAD) || this.hasRoleDirect(Role.BRANCH_USER)) {
        userHomePageRoute = 'branch';
      } else if (this.hasRoleDirect(Role.CM_CR)) {
        userHomePageRoute = 'controller';
      } else if (this.hasRoleDirect(Role.AO_OFFICER) || this.hasRoleDirect(Role.RBO_DESK_OFFICER)) {
        userHomePageRoute = 'controller/verifications';
      } else if (this.hasRoleDirect(Role.REGIONAL_MAGER) || this.hasRoleDirect(Role.AGM_GB)) {
        userHomePageRoute = 'controller';
      } else if (this.hasRoleDirect(Role.FSLO_USER)) {
        userHomePageRoute = 'fslo';
      } else if (this.hasRoleDirect(Role.SECURITY_OFFICER)) {
        userHomePageRoute = 'security-officer';
      } else if (this.hasRoleDirect(Role.DGM_CFO)) {
        userHomePageRoute = 'dgm-cfo';
      } else if (this.hasRoleDirect(Role.ABD_USER) || this.hasRoleDirect(Role.ABD_DGM)) {
        userHomePageRoute = 'abd';
      } else if (this.hasRoleDirect(Role.VERIFICATION_OFFICER)) {
        userHomePageRoute = 'verification-officer';
      } else if (this.hasRoleDirect(Role.DGM_BO)) {
        userHomePageRoute = 'dgm-bo';
      } else if (this.hasRoleDirect(Role.GM_NW)) {
        userHomePageRoute = 'gm-nw';
      } else if (this.hasRoleDirect(Role.CGM_CIRCLE)) {
        userHomePageRoute = 'cgm-circle';
      } else {
        this.log.debug('No valid role found');
      }
      this.log.debug(`redirection to ${userHomePageRoute}`);
      this.router.navigate([userHomePageRoute]);
    }
  }

  getUserLevel(): Level {
    if (this.hasRoleDirect(Role.ABD_USER)) {
      return Level.BANK;
    } else if (this.hasRoleDirect(Role.CIRCLE_ADMIN)) {
      return Level.CIRCLE;
    } else if (this.hasAnyRolesDirect([Role.AO_OFFICER, Role.AGM_GB, Role.DGM_BO])) {
      return Level.MODULE;
    } else if (this.hasAnyRolesDirect([Role.CM_CR, Role.REGIONAL_MAGER])) {
      return Level.REGION;
    }
    return Level.NONE;
  }
}
