import { UserRole } from './user-role';

export interface UserRequest {
  id: number;
  roles: UserRole[];
  requestType: string;
  requestedBy: number;
  requestedOn: Date;
  requestStatus: string;
  requestMessage?: any;
}

export interface User {
  id: number;
  title?: string;
  name: string;
  designation: string;
  branch?: any;
  branchCode?: number;
  branchName?: string;
  roles?: UserRole[];
  email?: string;
  lastLogin?: Date;
  mobileNo?: number;
  emailId?: string;
  present?: boolean;
  userRequest?: UserRequest;
  enabled: boolean;
  deleted?: boolean;
  approved?: boolean;
  networkCode?:number;
}
