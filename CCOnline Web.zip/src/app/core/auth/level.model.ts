export enum Level {
  NONE,
  BANK,
  CIRCLE,
  MODULE,
  REGION,
}
