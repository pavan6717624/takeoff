export interface EncryptionConfig {
  keySize: number;
  iterations: number;
  salt: string;
  iv: string;
  secret: string;
  publicKey: string;
}
