import { Injectable } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NGXLogger } from 'ngx-logger';
import { Observable, Subject } from 'rxjs';

export type AlertType = 'success' | 'info' | 'warning' | 'error';

export interface Alert {
  type: AlertType;
  title?: string;
  messages: string[];
  clearPrevious?: boolean;
}

/**
 * Service for handling alert related activities
 */
@Injectable({ providedIn: 'root' })
export class AlertService {
  alerts = new Subject<Alert>();

  constructor(private log: NGXLogger, private notification: NzNotificationService) {}

  set(alert: Alert, template = false): void {
    this.log.debug('setting alert', alert);
    if (template) {
      this.alerts.next(alert);
    } else {
      switch (alert.type) {
        case 'success':
          this.notification.success(alert.title ? alert.title : 'Success', alert.messages.toString());
          break;
        case 'error':
          this.notification.error(alert.title ? alert.title : 'Error', alert.messages.toString(), { nzDuration: 10000 });
          break;
        case 'warning':
          this.notification.warning(alert.title ? alert.title : 'Warning', alert.messages.toString());
          break;
        case 'info':
          this.notification.info(alert.title ? alert.title : 'Info', alert.messages.toString());
          break;
      }
    }
  }

  clear(): void {
    this.log.debug('clearing alerts');
    this.alerts.next();
  }

  get(): Observable<Alert> {
    return this.alerts.asObservable();
  }
}
