import { Injectable } from '@angular/core';
import { parse } from 'date-fns';

@Injectable({ providedIn: 'root' })
export class DateUtilsService {
  parseDate(dateString: string, pattern: string): Date {
    return parse(dateString, pattern, new Date());
  }
}
