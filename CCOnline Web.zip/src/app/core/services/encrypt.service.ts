import { Injectable } from '@angular/core';

import * as CryptoJS from 'crypto-js';
import * as JsEncryptLib from 'jsencrypt';

import { EncryptionConfig } from './encrypt-config';

/**
 * Service for payload encryption
 * @author Sai Suman Padi, Kiran Marturu
 */
@Injectable({ providedIn: 'root' })
export class EncryptService {
  readonly encryptionConfig: EncryptionConfig;

  constructor() {
    // for any changes later to move the config outside the code
    this.encryptionConfig = {
      keySize: 256 / 32,
      iterations: 1000,
      secret: CryptoJS.lib.WordArray.random(128 / 8).toString(CryptoJS.enc.Hex),
      salt: CryptoJS.lib.WordArray.random(128 / 8).toString(CryptoJS.enc.Hex),
      iv: CryptoJS.lib.WordArray.random(128 / 8).toString(CryptoJS.enc.Hex),
      publicKey:
        '-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3mSyrMiYnEq2cH+6e/6pm46Ntt2TOFNC81wXkoC3hfR5hTbM9hm7HrYy66BqxkO+K1NO0dMZk3xaxibMnoABdXnv2UnTt9kH7yJfppkH0NvEQDU8+BS8ioNvJ6ipbFgNHatgl0zJeObOhbyq2hY+1Mvr8UI5cp6WaVnBszvl+RYPu7WYiS1PdyVSpR6FdJHJ2zeb/48ZLf+1YpaDlQS1/d/2YkEfVaKm7irUOUd6ww8CKIfCdkzVOrot9dURlWb41n0gpytR/IOl8nvoFssNgBFl9YGvFiaVluUv1IljC+CoobLQTTJ0BpYUL7cz4RNAaxvzs6ZlnvSuGUDptyvCsQIDAQAB-----END PUBLIC KEY-----',
    };
  }

  generateKey(salt: string, passPhrase: string): object {
    return CryptoJS.PBKDF2(passPhrase, CryptoJS.enc.Hex.parse(salt), {
      keySize: this.encryptionConfig.keySize,
      iterations: this.encryptionConfig.iterations,
    });
  }

  encrypt(salt: any, iv: any, passPhrase: any, plainText: any): any {
    const key = this.generateKey(salt, passPhrase);
    const encrypted = CryptoJS.AES.encrypt(plainText, key, {
      iv: CryptoJS.enc.Hex.parse(iv),
    });

    return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
  }

  decrypt(salt: any, iv: any, passPhrase: any, cipherText: any): any {
    const key = this.generateKey(salt, passPhrase);
    const cipherParams = CryptoJS.lib.CipherParams.create({
      ciphertext: CryptoJS.enc.Base64.parse(cipherText),
    });

    return CryptoJS.AES.decrypt(cipherParams, key, {
      iv: CryptoJS.enc.Hex.parse(iv),
    }).toString(CryptoJS.enc.Utf8);
  }

  test(): void {
    const cipherText = this.encrypt(this.encryptionConfig.salt, this.encryptionConfig.iv, this.encryptionConfig.secret, 'Plain Text');

    console.log('cipher text: ', cipherText);
    console.log(
      'plain text: ',
      this.decrypt(this.encryptionConfig.salt, this.encryptionConfig.iv, this.encryptionConfig.secret, cipherText)
    );

    const testPayload = {
      id: 6717659,
      name: 'Kiran',
    };

    const encryptedPayLoad = this.encryptPayload(testPayload);

    console.log('encrypted Paylod: ', encryptedPayLoad);
  }

  encryptRsa(data: any): any {
    const rsaEncrypt = new JsEncryptLib.JSEncrypt();
    rsaEncrypt.setPublicKey(this.encryptionConfig.publicKey);
    return rsaEncrypt.encrypt(data);
  }

  encryptPayload(payload: any): object {
    const cipherText = this.encrypt(
      this.encryptionConfig.salt,
      this.encryptionConfig.iv,
      this.encryptionConfig.secret,
      JSON.stringify(payload)
    );

    return {
      payload: btoa(cipherText),
      codeX: btoa(this.encryptRsa(this.encryptionConfig.secret)),
      codeY: btoa(this.encryptRsa(this.encryptionConfig.iv)),
      codeZ: btoa(this.encryptRsa(this.encryptionConfig.salt)),
    };
  }

  decryptPayload(payload: any): any {
    return this.decrypt(this.encryptionConfig.salt, this.encryptionConfig.iv, this.encryptionConfig.secret, payload);
  }
}
