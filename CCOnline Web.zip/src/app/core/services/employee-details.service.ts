import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from 'src/app/shared/models/employee-details.model';

import { environment } from 'src/environments/environment';

/**
 * Employee details service that fetches employee details from SSO/HRMS
 */
@Injectable({ providedIn: 'root' })
export class EmployeeDetailsService {
  constructor(private http: HttpClient) {}

  /**
   * Get employee details from pf id
   *
   * @param pfId - PF Index of the employee
   * @returns Observable of EmployeeDetails
   */
  getEmployeeDetails(pfId: number): Observable<EmployeeDetails> {
    return this.http.get<EmployeeDetails>(`${environment.apiUrl}/employee/${pfId}`);
  }
}
