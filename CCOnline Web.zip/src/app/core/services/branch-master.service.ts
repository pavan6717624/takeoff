import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Circle } from 'src/app/shared/models/circle.model';
import { Module } from 'src/app/shared/models/module.model';
import { Network } from 'src/app/shared/models/network.model';
import { Region } from 'src/app/shared/models/region.model';
import { environment } from 'src/environments/environment';
import { Branch } from '../interface/branch';

@Injectable({ providedIn: 'root' })
export class BranchMasterService {
  constructor(private http: HttpClient) {}

  circles(): Observable<Circle> {
    return this.http.get<Circle>(`${environment.apiUrl}/circles`);
  }

  networks(circleCode: number): Observable<Network[]> {
    let params = new HttpParams();
    params = params.append('circleCode', String(circleCode));

    return this.http.get<Network[]>(`${environment.apiUrl}/networks`, { params: params });
  }

  modules(circle: number, network: number): Observable<Module[]> {
    let params = new HttpParams();
    params = params.append('circleCode', String(circle));
    params = params.append('networkCode', String(network));

    return this.http.get<Module[]>(`${environment.apiUrl}/modules`, { params: params });
  }

  regions(circle: number, network: number, module: number): Observable<Region[]> {
    let params = new HttpParams();
    params = params.append('circleCode', String(circle));
    params = params.append('networkCode', String(network));
    params = params.append('moduleCode', String(module));

    return this.http.get<Region[]>(`${environment.apiUrl}/regions`, { params: params });
  }

  branches(circleCode: number, networkCode: number, moduleCode: number, regionCode: number): Observable<Branch[]> {
    let params = new HttpParams();
    params = params.append('circleCode', String(circleCode));
    params = params.append('networkCode', String(networkCode));
    params = params.append('moduleCode', String(moduleCode));
    params = params.append('regionCode', String(regionCode));

    return this.http.get<Branch[]>(`${environment.apiUrl}/branches`, { params: params });
  }
}
