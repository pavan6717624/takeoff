export interface Branch {
  branchCode: number;
  branchName: string;
}
