import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { STColumn, STComponent, STData, STPage, STRes } from '@delon/abc/st';
import { NGXLogger } from 'ngx-logger';
import { VerificationBlock, VerificationBlocks } from 'src/app/circle-admin/identify-vo/assign-vo-models';
import { IdentifyVoService } from 'src/app/circle-admin/identify-vo/identify-vo.service';
import { VerificationUtilService } from 'src/app/verification/service/verification-util.service';
import { Action, VerificationService } from 'src/app/verification/service/verification.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.component.html',
})
export class VerificationComponent implements OnInit {
  loading = false;

  verificationType = 'dgm-cfo';

  verificationBlocks: VerificationBlocks;
  selectedBlock: VerificationBlock;

  responseMapping: STRes = { reName: { list: 'content', total: 'totalElements' } };
  pagerConfig: STPage = { zeroIndexed: true, showSize: true, pageSizes: [10, 20, 30, 40, 50, 100, 200] };

  columns: STColumn[] = [
    { title: 'Network', index: 'networkCode', className: 'text-right' },
    { title: 'Module', index: 'moduleName' },
    { title: 'Region', index: 'regionCode', className: 'text-right' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-right' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'Status', index: 'verificationStatus', className: 'text-center' },
    {
      title: '',
      buttons: [
        { text: 'Start Verification', iif: r => !r.verification, click: record => this.startVerification(record) },
        {
          text: 'Continue Verification',
          iif: r => this.isContinueVerification(r),
          click: record => this.continueVerification(record),
        },
        {
          text: 'View Report',
          iif: r => this.verificationService.displayAction(r, this.selectedBlock, Action.DOWNLOAD_REPORT),
          click: r => this.verificationService.downloadReport(r?.verification?.id, `DGM_CFO_VISIT_Report_${r?.branchCode}.pdf`),
        },
      ],
    },

    {
      title: 'Compliance Report',
      buttons: [
        {
          text: 'View Report',
          iif: r => this.verificationService.displayAction(r, this.selectedBlock, Action.DOWNLOAD_REPORT),
          click: r => this.verificationService.downloadComplianceReport(r?.verification?.id, `DGM_CFO_VISIT_Report_${r?.branchCode}.pdf`),
        },
      ],
    },
   
  ];

  @ViewChild('st', { static: false }) private st: STComponent;

  constructor(
    private router: Router,
    private log: NGXLogger,
    private assignVoService: IdentifyVoService,
    private verificationService: VerificationService,
    private vUtilService: VerificationUtilService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    this.loadBlocks();
  }

  dataUrl(): string {
    if (this.selectedBlock) {
      return `${environment.apiUrl}/verifications/${this.verificationType}`;
    }
    return '';
  }

  requestParams(): any {
    if (this.selectedBlock) {
      return { blockFrom: this.selectedBlock.blockFrom, blockTo: this.selectedBlock.blockTo };
    }
  }

  loadBlocks(): void {
    this.log.debug('loading blocks');
    this.assignVoService.getVerificationBlocks(this.verificationType).subscribe(res => {
      this.verificationBlocks = res;
      if (this.verificationBlocks && this.verificationBlocks.blocks) {
        this.selectedBlock = this.verificationBlocks.blocks[0];
        this.log.debug('Selected block', this.selectedBlock);
      }
      this.loading = false;
    });
  }

  changeBlock(e: any): void {
    this.verificationBlocks.blocks.forEach(block => {
      if (block.id === e) {
        this.selectedBlock = block;
      }
    });
    this.st.resetColumns();
  }

  startVerification(branch: STData): void {
    this.log.debug('starting verification for ', branch, this.selectedBlock);
    this.verificationService.startVerification(branch.branchCode, this.selectedBlock.id).subscribe(res => {
      this.log.debug(res);
      this.router.navigate(['/dgm-cfo/verification/' + res.id]);
    });
  }

  continueVerification(branch: STData): void {
    this.log.debug('continuing verification for ', branch);
    this.router.navigate(['/dgm-cfo/verification/' + branch.verification.id]);
  }

  isContinueVerification(data: STData): boolean {
    return this.vUtilService.isContinueVerification(data);
  }
}
