import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { STColumn, STComponent, STData, STPage, STRes } from '@delon/abc/st';
import { Observable } from 'rxjs';
import { NGXLogger } from 'ngx-logger';

import { VerificationBlock, VerificationBlocks } from 'src/app/circle-admin/identify-vo/assign-vo-models';
import { IdentifyVoService } from 'src/app/circle-admin/identify-vo/identify-vo.service';
import { VerificationUtilService } from 'src/app/verification/service/verification-util.service';
import { VerificationService } from 'src/app/verification/service/verification.service';
import { environment } from 'src/environments/environment';
import { VisitsStatusSummary } from 'src/app/cgm-circle/visits-summary.model';
import { Circle } from 'src/app/shared/models/circle.model';
import { Network } from 'src/app/shared/models/network.model';
import { Module } from 'src/app/shared/models/module.model';
import { Region } from 'src/app/shared/models/region.model';
import { VerificationCriteria } from 'src/app/circle-admin/identify-vo/model/verification-criteria.model';

@Component({
  selector: 'app-controller-visit-dgm-cfo',
  templateUrl: './controller-visit-dgm-cfo.component.html',
  styles: [
    `
      .ant-advanced-search-form {
        padding: 24px;
        background: #fbfbfb;
        border: 1px solid #d9d9d9;
        border-radius: 6px;
      }
    `,
  ],
})
export class ControllerVisitDgmCfoComponent implements OnInit {

  loading = false;
  isLoading = false;

  verificationType = 'dgm-cfo-visit';

  verificationBlocks: VerificationBlocks;
  selectedBlock: VerificationBlock;
  summary: VisitsStatusSummary;

  responseMapping: STRes = { reName: { list: 'content', total: 'totalElements' } };
  pagerConfig: STPage = { zeroIndexed: true, showSize: true, pageSizes: [10, 20, 30, 40, 50, 100, 200] };

  columns: STColumn[] = [
    { title: 'Network', index: 'networkCode', className: 'text-center' },
    { title: 'Module', index: 'moduleName' },
    { title: 'Region', index: 'regionCode', className: 'text-center' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-center' },
    { title: 'Branch Name', index: 'branchName' },
    {
      title: '',
      buttons: [
        { text: 'Start Verification', iif: r => !r.verification, click: record => this.startVerification(record) },
        {
          text: 'Continue Verification',
          iif: r => this.verificationUtilService.isContinueVerification(r),
          click: record => this.continueVerification(record),
        },
        {
          text: 'Verification Report',
          iif: r => this.isVerificationFinished(r),
          click: r => this.verificationUtilService.downloadReport(r.verification.id),
        },
      ],
    },
  ];

  @ViewChild('st', { static: false }) private st: STComponent;

  constructor(
    private http: HttpClient,
    private log: NGXLogger,
    private router: Router,
    private assignVoService: IdentifyVoService,
    private verificationService: VerificationService,
    private verificationUtilService: VerificationUtilService
  ) {}

  //#region filters

  circles: Circle[];
  networks: Network[];
  modules: Module[];
  regions: Region[];

  q = <VerificationCriteria>{};
  cq = <VerificationCriteria>{};

  displayCircleFilter = false;
  displayNetworkFilter = false;
  displayModuleFilter = false;
  displayRegionFilter = false;

  //#endregion
  
  ngOnInit(): void {
    this.loading = true;

    this.displayNetworkFilter = true;
    this.displayModuleFilter = true;
    this.displayRegionFilter = true;

    this.loadBlocks();
  }

  dataUrl(): string {
    if (this.selectedBlock && this.selectedBlock.blockFrom && this.selectedBlock.blockTo) {
      return `${environment.apiUrl}/verifications/${this.verificationType}`;
    }
    return '';
  }

  requestParams(): any {
    if (this.selectedBlock) {
      //return { blockFrom: this.selectedBlock.blockFrom, blockTo: this.selectedBlock.blockTo };
      var params: any = {};
      params.blockFrom = this.selectedBlock.blockFrom;
      params.blockTo = this.selectedBlock.blockTo;

      if (this.cq.circle) {
        params.circle = this.cq.circle;
      }

      if (this.cq.network) {
        params.network = this.cq.network;
      }

      if (this.cq.module) {
        params.module = this.cq.module;
      }

      if (this.cq.region) {
        params.region = this.cq.region;
      }

      if (this.cq.branchCode) {
        params.branchCode = this.cq.branchCode;
      }

      if (this.cq.status) {
        params.status = this.cq.status;
      }

      if (this.cq.voPfId) {
        params.voPfId = this.cq.voPfId;
      }

      return params;
    }
  }

  loadBlocks(): void {
    this.assignVoService.getVerificationBlocks(this.verificationType).subscribe(res => {
      this.verificationBlocks = res;
      if (this.verificationBlocks && this.verificationBlocks.blocks) {
        this.selectedBlock = this.verificationBlocks.blocks[0];
        this.loadVisitsSummary();
      }
      this.loading = false;
      this.load();
    });
  }

  changeBlock(e: any): void {
    this.verificationBlocks.blocks.forEach(blk => {
      if (blk.id === e) {
        this.selectedBlock = blk;
        this.st.reset(this.requestParams());
        this.isLoading = true;
        this.loadVisitsSummary();
      }
    });
  }

  loadVisitsSummary(): void {
    this.log.trace('>> loadVisitsSummary()');
    this.getVisitsSummary().subscribe(
      value => {
        console.log('Summary:', value);
        this.summary = value;
        this.isLoading = true;
      },
      error => {
        console.log(' summary error: ', error);
      },
      () => (this.isLoading = false)
    );
  }

  getVisitsSummary(): Observable<VisitsStatusSummary> {
    let params = new HttpParams();
    params = params.append('blockFrom', String(this.selectedBlock.blockFrom));
    params = params.append('blockTo', String(this.selectedBlock.blockTo));
    return this.http.get<VisitsStatusSummary>(`${environment.apiUrl}/verifications/${this.verificationType}/visitsSummary`, {
      params: params,
    });
    //return this.http.get<VisitsStatusSummary>(`${environment.apiUrl}/nsms/reportSummary`, { params: params })
  }
  
  startVerification(branch: any): void {
    this.verificationService.startVerification(branch.branchCode, this.selectedBlock.id).subscribe(res => {
      this.router.navigate(['/dgm-cfo/verification/' + res.id]);
    });
  }

  continueVerification(branch: STData): void {
    this.router.navigate(['/dgm-cfo/verification/' + branch.verification.id]);
  }

  isContinueVerification(data: STData): boolean {
    if (data.verification) {
      if (data.verification.status) {
        return data.verification.status === 'IN_PROGRESS';
      }
      return true;
    }
    return false;
  }

  isVerificationFinished(data: STData): boolean {
    return this.verificationUtilService.isVerificationFinished(data);
  }

  //#region filters

  load(): void {
    this.log.trace('>> load ()');

    if (this.verificationType && this.selectedBlock) {
      // load circles
      this.assignVoService.circles(this.verificationType, this.selectedBlock).subscribe(circles => {
        this.circles = circles;

        if (!this.displayCircleFilter) {
          this.assignVoService.networks(this.verificationType, this.selectedBlock).subscribe(networks => {
            this.networks = networks;
          });

          if (!this.displayModuleFilter) {
            this.assignVoService.regions(this.verificationType, this.selectedBlock).subscribe(regions => {
              this.regions = regions;
            });
          }
        }
        this.st.resetColumns({ emitReload: true });
      });
    }
  }

  filterFetch(): void {
    this.log.trace('>> filterFetch ()');

    console.log('criteria', this.q);

    this.cq = { ...this.q };

    this.st.reset(this.requestParams());
  }

  filterClear(): void {
    this.cq = <VerificationCriteria>{};
    this.st.reset(this.requestParams());
  }

  onNetworkChange(network: any): void {
    console.log('network changed', network);

    this.modules = [];
    this.regions = [];

    this.q.module = null;
    this.q.region = null;

    if (network && this.verificationType && this.selectedBlock) {
      this.assignVoService.modules(this.verificationType, this.selectedBlock, network, this.q.circle).subscribe(modules => {
        this.modules = modules;
        this.regions = [];
      });
    }
  }

  onModuleChange(module: any): void {
    this.regions = [];
    this.q.region = null;

    if (module && this.verificationType && this.selectedBlock) {
      this.assignVoService.regions(this.verificationType, this.selectedBlock, module, this.q.network, this.q.circle).subscribe(regions => {
        this.regions = regions;
      });
    }
  }

  //#endregion
}

