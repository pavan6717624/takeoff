import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControllerVisitDgmCfoComponent } from './controller-visit-dgm-cfo.component';

describe('ControllerVisitDgmCfoComponent', () => {
  let component: ControllerVisitDgmCfoComponent;
  let fixture: ComponentFixture<ControllerVisitDgmCfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControllerVisitDgmCfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControllerVisitDgmCfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
