import { Component, OnInit } from '@angular/core';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

@Component({
  selector: 'app-dgm-cfo-closure',
  template: `<app-verification-closure [startUrl]="startUrl" [tabs]="tabs" [activeTab]="activeTab"></app-verification-closure>`,
})
export class DgmCfoClosureComponent implements OnInit {
  startUrl = '/dgm-cfo/compliance/';

  tabs: Tab[] = [
    {
      id: 1,
      title: 'Bi-Monthly',
      key: 'bi-monthly',
      assignable: true,
    },

    {
      id: 2,
      title: 'Half-Yearly',
      key: 'half-yearly',
      assignable: true,
    },

    {
      id: 3,
      title: 'Security Officer',
      key: 'security-officer',
      assignable: false,
    },
  ];

  activeTab: Tab = {
    id: 1,
    title: 'Bi-Monthly',
    key: 'bi-monthly',
    assignable: true,
  };

  constructor() {}

  ngOnInit(): void {}
}
