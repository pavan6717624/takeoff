import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { VerificationComponent } from './verification/verification.component';
import { VerificationModule } from '../verification/verification.module';
import { BranchProfileComponent } from '../verification/branch-profile/branch-profile.component';
import { ValueStatementsComponent } from '../verification/value-statements/value-statements.component';
import { PreviewForSubmissionComponent } from '../verification/preview-for-submission/preview-for-submission.component';
import { SectionsComponent } from '../verification/sections/sections.component';
import { SubmitResultComponent } from '../verification/submit-result/submit-result.component';
import { SectionsComplianceComponent } from '../compliance/sections/sections-compliance.component';
import { ComplianceModule } from '../compliance/compliance.module';
import { ChestSlipNotUploadedBranchesComponent } from '../abd/chest-slip-not-uploaded-branches/chest-slip-not-uploaded-branches.component';
import { ChestSlipUploadedBranchesComponent } from '../abd/chest-slip-uploaded-branches/chest-slip-uploaded-branches.component';
import { ChestBranchesAboveCglComponent } from '../abd/chest-branches-above-cgl/chest-branches-above-cgl.component';
import { BglCcDifferenceComponent } from '../abd/bgl-cc-difference/bgl-cc-difference.component';
import { CustomReportsComponent } from '../abd/custom-reports/custom-reports.component';
import { ControllerVisitDgmCfoComponent } from './controller-visit-dgm-cfo/controller-visit-dgm-cfo.component';
import { RbiPenaltyUpdationStatusComponent } from '../fslo/rbi-penalty-updation-status/rbi-penalty-updation-status.component';
import { DgmCfoClosureComponent } from './closure/dgm-cfo-closure.component';
import { ClosureModule } from '../closure/closure.module';
import { ChestBranchesAboveCglConsecutiveComponent } from '../abd/chest-branches-above-cgl-consecutive/chest-branches-above-cgl-consecutive.component';

const routes: Routes = [
  { path: '', redirectTo: 'closure', pathMatch: 'full' },
  { path: 'verification', component: VerificationComponent },
  { path: 'verifications', component: VerificationComponent },
  { path: 'verification/:verificationId', component: SectionsComponent, data: { userRoutePrefix: 'dgm-cfo' } },
  { path: 'verification/:verificationId/branch-profile', component: BranchProfileComponent },
  { path: 'verification/:verificationId/value-statements/:sectionId', component: ValueStatementsComponent },
  { path: 'verification/:verificationId/preview', component: PreviewForSubmissionComponent, data: { userRoutePrefix: 'dgm-cfo' } },
  { path: 'verification/:verificationId/submitted', component: SubmitResultComponent, data: { userRoutePrefix: 'dgm-cfo' } },
  { path: 'closure', component: DgmCfoClosureComponent, data: { userRoutePrefix: 'dgm-cfo' } },
  { path: 'compliance/:verificationId', component: SectionsComplianceComponent },
  { path: 'penalty-reports', component: RbiPenaltyUpdationStatusComponent },
  {
    path: 'chest-slip-not-uploaded-branches',
    component: ChestSlipNotUploadedBranchesComponent,
  },
  {
    path: 'chest-slip-uploaded-branches',
    component: ChestSlipUploadedBranchesComponent,
  },
  {
    path: 'chest-branches-above-cbl',
    component: ChestBranchesAboveCglComponent,
  },
  
  {
    path: 'bgl-cc-difference',
    component: BglCcDifferenceComponent,
  },
  {
    path: 'consecutiveDaysReport',
    component: ChestBranchesAboveCglConsecutiveComponent,
  },
  {
    path: 'custom-reports',
    component: CustomReportsComponent,
  },
  { path: 'controllerVisit', component: ControllerVisitDgmCfoComponent },
];

@NgModule({
  declarations: [VerificationComponent, DgmCfoClosureComponent, ControllerVisitDgmCfoComponent],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule, VerificationModule, ComplianceModule, ClosureModule],
})
export class DgmCfoModule {}
