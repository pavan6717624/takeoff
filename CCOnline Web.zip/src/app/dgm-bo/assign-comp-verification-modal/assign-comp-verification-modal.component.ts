import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { NzDrawerRef } from 'ng-zorro-antd/drawer';
import { NGXLogger } from 'ngx-logger';

import { EMAIL_REGEX, MOBILE_NO_PATTERN, PF_ID_PATTERN } from 'src/app/core/constants/validation.constants';
import { DateUtilsService } from 'src/app/core/services/date-utils.service';
import { EmployeeDetailsService } from 'src/app/core/services/employee-details.service';
import { DATE_JACKSON_FORMAT } from 'src/app/shared/constants/input.constants';
import { EmployeeDetails } from 'src/app/shared/models/employee-details.model';
import { environment } from 'src/environments/environment';
import { AssignModify } from '../models/assign-modify-officer.model';
import { ComplianceVerificationOfficer } from '../models/compliance-verification-officer.model';

@Component({
  selector: 'app-assign-comp-verification-modal',
  templateUrl: './assign-comp-verification-modal.component.html',
})
export class AssignCompVerificationModalComponent implements OnInit {
  constructor(
    private ref: NzDrawerRef,
    private log: NGXLogger,
    private dateUtils: DateUtilsService,
    private fb: FormBuilder,
    private empDetailsService: EmployeeDetailsService,
    private http: HttpClient
  ) {}

  @Input() record: AssignModify;

  fetchedUserDetails = false;
  isModify = false;
  assigning = false;
  isFetchingUserDetails = false;

  assignOfficerForm: FormGroup;
  employeeDetails: EmployeeDetails;

  blockFrom: Date;
  blockTo: Date;

  ngOnInit(): void {
    this.blockFrom = this.dateUtils.parseDate(this.record.block.blockFrom as string, DATE_JACKSON_FORMAT);
    this.blockTo = this.dateUtils.parseDate(this.record.block.blockTo as string, DATE_JACKSON_FORMAT);

    this.assignOfficerForm = this.fb.group({
      pfId: ['', [Validators.required, Validators.pattern(PF_ID_PATTERN), Validators.min(1000000), Validators.max(9999999999)]],
      // emailId: ['', [Validators.required, Validators.email, Validators.pattern(EMAIL_REGEX)]],
      // mobileNo: ['', [Validators.required, Validators.pattern(MOBILE_NO_PATTERN)]],
    });

    if (this.record.verification?.complianceVerificationOfficer) {
      this.employeeDetails = {
        pfId: this.record.verification.complianceVerificationOfficer.pfId,
        name: this.record.verification.complianceVerificationOfficer.name,
        branchCode: this.record.verification.complianceVerificationOfficer.branch.branchCode,
        branchName: this.record.verification.complianceVerificationOfficer.branch.branchName,
        designation: this.record.verification.complianceVerificationOfficer.designation,
        emailId: this.record.verification.complianceVerificationOfficer.emailId,
        mobileNo: this.record.verification.complianceVerificationOfficer.mobileNo,
      };

      this.assignOfficerForm.patchValue({
        pfId: this.employeeDetails.pfId,
        emailId: this.employeeDetails.emailId,
        mobileNo: this.employeeDetails.mobileNo,
      });

      this.fetchedUserDetails = true;
      this.isModify = true;
    }

    this.onPfIdChanges();
  }

  onPfIdChanges(): void {
    this.assignOfficerForm.get('pfId').valueChanges.subscribe(() => {
      if (this.fetchedUserDetails) {
        this.fetchedUserDetails = false;
        this.assignOfficerForm.get('emailId').reset();
        this.assignOfficerForm.get('mobileNo').reset();
      }
    });
  }

  fetchUserDetails(pfIdFormControl: AbstractControl): void {
    this.isFetchingUserDetails = true;

    this.empDetailsService.getEmployeeDetails(pfIdFormControl.value).subscribe(
      res => {
        this.employeeDetails = res;
        // this.assignOfficerForm.patchValue((({ pfId, emailId, mobileNo }) => ({ pfId, emailId, mobileNo }))(res));

        // this.assignOfficerForm.get('emailId').markAsTouched();
        // this.assignOfficerForm.get('mobileNo').markAsTouched();

        this.fetchedUserDetails = true;
        this.isFetchingUserDetails = false;
      },
      () => (this.isFetchingUserDetails = false)
    );
  }

  assign(): void {
    this.assigning = true;

    const details = {
      verificationId: this.record.verification.id,
      branchCode: this.record.branchCode,
      block: this.record.block.id,
      officerPfId: this.assignOfficerForm.get('pfId').value,
      // mobileNo: this.assignOfficerForm.get('mobileNo').value,
      // emailId: this.assignOfficerForm.get('emailId').value,
    };

    if (this.record.modify) {
      this.http.put<ComplianceVerificationOfficer>(`${environment.apiUrl}/compliance-verification-officer/bi-monthly`, details).subscribe(
        res => {
          this.ref.close(res);
        },
        () => {
          this.assigning = false;
        }
      );
    } else {
      this.http.post<ComplianceVerificationOfficer>(`${environment.apiUrl}/compliance-verification-officer/bi-monthly`, details).subscribe(
        res => {
          this.ref.close(res);
        },
        () => {
          this.assigning = false;
        }
      );
    }
  }

  cancel(): void {
    this.ref.close();
  }
}
