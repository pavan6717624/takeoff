import { Component, OnInit, ViewChild } from '@angular/core';

import { STColumn, STComponent, STPage, STRes } from '@delon/abc/st';
import { DrawerHelper, DrawerHelperOptions } from '@delon/theme';
import { NzDrawerOptions } from 'ng-zorro-antd/drawer';
import { NzMessageService } from 'ng-zorro-antd/message';

import { VerificationBlock, VerificationBlocks } from 'src/app/circle-admin/identify-vo/assign-vo-models';
import { IdentifyVoService } from 'src/app/circle-admin/identify-vo/identify-vo.service';
import { VerificationCriteria } from 'src/app/circle-admin/identify-vo/model/verification-criteria.model';
import { Region } from 'src/app/shared/models/region.model';
import { environment } from 'src/environments/environment';
import { AssignCompVerificationModalComponent } from '../assign-comp-verification-modal/assign-comp-verification-modal.component';
import { AssignModify } from '../models/assign-modify-officer.model';

@Component({
  selector: 'app-assign-comp-verification',
  templateUrl: './assign-comp-verification.component.html',
})
export class AssignCompVerificationComponent implements OnInit {
  private readonly drawerOptions = <DrawerHelperOptions>{
    size: 'xl',
    drawerOptions: { nzWidth: 600, nzKeyboard: false, nzMaskClosable: false },
  };

  constructor(private assignVoService: IdentifyVoService, private modalHelper: DrawerHelper, private message: NzMessageService) {}

  loading = true;

  regions: Region[];

  verificationBlocks: VerificationBlocks;
  selectedBlock: VerificationBlock;

  columns: STColumn[] = [
    { title: 'Region', index: 'regionCode', type: 'number' },
    { title: 'Branch Code', index: 'branchCode', className: 'text-right' },
    { title: 'Branch Name', index: 'branchName' },
    { title: 'Status', index: 'verificationStatus', className: 'text-center' },
    {
      title: 'Verification Done By',
      format: item => `${item.verification.officer.name} (${item.verification.officer.pfId})`,
    },
    { title: 'Date of Verification', index: 'verification.dateOfVerification', type: 'date', dateFormat: 'dd-MM-yyyy' },
    {
      title: 'Compliance Verification',
      format: item =>
        `${
          item.verification.complianceVerificationOfficer
            ? `${item.verification.complianceVerificationOfficer.name} (${item.verification.complianceVerificationOfficer.pfId})`
            : '--'
        }`,
    },
    {
      title: 'Actions',
      buttons: [
        {
          text: 'Assign Officer for Compliance Verification',
          click: data => this.assign(data),
          iif: data => !data.verification?.complianceVerificationOfficer && this.canModify(data),
        },
        {
          text: 'Modify Assigned Officer',
          click: data => this.modify(data),
          iif: data => data.verification?.complianceVerificationOfficer && this.canModify(data),
        },
      ],
    },
  ];

  @ViewChild('st', { static: false }) private st: STComponent;

  q = <VerificationCriteria>{};
  cq = <VerificationCriteria>{};

  responseMapping: STRes = { reName: { list: 'content', total: 'totalElements' } };
  pagerConfig: STPage = { zeroIndexed: true, showSize: true, pageSizes: [10, 20, 30, 40, 50] };

  ngOnInit(): void {
    this.loadBlocks();
  }

  loadBlocks(): void {
    this.assignVoService.getVerificationBlocks('bi-monthly').subscribe(res => {
      this.verificationBlocks = res;
      if (this.verificationBlocks && this.verificationBlocks.blocks) {
        this.selectedBlock = this.verificationBlocks.blocks[0];
      }
      this.loading = false;
      this.load();
    });
  }

  filterClear(): void {
    this.cq = <VerificationCriteria>{};
    this.st.reset(this.requestParams());
  }

  filterFetch(): void {
    console.log('in filter fetch');
    console.log('criteria', this.q);

    this.cq = { ...this.q };

    this.st.reset(this.requestParams());
  }

  load(): void {
    if (this.selectedBlock) {
      this.assignVoService.regions('bi-monthly', this.selectedBlock).subscribe(regions => {
        this.regions = regions;
      });
    }
  }

  requestParams(): any {
    if (this.selectedBlock) {
      var params: any = {};
      params.blockFrom = this.selectedBlock.blockFrom;
      params.blockTo = this.selectedBlock.blockTo;

      params.status = 'ASSIGN_COMPL_VO';

      if (this.cq.circle) {
        params.circle = this.cq.circle;
      }

      if (this.cq.network) {
        params.network = this.cq.network;
      }

      if (this.cq.module) {
        params.module = this.cq.module;
      }

      if (this.cq.region) {
        params.region = this.cq.region;
      }

      if (this.cq.branchCode) {
        params.branchCode = this.cq.branchCode;
      }

      if (this.cq.status) {
        params.status = this.cq.status;
      }

      if (this.cq.voPfId) {
        params.voPfId = this.cq.voPfId;
      }
      return params;
    }
  }

  changeBlock(e: any): void {
    this.verificationBlocks.blocks.forEach(value => {
      if (value.id === e) {
        this.selectedBlock = value;
        this.st.reset(this.requestParams());
      }
    });
  }

  data(): string {
    if (this.selectedBlock) {
      return `${environment.apiUrl}/verifications/bi-monthly/`;
    }
    return '';
  }

  canModify(data: any): boolean {
    if (data.verification?.status === 'CMP_SUBMITTED_BY_SCRUTINIZER') {
      return true;
    }

    return false;
  }

  assign(data: any): void {
    this.modalHelper
      .create(
        `Assign officer for Bi-Monthly Compliance Verification`,
        AssignCompVerificationModalComponent,
        {
          record: <AssignModify>{
            modify: false,
            verification: data.verification,
            branchCode: data.branchCode,
            branchName: data.branchName,
            block: this.selectedBlock,
          },
        },
        this.drawerOptions
      )
      .subscribe(res => {
        this.st.reload();
        if (res) {
          this.message.success(
            `${res.name} (${res.pfId}) has been assigned for compliance verification of ${data.branchName} (${data.branchCode})`,
            { nzDuration: 10000 }
          );
        }
      });
  }

  modify(data: any): void {
    this.modalHelper
      .create(
        'Modify officer for Bi-Monthly Compliance Verification',
        AssignCompVerificationModalComponent,
        {
          record: <AssignModify>{
            modify: true,
            verification: data.verification,
            branchCode: data.branchCode,
            branchName: data.branchName,
            block: this.selectedBlock,
          },
        },
        this.drawerOptions
      )
      .subscribe(res => {
        if (res) {
          this.st.reload();
          this.message.success(
            `${res.name} (${res.pfId}) has been assigned (after modify) for compliance verification of ${data.branchName} (${data.branchCode})`,
            { nzDuration: 10000 }
          );
        }
      });
  }
}
