import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControllerVisitModuleHeadComponent } from './controller-visit-module-head.component';

describe('ControllerVisitModuleHeadComponent', () => {
  let component: ControllerVisitModuleHeadComponent;
  let fixture: ComponentFixture<ControllerVisitModuleHeadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControllerVisitModuleHeadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControllerVisitModuleHeadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
