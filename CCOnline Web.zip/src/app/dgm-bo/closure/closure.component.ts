import { Component, OnInit } from '@angular/core';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

@Component({
  selector: 'app-closure',
  template: `<app-verification-closure [startUrl]="startUrl" [tabs]="tabs" [activeTab]="activeTab"></app-verification-closure>`,
})
export class ClosureComponent implements OnInit {
  startUrl = '/dgm-bo/compliance/';

  tabs: Tab[] = [
    {
      id: 1,
      title: 'Quarterly',
      key: 'quarterly',
      assignable: false,
    },
    {
      id: 2,
      title: 'Controller (RM/DGM) Visit',
      key: 'rm-dgm-controller-visit',
      assignable: false,
    },
  ];

  activeTab: Tab = {
    id: 1,
    title: 'Quarterly',
    key: 'quarterly',
    assignable: false,
  };

  constructor() {}

  ngOnInit(): void {}
}
