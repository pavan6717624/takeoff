import { VerificationBlock } from 'src/app/circle-admin/identify-vo/assign-vo-models';

export interface AssignModify {
  modify: boolean;
  verification: any;
  branchCode: number;
  branchName: string;
  block: VerificationBlock;
}
