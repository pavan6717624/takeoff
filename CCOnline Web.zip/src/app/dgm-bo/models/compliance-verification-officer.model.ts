import { Branch } from 'src/app/core/interface/branch';

export interface ComplianceVerificationOfficer {
  id: number;
  pfId: number;
  title: string;
  name: string;
  designation: string;
  mobileNo: number;
  emailId: string;
  branch: Branch;
}
