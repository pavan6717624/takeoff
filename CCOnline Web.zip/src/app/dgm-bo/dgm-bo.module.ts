import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { VerificationComponent } from '../dgm-bo/verification/verification.component';
import { SectionsComponent } from '../verification/sections/sections.component';
import { BranchProfileComponent } from '../verification/branch-profile/branch-profile.component';
import { PreviewForSubmissionComponent } from '../verification/preview-for-submission/preview-for-submission.component';
import { SubmitResultComponent } from '../verification/submit-result/submit-result.component';
import { SectionsComplianceComponent } from '../compliance/sections/sections-compliance.component';
import { ValueStatementsComponent } from '../verification/value-statements/value-statements.component';
import { VerificationModule } from '../verification/verification.module';
import { ComplianceModule } from '../compliance/compliance.module';
import { ClosureComponent } from './closure/closure.component';
import { AssignCompVerificationComponent } from './assign-comp-verification/assign-comp-verification.component';
import { AssignCompVerificationModalComponent } from './assign-comp-verification-modal/assign-comp-verification-modal.component';
import { ControllerVisitModuleHeadComponent } from './controller-visit-module-head/controller-visit-module-head.component';
import { ControllerVisitDirectBrsComponent } from './controller-visit-direct-brs/controller-visit-direct-brs.component';
import { ClosureModule } from '../closure/closure.module';
import { AutoAlertsComponent } from '../branch/auto-alerts/auto-alerts.component';
import { AutoAlertsHbbComponent } from '../branch/auto-alerts-hbb/auto-alerts-hbb.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', redirectTo: 'controllerVisitModuleHead', pathMatch: 'full' },
      { path: 'closure', component: ClosureComponent, data: { userRoutePrefix: 'dgm-bo' } },
      { path: 'verification', component: VerificationComponent },
      { path: 'verifications', component: VerificationComponent },
      { path: 'verification/:verificationId', component: SectionsComponent, data: { userRoutePrefix: 'dgm-bo' } },
      { path: 'verification/:verificationId/branch-profile', component: BranchProfileComponent },
      { path: 'verification/:verificationId/value-statements/:sectionId', component: ValueStatementsComponent },
      { path: 'verification/:verificationId/preview', component: PreviewForSubmissionComponent, data: { userRoutePrefix: 'dgm-bo' } },
      { path: 'verification/:verificationId/submitted', component: SubmitResultComponent, data: { userRoutePrefix: 'dgm-bo' } },
      { path: 'compliance/:verificationId', component: SectionsComplianceComponent },
      { path: 'controllerVisitDirectBrs', component: ControllerVisitDirectBrsComponent },
      { path: 'controllerVisitModuleHead', component: ControllerVisitModuleHeadComponent },
      { path: 'assign-comp-vo', component: AssignCompVerificationComponent },
      {
        path: 'autoAlertSettings',
        component: AutoAlertsComponent,
      },
      {
        path: 'autoAlertSettingsHbb',
        component: AutoAlertsHbbComponent,
      },
    ],
  },
];

@NgModule({
  declarations: [
    VerificationComponent,
    ClosureComponent,
    AssignCompVerificationComponent,
    AssignCompVerificationModalComponent,
    ControllerVisitModuleHeadComponent,
    ControllerVisitDirectBrsComponent,
  ],
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes), VerificationModule, ComplianceModule, ClosureModule],
})
export class DgmBoModule {}
