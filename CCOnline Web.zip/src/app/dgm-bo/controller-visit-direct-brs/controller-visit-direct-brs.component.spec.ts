import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControllerVisitDirectBrsComponent } from './controller-visit-direct-brs.component';

describe('ControllerVisitDirectBrsComponent', () => {
  let component: ControllerVisitDirectBrsComponent;
  let fixture: ComponentFixture<ControllerVisitDirectBrsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControllerVisitDirectBrsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControllerVisitDirectBrsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
