import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NGXLogger } from 'ngx-logger';

import { SessionStorageService } from 'ngx-webstorage';
import { AuthService } from '../core/auth/auth.service';
import { environment } from 'src/environments/environment';

export interface LoginResponse {
  isSuccess: boolean;
  token: string;
  message: string;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less'],
})
export class LoginComponent implements OnInit {
  loginData: LoginResponse = {
    isSuccess: false,
    token: '',
    message: '',
  };

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private $sessionStorage: SessionStorageService,
    private log: NGXLogger
  ) {}

  ngOnInit(): void {
    this.log.debug('initialized, login component');

    if (environment.type === 'dev') {
      this.devLogin();
    } else {
      this.nonDevLogin();
    }
  }

  devLogin(): void {
    this.route.queryParams.subscribe(params => {
      this.log.debug('params: ', params);

      this.loginData.isSuccess = params.isSuccess || false;
      this.loginData.message = params.message || '';
      this.loginData.token = params.token || '';

      if (this.loginData.isSuccess && this.loginData.token) {
        // store token
        this.authService.setToken(this.loginData.token);

        // redirect to user home page
        this.authService.getPrincipal(true).subscribe(
          principal => {
            this.authService.redirectToUserHomePage();
          },
          err => {
            console.log(err);
          }
        );
      } else {
        // redirect to home page
        if (this.loginData.message) {
          this.$sessionStorage.store(AuthService.LOGIN_FAILURE_MESSAGE, this.loginData.message);
        } else {
          this.$sessionStorage.store(AuthService.LOGIN_FAILURE_MESSAGE, 'An error occured while processing login.');
        }
        this.router.navigate(['']);
      }
    });
  }

  nonDevLogin(): void {
    this.log.debug('>> nonDevLogin()');

    const storedLoginResponse = sessionStorage.getItem('cco_loginResponse');
    sessionStorage.removeItem('cco_loginResponse');
    const loginResponse = storedLoginResponse ? JSON.parse(storedLoginResponse) : null;

    if (loginResponse) {
      this.log.debug('login response is valid');

      if (loginResponse.isLoginSuccessful && loginResponse.token) {
        // store token
        this.log.debug('setting token');
        this.authService.setToken(loginResponse.token);

        // redirect to user home page
        this.authService.getPrincipal(true).subscribe(
          principal => {
            this.authService.redirectToUserHomePage();
          },
          err => {
            this.log.debug('Error while fetching principal', err);
          }
        );
      } else {
        // redirect to home page
        if (loginResponse.message) {
          this.$sessionStorage.store(AuthService.LOGIN_FAILURE_MESSAGE, loginResponse.message);
        } else {
          this.$sessionStorage.store(AuthService.LOGIN_FAILURE_MESSAGE, 'An error occured while processing login.');
        }
        this.router.navigate(['']);
      }
    } else {
      this.$sessionStorage.store(
        AuthService.LOGIN_FAILURE_MESSAGE,
        'An error occured while processing login. No data recieved from server.'
      );
      this.router.navigate(['']);
    }
  }
}
