export interface VisitsStatusSummary {
  totalCcs: number;
  //visitedCcs?: number;
  voReportSubmitted?: number;
}
