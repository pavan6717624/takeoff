import { Component, OnInit } from '@angular/core';
import { Tab } from 'src/app/circle-admin/identify-vo/model/tab.model';

@Component({
  selector: 'app-cgm-closure',
  template: `<app-verification-closure [startUrl]="startUrl" [tabs]="tabs" [activeTab]="activeTab"></app-verification-closure>`,
})
export class CgmClosureComponent implements OnInit {
  startUrl = 'cgm-circle/compliance/';

  tabs: Tab[] = [
    {
      id: 1,
      title: 'GM Network Visit',
      key: 'gm-network-visit',
      assignable: true,
    },
  ];

  activeTab: Tab = { id: 1, key: 'gm-network-visit', title: 'GM Network Visit', assignable: true };

  constructor() {}

  ngOnInit(): void {}
}
