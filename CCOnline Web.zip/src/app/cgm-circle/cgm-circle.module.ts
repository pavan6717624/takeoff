import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { IdentifyVoComponent } from '../circle-admin/identify-vo/identify-vo.component';
import { SectionsComponent } from '../verification/sections/sections.component';
import { BranchProfileComponent } from '../verification/branch-profile/branch-profile.component';
import { ValueStatementsComponent } from '../verification/value-statements/value-statements.component';
import { PreviewForSubmissionComponent } from '../verification/preview-for-submission/preview-for-submission.component';
import { SubmitResultComponent } from '../verification/submit-result/submit-result.component';
import { ScrutinyComponent } from '../controller/scrutiny/scrutiny.component';
import { SectionsComplianceComponent } from '../compliance/sections/sections-compliance.component';
import { VerificationModule } from '../verification/verification.module';
import { ControllerVisitCgmCircleComponent } from './controller-visit-cgm-circle/controller-visit-cgm-circle.component';
import { ClosureModule } from '../closure/closure.module';
import { CgmClosureComponent } from './closure/cgm-closure.component';

const routes: Routes = [
  { path: '', redirectTo: 'controllerVisit', pathMatch: 'full' },
  { path: 'verifications', component: IdentifyVoComponent },
  { path: 'verification/:verificationId', component: SectionsComponent, data: { userRoutePrefix: 'cgm-circle' } },
  { path: 'verification/:verificationId/branch-profile', component: BranchProfileComponent },
  { path: 'verification/:verificationId/value-statements/:sectionId', component: ValueStatementsComponent },
  { path: 'verification/:verificationId/preview', component: PreviewForSubmissionComponent, data: { userRoutePrefix: 'cgm-circle' } },
  { path: 'verification/:verificationId/submitted', component: SubmitResultComponent, data: { userRoutePrefix: 'cgm-circle' } },
  { path: 'scrutiny', component: ScrutinyComponent },
  { path: 'closure', component: CgmClosureComponent, data: { userRoutePrefix: 'cgm-circle' } },
  { path: 'compliance/:verificationId', component: SectionsComplianceComponent },
  { path: 'controllerVisit', component: ControllerVisitCgmCircleComponent },
];

@NgModule({
  declarations: [ControllerVisitCgmCircleComponent, CgmClosureComponent],
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes), VerificationModule, ClosureModule],
})
export class CgmModule {}
