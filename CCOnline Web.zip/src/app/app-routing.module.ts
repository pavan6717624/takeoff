import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './core/auth/auth.guard';

import { HomeComponent } from './home/home.component';
import { LayoutDefaultComponent } from './layout/default/default.component';
import { LoginComponent } from './login/login.component';
import { Role } from './shared/constants/role.constants';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    pathMatch: 'full',
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'branch',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./branch/branch.module').then(m => m.BranchModule) }],
    data: {
      allowedRoles: [Role.BRANCH_USER, Role.BRANCH_HEAD],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'controller',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./controller/controller.module').then(m => m.ControllerModule) }],
    data: {
      allowedRoles: [Role.CM_CR, Role.REGIONAL_MAGER, Role.RBO_DESK_OFFICER, Role.AO_OFFICER, Role.AGM_GB],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'circle-admin',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./circle-admin/circle-admin.module').then(m => m.CircleAdminModule) }],
    data: {
      allowedRoles: [Role.CIRCLE_ADMIN],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'security-officer',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./security-officer/security-officer.module').then(m => m.SecurityOfficerModule) }],
    data: {
      allowedRoles: [Role.SECURITY_OFFICER],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'dgm-cfo',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./dgm-cfo/dgm-cfo.module').then(m => m.DgmCfoModule) }],
    data: {
      allowedRoles: [Role.DGM_CFO],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'fslo',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./fslo/fslo.module').then(m => m.FsloModule) }],
    data: {
      allowedRoles: [Role.FSLO_USER],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'abd',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./abd/abd.module').then(m => m.AbdModule) }],
    data: {
      allowedRoles: [Role.ABD_USER, Role.ABD_DGM, Role.CIRCLE_ADMIN],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'verification-officer',
    component: LayoutDefaultComponent,
    children: [
      { path: '', loadChildren: () => import('./verification-officer/verification-officer.module').then(m => m.VerificationOfficerModule) },
    ],
    data: {
      allowedRoles: [Role.VERIFICATION_OFFICER],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'users',
    component: LayoutDefaultComponent,
    loadChildren: () => import('./user/user.module').then(m => m.UserModule),
    data: {
      allowedRoles: [Role.ABD_DGM, Role.ABD_USER, Role.CIRCLE_ADMIN, Role.CM_CR, Role.REGIONAL_MAGER, Role.AO_OFFICER, Role.AGM_GB],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'dgm-bo',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./dgm-bo/dgm-bo.module').then(m => m.DgmBoModule) }],
    data: {
      allowedRoles: [Role.DGM_BO],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'cgm-circle',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./cgm-circle/cgm-circle.module').then(m => m.CgmModule) }],
    data: {
      allowedRoles: [Role.CGM_CIRCLE],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'gm-nw',
    component: LayoutDefaultComponent,
    children: [{ path: '', loadChildren: () => import('./gm-nw/gm-nw.module').then(m => m.GmNwModule) }],
    data: {
      allowedRoles: [Role.GM_NW],
    },
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
  },
  {
    path: 'mis',
    component: LayoutDefaultComponent,
    loadChildren: () => import('./mis/mis.module').then(m => m.MisModule),
  },
  {
    path: 'exception',
    loadChildren: () => import('./pages/pages.module').then(m => m.PagesModule),
  },
  { path: '**', redirectTo: 'exception/page-not-found' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: false })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
