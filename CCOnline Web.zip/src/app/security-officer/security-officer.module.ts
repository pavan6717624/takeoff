import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { VerificationComponent } from './verification/verification.component';
import { SharedModule } from '../shared/shared.module';
import { SectionsComponent } from '../verification/sections/sections.component';
import { BranchProfileComponent } from '../verification/branch-profile/branch-profile.component';
import { ValueStatementsComponent } from '../verification/value-statements/value-statements.component';
import { VerificationModule } from '../verification/verification.module';
import { PreviewForSubmissionComponent } from '../verification/preview-for-submission/preview-for-submission.component';
import { SubmitResultComponent } from '../verification/submit-result/submit-result.component';

const routes: Routes = [
  { path: '', redirectTo: 'verification', pathMatch: 'full' },
  { path: 'verification', component: VerificationComponent },
  { path: 'verifications', component: VerificationComponent },
  { path: 'verification/:verificationId', component: SectionsComponent, data: { userRoutePrefix: 'security-officer' } },
  { path: 'verification/:verificationId/branch-profile', component: BranchProfileComponent },
  { path: 'verification/:verificationId/value-statements/:sectionId', component: ValueStatementsComponent },
  {
    path: 'verification/:verificationId/preview',
    component: PreviewForSubmissionComponent,
    data: { userRoutePrefix: 'security-officer' },
  },
  { path: 'verification/:verificationId/submitted', component: SubmitResultComponent, data: { userRoutePrefix: 'security-officer' } },
];

@NgModule({
  declarations: [VerificationComponent],
  imports: [CommonModule, RouterModule.forChild(routes), SharedModule, VerificationModule],
})
export class SecurityOfficerModule {}
