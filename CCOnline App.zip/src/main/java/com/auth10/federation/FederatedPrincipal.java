package com.auth10.federation;

import java.io.Serializable;
import java.security.Principal;
import java.util.Collections;
import java.util.List;

public class FederatedPrincipal implements Principal, Serializable {

    private static final long serialVersionUID = 1692735012353353844L;

    private static final String NAME_CLAIM_TYPE = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
    private static final String EMAIL_CLAIM_TYPE = "http://schemas.xmlsoap.org/claims/EmailAddress";

    private List<Claim> claims = null;

    public FederatedPrincipal(List<Claim> claims) {
        this.claims = claims;
    }

    public String getName() {
        String name = "";

        for (Claim claim : claims) {
            if (claim.getClaimType().equals(NAME_CLAIM_TYPE)) name = claim.getClaimValue();
        }

        if (name.isEmpty()) {
            for (Claim claim : claims) {
                if (claim.getClaimType().equals(EMAIL_CLAIM_TYPE)) name = claim.getClaimValue();
            }
        }

        return name;
    }

    public List<Claim> getClaims() {
        return Collections.unmodifiableList(this.claims);
    }
}
