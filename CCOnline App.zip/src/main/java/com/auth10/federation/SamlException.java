package com.auth10.federation;

public class SamlException extends RuntimeException {

    private static final long serialVersionUID = 7912178833297938392L;

    public SamlException(Throwable e) {
        super(e);
    }

    public SamlException(String msg) {
        super(msg);
    }
}
