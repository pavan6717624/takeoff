package com.auth10.federation;

public class AdfsException extends RuntimeException {

    private static final long serialVersionUID = 5229069600014950499L;

    public AdfsException(String msg, Throwable t) {
        super(msg, t);
    }
}
