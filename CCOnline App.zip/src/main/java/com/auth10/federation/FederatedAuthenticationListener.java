package com.auth10.federation;

public interface FederatedAuthenticationListener {
    public void OnAuthenticationSucceed(FederatedPrincipal principal);
}
