package sbi.sf.gocblr.cconline.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Fslo, branch subclass
 *
 * @author Kiran Marturu
 *
 */
@Entity
@Table(name = "fslos")
@PrimaryKeyJoinColumn(name = "branch_code", foreignKey = @ForeignKey(name = "fk_fslos_branches"))
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
public class Fslo extends Branch {

    private static final long serialVersionUID = 1033491131540222769L;

    @Embedded
    @AttributeOverride(name = "pfId", column = @Column(name = "agm_id"))
    @AttributeOverride(name = "name", column = @Column(name = "agm_name", length = 100))
    @AttributeOverride(name = "emailId", column = @Column(name = "agm_email", length = 300))
    @AttributeOverride(name = "mobileNo", column = @Column(name = "agm_mobile_no"))
    private FsloStaff agm;

    @Embedded
    @AttributeOverride(name = "pfId", column = @Column(name = "officer_id"))
    @AttributeOverride(name = "name", column = @Column(name = "officer_name", length = 100))
    @AttributeOverride(name = "emailId", column = @Column(name = "officer_email", length = 300))
    @AttributeOverride(name = "mobileNo", column = @Column(name = "officer_mobile_no"))
    private FsloStaff otherOfficer;

    private Integer rbiRegionCode;

    @Column(name = "email_id", length = 300)
    private String emailId;
}
