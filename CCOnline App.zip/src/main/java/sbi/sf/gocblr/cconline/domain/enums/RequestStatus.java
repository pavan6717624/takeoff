package sbi.sf.gocblr.cconline.domain.enums;

import sbi.sf.gocblr.cconline.utils.TextUtils;

public enum RequestStatus {
    PENDING("P", "Pending"),
    APPROVED("A", "Approved"),
    REJECTED("R", "Rejected");

    private final String code;
    private final String description;

    RequestStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static RequestStatus fromCode(String code) {
        if (!TextUtils.hasText(code)) {
            return PENDING;
        }

        for (RequestStatus n : RequestStatus.values()) {
            if (n.code.equalsIgnoreCase(code)) {
                return n;
            }
        }
        return PENDING;
    }
}
