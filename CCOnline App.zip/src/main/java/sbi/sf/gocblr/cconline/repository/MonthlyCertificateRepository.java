package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateStmts;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateDetailedReport;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateSubmissionSummary;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateVsSummary;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateVsYesList;

public interface MonthlyCertificateRepository
    extends JpaRepository<MonthlyCertificateStmts, Integer>, CustomizedMonthlyCertificateRepository {
    @Query(
        "SELECT SUM(CASE WHEN s IS NULL THEN 1 ELSE 0 END) as notSubmitted, " +
        "       SUM(CASE WHEN s IS NULL THEN 0 ELSE 1 END) as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN MonthlyCertificateStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE abs(c.fslo.branchCode)= :fsloCode "
    )
    MonthlyCertificateSubmissionSummary monthlyCertificateSubmissionSummary(
        @Param("month") LocalDate month,
        @Param("fsloCode") long fsloCode
    );

    // FSLO
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN MonthlyCertificateStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE abs(c.fslo.branchCode)= :fsloCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateDetailedReport> monthlyCertificateReport(@Param("month") LocalDate month, @Param("fsloCode") long fsloCode);

    // Circle_Admin
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN MonthlyCertificateStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateDetailedReport> monthlyCertificateReportCircleAdmin(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode
    );

    // AO_User and AGM_GB
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "		CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN MonthlyCertificateStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateDetailedReport> monthlyCertificateReportAoUser(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode
    );

    // RM and RBO_CM
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "		CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN MonthlyCertificateStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND c.region.regionCode = :regionCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateDetailedReport> monthlyCertificateReportRBO(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("regionCode") long regionCode
    );

    // FSLO
    @Query(
        "SELECT s.displayNo as displayNo, " +
        "       s.displayOrder as displayOrder, " +
        "       s.isHeaderOnly as headerOnly, " +
        "       s.description as description, " +
        "       SUM(CASE WHEN d.optionInput = 'YES' THEN 1 ELSE 0 END) as inputYes, " +
        "       SUM(CASE WHEN d.optionInput = 'NO' THEN 1 ELSE 0 END) as inputNo " +
        " FROM MonthlyCertificateStmts s " +
        "      LEFT JOIN MonthlyCertificateData d " +
        "             ON d.statement = s " +
        "            AND d.month = :month " +
        "      LEFT JOIN CurrencyChest c " +
        "             ON c = d.cc " +
        "            AND abs(c.fslo.branchCode) = :fsloCode " +
        " WHERE NVL(c.closedDate, :month) >= :month " +
        "   AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        " GROUP BY s.displayNo, s.displayOrder, s.isHeaderOnly, s.description" +
        " ORDER BY s.displayOrder "
    )
    List<MonthlyCertificateVsSummary> monthlyCertificateVsSummary(@Param("month") LocalDate month, @Param("fsloCode") long fsloCode);

    //        "SELECT  m.statement.displayNo as displayNo, m.statement.displayOrder as displayOrder " +
    //        "       , m.statement.isHeaderOnly as isHeaderOnly, m.statement.description as description " +
    //        "       , SUM(CASE WHEN m.optionInput = 'YES' THEN 1 ELSE 0 END) as inputYes " +
    //        "		, SUM(CASE WHEN m.optionInput = 'NO' THEN 1 ELSE 0 END) as inputNo " +
    //        "  FROM MonthlyCertificateData m " +
    //        " WHERE m.cc.fslo.branchCode = :fsloCode " +
    //        "   AND m.month = :month " +
    //        " GROUP BY m.statement.displayNo, m.statement.displayOrder, m.statement.isHeaderOnly, m.statement.description " +
    //        " ORDER BY m.statement.displayOrder "
    //    )
    //    List<MonthlyCertificateVsSummary> monthlyCertificateVsSummary(@Param("month") LocalDate month, @Param("fsloCode") long fsloCode);

    // FSLO
    @Query(
        "SELECT s.cc.circle.circleCode as circleCode, " +
        "       s.cc.circle.circleName as circleName, " +
        // gives circle, network, module	codes
        //"       s.cc.region.module.network.networkCode as networkCode, " +
        "       s.cc.network.networkCode as networkCode, " +
        "       s.cc.module.moduleCode as moduleCode, " +
        "       s.cc.module.moduleName as moduleName, " +
        "       s.cc.region.regionCode as regionCode, " +
        "       s.cc.branchCode as branchCode, " +
        "       s.cc.branchName as branchName " +
        "  FROM MonthlyCertificateData s " +
        "  WHERE abs(s.cc.fslo.branchCode)= :fsloCode " +
        "    AND s.statement.displayOrder= :displayOrder " +
        "    AND s.optionInput= :option " +
        "    AND s.month= :month " +
        "    AND NVL(s.cc.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(s.cc.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateVsYesList> getVsListYes(
        @Param("month") LocalDate month,
        @Param("fsloCode") long fsloCode,
        @Param("displayOrder") Integer displayOrder,
        @Param("option") String option
    );

    // Circle_Admin
    @Query(
        "SELECT s.displayNo as displayNo, " +
        "       s.displayOrder as displayOrder, " +
        "       s.isHeaderOnly as headerOnly, " +
        "       s.description as description, " +
        "       SUM(CASE WHEN d.optionInput = 'YES' THEN 1 ELSE 0 END) as inputYes, " +
        "       SUM(CASE WHEN d.optionInput = 'NO' THEN 1 ELSE 0 END) as inputNo " +
        " FROM MonthlyCertificateStmts s " +
        "      LEFT JOIN MonthlyCertificateData d " +
        "             ON d.statement = s " +
        "            AND d.month = :month " +
        "      LEFT JOIN CurrencyChest c " +
        "             ON c = d.cc " +
        "            AND c.circle.circleCode = :circleCode " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        " GROUP BY s.displayNo, s.displayOrder, s.isHeaderOnly, s.description" +
        " ORDER BY s.displayOrder "
    )
    List<MonthlyCertificateVsSummary> monthlyCertificateVsSummaryCircleAdmin(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode
    );

    // AO_User and AGM_GB
    @Query(
        "SELECT s.displayNo as displayNo, " +
        "       s.displayOrder as displayOrder, " +
        "       s.isHeaderOnly as headerOnly, " +
        "       s.description as description, " +
        "       SUM(CASE WHEN d.optionInput = 'YES' THEN 1 ELSE 0 END) as inputYes, " +
        "       SUM(CASE WHEN d.optionInput = 'NO' THEN 1 ELSE 0 END) as inputNo " +
        " FROM MonthlyCertificateStmts s " +
        "      LEFT JOIN MonthlyCertificateData d " +
        "             ON d.statement = s " +
        "            AND d.month = :month " +
        "      LEFT JOIN CurrencyChest c " +
        "             ON c = d.cc " +
        "            AND c.circle.circleCode = :circleCode " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        " GROUP BY s.displayNo, s.displayOrder, s.isHeaderOnly, s.description" +
        " ORDER BY s.displayOrder "
    )
    List<MonthlyCertificateVsSummary> monthlyCertificateVsSummaryAoUser(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode
    );

    // RM and RBO_CM
    @Query(
        "SELECT s.displayNo as displayNo, " +
        "       s.displayOrder as displayOrder, " +
        "       s.isHeaderOnly as headerOnly, " +
        "       s.description as description, " +
        "       SUM(CASE WHEN d.optionInput = 'YES' THEN 1 ELSE 0 END) as inputYes, " +
        "       SUM(CASE WHEN d.optionInput = 'NO' THEN 1 ELSE 0 END) as inputNo " +
        " FROM MonthlyCertificateStmts s " +
        "      LEFT JOIN MonthlyCertificateData d " +
        "             ON d.statement = s " +
        "            AND d.month = :month " +
        "      LEFT JOIN CurrencyChest c " +
        "             ON c = d.cc " +
        "            AND c.circle.circleCode = :circleCode " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND c.region.regionCode = :regionCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        " GROUP BY s.displayNo, s.displayOrder, s.isHeaderOnly, s.description" +
        " ORDER BY s.displayOrder "
    )
    List<MonthlyCertificateVsSummary> monthlyCertificateVsSummaryRBO(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("regionCode") long regionCode
    );

    // Circle_Admin
    @Query(
        "SELECT s.cc.circle.circleCode as circleCode, " +
        "       s.cc.circle.circleName as circleName, " +
        "       s.cc.network.networkCode as networkCode, " +
        "       s.cc.module.moduleCode as moduleCode, " +
        "       s.cc.module.moduleName as moduleName, " +
        "       s.cc.region.regionCode as regionCode, " +
        "       s.cc.branchCode as branchCode, " +
        "       s.cc.branchName as branchName " +
        "  FROM MonthlyCertificateData s " +
        "  WHERE s.cc.circle.circleCode= :circleCode " +
        "    AND s.statement.displayOrder= :displayOrder " +
        "    AND s.optionInput= :option " +
        "    AND s.month= :month " +
        "    AND NVL(s.cc.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(s.cc.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateVsYesList> getVsListYesCircleAdmin(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("displayOrder") Integer displayOrder,
        @Param("option") String option
    );

    // AO_User and AGM_GB
    @Query(
        "SELECT s.cc.circle.circleCode as circleCode, " +
        "       s.cc.circle.circleName as circleName, " +
        "       s.cc.network.networkCode as networkCode, " +
        "       s.cc.module.moduleCode as moduleCode, " +
        "       s.cc.module.moduleName as moduleName, " +
        "       s.cc.region.regionCode as regionCode, " +
        "       s.cc.branchCode as branchCode, " +
        "       s.cc.branchName as branchName " +
        "  FROM MonthlyCertificateData s " +
        "  WHERE s.cc.circle.circleCode= :circleCode " +
        "    AND s.cc.network.networkCode = :networkCode " +
        "    AND s.cc.module.moduleCode = :moduleCode " +
        "    AND s.statement.displayOrder= :displayOrder " +
        "    AND s.optionInput= :option " +
        "    AND s.month= :month " +
        "    AND NVL(s.cc.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(s.cc.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateVsYesList> getVsListYesAoUser(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("displayOrder") Integer displayOrder,
        @Param("option") String option
    );

    // RM and RBO_CM
    @Query(
        "SELECT s.cc.circle.circleCode as circleCode, " +
        "       s.cc.circle.circleName as circleName, " +
        "       s.cc.network.networkCode as networkCode, " +
        "       s.cc.module.moduleCode as moduleCode, " +
        "       s.cc.module.moduleName as moduleName, " +
        "       s.cc.region.regionCode as regionCode, " +
        "       s.cc.branchCode as branchCode, " +
        "       s.cc.branchName as branchName " +
        "  FROM MonthlyCertificateData s " +
        "  WHERE s.cc.circle.circleCode= :circleCode " +
        "    AND s.cc.network.networkCode = :networkCode " +
        "    AND s.cc.module.moduleCode = :moduleCode " +
        "    AND s.cc.region.regionCode = :regionCode " +
        "    AND s.statement.displayOrder= :displayOrder " +
        "    AND s.optionInput= :option " +
        "    AND s.month= :month " +
        "    AND NVL(s.cc.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(s.cc.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<MonthlyCertificateVsYesList> getVsListYesRBO(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("regionCode") long regionCode,
        @Param("displayOrder") Integer displayOrder,
        @Param("option") String option
    );
}
