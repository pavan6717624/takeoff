package sbi.sf.gocblr.cconline.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import sbi.sf.gocblr.cconline.domain.Nsm;

@Data
@NoArgsConstructor
public class CcNsmModal {

    private Long id;
    private int yearOfPurchase;
    private Nsm nsm;
    private Long branchCode;
    private String status;
}
