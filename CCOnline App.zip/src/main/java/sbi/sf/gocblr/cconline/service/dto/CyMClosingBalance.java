package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.time.LocalDate;

@JsonInclude(content = Include.NON_NULL)
public interface CyMClosingBalance {
    Long getBranchCode();
    LocalDate getCcClosingBalanceDate();
    Double getCcClosingBalance();
}
