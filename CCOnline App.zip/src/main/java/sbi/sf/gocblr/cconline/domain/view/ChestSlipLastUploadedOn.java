package sbi.sf.gocblr.cconline.domain.view;

import java.time.LocalDate;
import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Immutable
@Table(name = "view_cs_last_uploaded")
public class ChestSlipLastUploadedOn {

    @Id
    @Column(name = "cc_branch_code")
    private long ccBranchCode;

    @Column(name = "last_uploaded_on")
    private LocalDate lastUploadedOn;
}
