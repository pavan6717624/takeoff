package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.BalanceVerification;
import sbi.sf.gocblr.cconline.domain.BalanceVerificationDetails;
import sbi.sf.gocblr.cconline.domain.Denomination;

public interface BalanceVerificationDetailsRepository extends JpaRepository<BalanceVerificationDetails, Long> {
    Optional<BalanceVerificationDetails> findByBalanceVerificationAndDenomination(BalanceVerification bv, Denomination d);
    Optional<BalanceVerificationDetails> findByBalanceVerificationIdAndDenomination(long id, Denomination d);
    List<BalanceVerificationDetails> findByBalanceVerificationIdAndDenominationType(long id, String denomType);
}
