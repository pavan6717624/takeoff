package sbi.sf.gocblr.cconline.model.ui;

import lombok.Value;

@Value
public class NzFilterMenu {

    private String text;
    private String value;
}
