package sbi.sf.gocblr.cconline.model.verificationmis;

import sbi.sf.gocblr.cconline.domain.enums.InputType;

public interface RepeatedObservationBranches {
    long getSectionId();
    String getSectionDisplayNo();
    String getSectionName();

    long getVsId();
    String getVsDescription();
    String getVsDisplayNo();
    int getVsDisplayOrder();
    int getVsIndentLevel();
    InputType getVsInputType();

    int getIsOnlyAsHeader();

    String getRepeatingBranches();
}
