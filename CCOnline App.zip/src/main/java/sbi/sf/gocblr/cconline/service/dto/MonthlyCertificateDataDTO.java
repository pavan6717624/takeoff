package sbi.sf.gocblr.cconline.service.dto;

import java.time.LocalDate;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateStmts;

public interface MonthlyCertificateDataDTO {
    MonthlyCertificateStmts getStatement();
    String getOptionInput();
    LocalDate getDateInput();
    Boolean getIsSaved();
}
