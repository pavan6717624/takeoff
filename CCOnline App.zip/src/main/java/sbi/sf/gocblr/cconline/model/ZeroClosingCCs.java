package sbi.sf.gocblr.cconline.model;

public interface ZeroClosingCCs {
    String getCircle();
    Long getNetwork();
    Long getModule();
    String getModuleName();
    Long getRegion();
    Long getBrcode();
    String getBrname();
    String getCsdate();
    Long getOpeningBalance();
    Long getClosingBalance();
}
