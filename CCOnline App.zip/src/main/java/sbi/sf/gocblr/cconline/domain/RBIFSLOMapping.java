package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "rbi_fslo_mapping")
public class RBIFSLOMapping implements Serializable {

    private static final long serialVersionUID = 119579246923896682L;

    @Id
    @Column(name = "rbi_region_code")
    Integer rbiRegionCode;

    @ManyToOne
    @JoinColumn(name = "fslo_code", foreignKey = @ForeignKey(name = "fk_rbi_fslo_mapping"))
    Fslo fslo;
}
