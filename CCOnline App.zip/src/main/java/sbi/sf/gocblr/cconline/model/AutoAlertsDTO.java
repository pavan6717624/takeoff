package sbi.sf.gocblr.cconline.model;

public interface AutoAlertsDTO {

public String getRole();
public Long getPfid();
public Long getBrcode();
public String getName();
public Long getMobile();
public String getEmail();
public Long getRoleId();
public String getDesignation();

}
