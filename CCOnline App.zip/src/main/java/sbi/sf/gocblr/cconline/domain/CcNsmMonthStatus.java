package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "cc_nsm_month_status")
public class CcNsmMonthStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_cc_nsm_month_status_cc_branch_code"))
    private CurrencyChest cc;

    private LocalDate month;

    @Column(name = "is_saved")
    private Boolean saved;
}
