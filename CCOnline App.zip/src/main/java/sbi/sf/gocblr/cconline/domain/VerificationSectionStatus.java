package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "verification_section_statuses")
public class VerificationSectionStatus implements Serializable {

    private static final long serialVersionUID = -1264051917294752863L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "verification_id", foreignKey = @ForeignKey(name = "fk_verification_section_status_verification"))
    private Verification verification;

    @OneToOne
    @JoinColumn(name = "verification_section_id", foreignKey = @ForeignKey(name = "fk_verification_section_status_section_id"))
    private VerificationSection section;

    @Column(name = "is_saved")
    private Boolean isSaved = false;
}
