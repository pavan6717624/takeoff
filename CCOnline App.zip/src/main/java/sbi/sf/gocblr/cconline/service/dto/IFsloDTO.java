package sbi.sf.gocblr.cconline.service.dto;

public interface IFsloDTO {
    Integer getFsloCode();
    String getFsloName();
}
