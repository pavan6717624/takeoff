package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Enum for representing CcProfile status
 * @author Kiran
 *
 */
public enum CcProfileStatus {
    SAVED,
    SUBMITTED,
    ACCEPTED,
    REJECTED;

    public static CcProfileStatus fromCode(String code) {
        for (CcProfileStatus n : CcProfileStatus.values()) {
            if (n.toString().equalsIgnoreCase(code)) {
                return n;
            }
        }
        return null;
    }
}
