package sbi.sf.gocblr.cconline.service.externalmodel;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * SsoUser for mocking
 * @author Kiran Marturu
 * TODO: modify once integrated with SSO
 *
 */
@Data
@AllArgsConstructor
public class SsoUser {

    private String pfIndex;
    private String employeeName;
    private String employeeGroupCode; // cadre O, S, C
    private String employeeSubGroupDesc; // designation
    private String personalSubAreaCode; // branch code
    private String personalSubAreaDesc;
    private String position;
    private String officialMailId;
    private String mobileNo;
}
