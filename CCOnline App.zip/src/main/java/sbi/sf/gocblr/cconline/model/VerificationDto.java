package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import sbi.sf.gocblr.cconline.domain.Verification;

@JsonInclude(content = Include.NON_NULL)
public interface VerificationDto {
    String getCircleName();
    Integer getNetworkCode();
    Integer getModuleCode();
    String getModuleName();
    Integer getRegionCode();
    Integer getBranchCode();
    String getBranchName();
    Verification getVerification();
}
