package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.CcCloseStatus;

@Converter(autoApply = true)
public class CcCloseStatusConverter implements AttributeConverter<CcCloseStatus, String> {

    @Override
    public String convertToDatabaseColumn(CcCloseStatus cs) {
        if (cs == null) {
            return null;
        }
        return cs.code();
    }

    @Override
    public CcCloseStatus convertToEntityAttribute(String ccCode) {
        if (ccCode == null) {
            return null;
        }
        return CcCloseStatus.fromCode(ccCode);
    }
}
