package sbi.sf.gocblr.cconline.model;

import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;

@Getter
@Setter
public class BranchDetailsDto {

    private String centerName;
    private String centerType;
    private String policeStation;
    private int cmCRPfId;
    private String cmCRName;
    private String cmCRContactNo;

    public BranchDetailsDto(CurrencyChest cc) {}
}
