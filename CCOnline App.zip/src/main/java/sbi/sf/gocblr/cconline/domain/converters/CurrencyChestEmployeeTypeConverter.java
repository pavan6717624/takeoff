package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.CurrencyChestEmployeeType;

/**
 * Attribute converter for @see sbi.sf.gocblr.cconline.domain.enums.CurrencyChestEmployeeType
 * @author Kiran Marturu
 *
 */
@Converter(autoApply = true)
public class CurrencyChestEmployeeTypeConverter implements AttributeConverter<CurrencyChestEmployeeType, String> {

    @Override
    public String convertToDatabaseColumn(CurrencyChestEmployeeType jct) {
        return jct.code();
    }

    @Override
    public CurrencyChestEmployeeType convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return CurrencyChestEmployeeType.fromCode(code);
    }
}
