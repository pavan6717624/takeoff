package sbi.sf.gocblr.cconline.service;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.VerificationSectionStatus;
import sbi.sf.gocblr.cconline.repository.VerificationSectionStatusRepository;

@Service
@RequiredArgsConstructor
public class VerificationSectionStatusService {

    private final VerificationSectionStatusRepository repo;

    private final VerificationService verificationService;

    public boolean isSectionSaved(Verification v, VerificationSection vs) {
        var status = repo.findByVerificationAndSection(v, vs);
        if (status.isPresent()) {
            return status.get().getIsSaved().booleanValue();
        }
        return false;
    }

    @Transactional
    public void updateSavedStatus(Verification v, VerificationSection vs) {
        Optional<VerificationSectionStatus> ex = repo.findByVerificationAndSection(v, vs);

        VerificationSectionStatus toSave;
        if (ex.isPresent()) {
            toSave = ex.get();
            toSave.setIsSaved(true);
        } else {
            toSave = new VerificationSectionStatus();
            toSave.setVerification(v);
            toSave.setSection(vs);
            toSave.setIsSaved(true);
        }

        repo.save(toSave);
        verificationService.markInProgress(v);
    }

    @Transactional
    public void markSectionDirty(Verification v, VerificationSection vs) {
        Optional<VerificationSectionStatus> ex = repo.findByVerificationAndSection(v, vs);

        if (ex.isPresent()) {
            ex.get().setIsSaved(false);
            repo.save(ex.get());
        }
    }
}
