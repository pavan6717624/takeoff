package sbi.sf.gocblr.cconline.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Action {

    private String label;
    private Boolean isEnabled;
}
