package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.enums.CcProfileStatus;
import sbi.sf.gocblr.cconline.web.rest.vm.ChestProfileSaveVM;

/**
 * Entity to Store save data while editing CC Profile
 * Only one entry to be kept for a given CC
 *
 * @author Kiran Marturu
 *
 */
@Data
@Entity
@Table(name = "cc_profile_saved_data")
public class CcProfileSaveData implements Serializable {

    private static final long serialVersionUID = -4667873393191266127L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @OneToOne
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_cc_profile_saved_data_cc"))
    private CurrencyChest currencyChest;

    // stores save data in JSON for easy processing
    @Column(length = 2000)
    private ChestProfileSaveVM data;

    @Column(name = "cc_profile_status", length = 50)
    private CcProfileStatus ccProfileStatus;
}
