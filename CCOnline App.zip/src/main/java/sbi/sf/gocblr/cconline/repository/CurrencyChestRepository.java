package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Fslo;
import sbi.sf.gocblr.cconline.domain.State;
import sbi.sf.gocblr.cconline.domain.enums.NotificationType;
import sbi.sf.gocblr.cconline.model.IMisReport;
import sbi.sf.gocblr.cconline.model.MisBglDifference;
import sbi.sf.gocblr.cconline.service.dto.BglDiffForSmsDTO;
import sbi.sf.gocblr.cconline.service.dto.CblExceededSmsDTO;
import sbi.sf.gocblr.cconline.service.dto.CsNotUploadedSmsDTO;

public interface CurrencyChestRepository extends JpaRepository<CurrencyChest, Long>, JpaSpecificationExecutor<CurrencyChest> {
    // for getting only hierarchy related details
    Optional<Branch> searchByBranchCode(Long branchCode);

    // for getting all details excluding lazy loaded ones
    Optional<CurrencyChest> findByBranchCode(Long branchCode);

    Optional<CurrencyChest> findByBranchCodeAndFsloBranchCode(long branchCode, long fsloCode);

    // for getting all details including lazy loaded ones
    @EntityGraph(
        attributePaths = {
            "region",
            "region.module",
            "region.module.network",
            "region.module.network.circle",
            "linkedBranches",
            "fslo",
            "fslo.agm",
            "fslo.otherOfficer",
        }
    )
    Optional<CurrencyChest> getByBranchCode(Long branchCode);

    // note: cc code is diff from branch code
    Optional<CurrencyChest> findByCcCode(Long ccCode);

    List<CurrencyChest> findByFsloOrderByBranchCodeAsc(Fslo fslo);
    List<CurrencyChest> findByAddressState(State state);
    List<CurrencyChest> findByVerificationsTypeId(int verificationTypeId);
    List<CurrencyChest> findByIsClosed(Boolean isClosed);

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo, " +
        "       lastCs.lastUploadedOn as lastUploadedOn, " +
        "       s.sent as smsSent " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN ChestSlipUploadDetails cs " +
        "              ON cs.status = 'New' " +
        "             AND cs.currencyChest = c " +
        "             AND cs.chestSlipDate = :asOn " +
        "       LEFT JOIN ChestSlipLastUploadedOn lastCs " +
        "              ON lastCs.ccBranchCode = c.branchCode " +
        "       LEFT JOIN SmsStatus s " +
        "              ON s.currencyChest = c " +
        "             AND s.forDate = :asOn " +
        "             AND s.notificationType = :notificationType " +
        " WHERE c.fslo.branchCode = :fsloCode " +
        "   AND cs.currencyChest IS NULL " +
        "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :asOn " +
        " ORDER BY c.branchCode "
    )
    List<CsNotUploadedSmsDTO> chestSlipNotUploaded(
        @Param("fsloCode") long fsloCode,
        @Param("asOn") LocalDate asOn,
        @Param("notificationType") NotificationType notificationType,
        Pageable page
    );

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo, " +
        "       lastCs.lastUploadedOn as lastUploadedOn, " +
        "       s.sent as smsSent " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN ChestSlipUploadDetails cs " +
        "              ON cs.status = 'New' " +
        "             AND cs.currencyChest = c " +
        "             AND cs.chestSlipDate = :asOn " +
        "       LEFT JOIN ChestSlipLastUploadedOn lastCs " +
        "              ON lastCs.ccBranchCode = c.branchCode " +
        "       LEFT JOIN SmsStatus s " +
        "              ON s.currencyChest = c " +
        "             AND s.forDate = :asOn " +
        " WHERE c.fslo.branchCode = :fsloCode " +
        "   AND cs.currencyChest IS NULL " +
        "   AND c.branchCode IN (:branches) " +
        "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :asOn " +
        " ORDER BY c.branchCode "
    )
    List<CsNotUploadedSmsDTO> chestSlipNotUploaded(
        @Param("fsloCode") long fsloCode,
        @Param("branches") Set<Long> branches,
        @Param("asOn") LocalDate asOn,
        Pageable page
    );

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.cashBalanceLimit * 10000000 as cashBalanceLimit, " +
        "       cb.cymValue as cymClosingBalance, " +
        "       ABS((c.cashBalanceLimit * 10000000) - cb.cymValue) as exceededBy, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo, " +
        "       sms.sent as smsSent " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN ChestSlipUploadDetails cs " +
        "              ON cs.status = 'New' " +
        "             AND cs.currencyChest = c " +
        "             AND cs.chestSlipDate = :asOn " +
        "       LEFT JOIN CcClosingBalance cb " +
        "              ON cb.csUploadId = cs.id " +
        "       LEFT JOIN SmsStatus sms " +
        "              ON sms.currencyChest = c " +
        "             AND sms.forDate = :asOn " +
        "             AND sms.notificationType = :notificationType " +
        " WHERE ((:percent / 100) * c.cashBalanceLimit * 10000000) < cb.cymValue " +
        "   AND c.fslo.branchCode = :fsloCode " +
        "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :asOn " +
        " ORDER BY c.branchCode "
    )
    List<CblExceededSmsDTO> cblExceeded(
        @Param("fsloCode") long fsloCode,
        @Param("asOn") LocalDate asOn,
        @Param("percent") int percent,
        @Param("notificationType") NotificationType notificationType,
        Pageable page
    );

    
    @Query(
            "SELECT c.branchCode as branchCode, " +
            "       c.branchName as branchName, " +
            "       c.cashBalanceLimit * 10000000 as cashBalanceLimit, " +
            "       cb.cymValue as cymClosingBalance, " +
            "       ABS((c.cashBalanceLimit * 10000000) - cb.cymValue) as exceededBy, " +
            "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
            "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
            "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo " +
            "  FROM CurrencyChest c " +
            "       LEFT JOIN ChestSlipUploadDetails cs " +
            "              ON cs.status = 'New' " +
            "             AND cs.currencyChest = c " +
            "             AND cs.chestSlipDate = :asOn " +
            "       LEFT JOIN CcClosingBalance cb " +
            "              ON cb.csUploadId = cs.id "+ 
            "		JOIN AutoAlertsDetails a on "
            + "			a.branch.branchCode=c.branchCode " +
            " WHERE (c.cashBalanceLimit * 10000000) < cb.cymValue " +
            "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
            "   AND NVL(c.closedDate, CURRENT_DATE ) > :asOn " +
            " ORDER BY c.branchCode "
        )
        List<CblExceededSmsDTO> alertSMSCBLExceeded(
            @Param("asOn") LocalDate asOn
          );

    
    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.cashBalanceLimit * 10000000 as cashBalanceLimit, " +
        "       cb.cymValue as cymClosingBalance, " +
        "       ABS((c.cashBalanceLimit * 10000000) - cb.cymValue) as exceededBy, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo, " +
        "       sms.sent as smsSent " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN ChestSlipUploadDetails cs " +
        "              ON cs.status = 'New' " +
        "             AND cs.currencyChest = c " +
        "             AND cs.chestSlipDate = :asOn " +
        "       LEFT JOIN CcClosingBalance cb " +
        "              ON cb.csUploadId = cs.id " +
        "       LEFT JOIN SmsStatus sms " +
        "              ON sms.currencyChest = c " +
        "             AND sms.forDate = :asOn " +
        "             AND sms.notificationType = :notificationType " +
        " WHERE ((:percent / 100) * c.cashBalanceLimit * 10000000) < cb.cymValue " +
        "   AND c.fslo.branchCode = :fsloCode " +
        "   AND c.branchCode IN (:branches) " +
        "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :asOn " +
        " ORDER BY c.branchCode "
    )
    Page<CblExceededSmsDTO> cblExceededFilterByBranches(
        @Param("fsloCode") long fsloCode,
        @Param("branches") Set<Long> branches,
        @Param("asOn") LocalDate asOn,
        @Param("percent") int percent,
        @Param("notificationType") NotificationType notificationType,
        Pageable page
    );

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.fslo.branchCode as fsloCode, " +
        "       c.fslo.branchName as fsloName, " +
        "       csud.chestSlipDate as chestSlipDate, " +
        "       net.cymValue as cymValue, " +
        "       bgl.value as bglValue, " +
        "       (net.cymValue - bgl.value) as difference, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo " +
        "  FROM CurrencyChest c " +
        "       JOIN ChestSlipUploadDetails csud " +
        "         ON csud.status = 'New' " +
        "        AND csud.currencyChest = c " +
        "        AND csud.chestSlipDate = :asOn " +
        "       JOIN CcNetDepAndWdl net " +
        "         ON net.csUploadId = csud.id " +
        "       JOIN CcBglBalance bgl " +
        "         ON bgl.currencyChest = csud.currencyChest " +
        "        AND bgl.date = csud.chestSlipDate " +
        "       JOIN ChestClosingFields cls " +
        "         ON cls.id = bgl.checkClosingFields " +
        "        AND cls.fieldName = 'BGL98908Closing' " +
        "  LEFT JOIN SmsStatus sms " +
        "         ON sms.currencyChest = c " +
        "        AND sms.forDate = :asOn " +
        " WHERE (net.cymValue - bgl.value) <> 0 " +
        "   AND c.fslo.branchCode = :fsloCode " +
        "   AND c.branchCode IN (:branches) " +
        "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :asOn " +
        " ORDER BY c.branchCode "
    )
    List<BglDiffForSmsDTO> bgl98908Diff(
        @Param("fsloCode") long fsloCode,
        @Param("branches") Set<Long> branches,
        @Param("asOn") LocalDate asOn,
        Pageable page
    );

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.fslo.branchCode as fsloCode, " +
        "       c.fslo.branchName as fsloName, " +
        "       csud.chestSlipDate as chestSlipDate, " +
        "       net.cymValue as cymValue, " +
        "       bgl.value as bglValue, " +
        "       (net.cymValue - bgl.value) as difference, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo, " +
        "       sms.sent as smsSent " +
        "  FROM CurrencyChest c " +
        "       JOIN ChestSlipUploadDetails csud " +
        "         ON csud.status = 'New' " +
        "        AND csud.currencyChest = c " +
        "        AND csud.chestSlipDate = :since " +
        "       JOIN CcNetDepAndWdl net " +
        "         ON net.csUploadId = csud.id " +
        "       JOIN CcBglBalance bgl " +
        "         ON bgl.currencyChest = csud.currencyChest " +
        "        AND bgl.date = csud.chestSlipDate " +
        "       JOIN ChestClosingFields cls " +
        "         ON cls.id = bgl.checkClosingFields " +
        "  LEFT JOIN SmsStatus sms " +
        "         ON sms.currencyChest = c " +
        "        AND sms.forDate = :since " +
        "        AND sms.notificationType = :notificationType " +
        " WHERE cls.fieldName = 'BGL98908Closing' " +
        "   AND csud.chestSlipDate = :since " +
        "   AND (net.cymValue - bgl.value) <> 0 " +
        "   AND c.fslo.branchCode = :fsloCode " +
        "   AND NVL(c.dateOfOpening, :since) <= :since " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :since " +
        " ORDER BY c.branchCode "
    )
    List<BglDiffForSmsDTO> bgl98908Diff(
        @Param("fsloCode") long fsloCode,
        @Param("since") LocalDate since,
        @Param("notificationType") NotificationType notificationType,
        Pageable page
    );

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.fslo.branchCode as fsloCode, " +
        "       c.fslo.branchName as fsloName, " +
        "       csud.chestSlipDate as chestSlipDate, " +
        "       clb.cymValue as cymValue, " +
        "       bgl.value as bglValue, " +
        "       (clb.cymValue + bgl.value) as difference, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo, " +
        "       sms.sent as smsSent " +
        "  FROM CurrencyChest c " +
        "       JOIN ChestSlipUploadDetails csud " +
        "         ON csud.status = 'New' " +
        "        AND csud.currencyChest = c " +
        "       JOIN CcClosingBalance clb " +
        "         ON clb.csUploadId = csud.id " +
        "       JOIN CcBglBalance bgl " +
        "         ON bgl.currencyChest = csud.currencyChest " +
        "        AND bgl.date = csud.chestSlipDate " +
        "       JOIN ChestClosingFields cls " +
        "         ON cls.id = bgl.checkClosingFields " +
        "  LEFT JOIN SmsStatus sms " +
        "         ON sms.currencyChest = c " +
        "        AND sms.forDate = :since " +
        "        AND sms.notificationType = :notificationType " +
        " WHERE cls.fieldName = 'BGL98958Closing' " +
        "   AND (clb.cymValue + bgl.value) <> 0 " +
        "   AND c.fslo.branchCode = :fsloCode " +
        "   AND csud.chestSlipDate = :since " +
        "   AND NVL(c.dateOfOpening, :since) <= :since " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :since " +
        " ORDER BY c.branchCode"
    )
    List<BglDiffForSmsDTO> bgl98958Diff(
        @Param("fsloCode") long fsloCode,
        @Param("since") LocalDate since,
        @Param("notificationType") NotificationType notificationType,
        Pageable page
    );

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       c.fslo.branchCode as fsloCode, " +
        "       c.fslo.branchName as fsloName, " +
        "       csud.chestSlipDate as chestSlipDate, " +
        "       clb.cymValue as cymValue, " +
        "       bgl.value as bglValue, " +
        "       (clb.cymValue - bgl.value) as difference, " +
        "       c.ccEmployeeDetails.coMobileNo as coMobileNo, " +
        "       c.ccEmployeeDetails.accountantMobileNo as accountantMobileNo, " +
        "       c.ccEmployeeDetails.bmMobileNo as bmMobileNo " +
        "  FROM CurrencyChest c " +
        "       JOIN ChestSlipUploadDetails csud " +
        "         ON csud.status = 'New' " +
        "        AND csud.currencyChest = c " +
        "       JOIN CcClosingBalance clb " +
        "         ON clb.csUploadId = csud.id " +
        "       JOIN CcBglBalance bgl " +
        "         ON bgl.currencyChest = csud.currencyChest " +
        "        AND bgl.date = csud.chestSlipDate " +
        "       JOIN ChestClosingFields cls " +
        "         ON cls.id = bgl.checkClosingFields " +
        " WHERE cls.fieldName = 'BGL98958Closing' " +
        "   AND (clb.cymValue - bgl.value) <> 0 " +
        "   AND c.fslo.branchCode = :fsloCode " +
        "   AND csud.chestSlipDate = :since " +
        "   AND c.branchCode IN (:branches) " +
        "   AND NVL(c.dateOfOpening, :since) <= :since " +
        "   AND NVL(c.closedDate, CURRENT_DATE ) > :since " +
        " ORDER BY c.branchCode "
    )
    Page<BglDiffForSmsDTO> bgl98958Diff(
        @Param("fsloCode") long fsloCode,
        @Param("branches") Set<Long> branches,
        @Param("since") LocalDate since,
        Pageable page
    );

    // ~ For MIS Reports
    // =================

    @Query(
        "SELECT c.fslo.branchCode as fslocode, " +
        "       c.fslo.branchName as fsloName, " +
        "       c.circle.circleName as circle, " +
        "       c.network.networkCode as network, " +
        "       c.module.moduleCode as module, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as region,  " +
        "       c.branchCode as brcode, " +
        "       c.branchName as brname, " +
        "       c.ccCode as cccode, " +
        "       (c.cashBalanceLimit * 10000000) as cbl, " +
        "       cb.cymValue as total " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN ChestSlipUploadDetails csud " +
        "              ON csud.status = 'New' " +
        "             AND csud.currencyChest = c " +
        "             AND csud.chestSlipDate = :asOn " +
        "       LEFT JOIN CcClosingBalance cb " +
        "              ON cb.csUploadId = csud.id " +
        " WHERE ((:limit / 100) * c.cashBalanceLimit * 10000000) < cb.cymValue " +
        "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, :asOn + 1) > :asOn " +
        "   AND ( (:fsloCode IS NULL OR ABS(c.fslo.branchCode) = :fsloCode) OR (:circleCode IS NULL OR c.circle.circleCode = :circleCode) ) " +
        "   AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR c.region.regionCode = :regionCode) " +
        "   AND (:branchCode IS NULL OR c.branchCode = :branchCode) " +
        " ORDER BY c.circle, c.network, c.module, c.region, c.branchCode"
    )
    List<IMisReport> cblExceeded(
        @Param("asOn") LocalDate asOn,
        @Param("fsloCode") Long fsloCode,
        @Param("circleCode") Long circleCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode,
        @Param("branchCode") Long branchCode,
        @Param("limit") Integer limit
    );

    @Query(
        "SELECT c.circle.circleName as circle, " +
        "       c.network.networkCode as network, " +
        "       c.module.moduleCode as module, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as region, " +
        "       c.branchCode as brCode, " +
        "       c.branchName as brName, " +
        "       bgl08.value as bgl98908balance, " +
        "       net.cymValue as net, " +
        "       (NVL(net.cymValue, 0) - NVL(bgl08.value, 0)) as netDifference, " +
        "       bgl58.value as bgl98958balance, " +
        "       clb.cymValue as closingBalance, " +
        "       (NVL(bgl58.value, 0) + NVL(clb.cymValue, 0)) as closingDifference " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN ChestSlipUploadDetails csud " +
        "              ON csud.status = 'New' " +
        "             AND csud.currencyChest = c " +
        "             AND csud.chestSlipDate = :asOn " +
        "       LEFT JOIN CcNetDepAndWdl net " +
        "              ON net.csUploadId = csud.id " +
        "       LEFT JOIN CcBglBalance bgl08 " +
        "              ON bgl08.currencyChest = c " +
        "             AND bgl08.date = :asOn " +
        "             AND bgl08.checkClosingFields.id = 2 " +
        "       LEFT JOIN CcClosingBalance clb " +
        "              ON clb.csUploadId = csud.id " +
        "       LEFT JOIN CcBglBalance bgl58 " +
        "              ON bgl58.currencyChest = c " +
        "             AND bgl58.date = :asOn  " +
        "             AND bgl58.checkClosingFields.id = 1 " +
        " WHERE NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, :asOn + 1) > :asOn " +
        "   AND ( (:fsloCode IS NULL OR ABS(c.fslo.branchCode) = :fsloCode) OR (:circleCode IS NULL OR c.circle.circleCode = :circleCode) ) " +
        "   AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR c.region.regionCode = :regionCode) " +
        "   AND (:branchCode IS NULL OR  c.branchCode  = :branchCode) " +
        " ORDER BY c.circle, c.network, c.module, c.region, c.branchCode"
    )
    List<MisBglDifference> bglDifference(
        @Param("asOn") LocalDate asOn,
        @Param("fsloCode") Long fsloCode,
        @Param("circleCode") Long circleCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode,
        @Param("branchCode") Long branchCode
    );
}
