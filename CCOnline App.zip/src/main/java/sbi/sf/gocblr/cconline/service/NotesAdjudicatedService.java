package sbi.sf.gocblr.cconline.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.NotesAdjudicated;
import sbi.sf.gocblr.cconline.domain.NotesAdjudicatedDetails;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.repository.NotesAdjudicatedDetailsRepository;
import sbi.sf.gocblr.cconline.repository.NotesAdjudicatedRepository;
import sbi.sf.gocblr.cconline.service.dto.NotesAdjudicatedDetailsDTO;
import sbi.sf.gocblr.cconline.web.rest.vm.NotesAdjudicatedVM;

@Service
@RequiredArgsConstructor
public class NotesAdjudicatedService {

    private final NotesAdjudicatedRepository repo;
    private final NotesAdjudicatedDetailsRepository detailsRepo;

    private final VerificationService verificationService;
    private final VerificationSectionService sectionService;
    private final DenominationService denominationService;
    private final VerificationSectionStatusService statusService;

    @Transactional(readOnly = true)
    public List<NotesAdjudicatedDetailsDTO> notesAdjudicatedDetails(long verificationId) {
        Verification v = verificationService.getVerificationById(verificationId);
        return detailsRepo
            .notesAdjudicatedDetails(v)
            .stream()
            .filter(x -> x.getDenominationType().equals("N"))
            .collect(Collectors.toList());
    }

    @Transactional
    public void save(long verificationId, Map<Integer, NotesAdjudicatedVM> data) {
        var v = verificationService.notSubmitted(verificationId);

        var existing = repo.findByVerificationId(verificationId);

        NotesAdjudicated nd;
        if (existing.isPresent()) {
            // existing
            nd = existing.get();

            for (Map.Entry<Integer, NotesAdjudicatedVM> entry : data.entrySet()) {
                var denom = denominationService.getById(entry.getKey());
                var d = detailsRepo.findByNotesAdjudicatedAndDenomination(nd, denominationService.getById(entry.getKey()));
                if (d.isPresent()) {
                    d.get().setFullValuePieces(entry.getValue().getFullValuePieces());
                    d.get().setHalfValuePieces(entry.getValue().getHalfValuePieces());
                    d.get().setRejectedPieces(entry.getValue().getRejectedPieces());
                    nd.addDetails(detailsRepo.save(d.get()));
                } else {
                    var dn = new NotesAdjudicatedDetails();
                    dn.setNotesAdjudicated(nd);
                    dn.setDenomination(denom);
                    dn.setFullValuePieces(entry.getValue().getFullValuePieces());
                    dn.setHalfValuePieces(entry.getValue().getHalfValuePieces());
                    dn.setRejectedPieces(entry.getValue().getRejectedPieces());
                    nd.addDetails(dn);
                }
            }
        } else {
            // update
            nd = new NotesAdjudicated();
            nd.setVerification(v);
            nd = repo.save(nd);

            for (Map.Entry<Integer, NotesAdjudicatedVM> entry : data.entrySet()) {
                var d = new NotesAdjudicatedDetails();
                d.setNotesAdjudicated(nd);
                d.setDenomination(denominationService.getById(entry.getKey()));
                d.setFullValuePieces(entry.getValue().getFullValuePieces());
                d.setHalfValuePieces(entry.getValue().getHalfValuePieces());
                d.setRejectedPieces(entry.getValue().getRejectedPieces());

                nd.addDetails(d);
            }
        }
        repo.save(nd);

        VerificationSection section = sectionService.getByTypeAndRoute(v.getType(), "notes-adjudicated");
        statusService.updateSavedStatus(v, section);
    }
}
