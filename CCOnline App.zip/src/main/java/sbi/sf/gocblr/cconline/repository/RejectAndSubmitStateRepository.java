package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.RejectAndSubmitState;
import sbi.sf.gocblr.cconline.domain.VerificationType;

public interface RejectAndSubmitStateRepository extends JpaRepository<RejectAndSubmitState, Long> {
    Optional<RejectAndSubmitState> findByVerificationTypeAndForRoleName(VerificationType type, String role);
}
