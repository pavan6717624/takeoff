package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationBranchProfile;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.domain.enums.CcType;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.repository.VerificationBranchProfileRepository;
import sbi.sf.gocblr.cconline.service.dto.StaffPosition;
import sbi.sf.gocblr.cconline.service.dto.VerificationBranchProfileIM;
import sbi.sf.gocblr.cconline.service.dto.VerificationBranchProfileVM;
import sbi.sf.gocblr.cconline.service.dto.VerificationBranchProfileViewAndInput;

@Slf4j
@Service
@RequiredArgsConstructor
public class VerificationBranchProfileService {

    private final VerificationBranchProfileRepository repo;

    private final VerificationService verificationService;
    private final VerificationSectionService sectionService;
    private final VerificationSectionStatusService statusService;
    private final DisplayService ccPositionService;
    private final ChestSlipService csService;
    private final CcBglBalanceService bglBalanceService;

    @Transactional(readOnly = true)
    public VerificationBranchProfileViewAndInput get(long verificationId) {
        VerificationBranchProfileViewAndInput vm = new VerificationBranchProfileViewAndInput();

        Verification v = verificationService.getVerificationById(verificationId);
        CurrencyChest cc = v.getCurrencyChest();

        VerificationBranchProfileVM view = new VerificationBranchProfileVM();
        view.setBranchCode(cc.getBranchCode());
        view.setBranchName(cc.getBranchName());
        view.setCircleCode(cc.getRegion().getModule().getNetwork().getCircle().getCircleCode());
        view.setCircleName(cc.getRegion().getModule().getNetwork().getCircle().getCircleName());
        view.setNetworkCode(cc.getRegion().getModule().getNetwork().getNetworkCode());
        view.setModuleCode(cc.getRegion().getModule().getModuleCode());
        view.setModuleName(cc.getRegion().getModule().getModuleName());
        view.setRegionCode(cc.getRegion().getRegionCode());

        view.setStrongRoomSize(cc.getStrongRoomSize());
        view.setCashBalanceLimit(cc.getCashBalanceLimit());
        view.setCapacityToStoreCashInBundles(cc.getCapacityToStoreCashInBundles());
        view.setAverageDailyReciepts(cc.getAverageDailyReciepts());
        view.setAverageDailyPayments(cc.getAverageDailyPayments());

        // BGL 98958 and Soiled notes balance reported not to be updated for
        // Bi Monthly and Quarterly
        if (isBiMonthlyOrHalfYearly(v.getType())) {
            vm.setBalancesUpdatedLater(true);

            view.setBgl98958Balance(0L);
            view.setSoiledNotesBalanceReported(0L);
        } else {
            var ccPosition = ccPositionService.displayDifference(cc.getBranchCode());
            view.setBgl98958Balance(ccPosition.getBgl98958balance().longValue());

            var scb = csService.getSoiledNotesClosingBalance(cc);
            view.setSoiledNotesBalanceReported((long) scb);
        }

        VerificationBranchProfileIM input = new VerificationBranchProfileIM();
        input.setTotalStaff(new StaffPosition());
        input.setCashDeptStaff(new StaffPosition());

        Optional<VerificationBranchProfile> saved = repo.findByVerificationId(v.getId());

        if (saved.isPresent()) {
            VerificationBranchProfile p = saved.get();
            input.setIncumbency(p.getIncumbency());
            input.setIncumbencySince(p.getIncumbencySince());
            input.setCcType(p.getCcType());

            if (p.getTotalStaff() != null) {
                input.setTotalStaff(p.getTotalStaff());
            }
            if (p.getCashDeptStaff() != null) {
                input.setCashDeptStaff(p.getCashDeptStaff());
            }
            input.setCcBalanceReportedInCyM(p.getCcBalanceReportedInCyM());
            input.setBalanceOfSoiledNotesAvailableInCc(p.getBalanceOfSoiledNotesAvailableInCc());
            input.setLastBiMonthlyVerification(p.getLastBiMonthlyVerification());
            input.setLastQuarterlyVerification(p.getLastQuarterlyVerification());
            input.setLastHalfYearlyVerification(p.getLastHalfYearlyVerification());
            input.setLastSecurityOfficerVist(p.getLastSecurityOfficerVist());
            input.setStrongRoomFitnessCertExpiryDate(p.getStrongRoomFitnessCertExpiryDate());

            if (p.getBgl98958Balance() != null) {
                view.setBgl98958Balance(p.getBgl98958Balance().longValue());
            }
            if (p.getSoiledNotesBalanceReported() != null) {
                view.setSoiledNotesBalanceReported(p.getSoiledNotesBalanceReported().longValue());
            }

            vm.setInputModel(input);
        }
        vm.setInputModel(input);
        vm.setCcTypes(CcType.getAsIdNameAndDesc());

        vm.setSecurityOfficer(v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.SECURITY_OFFICER));

        // for handling top-official visit logic in UI
        vm.setTopOfficialsVisit(
            (v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.RM_DGM_CONTROLLER_VISIT)) ||
            (v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_BO_MODULE_HEAD_VISIT)) ||
            (v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.GM_NETWORK_VISIT)) ||
            (v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.CGM_VISIT)) ||
            (v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_CFO_VISIT))
        );

        vm.setViewModel(view);

        return vm;
    }

    private boolean isBiMonthlyOrHalfYearly(VerificationType type) {
        return (
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.HALF_YEARLY)
        );
    }

    private boolean isTopOfficialsVisit(VerificationType type) {
        return (
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.RM_DGM_CONTROLLER_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_BO_MODULE_HEAD_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.GM_NETWORK_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.CGM_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_CFO_VISIT)
        );
    }

    @Transactional
    public void save(long verificationId, VerificationBranchProfileIM input) {
        Optional<VerificationBranchProfile> existing = repo.findByVerificationId(verificationId);

        Verification v = verificationService.notSubmitted(verificationId);

        List<String> errors = validate(
            input,
            v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.SECURITY_OFFICER),
            isTopOfficialsVisit(v.getType())
        );

        if (!errors.isEmpty()) {
            throw new ValidationException("Errors in form data", errors);
        }

        VerificationBranchProfile toSave;
        if (existing.isPresent()) {
            toSave = existing.get();
            updateFieldsFromDtoToDomain(input, toSave);
        } else {
            CurrencyChest cc = v.getCurrencyChest();

            toSave = new VerificationBranchProfile();
            toSave.setVerification(v);

            toSave.setBranchCode(cc.getBranchCode());
            toSave.setBranchName(cc.getBranchName());
            toSave.setCircleCode(cc.getRegion().getModule().getNetwork().getCircle().getCircleCode());
            toSave.setCircleName(cc.getRegion().getModule().getNetwork().getCircle().getCircleName());
            toSave.setNetworkCode(cc.getRegion().getModule().getNetwork().getNetworkCode());
            toSave.setModuleCode(cc.getRegion().getModule().getModuleCode());
            toSave.setModuleName(cc.getRegion().getModule().getModuleName());
            toSave.setRegionCode(cc.getRegion().getRegionCode());
            toSave.setStrongRoomSize(cc.getStrongRoomSize());
            toSave.setCashBalanceLimit(cc.getCashBalanceLimit());
            toSave.setCapacityToStoreCashInBundles(cc.getCapacityToStoreCashInBundles());
            toSave.setAverageDailyReciept(cc.getAverageDailyReciepts());
            toSave.setAverageDailyPayment(cc.getAverageDailyPayments());

            updateFieldsFromDtoToDomain(input, toSave);
        }

        if (!isBiMonthlyOrHalfYearly(v.getType())) {
            var ccPosition = ccPositionService.displayDifference(v.getCurrencyChest().getBranchCode());
            toSave.setBgl98958Balance(ccPosition.getBgl98958balance());

            var scb = csService.getSoiledNotesClosingBalance(v.getCurrencyChest());
            toSave.setSoiledNotesBalanceReported(scb);
        }

        VerificationBranchProfile saved = repo.save(toSave);

        // get section
        VerificationSection section = sectionService.getByTypeAndRoute(toSave.getVerification().getType(), "branch-profile");
        statusService.updateSavedStatus(saved.getVerification(), section);
    }

    /**
     * Validate VerificationBranchProfileIM based on whether it is security officer or not
     * @param input input model from front-end
     * @param isSecurityOfficer whether verification is security officer or not
     * @return list of errors, empty in case no errors
     */
    private List<String> validate(VerificationBranchProfileIM input, boolean isSecurityOfficer, boolean isTopOfficialsVisit) {
        // validate based on security officer
        List<String> errorsMap = new ArrayList<>();
        if (isSecurityOfficer) {
            if (input.getLastSecurityOfficerVist() == null) {
                errorsMap.add("Last security officer visit is required");
            }
        } else if (isTopOfficialsVisit) {} else {
            if (input.getTotalStaff() == null) {
                errorsMap.add("Branch staff details are required");
            }
            if (input.getCashDeptStaff() == null) {
                errorsMap.add("Cash dept. staff details are required");
            }
            if (input.getCcBalanceReportedInCyM() == null) {
                errorsMap.add("CC balance reported in CyM is required");
            }
            if (input.getBalanceOfSoiledNotesAvailableInCc() == null) {
                errorsMap.add("Balance of soiled notes available in CC is required");
            }
            if (input.getLastBiMonthlyVerification() == null) {
                errorsMap.add("Last bi-monthly verification date is required");
            }
            if (input.getLastHalfYearlyVerification() == null) {
                errorsMap.add("Last half-yearly verification date is required");
            }
        }
        return errorsMap;
    }

    private void updateFieldsFromDtoToDomain(VerificationBranchProfileIM input, VerificationBranchProfile ex) {
        ex.setIncumbency(input.getIncumbency());
        ex.setIncumbencySince(input.getIncumbencySince());
        ex.setCcType(input.getCcType());
        ex.setTotalStaff(input.getTotalStaff());
        ex.setCashDeptStaff(input.getCashDeptStaff());
        ex.setCcBalanceReportedInCyM(input.getCcBalanceReportedInCyM());
        ex.setBalanceOfSoiledNotesAvailableInCc(input.getBalanceOfSoiledNotesAvailableInCc());
        ex.setLastBiMonthlyVerification(input.getLastBiMonthlyVerification());
        ex.setLastQuarterlyVerification(input.getLastQuarterlyVerification());
        ex.setLastHalfYearlyVerification(input.getLastHalfYearlyVerification());
        ex.setLastSecurityOfficerVist(input.getLastSecurityOfficerVist());
        ex.setStrongRoomFitnessCertExpiryDate(input.getStrongRoomFitnessCertExpiryDate());
    }

    public VerificationBranchProfile getSavedBranchProfile(long id) {
        return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException(""));
    }

    @Transactional
    public void update98958AndSoiledBalanaceReported(long verificationId, LocalDate balancesAsOn) {
        log.trace(">> update98958AndSoiledBalanaceReported({}, {})", verificationId, balancesAsOn);

        Verification verification = verificationService.notSubmitted(verificationId);

        Optional<VerificationBranchProfile> existing = repo.findByVerificationId(verificationId);
        if (existing.isPresent()) {
            double bgl98958balance = bglBalanceService.bgl98958AsOn(verification.getCurrencyChest().getBranchCode(), balancesAsOn);
            double soiledNotesBalanaceReported = csService.getSoiledNotesClosingBalance(
                verification.getCurrencyChest().getBranchCode(),
                balancesAsOn
            );

            existing.get().setBgl98958Balance(bgl98958balance);
            existing.get().setSoiledNotesBalanceReported(soiledNotesBalanaceReported);

            repo.save(existing.get());
        }
    }
}
