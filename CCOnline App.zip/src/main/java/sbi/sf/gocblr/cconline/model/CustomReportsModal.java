package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class CustomReportsModal {

    String csdate;
    String circle;
    Long net;
    String zone;
    Long region;
    Long brcode;
    String brname;
    Long cccode;
    Long fslocode;
    String popcode;
    String state;
    String fsloname;
    Long cbl;
    Double n1;
    Double n2;
    Double n5;
    Double n10;
    Double n20;
    Double n50;
    Double n100;
    Double n200;
    Double n500;
    Double n1000;
    Double n2000;
    Double c1;
    Double c2;
    Double c5;
    Double c10;
    Double c20;
    Double totalpieces;
    Double totalvalue;
}
