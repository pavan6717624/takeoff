package sbi.sf.gocblr.cconline.service.dto;

import java.util.List;
import lombok.Data;
import sbi.sf.gocblr.cconline.model.DenomintaionAndPiecesDTO;

@Data
public class NotesAndCoinsDenominationAndPiecesDTO {

    private List<DenomintaionAndPiecesDTO> notes;
    private List<DenomintaionAndPiecesDTO> coins;
}
