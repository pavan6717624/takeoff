package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import sbi.sf.gocblr.cconline.domain.enums.CcClass;
import sbi.sf.gocblr.cconline.domain.enums.CcType;

/**
 * Currency chest, which is a sub-class of Branch only containing fields
 * relevant to CC
 *
 * @author Kiran Marturu
 */
@Entity
@Table(name = "currency_chests")
@Getter
@Setter
@PrimaryKeyJoinColumn(name = "branch_code", foreignKey = @ForeignKey(name = "fk_currency_chests_branches"))
@ToString
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
public class CurrencyChest extends Branch {

    private static final long serialVersionUID = -5398461710952310022L;

    @Column(name = "is_closed")
    private Boolean isClosed;

    @Column(name = "closed_date")
    private LocalDate closedDate;

    @Column(name = "currency_chest_code", length = 10)
    private Long ccCode;

    @Column(name = "date_of_opening")
    private LocalDate dateOfOpening;

    @Column(name = "currency_chest_type", length = 10)
    private CcType ccType;

    @Column(name = "strong_room_fitness_validity")
    private LocalDate validityDateOfStrongRoomFitnessCertificate;

    @Column(name = "currency_chest_class", length = 3)
    private CcClass chestClass;

    @Column(name = "cash_balance_limit")
    private Long cashBalanceLimit;

    @Column(name = "capacity_to_store_cash_in_bundles")
    private Long capacityToStoreCashInBundles;

    @Column(name = "avg_daily_reciepts")
    private Long averageDailyReciepts;

    @Column(name = "avg_daily_payments")
    private Long averageDailyPayments;

    @Column(name = "total_staff")
    private Integer totalStaff;

    @Column(name = "cash_dept_staff")
    private Integer cashDeptStaff;

    @Column(name = "no_of_guards")
    private Integer noOfGuardsPosted;

    @Column(name = "no_of_other_bank_branches_linked")
    private Integer noOfOtherBankBranchesLinked;

    @Column(name = "no_of_bins_available")
    private Integer noOfBinsAvailable;

    @Column(name = "no_of_ccs_mapped_in_cbs")
    private Integer noOfCCsMappedinCBS;

    @Column(name = "holding_capacity_of_bins")
    private Long holdingCapacityOfBins;

    @Column(name = "coin_vending_machine_available")
    private Boolean coinVendingMachineAvailable;

    @Column(name = "no_of_4plus1_type_nsms")
    private Integer noOf4plus1TypeNSM;

    @Column(name = "no_of_3plus1_type_nsms")
    private Integer noOf3plus1TypeNSM;

    @Column(name = "no_of_2plus1_type_nsms")
    private Integer noOf2plus1TypeNSM;

    @Column(name = "no_of_1plus1_type_nsms")
    private Integer noOf1plus1TypeNSM;

    @Embedded
    @AttributeOverride(name = "line1", column = @Column(name = "address_line1", length = 100))
    @AttributeOverride(name = "line2", column = @Column(name = "address_line2", length = 100))
    @AttributeOverride(name = "line3", column = @Column(name = "address_line3", length = 100))
    @AttributeOverride(name = "district", column = @Column(name = "district", length = 100))
    @AttributeOverride(name = "centerName", column = @Column(name = "center_name", length = 100))
    @AttributeOverride(name = "centerType", column = @Column(name = "center_type", length = 100))
    @AttributeOverride(name = "policeStation", column = @Column(name = "police_station", length = 300))
    @AttributeOverride(name = "populationGroup", column = @Column(name = "population_group", length = 20))
    private Address address;

    private Integer incumbency;

    @Column(name = "is_region_branch")
    private Boolean isUnderRm;

    @Column(name = "is_dgm_branch")
    private Boolean isUnderDgm;

    @Column(name = "strong_room_area")
    private Long strongRoomSize;

    @Column(name = "cash_area")
    private Long cashProcessingArea;

    @ManyToOne
    @JoinColumn(name = "fslo_code", foreignKey = @ForeignKey(name = "fk_currency_chests_fslo"))
    private Fslo fslo;

    //@OneToMany(mappedBy = "currencyChest")
    //private Set<CurrencyChestEmployee> ccEmployees = new HashSet<>();

    @Embedded
    @AttributeOverride(name = "accountantId", column = @Column(name = "accountant_id"))
    @AttributeOverride(name = "accountantName", column = @Column(name = "accountant_name", length = 100))
    @AttributeOverride(name = "accountantDateOfTakingOver", column = @Column(name = "accountant_date_of_taking_over"))
    @AttributeOverride(name = "accountantMobileNo", column = @Column(name = "accountant_mobile_no"))
    @AttributeOverride(name = "coId", column = @Column(name = "co_id"))
    @AttributeOverride(name = "coName", column = @Column(name = "co_name", length = 100))
    @AttributeOverride(name = "coDateOfTakingOver", column = @Column(name = "co_date_of_taking_over"))
    @AttributeOverride(name = "coMobileNo", column = @Column(name = "co_mobile_no"))
    @AttributeOverride(name = "bmId", column = @Column(name = "BM_ID"))
    @AttributeOverride(name = "bmName", column = @Column(name = "BM_NAME", length = 100))
    @AttributeOverride(name = "bmDateOfTakingOver", column = @Column(name = "BM_DATE_OF_TAKING_OVER"))
    @AttributeOverride(name = "bmMobileNo", column = @Column(name = "BM_MOBILE_NO"))
    private CcEmployeeDetails ccEmployeeDetails = new CcEmployeeDetails();

    @OneToMany
    @JoinTable(
        name = "cc_linked_branches",
        joinColumns = @JoinColumn(
            name = "cc_branch_code",
            referencedColumnName = "branch_code",
            foreignKey = @ForeignKey(name = "fk_cc_linked_branches_cc_branch_code")
        ),
        inverseJoinColumns = {
            @JoinColumn(
                name = "linked_branch_code",
                referencedColumnName = "branch_code",
                foreignKey = @ForeignKey(name = "fk_cc_linked_branches_linked_branch_code")
            ),
        }
    )
    private Set<Branch> linkedBranches = new HashSet<>();

    @OneToMany(mappedBy = "currencyChest")
    private Set<Verification> verifications;

    //    @OneToOne(mappedBy = "cc")
    //    private CcCloseRequests ccCloseRequests;

    @OneToMany(mappedBy = "cc")
    private Set<MonthlyCertificateStatus> monthlyCertificateStatuses;

    public CurrencyChest(Long branchCode, CcType ccType, CcClass ccClass, boolean coinVendingMachineAvailable) {
        this.setBranchCode(branchCode);
        this.ccType = ccType;
        this.chestClass = ccClass;
        this.coinVendingMachineAvailable = coinVendingMachineAvailable;
    }
}
