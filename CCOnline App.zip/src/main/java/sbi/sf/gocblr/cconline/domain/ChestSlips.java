package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import lombok.Data;

/**
 *
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
@Entity
public class ChestSlips implements Serializable {

    private static final long serialVersionUID = 9105241626907835335L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long csid;

    @OneToOne
    @JoinColumn(name = "particular_id", foreignKey = @ForeignKey(name = "fk_chest_slips_particular"))
    private ChestSlipParticular particulars;

    @OneToOne
    @JoinColumn(name = "denomination_id", foreignKey = @ForeignKey(name = "fk_chest_slips_denomination"))
    private Denomination denominations;

    @Column(columnDefinition = "NUMBER(20,2)")
    double value;

    @ManyToOne
    @JoinColumn(name = "CheckSlipUploadDetails_uploadId", foreignKey = @ForeignKey(name = "fk_chest_slips_cs_upload_details"))
    private ChestSlipUploadDetails checkSlipUploadDetails;
}
