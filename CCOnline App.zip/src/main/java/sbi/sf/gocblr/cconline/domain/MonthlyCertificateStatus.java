package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.NaturalId;

/**
 * Month wise submission status of branches
 *
 */
@Entity
@Table(
    name = "MONTHLY_CERTIFICATE_STATUS",
    uniqueConstraints = @UniqueConstraint(name = "uk_monthly_certificate_status", columnNames = { "cc_branch_code", "month" })
)
@Getter
@Setter
@ToString
public class MonthlyCertificateStatus implements Serializable {

    private static final long serialVersionUID = 6137125581334138679L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(
        name = "cc_branch_code",
        referencedColumnName = "branch_code",
        foreignKey = @ForeignKey(name = "fk_monthly_certificate_cc_branch_code")
    )
    @NaturalId
    private CurrencyChest cc;

    @NaturalId
    @Column(name = "month")
    private LocalDate month;

    @Column(name = "is_submitted")
    private Boolean isSubmitted;

    @Column(name = "submitted_on")
    private LocalDate submittedOn;

    @Column(name = "submitted_by")
    private Long submittedBy;
}
