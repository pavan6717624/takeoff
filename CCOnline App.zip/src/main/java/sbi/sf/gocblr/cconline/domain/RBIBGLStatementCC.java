package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "rbi_bgl_statement_cc")
public class RBIBGLStatementCC {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @ManyToOne
    @JoinColumn(
        name = "cc_branch_code",
        referencedColumnName = "branch_code",
        foreignKey = @ForeignKey(name = "fk_rbi_bgl_statement_cc_currency_chest")
    )
    private CurrencyChest branchProfile;

    @Column(columnDefinition = "NUMBER(20,2)")
    double deposits;

    @Column(columnDefinition = "NUMBER(20,2)")
    double withdrawals;

    @Column(columnDefinition = "NUMBER(20,2)")
    double ct;

    @ManyToOne
    @JoinColumn(name = "fslo_id", foreignKey = @ForeignKey(name = "fk_rbi_bgl_statement_cc_fslo"))
    RBIBGLStatementFslo fslo;
}
