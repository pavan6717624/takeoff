package sbi.sf.gocblr.cconline.model;

public interface ViewChestSlip {
    String getCsdate();
    Long getBrcode();
    Long getCccode();
    String getParticular();
    String getType();
    Long getN1();
    Long getN2();
    Long getN5();
    Long getN10();
    Long getN20();
    Long getN50();
    Long getN100();
    Long getN200();
    Long getN500();
    Long getN1000();
    Long getN2000();
    Long getC1();
    Long getC2();
    Long getC5();
    Long getC10();
    Long getC20();
    Long getTotalpieces();
    Long getTotalvalue();
}
