package sbi.sf.gocblr.cconline.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.Nsm;

public interface NsmRepository extends JpaRepository<Nsm, Long> {}
