package sbi.sf.gocblr.cconline.model;

import java.util.Set;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;

@Data
public class UserInputModel {

    @NotNull
    private Long pfId;

    @NotNull
    @Size(min = 1, max = 2)
    private Set<String> roles;

    private Long fslo;
    private Long network;
}
