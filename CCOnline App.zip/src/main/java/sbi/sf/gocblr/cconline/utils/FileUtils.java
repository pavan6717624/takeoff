package sbi.sf.gocblr.cconline.utils;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.tika.detect.DefaultDetector;
import org.apache.tika.detect.Detector;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaMetadataKeys;
import org.apache.tika.mime.MediaType;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
public class FileUtils {

    private FileUtils() {
        // static utils class, not to be intialized
    }

    /**
     * Checks whether the given MultipartFile contains a valid PDF file
     * @param pdfFile PDF file as MultiPartFile
     * @throws IOException If any issue with input
     */
    public static boolean isValidPdfFile(MultipartFile pdfFile) {
        String contentType;
        try {
            contentType = getFileContentType(pdfFile);
            return contentType.equalsIgnoreCase("application/pdf");
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Check whether the given file is a valid CSV file by content detection using
     * Apache Tika
     *
     * @param csvFile
     * @return true if csvFile is valid CSV file else false
     * @throws IOException If any issue with input
     */
    public static boolean isValidCsv(MultipartFile csvFile) throws IOException {
        String contentType = getFileContentType(csvFile);

        log.debug("Detected content type: {}", contentType);

        List<String> validCsvType = new ArrayList<>(2);
        validCsvType.add("text/plain");
        validCsvType.add("text/csv");

        return validCsvType.contains(contentType.toLowerCase());
    }

    public static boolean isValidExcelOrCsv(MultipartFile excelFile) {
        String contentType;
        try {
            contentType = getFileContentType(excelFile);

            log.debug("Detected content type: {}", contentType);

            List<String> validCsvType = new ArrayList<>(2);
            validCsvType.add("text/plain");
            validCsvType.add("text/csv");
            validCsvType.add("application/vnd.ms-excel");
            validCsvType.add("application/msexcel");
            validCsvType.add("application/x-msexcel");
            validCsvType.add("application/x-ms-excel");
            validCsvType.add("application/x-excel");
            validCsvType.add("application/x-dos_ms_excel");
            validCsvType.add("application/xls");
            validCsvType.add("application/x-xls");
            validCsvType.add("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

            return validCsvType.contains(contentType.toLowerCase());
        } catch (IOException e) {
            log.warn(e.getMessage(), e);
            return false;
        }
    }

    /**
     * Read the file and get the actual file content type
     *
     * @param multipartFile MultiPartFile received after upload
     * @return String representing file type
     * @throws IOException If any exception occurred reading the MultiPartFile
     */
    private static String getFileContentType(MultipartFile multipartFile) throws IOException {
        try (BufferedInputStream is = new BufferedInputStream(multipartFile.getInputStream())) {
            Metadata metadata = new Metadata();
            metadata.set(TikaMetadataKeys.RESOURCE_NAME_KEY, multipartFile.getName());

            Detector detector = new DefaultDetector();
            MediaType mediaType = detector.detect(is, metadata);

            log.debug("MediaType detected: {}", mediaType.toString());

            return mediaType.toString();
        }
    }
}
