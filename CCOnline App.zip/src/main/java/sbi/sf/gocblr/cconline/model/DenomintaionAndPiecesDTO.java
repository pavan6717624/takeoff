package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import sbi.sf.gocblr.cconline.domain.enums.DenominationType;

public interface DenomintaionAndPiecesDTO {
    Long getDenominationId();
    Integer getDenominationValue();

    @JsonIgnore
    DenominationType getDenominationType();

    Long getNoOfPieces();
}
