package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "generated_ekuber_zipfile")
public class GeneratedEKuberZipFile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String filePath;

    @ManyToOne
    @JoinColumn(name = "bglStatementUploadDetails_id", foreignKey = @ForeignKey(name = "fk_generated_ekuber_zipfile_bgl_stmt_upload_id"))
    RBIBGLStatementUploadDetails bglStatementUploadDetails;
}
