package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.BalanceVerification;

@Repository
public interface BalanceVerificationRepository extends JpaRepository<BalanceVerification, Long> {
    @EntityGraph(attributePaths = { "verification" })
    Optional<BalanceVerification> findByVerificationId(long verificationId);

    Optional<BalanceVerification> getById(long id);
}
