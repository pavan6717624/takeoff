package sbi.sf.gocblr.cconline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sbi.sf.gocblr.cconline.domain.AutoSmsResponse;

public interface AutoSmsResponseRepository extends JpaRepository<AutoSmsResponse, Long> {

}
