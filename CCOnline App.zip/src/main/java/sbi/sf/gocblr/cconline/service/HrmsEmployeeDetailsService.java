package sbi.sf.gocblr.cconline.service;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.exception.ExternalServiceException;
import sbi.sf.gocblr.cconline.model.EisDecryptedResponse;
import sbi.sf.gocblr.cconline.model.EisEncryptedRequest;
import sbi.sf.gocblr.cconline.model.EisEncryptedResponse;
import sbi.sf.gocblr.cconline.model.EisHrmsRequest;
import sbi.sf.gocblr.cconline.model.EmployeeDetailsModel;
import sbi.sf.gocblr.cconline.utils.TextUtils;

@Slf4j
@Service
@Primary
public class HrmsEmployeeDetailsService implements EmployeeDetailsService {

    private static final String RSA_CIPHER_MODE_OPERATION = "RSA/ECB/OAEPPadding";
    private static final String AES_CHIPHER_MODE_OPERATION = "AES/CBC/PKCS5Padding";
    private static final DateTimeFormatter REQ_REF_NO_DATE_FORMAT = DateTimeFormatter.ofPattern("yyDDDhhmmssS");
    private static final String DATA_FOR_RANDOM_STRING = "abcdefghijklmnopqrstuvwxyz" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final Signature rsaSignature;
    private final Certificate eisCertificate;
    private final PrivateKey channelPrivateKey;
    private final SSLContext sslContext;
    private final ApplicationProperties appProperties;

    private static final ObjectMapper mapper = JsonMapper
        .builder()
        .addModule(new Jdk8Module())
        .addModule(new JavaTimeModule())
        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
        .build();

    public HrmsEmployeeDetailsService(ApplicationProperties appProperties, ResourceLoader resourceLoader)
        throws IOException, GeneralSecurityException {
        this.appProperties = appProperties;
        InputStream keyIn=null;
        char[] keyChar = null;
        StringBuilder keyString=new StringBuilder(2000);

        // load eis certificate
        try (InputStream in = resourceLoader.getResource(appProperties.getEisPublicKey()).getInputStream()) {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            eisCertificate = cf.generateCertificate(in);
        }

        try (
            InputStream in = resourceLoader.getResource(appProperties.getAppPrivateKey()).getInputStream();
            BufferedReader buf = new BufferedReader(new InputStreamReader(in))
        ) {
            keyString = new StringBuilder(2000);
            String line;

            while ((line = buf.readLine()) != null) {
                keyString.append(line);
            }

            String privateKeyPEM = keyString
                .toString()
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PRIVATE KEY-----", "");
            byte[] encoded = Base64.getDecoder().decode(privateKeyPEM);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
            channelPrivateKey = kf.generatePrivate(keySpec);
        }

        rsaSignature = Signature.getInstance("SHA256withRSA");
        
        

        // load eis https certificate
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        try (
            InputStream in = resourceLoader.getResource(appProperties.getEisHttpsCertificate()).getInputStream();
            BufferedInputStream bufIs = new BufferedInputStream(in);
        ) {
            Certificate ca = cf.generateCertificate(bufIs);

            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
          
            keyStore.load(keyIn,keyChar);
            keyStore.setCertificateEntry("ca", ca);

            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(keyStore);

            sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, tmf.getTrustManagers(), new SecureRandom());
        }
    }

    private String aesEncrypt(String strToEncrypt, String secret)
        throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "AES");
        Cipher cipher = Cipher.getInstance(AES_CHIPHER_MODE_OPERATION);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(secret.substring(0, 16).getBytes()));
        return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
    }

    private String aesDecrypt(String strToDecrypt, String secret)
        throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "AES");
        Cipher cipher = Cipher.getInstance(AES_CHIPHER_MODE_OPERATION);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(secret.substring(0, 16).getBytes()));
        return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
    }

    private String signSha256Rsa(String plaintext) throws InvalidKeyException, SignatureException {
        rsaSignature.initSign(channelPrivateKey);
        rsaSignature.update(plaintext.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(rsaSignature.sign());
    }

    private byte[] rsaEncrypt(String data) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance(RSA_CIPHER_MODE_OPERATION);
        cipher.init(Cipher.ENCRYPT_MODE, eisCertificate.getPublicKey());
        return cipher.doFinal(data.getBytes());
    }

    private String randomKey(int length) {
        if (length < 1) {
            throw new IllegalArgumentException();
        }

        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int rndCharAt = SECURE_RANDOM.nextInt(DATA_FOR_RANDOM_STRING.length());
            char rndChar = DATA_FOR_RANDOM_STRING.charAt(rndCharAt);

            sb.append(rndChar);
        }
        return sb.toString();
    }

    @Override
    public EmployeeDetailsModel getEmployeeDetails(int pfId) {
        try {
            EisHrmsRequest eisRequest = new EisHrmsRequest(pfId + "", appProperties.getEisSourceId());
            String payLoad = mapper.writeValueAsString(eisRequest);
            log.debug("plain payload: {}", payLoad);

            String decryptedEisResponse = callEis(payLoad);

            EisDecryptedResponse decryptedResponse = mapper.readValue(decryptedEisResponse, EisDecryptedResponse.class);

            if (decryptedResponse.getResponseStatus() != 0) {
                throw new ExternalServiceException(
                    TextUtils.getNullPlaceHolder(decryptedResponse.getErrorDescription(), "Error fetching employee details.")
                );
            }
            return EmployeeDetailsModel.build(decryptedResponse);
        } catch (ConnectException ce) {
            throw new ExternalServiceException("EIS api timeout. Please try after sometime");
        } catch (IOException | GeneralSecurityException ex) {
            throw new ExternalServiceException("An error occured while getting employee details", ex);
        }
    }

    private String callEis(String plainPayloadString) throws GeneralSecurityException, IOException {
        final String aesKey = randomKey(32);
        log.debug("key: {} | iv: {}", aesKey, aesKey.substring(0, 16));

        String encryptedString = aesEncrypt(plainPayloadString, aesKey);
        log.debug("Encrypted Plain Text using AES/CBC/PKCS5Padding :: " + encryptedString);

        String base64Signature = signSha256Rsa(plainPayloadString);
        log.debug("RSA Signature on Plain Text :: " + base64Signature);

        String refNum = generateRequestRefNo();
        log.debug("ref. no. {}", refNum);

        EisEncryptedRequest request = new EisEncryptedRequest(refNum, encryptedString, base64Signature);
        String bodyJson = mapper.writeValueAsString(request);

        log.debug("request body: {}", bodyJson);

        byte[] rsaSecretKey = rsaEncrypt(aesKey);
        String rsaSecretKeyEncoded = Base64.getEncoder().encodeToString(rsaSecretKey);

        log.debug("AccessToken: {}", rsaSecretKeyEncoded);

        String output = doRequest(appProperties.getEisHrmsApiUrl(), bodyJson, rsaSecretKeyEncoded);

        log.debug("response recevied: {}", output);

        EisEncryptedResponse eisEncryptedResponse = mapper.readValue(output, EisEncryptedResponse.class);
        log.debug("eis response: {}", mapper.writeValueAsString(eisEncryptedResponse));

        String decryptedString = aesDecrypt(eisEncryptedResponse.getResponse(), aesKey);

        boolean isResponseDigiSignatureValid = isResponseSignatureValid(eisEncryptedResponse, decryptedString);

        log.debug("is response digital signature valid: {}", isResponseDigiSignatureValid);

        log.debug("decrypted response: {}", decryptedString);
        return decryptedString;
    }

    private boolean isResponseSignatureValid(EisEncryptedResponse eisEncryptedResponse, String decryptedString)
        throws InvalidKeyException, SignatureException {
        rsaSignature.initVerify(eisCertificate.getPublicKey());
        rsaSignature.update(decryptedString.getBytes());
        return rsaSignature.verify(Base64.getDecoder().decode(eisEncryptedResponse.getDigiSign()));
    }

    private String generateRequestRefNo() {
        return (
            "SBI" +
            appProperties.getEisSourceId() +
            REQ_REF_NO_DATE_FORMAT.format(LocalDateTime.now()) +
            "" +
            (10000000 + SECURE_RANDOM.nextInt(90000000))
        );
    }

    private String doRequest(String apiUrl, String requestBody, String accessToken) throws IOException {
        URL url = new URL(apiUrl);

        HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
        con.setSSLSocketFactory(sslContext.getSocketFactory());
        con.setRequestProperty("AccessToken", accessToken);
        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setRequestMethod("POST");
        con.setRequestProperty("Accept", "application/json");
        con.setDoOutput(true);

        try (OutputStream os = con.getOutputStream()) {
            byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        if (con.getResponseCode() != 200) {
            log.warn("EIS response code: {}", con.getResponseCode());
            throw new ExternalServiceException("Cannot get employee details from EIS");
        }

        try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            StringBuilder output = new StringBuilder(2000);
            String line = "";
            while ((line = br.readLine()) != null) output.append(line + "\n");
            return output.toString();
        }
    }
}
