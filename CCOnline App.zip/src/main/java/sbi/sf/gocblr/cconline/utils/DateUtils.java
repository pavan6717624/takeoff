package sbi.sf.gocblr.cconline.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.core.env.Profiles;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.service.AutoAlertService;
@Slf4j
public final class DateUtils {

    public static final DateTimeFormatter STANDARD_DATE_TIME_FROMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    public static final DateTimeFormatter FOR_BLOCK_ID = DateTimeFormatter.ofPattern("yyyyMMdd");
    public static final DateTimeFormatter FOR_BLOCK_DESC = DateTimeFormatter.ofPattern("MMM yyyy");
    public static final DateTimeFormatter BLOCK_DATE_INPUT = DateTimeFormatter.ofPattern("yyyyMMdd");

    private static final Pattern ISO_DATE_PATTERN = Pattern.compile("(\\d{4}-\\d{2}-\\d{2}).*");
    public static final DateTimeFormatter ISO_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private DateUtils() {}

    public static boolean isValidDate(@NonNull String dateAsText, @NonNull String datePatter) {
        if (TextUtils.hasText(dateAsText)) {
            try {
                DateTimeFormatter df = DateTimeFormatter.ofPattern(datePatter);
                LocalDate.parse(dateAsText, df);
                return true;
            } catch (IllegalArgumentException | DateTimeParseException e) {
            	 log.info("Exception as ", e);
                // ignore exception
            }
        }
        return false;
    }

    public static boolean isValidDate(@NonNull String dateAsText, @NonNull DateTimeFormatter df) {
        if (TextUtils.hasText(dateAsText)) {
            try {
                LocalDate.parse(dateAsText, df);
                return true;
            } catch (DateTimeParseException e) {
            	 log.info("Exception as ", e);
                // ignoring exception
            }
        }
        return false;
    }

    public static LocalDate parseDate(String dateAsText, String pattern) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(pattern);
        return parseDate(dateAsText, df);
    }

    public static LocalDate parseDate(String dateText, DateTimeFormatter dateFormatter) {
        return LocalDate.parse(dateText, dateFormatter);
    }

    public static LocalDate getLocalDate(Date date) {
        return LocalDate.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }

    public static LocalTime getLocalTime(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalTime();
    }

    public static LocalDate getLastDay(int year, int month) {
        YearMonth ym = YearMonth.of(year, month);
        return ym.atEndOfMonth();
    }

    @SuppressWarnings("deprecation")
    public static Date getDate(LocalDate dateToConvert) {
        return new Date(dateToConvert.getYear(), dateToConvert.getMonthValue(), dateToConvert.getDayOfMonth());
    }

    public static String format(LocalDate date) {
        if (date == null) {
            return "";
        }
        return date.format(STANDARD_DATE_TIME_FROMAT);
    }

    public static String format(LocalDateTime date) {
        if (date == null) {
            return "";
        }
        return date.format(STANDARD_DATE_TIME_FROMAT);
    }

    public static LocalDate parseIsoDate(String strDate) {
        String dateString = null;
        Matcher m = ISO_DATE_PATTERN.matcher(strDate);

        if (m.find()) {
            dateString = m.group(1);
        }
        if (dateString == null) {
            throw new DateTimeParseException("Invalid date", strDate, -1);
        }
        return LocalDate.parse(dateString);
    }

    public static String format(LocalDate date, DateTimeFormatter format) {
        if (date == null) {
            return "";
        }
        return date.format(format);
    }
}
