package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "penalty_reason")
public class PenaltyReason implements Serializable {

    private static final long serialVersionUID = -4320851284122541055L;

    @Id
    Long id;

    @ManyToOne
    @JoinColumn(name = "debit_type", foreignKey = @ForeignKey(name = "fk_penalty_debit_type_reasons_mapping"))
    PenaltyDebitType type;

    String reason;
}
