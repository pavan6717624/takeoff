package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.VsState;

@Converter(autoApply = true)
public class VsStateConverter implements AttributeConverter<VsState, String> {

    @Override
    public String convertToDatabaseColumn(VsState vsState) {
        if (vsState == null) {
            return null;
        }
        return vsState.code();
    }

    @Override
    public VsState convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return VsState.fromCode(code);
    }
}
