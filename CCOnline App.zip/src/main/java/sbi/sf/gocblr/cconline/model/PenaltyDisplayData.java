package sbi.sf.gocblr.cconline.model;

import java.util.List;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.PenaltyData;

@Data
public class PenaltyDisplayData {

    Double debitTotal;
    Double creditTotal;
    Double openingBalance;
    Double closingBalance;
    List<PenaltyData> penaltyData;

    String status;
    String message;
}
