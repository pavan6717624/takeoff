package sbi.sf.gocblr.cconline.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ChestClosingFields;

@Repository
public interface ChestClosingFieldsRepository extends JpaRepository<ChestClosingFields, Long> {
    @Query("SELECT c FROM ChestClosingFields c  WHERE c.fieldName=(:fieldName)")
    ChestClosingFields findByFieldName(@Param("fieldName") String fieldName);
}
