package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.PenaltyData;
import sbi.sf.gocblr.cconline.domain.PenaltyUpdation;

@Repository
public interface PenaltyUpdationRepository extends JpaRepository<PenaltyUpdation, Long> {
    List<PenaltyUpdation> findByNarrationAndStatus(@Param("narration") PenaltyData narration, @Param("status") String status);
    
    @Query("select count(p) from PenaltyUpdation p where p.narration=(:narration) and p.status like 'Submitted' and p.disposal is null")
    Long notSubmittedDisposal(@Param("narration") PenaltyData narration);


    @Query("select p from PenaltyUpdation p where p.narration=(:narration) and (p.status like 'Saved' or p.status like 'Submitted') order by p.splitId desc")
    List<PenaltyUpdation> findByNarrationLatest(@Param("narration") PenaltyData narration);

    @Query(
        "select p from PenaltyUpdation p where p.status like (:status) and (abs(p.narration.fslo.fslo.branchCode)=(:branchCode) or (:branchCode)=0) and p.narration.reportDate between  (:fromdate) and (:todate)"
    )
    List<PenaltyUpdation> findByStatus(
        @Param("status") String status,
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("branchCode") Long branchCode
    );

    

    @Query(
        "select p from PenaltyUpdation p where p.status like (:status) and abs(p.narration.fslo.fslo.branchCode) in (:fslos) and p.narration.reportDate between  (:fromdate) and (:todate)"
    )
    List<PenaltyUpdation> findByStatus(
        @Param("status") String status,
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("fslos") List<Long> fslos
    );
    /* @Query(
        "select p from PenaltyUpdation p where p.status like (:status)  and p.narration.reportDate between  (:fromdate) and (:todate) and p.disposal is not null order by p.narration.fslo.fslo.branchCode asc"
    )
    List<PenaltyUpdation> findByStatusOrderByNarrationFsloFsloBranchCodeAsc(
        @Param("status") String status,
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate
    );*/

    @Query(
        "select p from PenaltyUpdation p where p.status like (:status)  and p.narration.reportDate between  (:fromdate) and (:todate) and (abs(p.narration.fslo.fslo.branchCode)=(:branchCode) or (:branchCode)=0) order by p.narration.fslo.fslo.branchCode,p.narration.reportDate asc"
    )
    List<PenaltyUpdation> findByStatusOrderByNarrationFsloFsloBranchCodeAsc(
        @Param("status") String status,
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("branchCode") Long branchCode
    );
    
    @Query(
            "select p from PenaltyUpdation p where p.status like (:status)  and p.narration.reportDate between  (:fromdate) and (:todate) and abs(p.narration.fslo.fslo.branchCode) in (:fslos) order by p.narration.fslo.fslo.branchCode,p.narration.reportDate asc"
        )
        List<PenaltyUpdation> findByStatusOrderByNarrationFsloFsloBranchCodeAsc(
            @Param("status") String status,
            @Param("fromdate") LocalDate fromdate,
            @Param("todate") LocalDate todate,
            @Param("fslos") List<Long> fslos
        );
}
