package sbi.sf.gocblr.cconline.model;

public interface MonthWiseVerificationReport {
    String getCircleName();
    Long getTotal();
    Long getBiMonthly();
    Long getQuarterly();
    Long getHalfYearly();
    Long getSecurityOfficer();
    Long getDgmcfo();
    Long getControllerVisit();
    Long getModuleHeadVisit();
    Long getGmNetworkVisit();
    Long getCgmVisit();
    Long getDgmCFO();
    String getMonth();
}
