package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class MonthWiseVerificationReportModal {

    String circleName;

    Long total;
    Long biMonthly;
    Long quarterly;
    Long halfYearly;
    Long securityOfficer;
    Long dgmcfo;
    Long controllerVisit;
    Long moduleHeadVisit;
    Long gmNetworkVisit;
    Long cgmVisit;
    String month;
    Long dgmCFO;

    public Long getDgmCFO() {
        // TODO Auto-generated method stub
        return dgmCFO;
    }

    public Long getDgmcfo() {
        // TODO Auto-generated method stub
        return dgmcfo;
    }
}
