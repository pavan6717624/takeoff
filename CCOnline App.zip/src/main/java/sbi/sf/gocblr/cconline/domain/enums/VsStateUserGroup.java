package sbi.sf.gocblr.cconline.domain.enums;

public enum VsStateUserGroup {
    BRANCH_MAKER,
    BRANCH_HEAD,
    RBO_CM,
    RBO_RM,
    AO_OFFICER,
    AO_AGM,
    CONTROLLER_CHECKER,
    VERIFICATION_OFFICER,
    DGM_CFO,
}
