package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.view.VerificationSectionCount;
import sbi.sf.gocblr.cconline.domain.view.VerificationSectionCountId;

public interface VerificationSectionCountRepository extends JpaRepository<VerificationSectionCount, VerificationSectionCountId> {
    List<VerificationSectionCount> findByVerificationId(long verificationId);
    Optional<VerificationSectionCount> findByVerificationIdAndSectionId(long vid, long sid);
}
