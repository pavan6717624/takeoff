package sbi.sf.gocblr.cconline.exception;

public class ExternalServiceException extends RuntimeException {

    private static final long serialVersionUID = -9007742251954757396L;

    public ExternalServiceException(String msg) {
        super(msg);
    }

    public ExternalServiceException(String msg, Throwable t) {
        super(msg, t);
    }
}
