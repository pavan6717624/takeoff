package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.User;

/**
 *
 * @author Kiran Marturu
 *
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {
    /**
     * Get user with required attributes, add any other required attribute paths
     *
     * @param id user id
     * @return Optional of User
     */
    @EntityGraph(
        attributePaths = {
            "roles", "branch.region", "branch.region.module", "branch.region.module.network", "branch.region.module.network.circle",
        }
    )
    Optional<User> getById(Long id);

    @EntityGraph(
        attributePaths = {
            "roles", "userRequest", "userRequest.roles", "branch", "branch.region", "branch.module", "branch.network", "branch.circle",
        }
    )
    Page<User> findAll(Specification<User> spec, Pageable pageable);
}
