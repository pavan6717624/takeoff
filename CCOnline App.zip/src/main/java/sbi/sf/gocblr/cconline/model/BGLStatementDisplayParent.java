package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import java.util.List;

public class BGLStatementDisplayParent {

    public Long getFsloCode() {
        return Math.abs(fsloCode);
    }

    public void setFsloCode(Long fsloCode) {
        this.fsloCode = fsloCode;
    }

    public String getFsloName() {
        return fsloName;
    }

    public void setFsloName(String fsloName) {
        this.fsloName = fsloName;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public double getWithdrawal() {
        return withdrawal;
    }

    public void setWithdrawal(double withdrawal) {
        this.withdrawal = withdrawal;
    }

    public double getCt() {
        return ct;
    }

    public void setCt(double ct) {
        this.ct = ct;
    }

    public List<BGLStatementDisplayChild> getStatementChild() {
        return statementChild;
    }

    public void setStatementChild(List<BGLStatementDisplayChild> statementChild) {
        this.statementChild = statementChild;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    private Long fsloCode;
    private String fsloName;
    private double deposit;
    private double withdrawal;
    private double ct;
    private List<BGLStatementDisplayChild> statementChild;
    private LocalDate date;
}
