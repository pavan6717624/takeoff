package sbi.sf.gocblr.cconline.service.dto;

import java.time.LocalDate;
import sbi.sf.gocblr.cconline.domain.ValueStatement;
import sbi.sf.gocblr.cconline.domain.enums.ComplianceStatus;
import sbi.sf.gocblr.cconline.domain.enums.OptionCompliance;

public interface ValueStatementComplianceDTO {
    ValueStatement getValueStatement();
    String getOptionInput();
    OptionCompliance getCompliance();
    LocalDate getDateInput();
    Double getNumberInput();
    String getComments();
    ComplianceStatus getBranchCompliance();
    String getBranchComments();
}
