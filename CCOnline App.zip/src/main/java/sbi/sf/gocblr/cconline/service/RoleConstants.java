package sbi.sf.gocblr.cconline.service;

/**
 * User role constants for referring in app
 */
public final class RoleConstants {

    private RoleConstants() {
        // static class not to be initalized
    }

    public static final String BRANCH_USER = "BRANCH_USER";
    public static final String BRANCH_HEAD = "BRANCH_HEAD";
    public static final String RBO_CM = "RBO_CM";
    public static final String RM = "RBO_RM";
    public static final String AO_USER = "AO_OFFICER";
    public static final String AGM_GB = "AO_AGM";
    public static final String CIRCLE_ADMIN = "CIRCLE_ADMIN";
    public static final String FSLO_USER = "FSLO_USER";
    public static final String SECURITY_OFFICER = "SECURITY_OFFICER";
    public static final String DGM_CFO = "DGM_CFO";
    public static final String ABD_USER = "ABD_USER";
    public static final String DGM_ABD = "ABD_DGM";
    public static final String VERIFICATION_OFFICER = "VERIFICATION_OFFICER";
    public static final String RBO_DESK_OFFICER = "RBO_DESK_OFFICER";
    public static final String DGM_BO = "DGM_BO";
    public static final String GM_NW = "GM_NETWORK";
    public static final String CGM_CIRCLE = "CGM_CIRCLE";
}
