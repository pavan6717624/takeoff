package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "rbi_bgl_statement_fslo")
public class RBIBGLStatementFslo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @ManyToOne
    @JoinColumn(name = "fsloProfile_branchCode", foreignKey = @ForeignKey(name = "fk_rbi_bgl_statement_fslo_fslo"))
    Fslo fsloProfile;

    @Column(columnDefinition = "NUMBER(20,2)")
    double deposit;

    @Column(columnDefinition = "NUMBER(20,2)")
    double withdrawal;

    @Column(columnDefinition = "NUMBER(20,2)")
    double ct;

    /* @OneToOne
    @JoinColumn(name = "zipFile_id")
    GeneratedEKuberZipFile zipFile;*/

    String filePath;

    @ManyToOne
    @JoinColumn(name = "bglStatementUploadDetails_id", foreignKey = @ForeignKey(name = "fk_rbi_bgl_statement_fslo_bgl_stmt_upload_id"))
    RBIBGLStatementUploadDetails bglStatementUploadDetails;
}
