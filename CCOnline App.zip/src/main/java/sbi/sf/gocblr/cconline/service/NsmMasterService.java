package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.CcNsm;
import sbi.sf.gocblr.cconline.domain.CcNsmDenominationDetails;
import sbi.sf.gocblr.cconline.domain.CcNsmMonthStatus;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Denomination;
import sbi.sf.gocblr.cconline.domain.Nsm;
import sbi.sf.gocblr.cconline.exception.ResourceAlreadyExistsException;
import sbi.sf.gocblr.cconline.model.CcNsmModal;
import sbi.sf.gocblr.cconline.model.NsmSaveData;
import sbi.sf.gocblr.cconline.repository.CcNsmDenominationDetailsRepository;
import sbi.sf.gocblr.cconline.repository.CcNsmMonthStatusRepository;
import sbi.sf.gocblr.cconline.repository.CcNsmRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.DenominationRepository;
import sbi.sf.gocblr.cconline.repository.NsmMasterRepository;
import sbi.sf.gocblr.cconline.repository.RoleRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.dto.NsmReport;
import sbi.sf.gocblr.cconline.service.dto.NsmSubmissionSummary;
import sbi.sf.gocblr.cconline.web.rest.vm.NsmModel;

@Slf4j
@Service
@RequiredArgsConstructor
public class NsmMasterService {

    private final NsmMasterRepository nsmRepo;
    private final CcNsmRepository ccNsmRepository;
    private final DenominationRepository denominationRepository;
    private final CurrencyChestRepository currencyChestRepository;
    private final CcNsmDenominationDetailsRepository ccNsmDenominationDetailsRepository;
    private final CurrencyChestService currencyChestService;
    private final CcNsmMonthStatusRepository ccNsmMonthStatusRepository;
    private Object stmtRepo;
    private final RoleRepository roleRepository;
    private static final String USER_NOT_HAVING_APPROPRIATE_ROLE = "User not having appropriate role for accessing this resource";

    public List<CcNsmModal> getNSMData(LocalDate date) {
        AppUser user = SecurityUtils.getLoggedInUser();
        Long ccCode = user.getBranchCode();
        List<CcNsm> nsmList = ccNsmRepository.findByCurrencyChestBranchCodeAndActive(ccCode, true);
        List<CcNsmModal> nsms = new ArrayList<>();

        for (int i = 0; i < nsmList.size(); i++) {
            CcNsmModal ccNsm = new CcNsmModal();
            ccNsm.setBranchCode(nsmList.get(i).getCurrencyChest().getBranchCode());
            ccNsm.setId(nsmList.get(i).getId());
            ccNsm.setNsm(nsmList.get(i).getNsm());
            ccNsm.setYearOfPurchase(nsmList.get(i).getYearOfPurchase());
            List<CcNsmDenominationDetails> savedOrSubmited = ccNsmDenominationDetailsRepository.getSavedOrSubmittedData(
                date,
                nsmList.get(i)
            );
            String status = "Not Submitted";
            if (savedOrSubmited.size() > 0) {
                if (savedOrSubmited.get(i).getStatus().equals("Save")) status = "Saved"; else if (
                    savedOrSubmited.get(i).getStatus().equals("Submit")
                ) status = "Submitted";
            }

            ccNsm.setStatus(status);
            nsms.add(ccNsm);
        }

        return nsms;
    }

    @Transactional
    public List<Nsm> getNsmMasterList() {
        //List<Nsm> cn = nsmRepo.findAll();
        //return cn;
        return nsmRepo.findAll();
    }

    @Transactional
    public void submitAddNsm(NsmModel submitData) {
        log.trace("SubmitData1: {}", submitData);

        Nsm nsm = new Nsm();
        Optional<Nsm> nd = nsmRepo.findByMakeIgnoreCaseAndModelIgnoreCaseAndNsmType(
            submitData.getNsmMake(),
            submitData.getNsmModel(),
            submitData.getNsmType()
        );
        //NsmModel toSubmit;

        // 1. if already present
        if (nd.isPresent()) {
            //log.trace("NSM already added");
            throw new ResourceAlreadyExistsException("NSM is already existing");
        }
        // 2. saving for first time
        else {
            nsm.setMake(submitData.getNsmMake());
            nsm.setModel(submitData.getNsmModel());
            nsm.setNsmType(submitData.getNsmType());

            nsmRepo.save(nsm);
        }
        log.trace("NSM Type: {}", submitData);
    }

    public List<Denomination> getDenominationData() {
        return denominationRepository.allDenominationsByType("N");
    }

    @Transactional
    public String saveNSMData(NsmSaveData saveData, String status) {
        CurrencyChest cc = currencyChestService.getByBranchCode(SecurityUtils.getLoggedInUser().getBranchCode());

        String date = "01/" + saveData.getDate();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        CcNsmModal nsmModal = saveData.getNsmData();
        List<CcNsmDenominationDetails> ccNsmDenominationDetailsList = new ArrayList<>();
        List<CcNsmDenominationDetails> savedNsmData = ccNsmDenominationDetailsRepository.findByStatusAndMonthAndCcNsmOrderByDenominationValueAsc(
            "Save",
            LocalDate.parse(date, dateFormatter),
            ccNsmRepository.findById(nsmModal.getId()).get()
        );

        for (int i = 0; i < savedNsmData.size(); i++) {
            savedNsmData.get(i).setStatus("Deleted");
        }

        ccNsmDenominationDetailsRepository.saveAll(savedNsmData);

        Denomination[] denominations = saveData.getDenomination();
        Integer[] values = saveData.getCount();

        for (int i = 0; i < denominations.length; i++) {
            CcNsmDenominationDetails ccNsmDenominationDetails = new CcNsmDenominationDetails();
            ccNsmDenominationDetails.setCcNsm(ccNsmRepository.findById(nsmModal.getId()).get());
            ccNsmDenominationDetails.setCount(values[i]);
            ccNsmDenominationDetails.setDenomination(denominations[i]);
            ccNsmDenominationDetails.setMonth(LocalDate.parse(date, dateFormatter));

            ccNsmDenominationDetails.setStatus(status);

            ccNsmDenominationDetailsList.add(ccNsmDenominationDetails);
        }
        ccNsmDenominationDetailsRepository.saveAll(ccNsmDenominationDetailsList);

        if (status.equals("Save")) {
            return "{\"message\":\"Data Saved\"}";
        } else if (status.equals("Submit")) {
            //update Status table
            long nsmsCount;
            // get NSMs pending for processing data
            nsmsCount =
                ccNsmDenominationDetailsRepository.getPendingNsms(
                    LocalDate.parse(date, dateFormatter),
                    SecurityUtils.getLoggedInUser().getBranchCode()
                );
            //log.trace("Nsms count: {} ", nsmsCount);

            //update status table -> if pending NSMs count > 0, then branch is Pending else Submitted
            if (nsmsCount == 0) {
                CcNsmMonthStatus ccNsmMonthStatus = new CcNsmMonthStatus();
                ccNsmMonthStatus.setCc(cc);
                ccNsmMonthStatus.setMonth(LocalDate.parse(date, dateFormatter));
                ccNsmMonthStatus.setSaved(true);
                ccNsmMonthStatusRepository.save(ccNsmMonthStatus);
            }

            return "{\"message\":\"Data Submitted\"}";
        } else return "{}";
    }

    public List<CcNsmDenominationDetails> getNSMSavedData(NsmSaveData saveData) {
        String date = "01/" + saveData.getDate();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        CcNsmModal nsmModal = saveData.getNsmData();
        return ccNsmDenominationDetailsRepository.getSavedOrSubmittedData(
            LocalDate.parse(date, dateFormatter),
            ccNsmRepository.findById(nsmModal.getId()).get()
        );
    }

    public NsmSubmissionSummary getReportSummary(@NotNull LocalDate month) {
        // TODO Auto-generated method stub

        Long circleCode = SecurityUtils.getLoggedInUser().getCircleCode();
        Long networkCode = SecurityUtils.getLoggedInUser().getNetworkCode();
        Long moduleCode = SecurityUtils.getLoggedInUser().getModuleCode();
        Long regionCode = SecurityUtils.getLoggedInUser().getRegionCode();
        Long branchCode = SecurityUtils.getLoggedInUser().getBranchCode();

        //      AppUser user = SecurityUtils.getLoggedInUser();
        //      Set<Role> roles = user.getRoles();

        //        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        //        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        //        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        //        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        //        Role RBO_DESK_OFFICER = roleRepository.findByName(RoleConstants.RBO_DESK_OFFICER).get();
        //        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        //        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        //        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        //        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        //        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        //        if (roles.contains(FSLO_USER)) {
        //            return ccNsmRepository.getReportSummary(month, branchCode);
        //        } else if (roles.contains(CIRCLE_ADMIN)) {
        //            return ccNsmRepository.getReportSummaryCircleAdmin(month, circleCode);
        //        } else if (roles.contains(AO_USER) || roles.contains(AGM_GB)) {
        //            return ccNsmRepository.getReportSummaryAoUser(month, circleCode, networkCode, moduleCode);
        //        } else if (roles.contains(RM) || (roles.contains(RBO_CM))) {
        //            return ccNsmRepository.getReportSummaryRBO(month, circleCode, networkCode, moduleCode, regionCode);
        //        } else {
        //            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        //        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            return ccNsmRepository.getReportSummary(month, branchCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return ccNsmRepository.getReportSummaryCircleAdmin(month, circleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER, RoleConstants.AGM_GB)) {
            return ccNsmRepository.getReportSummaryAoUser(month, circleCode, networkCode, moduleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM, RoleConstants.RM, RoleConstants.RBO_DESK_OFFICER)) {
            return ccNsmRepository.getReportSummaryRBO(month, circleCode, networkCode, moduleCode, regionCode);
        } else {
            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        }
    }

    public List<NsmReport> getNsmStatusDetails(@NotNull LocalDate month) {
        //        AppUser user = SecurityUtils.getLoggedInUser();
        //        Set<Role> roles = user.getRoles();
        //
        //        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        //        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        //        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        //        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        //        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        //        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        //        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        //        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        //        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();
        /*
        RBO CM				RBO_CM
        Regional Manager	RBO_RM
        AO Officer			AO_OFFICER
        AO AGM				AO_AGM
        Circle Admin		CIRCLE_ADMIN
        FSLO User			FSLO_USER
        */

        Long circleCode = SecurityUtils.getLoggedInUser().getCircleCode();
        Long networkCode = SecurityUtils.getLoggedInUser().getNetworkCode();
        Long moduleCode = SecurityUtils.getLoggedInUser().getModuleCode();
        Long regionCode = SecurityUtils.getLoggedInUser().getRegionCode();
        Long branchCode = SecurityUtils.getLoggedInUser().getBranchCode();

        //        if (roles.contains(FSLO_USER)) {
        //            return ccNsmRepository.getNsmStatusDetails(month, branchCode);
        //        } else if (roles.contains(CIRCLE_ADMIN)) {
        //            return ccNsmRepository.getNsmStatusDetailsCircleAdmin(month, circleCode);
        //        } else if (roles.contains(AO_USER) || roles.contains(AGM_GB)) {
        //            return ccNsmRepository.getNsmStatusDetailsAoUser(month, circleCode, networkCode, moduleCode);
        //        } else if (roles.contains(RM) || (roles.contains(RBO_CM))) {
        //            return ccNsmRepository.getNsmStatusDetailsRBO(month, circleCode, networkCode, moduleCode, regionCode);
        //        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            return ccNsmRepository.getNsmStatusDetails(month, branchCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return ccNsmRepository.getNsmStatusDetailsCircleAdmin(month, circleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER, RoleConstants.AGM_GB)) {
            return ccNsmRepository.getNsmStatusDetailsAoUser(month, circleCode, networkCode, moduleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM, RoleConstants.RM, RoleConstants.RBO_DESK_OFFICER)) {
            return ccNsmRepository.getNsmStatusDetailsRBO(month, circleCode, networkCode, moduleCode, regionCode);
        } else {
            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        }
        //return null;
    }
}
