package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.CcNsm;
import sbi.sf.gocblr.cconline.domain.CcNsmDenominationDetails;

@Repository
public interface CcNsmDenominationDetailsRepository extends JpaRepository<CcNsmDenominationDetails, Long> {
    List<CcNsmDenominationDetails> findByStatusAndMonthAndCcNsmOrderByDenominationValueAsc(
        @Param("status") String status,
        @Param("month") LocalDate month,
        @Param("ccNsm") CcNsm ccNsm
    );

    @Query(
        "select c from CcNsmDenominationDetails c where (c.status like 'Save' or c.status like 'Submit') and c.month = (:month) and c.ccNsm = (:ccNsm) order by c.denomination.value asc"
    )
    List<CcNsmDenominationDetails> getSavedOrSubmittedData(@Param("month") LocalDate month, @Param("ccNsm") CcNsm ccNsm);

    @Query(
        "SELECT COUNT(1) " +
        "  FROM CcNsm cnsm " +
        " WHERE cnsm NOT IN (SELECT d.ccNsm " +
        "                     FROM CcNsmDenominationDetails d " +
        "                    WHERE status = 'Submit' " +
        "                      AND d.month = :month " +
        "                      AND d.ccNsm.currencyChest.branchCode= :branchCode " +
        "                  ) " +
        "   AND cnsm.active = 1 " +
        "   AND cnsm.currencyChest.branchCode = :branchCode"
    )
    Long getPendingNsms(@Param("month") LocalDate month, @Param("branchCode") long branchCode);
}
