package sbi.sf.gocblr.cconline.domain.criteria;

import java.time.LocalDate;
import lombok.Data;

@Data
public class MonthlyCertificateCriteria {

    private LocalDate month;

    private Long fsloCode;
    private Long circleCode;

    private Long moduleCode;
    private Long regionCode;
}
