package sbi.sf.gocblr.cconline.domain;



import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
public class AutoAlertsDetails implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 5537674786747413440L;
	
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 Long id;
	 
	 
	
	  // String forRole;

	   @ManyToOne
	   @JoinColumn(name = "for_role", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_vs_auto_alert_for_receipients"))
	   AutoAlertsRecipients forRole;
	 
	 Long pfid;
	 
	 @ManyToOne
	 @JoinColumn(name = "branch_code", referencedColumnName = "branch_code", foreignKey = @ForeignKey(name = "fk_vs_auto_alert_for_branch"))
	 Branch branch;
	 
	 String name;
	 String designation;
	 Long mobile;
	 String email;
	 
	 Long updatedBy;

}
