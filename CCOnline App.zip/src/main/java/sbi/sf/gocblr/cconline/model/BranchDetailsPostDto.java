package sbi.sf.gocblr.cconline.model;

import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;

@Getter
@Setter
public class BranchDetailsPostDto {

    private String centerName;
    private String centerType;
    private int ccCode;
    private String policeStation;
    private String openingDt;
    private String branchType;
    private String validityDt;
    private long strongRoomSize;
    private long cashProcArea;
    private String ccCategory;
    private long cbl;
    private int capacityToStoreCashInBundles;
    private int totalStaffCount;
    private int cashDeptStaffCount;
    private int guardsCount;
    private int otherBankBrsCount;
    private int totalBins;
    private int binsCapacity;
    private String coinMachine;

    public BranchDetailsPostDto(CurrencyChest cc) {}
}
