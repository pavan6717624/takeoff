package sbi.sf.gocblr.cconline.utils;

/**
 * Text utilities from various sources, instead of adding other dependencies
 *
 * @author Kiran Marturu
 *
 */
public class TextUtils {

    private TextUtils() {
        throw new IllegalArgumentException("Static utils class, not to be initalized");
    }

    public static boolean hasText(String text) {
        return text != null && text.trim().length() > 0;
    }

    public static String toUpperCase(String text) {
        if (text != null && text.length() > 0) {
            return text.toUpperCase();
        }
        return text;
    }

    public static String toUpperCase(String text, boolean trim) {
        if (text != null && text.length() > 0) {
            return trim ? text.toUpperCase().trim() : text.toUpperCase();
        }
        return text;
    }

    public static String trim(String text) {
        if (text == null) {
            return null;
        }
        return text.trim();
    }

    public static String trimAndSafeNull(String text, String nullPlaceHolder) {
        if (text == null) {
            return nullPlaceHolder;
        }
        return text.trim();
    }

    public static String getNullPlaceHolder(String text, String placeholder) {
        if (text == null) {
            return placeholder;
        }
        return text;
    }
}
