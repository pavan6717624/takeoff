package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.service.dto.VerificationSectionDTO;

public interface VerificationSectionRepository extends JpaRepository<VerificationSection, Long> {
    @Query(
        "SELECT vs.id as id," +
        "       vs.displayOrder as displayOrder," +
        "       vs.displayNo as displayNo," +
        "       vs.name as name," +
        "       vs.isHeader as isHeader," +
        "       vs.isValueStatementSection as isValueStatementSection," +
        "       vs.route as route," +
        "       vss.isSaved as isSaved " +
        "  FROM VerificationSection vs " +
        "       LEFT JOIN VerificationSectionStatus vss " +
        "            ON vs = vss.section" +
        "           AND vss.verification = :verification" +
        "  WHERE vs.verificationType = :verificationType " +
        " ORDER BY vs.displayOrder"
    )
    List<VerificationSectionDTO> sectionsWithStatus(
        @Param("verification") Verification verification,
        @Param("verificationType") VerificationType verificationType
    );

    @Query(
        "SELECT vs " +
        " FROM VerificationSection vs " +
        "       LEFT JOIN VerificationSectionStatus vss " +
        "            ON vs = vss.section" +
        "           AND vss.verification = :verification" +
        "  WHERE vs.verificationType = :verificationType " +
        "    AND NVL(vss.isSaved, false) = false " +
        "    AND NVL(vs.isHeader, false) = false " +
        " ORDER BY vs.displayOrder"
    )
    List<VerificationSection> pendingSections(
        @Param("verification") Verification verification,
        @Param("verificationType") VerificationType verificationType
    );

    @Query(
        "SELECT vs.id as id," +
        "       vs.displayOrder as displayOrder," +
        "       vs.displayNo as displayNo," +
        "       vs.name as name," +
        "       vs.isHeader as isHeader," +
        "       vs.isValueStatementSection as isValueStatementSection," +
        "       vs.route as route," +
        "       c.pending as pending," +
        "       c.total as total " +
        "  FROM VerificationSection vs " +
        "       LEFT JOIN VerificationSectionStatus vss " +
        "            ON vs = vss.section" +
        "           AND vss.verification = :verification " +
        "       LEFT JOIN VerificationSectionCount c " +
        "              ON vss.verification.id = c.verificationId " +
        "             AND vs.id = c.sectionId " +
        "  WHERE vs.verificationType = :verificationType " +
        " ORDER BY vs.displayOrder"
    )
    List<VerificationSectionDTO> sectionsWithComplianceStatus(
        @Param("verification") Verification verification,
        @Param("verificationType") VerificationType verificationType
    );

    Optional<VerificationSection> findByVerificationTypeAndRoute(VerificationType type, String route);
}
