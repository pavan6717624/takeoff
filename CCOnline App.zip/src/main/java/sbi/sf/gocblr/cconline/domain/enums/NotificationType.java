package sbi.sf.gocblr.cconline.domain.enums;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "notification_types")
public class NotificationType implements Serializable {

    private static final long serialVersionUID = 1687889298052547505L;

    @Id
    private int id;

    @Column(length = 50)
    private String name;

    @Column(length = 100)
    private String description;
}
