package sbi.sf.gocblr.cconline.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import sbi.sf.gocblr.cconline.model.ui.NzFilterMenu;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VerificationsListFilters {
    private List<NzFilterMenu> circles;
    private List<NzFilterMenu> networks;
    private List<NzFilterMenu> modules;
    private List<NzFilterMenu> regions;
}
