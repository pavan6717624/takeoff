package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.Editable;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;

public interface EditableRepository extends JpaRepository<Editable, Long> {
    Optional<Editable> findByVerificationTypeAndStatus(VerificationType vt, VerificationStatus vs);
    Optional<Editable> findByVerificationTypeAndForRoleNameAndStatus(VerificationType vt, String role, VerificationStatus vs);
}
