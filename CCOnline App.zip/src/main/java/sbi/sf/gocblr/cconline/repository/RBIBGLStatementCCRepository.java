package sbi.sf.gocblr.cconline.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.RBIBGLStatementCC;

@Repository
public interface RBIBGLStatementCCRepository extends JpaRepository<RBIBGLStatementCC, Long> {}
