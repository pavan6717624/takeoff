package sbi.sf.gocblr.cconline.service.dto;

import java.util.Date;

public interface CurrenyChestForSms {
    Integer getCircleCode();
    String getCircleName();
    Integer getFsloCode();
    String getFsloName();
    int getBranchCode();
    String getBranchName();
    Long getAcMobileNo();
    Long getCoMobileNo();
    Date getLastUploadedOn();
}
