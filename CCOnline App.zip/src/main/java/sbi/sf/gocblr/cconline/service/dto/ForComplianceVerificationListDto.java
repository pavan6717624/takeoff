package sbi.sf.gocblr.cconline.service.dto;

import java.time.LocalDate;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;
import sbi.sf.gocblr.cconline.utils.BlockUtils;

@Data
public class ForComplianceVerificationListDto {

    private long verificationId;
    private String period;
    private String statusDescription;

    private long networkCode;
    private long moduleCode;
    private String moduleName;
    private long regionCode;

    private long branchCode;
    private String branchName;

    private long verificationOfficerPfId;
    private String verificationOfficerName;

    public ForComplianceVerificationListDto(
        long id,
        LocalDate periodStart,
        LocalDate periodEnd,
        VerificationStatus status,
        long networkCode,
        long moduleCode,
        String moduleName,
        long regionCode,
        long branchCode,
        String branchName,
        long verificationOfficerPfId,
        String verificationOfficerName
    ) {
        this.verificationId = id;
        this.period = BlockUtils.formatBlockDescription(periodStart, periodEnd);
        if (status != null) {
            this.statusDescription = status.description();
        }

        this.networkCode = networkCode;
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
        this.regionCode = regionCode;
        this.branchCode = branchCode;
        this.branchName = branchName;

        this.verificationOfficerPfId = verificationOfficerPfId;
        this.verificationOfficerName = verificationOfficerName;
    }
}
