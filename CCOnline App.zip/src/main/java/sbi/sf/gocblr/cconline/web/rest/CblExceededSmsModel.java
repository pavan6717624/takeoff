package sbi.sf.gocblr.cconline.web.rest;

import java.util.Set;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

@Data
public class CblExceededSmsModel {

    @NotNull(message = "Exceeded by is required")
    @Range(min = 50, max = 100, message = "Exceeded by should be between [50, 10]")
    private Integer exceededBy;

    @Size(min = 1)
    @NotNull(message = "At least one branch to be selected")
    private Set<Long> branches;
}
