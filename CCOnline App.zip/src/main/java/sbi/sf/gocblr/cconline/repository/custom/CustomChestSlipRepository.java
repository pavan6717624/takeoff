package sbi.sf.gocblr.cconline.repository.custom;

public interface CustomChestSlipRepository {}
