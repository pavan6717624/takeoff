package sbi.sf.gocblr.cconline.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.repository.ParticularsRepository;

@Service
@RequiredArgsConstructor
public class ParticularService {

    private final ParticularsRepository repo;

    @Transactional(readOnly = true)
    public ChestSlipParticular getNotesClosingBalance() {
        return repo.particularByKeyword("Closing Balance (OB +", "Notes");
    }

    @Transactional(readOnly = true)
    public ChestSlipParticular getCoinsClosingBalance() {
        return repo.particularByKeyword("Closing Balance (OB +", "Coins");
    }

    @Transactional(readOnly = true)
    public ChestSlipParticular getSoiledNotesClosingBalance() {
        return repo.particularByKeyword("Soiled Notes Closing", "Notes");
    }
}
