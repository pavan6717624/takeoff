package sbi.sf.gocblr.cconline.model.verificationmis;

import org.springframework.beans.factory.annotation.Value;

public interface VsBranchPair {
    String getCode();

    @Value("#{target.compliance.code()}")
    String getStatus();
    
    String getNextStatus();
}
