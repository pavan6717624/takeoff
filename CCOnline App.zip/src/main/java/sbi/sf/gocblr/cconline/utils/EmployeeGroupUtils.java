package sbi.sf.gocblr.cconline.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeGroupUtils {

	private EmployeeGroupUtils() {
		// static class, not to be initialized
	}
	
	private static final Pattern SCALE_4_PATTERN = Pattern.compile("^[oOsS]4$");
	private static final Pattern SCALE_5_PATTERN = Pattern.compile("^[oOsS]5d$");
	
	public static boolean isScale4Officer(String employeeSubGroup) {
		if (TextUtils.hasText(employeeSubGroup)) {
			Matcher matcher = SCALE_4_PATTERN.matcher(employeeSubGroup.trim());
			return matcher.matches();
		}
		return false;
	}
	
	public static boolean isScale5Officer(String employeeSubGroup) {
		if (TextUtils.hasText(employeeSubGroup)) {
			Matcher matcher = SCALE_5_PATTERN.matcher(employeeSubGroup.trim());
			return matcher.matches();
		}
		return false;
	}
	
	public static boolean isAgmGb(String employeeSubGroup) {
		return false;
	}
}
