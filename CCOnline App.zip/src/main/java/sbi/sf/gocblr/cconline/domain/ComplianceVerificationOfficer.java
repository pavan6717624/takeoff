package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.NaturalId;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@Table(name = "compliance_verification_officer")
@EqualsAndHashCode(callSuper = false, onlyExplicitlyIncluded = true)
public class ComplianceVerificationOfficer extends AbstractAuditingEntity implements Serializable {
	private static final long serialVersionUID = 7889546366518705412L;
	
	@Id
	@EqualsAndHashCode.Include
	private Long id;

	@MapsId
    @OneToOne
    @JsonIgnore
    @NaturalId
    @JoinColumn(
		name = "id",
		foreignKey = @ForeignKey(name = "fk_compliance_verification_officer_verification")
	)
    private Verification verification;
	
	@NotNull
	@NaturalId(mutable = true)
	@Column(name = "pf_id")
	private Long pfId;
	
	@Column(length = 10)
	private String title;
	
	@Column(length = 100)
	private String name;
	
	@Column(length = 100)
	private String designation;
	
	@Min(6000000000L)
	@Max(9999999999L)
	@Column(name = "mobile_no")
	private Long mobileNo;
	
	@Email
	@Column(name = "email_id", length = 300)
	private String emailId;
	
	@NotNull
	@ManyToOne
	@JoinColumn(
		name = "branch_code",
		foreignKey = @ForeignKey(name = "fk_compliance_verification_officer_branch")
	)
	private Branch branch;
}
