package sbi.sf.gocblr.cconline.service;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.Fslo;
import sbi.sf.gocblr.cconline.domain.Module;
import sbi.sf.gocblr.cconline.domain.Network;
import sbi.sf.gocblr.cconline.domain.Region;
import sbi.sf.gocblr.cconline.domain.specification.ModuleSpecification;
import sbi.sf.gocblr.cconline.domain.specification.NetworkSpecifications;
import sbi.sf.gocblr.cconline.domain.specification.RegionSpecification;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.BranchRepository;
import sbi.sf.gocblr.cconline.repository.CircleRepository;
import sbi.sf.gocblr.cconline.repository.FsloRepository;
import sbi.sf.gocblr.cconline.repository.ModuleRepository;
import sbi.sf.gocblr.cconline.repository.NetworkRepository;
import sbi.sf.gocblr.cconline.repository.RegionRepository;

@Service
@RequiredArgsConstructor
public class BranchMasterService {

    private final BranchRepository branchRepo;
    private final CircleRepository circleRepo;
    private final NetworkRepository networkRepo;
    private final ModuleRepository moduleRepo;
    private final RegionRepository regionRepo;

    private final FsloRepository fsloRepo;

    public Circle getCircleByCode(long circleCode) {
        return circleRepo.findById(circleCode).orElseThrow(() -> new ResourceNotFoundException("No circle found with code " + circleCode));
    }

    public sbi.sf.gocblr.cconline.domain.Module getModule(long circleCode, long networkCode, long moduleCode) {
        return moduleRepo
            .module(circleCode, networkCode, moduleCode)
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        String.format(
                            "No module found for circle code: %d, network code: %d, module code: %d",
                            circleCode,
                            networkCode,
                            moduleCode
                        )
                    )
            );
    }

    public Region getRegion(long circleCode, long networkCode, long moduleCode, long regionCode) {
        return regionRepo
            .getRegion(circleCode, networkCode, moduleCode, regionCode)
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        String.format(
                            "No module found for circle code: %d, network code: %d, module code: %d, region: %d",
                            circleCode,
                            networkCode,
                            moduleCode,
                            regionCode
                        )
                    )
            );
    }

    public Branch getBranch(long branchCode) {
        return branchRepo
            .findById(branchCode)
            .orElseThrow(() -> new ResourceNotFoundException("No branch found with branch code: " + branchCode));
    }

    public List<Network> userNetworks(long circleCode) {
        return networkRepo.findAll(NetworkSpecifications.circleNetworks(circleCode));
    }

    public List<Module> modules(long circleCode, long networkCode) {
        return moduleRepo.findAll(ModuleSpecification.modules(circleCode, networkCode));
    }

    public List<Region> regions(long circleCode, long networkCode, long moduleCode) {
        return regionRepo.findAll(RegionSpecification.regions(circleCode, networkCode, moduleCode));
    }

    public Fslo getFslo(long fsloCode) {
        return fsloRepo.findByBranchCode(fsloCode).orElseThrow(() -> new ResourceNotFoundException("No fslo found with code " + fsloCode));
    }

    public Network findByCircleAndNetworkCode(Circle circle, Long networkCode) {
        return networkRepo
            .findByCircleAndNetworkCode(circle, networkCode)
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        String.format("No network found for circle code %d and network code %d", circle.getCircleCode(), networkCode)
                    )
            );
    }
}
