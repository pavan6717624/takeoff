package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public interface StatusSummary {
    String getCircle();
    Long getNetwork();
    String getModule();
    Long getRegion();
    Long getTotalCcs();
    Long getVoNotIdentified();
    Long getNotStarted();
    Long getInProgress();
    Long getVoReportSubmitted();
    
    Long getPendingAtBranch();
    Long getPendingAtController();
    Long getPendingAtCompliance();
    Long getAwaitingForClosure();
    Long getClosed();
    
    String getType();
    String getBlock();
    
    String getRmEmail();
	String getCmEmail();
	
	String getDgmEmail();
	String getCmAgmEmail();
	
	String getDgmEmailDirect();
	String getCmagmEmailDirect();
	
	String getAgmfsloEmail();
	String getDgmcfoEmail();
	String getDgmabdEmail();
	String getAbdEmail();
	String getAgmCircleEmail();
	

    
}
