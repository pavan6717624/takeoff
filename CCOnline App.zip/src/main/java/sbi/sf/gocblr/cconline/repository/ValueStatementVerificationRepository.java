package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ValueStatement;
import sbi.sf.gocblr.cconline.domain.ValueStatementVerification;
import sbi.sf.gocblr.cconline.domain.Verification;

@Repository
public interface ValueStatementVerificationRepository extends JpaRepository<ValueStatementVerification, Long> {
    //    Optional<ValueStatementVerification> findByIdAndVerification(Long id, Verification verification);
    Optional<ValueStatementVerification> findByVerificationAndValueStatement(Verification v, ValueStatement vs);
}
