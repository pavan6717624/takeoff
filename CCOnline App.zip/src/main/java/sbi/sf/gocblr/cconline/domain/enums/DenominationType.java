package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Enum for denomination type Coin, Note
 * @author Kiran Marturu
 *
 */
public enum DenominationType {
    COIN("C", "Coin"),
    NOTE("N", "Note");

    private final String code;
    private final String description;

    DenominationType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static DenominationType fromCode(String code) {
        for (DenominationType d : DenominationType.values()) {
            if (d.code.equalsIgnoreCase(code)) {
                return d;
            }
        }
        throw new IllegalArgumentException(String.format("Invalid %s code: %s", DenominationType.class.getName(), code));
    }
}
