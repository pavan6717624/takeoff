package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.VerificationOfficer;

public interface VerificationOfficerRepository extends JpaRepository<VerificationOfficer, Long> {
    List<VerificationOfficer> findByPfId(Long pfId);
    List<VerificationOfficer> findByPfIdAndVerificationTypeKeyIn(long pfId, String[] types);
}
