package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.enums.CcType;
import sbi.sf.gocblr.cconline.service.dto.StaffPosition;

/**
 * Verification branch profile
 *
 * NOTE: as this might be required in verification report so, not mapping
 *       hierarchy related entities and keeping it not normalized
 *
 * @author Kiran Marturu
 *
 */
@Entity
@Table(name = "verification_branch_profile")
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class VerificationBranchProfile implements Serializable {

    private static final long serialVersionUID = 5121242637950581531L;

    @Id
    private Long id;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id", foreignKey = @ForeignKey(name = "fk_verification_branch_profile_verification"))
    private Verification verification;

    @Column(name = "branch_code")
    private Long branchCode;

    @Column(name = "branch_name", length = 100)
    private String branchName;

    @Column(name = "circle_code")
    private Long circleCode;

    @Column(name = "circle_name", length = 100)
    private String circleName;

    @Column(name = "network_code")
    private Long networkCode;

    @Column(name = "module_code")
    private Long moduleCode;

    @Column(name = "module_name", length = 100)
    private String moduleName;

    @Column(name = "region_code")
    private Long regionCode;

    private Integer incumbency;

    @Column(name = "incumbency_since")
    private LocalDate incumbencySince;

    @Column(name = "cc_type")
    private CcType ccType;

    @Column(name = "strong_room_size")
    private Long strongRoomSize;

    @Column(name = "cash_balance_limit")
    private Long cashBalanceLimit;

    //    @Column(name = "holding_capacity_of_bins")
    //    private Long holdingCapacityOfBins;

    @Column(name = "capacity_to_store_cash_in_bundles")
    private Long capacityToStoreCashInBundles;

    @Column(name = "avg_daily_reciepts")
    private Long averageDailyReciept;

    @Column(name = "avg_daily_payments")
    private Long averageDailyPayment;

    @Embedded
    @AttributeOverride(name = "award", column = @Column(name = "total_staff_award"))
    @AttributeOverride(name = "supervisory", column = @Column(name = "total_staff_supervisory"))
    private StaffPosition totalStaff;

    @Embedded
    @AttributeOverride(name = "award", column = @Column(name = "cash_dept_award", length = 100))
    @AttributeOverride(name = "supervisory", column = @Column(name = "cash_dept_supervisory"))
    private StaffPosition cashDeptStaff;

    @Column(name = "cc_balance_reported_in_cym", columnDefinition = "NUMBER(20,2)")
    private Double ccBalanceReportedInCyM;

    @Column(name = "bgl_98958_balance", columnDefinition = "NUMBER(20,2)")
    private Double bgl98958Balance;

    @Column(name = "soiled_notes_balance_reported", columnDefinition = "NUMBER(20,2)")
    private Double soiledNotesBalanceReported;

    @Column(name = "balance_of_soiled_notes_available_in_cc", columnDefinition = "NUMBER(20,2)")
    private Double balanceOfSoiledNotesAvailableInCc;

    @Column(name = "last_bi_monthly_verification")
    private LocalDate lastBiMonthlyVerification;

    @Column(name = "last_quarterly_verification")
    private LocalDate lastQuarterlyVerification;

    @Column(name = "last_half_yearly_verification")
    private LocalDate lastHalfYearlyVerification;

    @Column(name = "last_security_officer_visit")
    private LocalDate lastSecurityOfficerVist;

    @Column(name = "strong_room_fitness_cert_expiry_date")
    private LocalDate strongRoomFitnessCertExpiryDate;
}
