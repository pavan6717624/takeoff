package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.Denomination;
import sbi.sf.gocblr.cconline.domain.DetailedVerification;
import sbi.sf.gocblr.cconline.domain.DetailedVerificationDetails;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.service.dto.DetailedVerificationDTO;

@Repository
public interface DetailedVerificationDetailsRepository extends JpaRepository<DetailedVerificationDetails, Long> {
    @Query(
        "SELECT d.id as denominationId," +
        "       d.value as denominationValue," +
        "       d.type as denominationType," +
        "       dvd.noOfPieces as noOfPieces," +
        "       dvd.discrepancyType as discrepancyType," +
        "       dvd.discrepancyPieces as discrepancyPieces," +
        "       dvd.ficn as ficn," +
        "       dvd.soiledWronglyClassified as soiledWronglyClassified," +
        "       dvd.mutilatedWronglyClassified as mutilatedWronglyClassified " +
        " FROM Denomination d " +
        "      LEFT JOIN DetailedVerification dv " +
        "             ON dv.verification = :verification " +
        "      LEFT JOIN DetailedVerificationDetails dvd " +
        "             ON dvd.denomination = d " +
        "            AND dvd.detailedVerification = dv " +
        " WHERE d.type = 'N' " +
        "ORDER BY d.value DESC"
    )
    List<DetailedVerificationDTO> detailedVerification(@Param("verification") Verification verification);

    Optional<DetailedVerificationDetails> findByDetailedVerificationAndDenomination(DetailedVerification dv, Denomination d);
}
