package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class BGLStatementData {

    double debitTotal;
    double creditTotal;
    double openingBalance;
    double closingBalance;
    String data;
    String date;
    String removedData;
}
