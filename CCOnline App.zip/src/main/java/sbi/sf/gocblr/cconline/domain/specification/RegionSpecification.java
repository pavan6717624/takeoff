package sbi.sf.gocblr.cconline.domain.specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.Module;
import sbi.sf.gocblr.cconline.domain.Network;
import sbi.sf.gocblr.cconline.domain.Region;

public class RegionSpecification {

    private RegionSpecification() {
        // static class
    }

    public static Specification<Region> regions(long circleCode, long networkCode, long moduleCode) {
        return new Specification<Region>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<Region> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                Join<Region, Module> module = root.join("module");
                Join<Module, Network> network = module.join("network");
                Join<Network, Circle> circle = network.join("circle");

                return cb.and(
                    cb.equal(circle.get("circleCode"), circleCode),
                    cb.equal(network.get("networkCode"), networkCode),
                    cb.equal(root.get("module").get("moduleCode"), moduleCode)
                );
            }
        };
    }
}
