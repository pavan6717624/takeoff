package sbi.sf.gocblr.cconline.domain;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "detailed_verification")
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DetailedVerification {

    @Id
    private Long id;

    @MapsId
    @OneToOne
    @JoinColumn(name = "id", foreignKey = @ForeignKey(name = "fk_detailed_verification_verification"))
    @EqualsAndHashCode.Include
    private Verification verification;

    @OneToMany(mappedBy = "detailedVerification", cascade = CascadeType.ALL)
    private Set<DetailedVerificationDetails> details = new HashSet<>();

    public void addDetails(DetailedVerificationDetails detail) {
        this.details.add(detail);
        detail.setDetailedVerification(this);
    }
}
