package sbi.sf.gocblr.cconline.domain.enums;

import java.util.ArrayList;
import java.util.List;
import sbi.sf.gocblr.cconline.web.rest.vm.IdNameDesc;

/**
 * Currency Chest Branches Reports
 * @author Sumalatha
 *
 */
public enum CcBranchesReports {
    BRLIST("BRLIST", "Branch_List"),
    BRSUMMARY("BRSUMMARY", "No_of_Branches"),
    CLOSEDBRS("CLOSEDBRS", "Closed_Branches");

    private final String code;
    private final String description;

    CcBranchesReports(String code, String desc) {
        this.code = code;
        this.description = desc;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static CcBranchesReports fromCode(String code) {
        for (CcBranchesReports n : CcBranchesReports.values()) {
            if (n.code.equalsIgnoreCase(code)) {
                return n;
            }
        }
        throw new IllegalArgumentException("Invalid Cc Branches Report: " + code);
    }

    public static List<IdNameDesc> getAsIdNameAndDesc() {
        List<IdNameDesc> data = new ArrayList<>();
        for (CcBranchesReports n : CcBranchesReports.values()) {
            data.add(new IdNameDesc(n.code + "", n.toString(), n.description));
        }

        return data;
    }
}
