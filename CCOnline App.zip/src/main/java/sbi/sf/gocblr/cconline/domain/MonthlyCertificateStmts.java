package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import sbi.sf.gocblr.cconline.domain.enums.InputType;

/**
 * List of Monthly Certificate Statements
 *
 */
@Entity
@Table(name = "MONTHLY_CERTIFICATE_STMTS")
@Getter
@Setter
@ToString
public class MonthlyCertificateStmts implements Serializable {

    private static final long serialVersionUID = 6137125581334138679L;

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "display_no")
    private String displayNo;

    @Column(name = "display_order")
    private Integer displayOrder;

    @Column(name = "is_header_only")
    private Boolean isHeaderOnly;

    @Column(name = "description")
    private String description;

    @Column(name = "input_type")
    @Enumerated(EnumType.STRING)
    private InputType inputType;
}
