package sbi.sf.gocblr.cconline.model;

import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DisplayData {

    String status;
    String message;
    List<BGLStatementDisplay> data;
}
