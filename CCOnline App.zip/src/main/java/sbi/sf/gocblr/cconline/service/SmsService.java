package sbi.sf.gocblr.cconline.service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.AutoSmsResponse;
import sbi.sf.gocblr.cconline.domain.SmsNotification;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.SmsFailureException;
import sbi.sf.gocblr.cconline.model.SmsApiResponse;
import sbi.sf.gocblr.cconline.repository.AutoSmsResponseRepository;
import sbi.sf.gocblr.cconline.utils.TextUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class SmsService {

    private final Environment env;
    private final ApplicationProperties app;
    private final SmsStatusService statusService;
    private final AutoSmsResponseRepository autoSmsResponseRepository;
    private static final X509Certificate[] certificate= null;
    

    private static class CustomTrustManager implements X509TrustManager {

        @Override
        public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
            // ignore
        }

        @Override
        public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
            // ignore
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
        	return certificate;
          
        }
    }
    
   

    private SmsApiResponse sendSms(String mobileNo, String msgText) {
        log.info(">> sendSms({}, {})", mobileNo, msgText);

        if (!TextUtils.hasText(mobileNo) || !TextUtils.hasText(msgText)) {
            throw new InvalidOperationException(String.format("Mobile no: %s or Message Text: %s has no text", mobileNo, msgText));
        }

        try {
            SSLContext ctx = SSLContext.getInstance("SSL");
            ctx.init(null, new TrustManager[] { new CustomTrustManager() }, new SecureRandom());
            //SSLContext.setDefault(ctx);

            Map<String, String> params = new HashMap<>();
            params.put("content_type", "text");
            params.put("sender_id", app.getSmsApiSenderId());
            params.put("mobile", mobileNo);
            params.put("message", msgText);
            params.put("intflag", "0");
            params.put("charging", "0");

            byte[] formData = getFormEncodedData(params);
            int formDataLength = formData.length;

            URL url = new URL(app.getSmsApiUrl());

            HttpsURLConnection.setDefaultSSLSocketFactory(ctx.getSocketFactory());

            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.setHostnameVerifier((a, b) -> true);
            conn.setRequestMethod("POST");

            String auth = Base64
                .getEncoder()
                .encodeToString(String.format("%s:%s", app.getSmsApiUserId(), app.getSmsApiPassword()).getBytes(StandardCharsets.UTF_8));
            conn.setRequestProperty("Authorization", "Basic " + auth);

            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("charset", StandardCharsets.UTF_8.name());
            conn.setRequestProperty("Content-Length", Integer.toString(formDataLength));

            try (DataOutputStream os = new DataOutputStream(conn.getOutputStream())) {
                os.write(formData);
            }

            if (conn.getResponseCode() != 200) {
                log.warn("SMS API Response Code: {}", conn.getResponseCode());
                throw new SmsFailureException("Error sending SMS");
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                StringBuilder output = new StringBuilder(2000);
                String line = "";
                while ((line = br.readLine()) != null) {
                    output.append(line + "\n");
                }
                String response = output.toString();
                log.warn("SMS API Response: {}", response);

                SmsApiResponse smsApiResponse = parseSmsApiResponse(response);

                log.info("{}", smsApiResponse);

                if (smsApiResponse.getErrorCode() != 0) {
                    throw new SmsFailureException(
                        String.format(
                            "API Error (%s): %d: %s",
                            smsApiResponse.getUmid(),
                            smsApiResponse.getErrorCode(),
                            smsApiResponse.getErrorDescription()
                        )
                    );
                }
                return smsApiResponse;
            }
        } catch (IOException | KeyManagementException | NoSuchAlgorithmException e) {
        	 log.info(e.toString());
            throw new SmsFailureException(e);
        }
    }

    private SmsApiResponse parseSmsApiResponse(String response) {
        if (TextUtils.hasText(response)) {
            SmsApiResponse smsApiResponse = new SmsApiResponse();
            String[] tokens = response.split("&");

            for (String token : tokens) {
                String[] keyValuePairs = token.split("=");
                if (keyValuePairs.length == 2) {
                    if (keyValuePairs[0].equalsIgnoreCase("error_code")) {
                        smsApiResponse.setErrorCode(Integer.parseInt(keyValuePairs[1]));
                    } else if (keyValuePairs[0].equalsIgnoreCase("error_desc")) {
                        smsApiResponse.setErrorDescription(keyValuePairs[1]);
                    } else if (keyValuePairs[0].equalsIgnoreCase("umid")) {
                        smsApiResponse.setUmid(keyValuePairs[1]);
                    }
                }
            }
            return smsApiResponse;
        } else {
            throw new IllegalArgumentException("Response is empty");
        }
    }

    private byte[] getFormEncodedData(Map<String, String> params) {
        StringBuilder data = new StringBuilder(2000);

        boolean firstParam = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (firstParam) {
                firstParam = false;
            } else {
                data.append("&");
            }

            data.append(URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8));
            data.append("=");
            data.append(URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8));
        }

        return data.toString().getBytes();
    }

    @Async
    public void sendSmsAsync(String mobileNo, String text) {
        boolean isDev = env.acceptsProfiles(Profiles.of("dev"));
        boolean isProd = env.acceptsProfiles(Profiles.of("prod"));

        if (isDev) {
            log.debug("Sending SMS...");
            log.debug("{}: {}", mobileNo, text);
        } else if (isProd) {
            sendSms(mobileNo, text);
        } else {
            sendSms(app.getSmsPreProdNumber().toString(), text);
        }
    }

    @Async
    public void sendSms(Set<SmsNotification> messages) {
        boolean isProd = env.acceptsProfiles(Profiles.of("prod"));

        for (var msg : messages) {
            try {
                SmsApiResponse res = null;
                if (isProd) {
                    res = sendSms(msg.getMobileNo() + "", msg.getText());
                } else {
                    res = sendSms(app.getSmsPreProdNumber().toString(), msg.getText());
                }
                statusService.updateMessageStatus(msg.getId(), true, res.toString());
            } catch (SmsFailureException e) {
                statusService.updateMessageStatus(msg.getId(), false, e.getMessage());
            }
        }
    }
    
    @Async
    public SmsApiResponse sendAutoSms(String mobileNo, String text) {
        boolean isProd = env.acceptsProfiles(Profiles.of("prod"));

        
       
            try {
                SmsApiResponse response = null;
                if (isProd) {
                	response = sendSms(mobileNo + "", text);
                	AutoSmsResponse autoSmsResponse=new AutoSmsResponse();
        			autoSmsResponse.setErrorCode(response.getErrorCode());
        			autoSmsResponse.setErrorDescription(response.getErrorDescription());
        			autoSmsResponse.setMobile(mobileNo);
        			autoSmsResponse.setSmsDate(LocalDate.now());
        			autoSmsResponse.setText(text);
        			autoSmsResponse.setUmid(response.getUmid());
        			autoSmsResponseRepository.save(autoSmsResponse);
                } else {
                	response = sendSms(app.getSmsPreProdNumber().toString(), text);
                	AutoSmsResponse autoSmsResponse=new AutoSmsResponse();
        			autoSmsResponse.setErrorCode(response.getErrorCode());
        			autoSmsResponse.setErrorDescription(response.getErrorDescription());
        			autoSmsResponse.setMobile(mobileNo);
        			autoSmsResponse.setSmsDate(LocalDate.now());
        			autoSmsResponse.setText(text);
        			autoSmsResponse.setUmid(response.getUmid());
        			autoSmsResponseRepository.save(autoSmsResponse);
                }
                
                
                
                return response;
            } catch (SmsFailureException e) {
            	//System.out.println(e);
                return null;
            }
        
    }
}
