package sbi.sf.gocblr.cconline.service;

import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.model.EmployeeDetailsModel;

/**
 * Employee details service interface for having a common interface for both SSO and HRMS.
 * So can be easily swapped after getting HRMS service
 * @see sbi.sf.gocblr.cconline.service.SsoEmployeeDetailsService
 *
 * @author Kiran Marturu
 *
 */
@Service
public interface EmployeeDetailsService {
    EmployeeDetailsModel getEmployeeDetails(int pfId);
}
