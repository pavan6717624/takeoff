package sbi.sf.gocblr.cconline.model;

import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.VerificationSectionStatus;

public interface VerificationSectionStatusDto {
    VerificationSection getSection();
    VerificationSectionStatus getStatus();
}
