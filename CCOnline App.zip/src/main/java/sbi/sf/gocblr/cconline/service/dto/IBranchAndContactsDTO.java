package sbi.sf.gocblr.cconline.service.dto;

public interface IBranchAndContactsDTO extends IBranchDTO, IBranchContactsDTO {}
