package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateStatus;

public interface MonthlyCertificateStatusRepository extends JpaRepository<MonthlyCertificateStatus, Integer> {
    Optional<MonthlyCertificateStatus> findByMonthAndCcBranchCode(LocalDate month, long branchCode);
}
