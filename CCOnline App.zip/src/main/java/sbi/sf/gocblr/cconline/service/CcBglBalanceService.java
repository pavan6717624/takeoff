package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.CcBglBalance;
import sbi.sf.gocblr.cconline.domain.specifications.CcBglBalanceSpecifications;
import sbi.sf.gocblr.cconline.repository.CcBglBalanceRepository;

@Service
@RequiredArgsConstructor
public class CcBglBalanceService {

    private final CcBglBalanceRepository repo;

    @Transactional(readOnly = true)
    public Double latestBglBalance(long branchCode) {
        Optional<CcBglBalance> bglBalance = repo.findTopByCurrencyChestBranchCodeOrderByDateDesc(branchCode);
        if (bglBalance.isPresent()) {
            return bglBalance.get().getValue();
        }
        return 0d;
    }

    /**
     * BGL 98958 balances as on particular date
     * @param branchCode
     * @param asOn
     * @return value, 0 in case not present
     */
    public double bgl98958AsOn(long branchCode, LocalDate asOn) {
        Optional<CcBglBalance> bal = repo.findOne(
            CcBglBalanceSpecifications
                .branchCode(branchCode)
                .and(CcBglBalanceSpecifications.bgl98958())
                .and(CcBglBalanceSpecifications.asOn(asOn))
        );

        if (bal.isPresent()) {
            return bal.get().getValue();
        }

        return 0d;
    }
}
