package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Value;

public interface VsConsolidatedSummaryBranchWise {
    Long getCircleCode();
    String getCircleName();
    Long getNetworkCode();
    Long getModuleCode();
    String getModuleName();
    Long getRegionCode();

    Long getBranchCode();
    String getBranchName();

    LocalDate getVerificationDate();

    Long getVsId();

    String getVsNo();

    @Value("#{target.compliance.code()}")
    String getCompliance();
}
