package sbi.sf.gocblr.cconline.model;

import java.io.Serializable;
import lombok.Data;

@Data
public class SsoClaimsModel implements Serializable {
    private static final long serialVersionUID = -9218612871980687921L;

    private Long pfId;
    private String title;
    private String name;
    private String employeeGroupCode; // O, S
    private String employeeSubGroupCode; // O4, O5
    private String designation;
    private String position;
    private String emailId;
    private String mobileNo;
    private Long branchCode;
    private String branchName;
}
