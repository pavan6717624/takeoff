package sbi.sf.gocblr.cconline.domain.enums;

public enum PopulationGroup {
    METRO("M", "Metro"),
    URBAN("U", "Urban"),
    SEMI_URBAN("SU", "Semi-Urban"),
    RURAL("R", "Rural");

    private String code;
    private String description;

    PopulationGroup(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static PopulationGroup fromCode(String code) {
        for (PopulationGroup n : PopulationGroup.values()) {
            if (n.code.equalsIgnoreCase(code)) {
                return n;
            }
        }
        return null;
        //throw new IllegalArgumentException("Invalid PopulationGroup code: " + code);
    }
}
