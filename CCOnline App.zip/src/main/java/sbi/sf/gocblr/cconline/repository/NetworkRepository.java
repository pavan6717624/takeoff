package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.Network;
import sbi.sf.gocblr.cconline.domain.NetworkId;

public interface NetworkRepository extends JpaRepository<Network, NetworkId>, JpaSpecificationExecutor<Network> {
    Optional<Network> findByCircleAndNetworkCode(Circle circle, int networkCode);

    Optional<Network> findByCircleAndNetworkCode(Circle circle, Long networkCode);

    List<Network> findAll(Specification<Network> spec);
}
