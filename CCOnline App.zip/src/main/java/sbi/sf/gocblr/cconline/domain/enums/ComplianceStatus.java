package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Compliance statuses
 * @author Kiran Marturu
 *
 */
public enum ComplianceStatus {
    COMPLIED("C", "Complied"),
    NOT_COMPLIED("NC", "Not Complied");

    private final String code;
    private final String description;

    ComplianceStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static ComplianceStatus fromCode(String code) {
        for (ComplianceStatus c : ComplianceStatus.values()) {
            if (c.code.equalsIgnoreCase(code)) {
                return c;
            }
        }

        throw new IllegalArgumentException("Invalid ComplianceStatus code: " + code);
    }
}
