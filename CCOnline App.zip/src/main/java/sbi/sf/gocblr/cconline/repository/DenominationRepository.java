package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.Denomination;

@Repository
public interface DenominationRepository extends JpaRepository<Denomination, Long> {
    @Query("SELECT d FROM Denomination d where d.value=(:value) and d.type=(:type)")
    Denomination denominationsByValue(@Param("value") int value, @Param("type") String type);

    @Query("SELECT value FROM Denomination d where d.type=(:type)")
    List<String> allDenominationValuesByType(@Param("type") String type);

    @Query("SELECT d FROM Denomination d where d.type=(:type)")
    List<Denomination> allDenominationsByType(@Param("type") String type);

    @Query("SELECT d.id FROM Denomination d order by d.id asc")
    List<Long> getIndices();

    Optional<Denomination> findByValue(int value);

    Optional<Denomination> findByValueAndType(int value, String type);
}
