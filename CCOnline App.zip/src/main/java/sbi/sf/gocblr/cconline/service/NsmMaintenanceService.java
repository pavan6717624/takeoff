package sbi.sf.gocblr.cconline.service;

import java.util.List;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.CcNsm;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Nsm;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.CcNsmRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.NsmRepository;
import sbi.sf.gocblr.cconline.web.rest.vm.addNsmToBranchVM;

@Slf4j
@Service
@RequiredArgsConstructor
public class NsmMaintenanceService {

    private final CcNsmRepository ccNsmRepo;
    private final CurrencyChestService ccService;
    private final NsmRepository nsmRepo;
    private final CurrencyChestRepository currencyChestRepository;

    @Transactional
    public List<CcNsm> getNSMsListByBranchCode(Long branchCode) {
        CurrencyChest cc = currencyChestRepository.findByBranchCode(branchCode).orElse(null);

        //return null;
        // for getting branch wise list of NSMs
        //		return ccNsmRepo
        //				.findByBranchCode(branchCode)
        //				.orElseThrow(() -> new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode)));
        if (cc == null) {
            throw new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode));
        } else {
            List<CcNsm> cn = ccNsmRepo.findByCurrencyChestBranchCode(branchCode);
            //log.debug("CcNSM: {}", cn);
            return cn;
            //return ccNsmRepo.findByCurrencyChestBranchCode(branchCode);
        }
    }

    @Transactional
    public List<Nsm> getCcNsmMasterDetails() {
        List<Nsm> nsm = nsmRepo.findAll();
        return nsm;
    }

    @Transactional
    public void postSubmitAddNsm(Long branchCode, @Valid addNsmToBranchVM submitData) {
        // TODO Auto-generated method stub

        //		CurrencyChest cc = currencyChestRepository.findByBranchCode(branchCode).orElse(null);

        var cc = ccService.getByBranchCode(branchCode);
        var nsm = nsmRepo
            .findById((long) submitData.getId())
            .orElseThrow(() -> new ResourceNotFoundException(String.format("No NSM found for id: %d", submitData.getId())));

        CcNsm ccNsm = new CcNsm();

        //ccNsm.setId(submitData.getId());
        ccNsm.setNsm(nsm);
        ccNsm.setYearOfPurchase(submitData.getYearOfPurchase());
        ccNsm.setCurrencyChest(cc);

        ccNsmRepo.save(ccNsm);

        log.trace("NSM Data_: {}", submitData);
    }

    @Transactional
    public void markNsmStatus(@Valid long id) {
        // TODO Auto-generated method stub
        //var nsm = nsmRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("No NSM found for id: %d", id)));
        CcNsm ccNsm = new CcNsm();

        ccNsm = ccNsmRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("No NSM found for id: %d", id)));

        if (ccNsm.isActive()) {
            ccNsm.setActive(false);
        } else {
            ccNsm.setActive(true);
        }
        ccNsmRepo.save(ccNsm);
    }
}
