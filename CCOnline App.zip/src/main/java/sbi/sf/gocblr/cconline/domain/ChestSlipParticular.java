package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
@Entity
@Table(name = "particulars")
public class ChestSlipParticular implements Serializable {

    private static final long serialVersionUID = -5862478216314189137L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pid;

    private String particular;
    private String keyword;

    @Column(name = "add_index")
    private Integer addindex;

    private String type;
}
