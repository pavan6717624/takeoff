package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.EmailReminder;
import sbi.sf.gocblr.cconline.domain.Fslo;
import sbi.sf.gocblr.cconline.exception.NothingSpecificException;
import sbi.sf.gocblr.cconline.model.EmailReminderInputModel;
import sbi.sf.gocblr.cconline.model.enums.ReminderFor;
import sbi.sf.gocblr.cconline.model.enums.ReminderTo;
import sbi.sf.gocblr.cconline.repository.ChestSlipUploadDetailsRepository;
import sbi.sf.gocblr.cconline.repository.CircleRepository;
import sbi.sf.gocblr.cconline.repository.EmailReminderRepository;
import sbi.sf.gocblr.cconline.repository.ExceptionReportRepository;
import sbi.sf.gocblr.cconline.repository.FsloRepository;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.dto.CcBglDiff;
import sbi.sf.gocblr.cconline.service.dto.CurrenyChestForSms;
import sbi.sf.gocblr.cconline.service.dto.ExceptionReportDTO;
import sbi.sf.gocblr.cconline.utils.DateUtils;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class EmailReminderService {

    private final SpringTemplateEngine templateEngine;

    private final FsloRepository fsloRepo;
    private final CircleRepository circleRepo;
    private final BranchMasterService bmService;
    private final ExceptionReportRepository exRepo;

    private final ChestSlipUploadDetailsRepository csudRepo;

    private final MailSenderService mail;

    private final Environment env;

    private final ApplicationProperties app;
    private final EmailReminderRepository repo;

    public String test(EmailReminderInputModel im) {
        var circle = bmService.getCircleByCode(13);
        var fslo = fsloRepo.findByBranchCode(40681L);

        LocalDate sinceWhen = LocalDate.of(2021, 3, 12);
        // return prepareCircleTemplate(circle, sinceWhen, im);
        return prepareFsloTemplate(fslo.get(), sinceWhen, im);
    }

    @Transactional
    public void sendEmailRemainder(EmailReminderInputModel im) {
        log.trace(">> sendEmailRemainder()");

        boolean isProd = env.acceptsProfiles(Profiles.of("prod"));
        log.debug("is prod profile: {}", isProd);

        LocalDate sinceWhen;
        if (isProd) {
            sinceWhen = LocalDate.now().minusDays(1);
        } else {
            // in case of not production take pending from 03-03-2021
            sinceWhen = LocalDate.of(2021, 3, 3);
        }

        var existing = repo.findByReminderForAndToBeSentToAndForDate(
            String.join(",", im.getReminderFor().stream().map(ReminderFor::toString).collect(Collectors.toList())),
            im.getToBeSentTo(),
            LocalDate.now().minusDays(1)
        );

        if (existing.isPresent()) {
            throw new NothingSpecificException("Mail has already been sent for the day");
        }

        if (im.getToBeSentTo() == ReminderTo.CFO) {
            log.trace("to be sent to CFO");
            var circles = circleRepo.findAll();

            for (var circle : circles) {
                log.trace("Circle: {}", circle.getCircleName());

                String content = prepareCircleTemplate(circle, sinceWhen, im);
                if (content != null) {
                    String subject = String.format("Currency Chest: Various Differences - %s", circle.getCircleName());
                    sendMail(new String[] { circle.getCfoEmailId() }, content, new String[] { circle.getCgmEmailId() }, subject);
                } else {
                    log.debug("{}: no content for sending mail", circle.getCircleName());
                }
            }
        } else if (im.getToBeSentTo() == ReminderTo.FSLO) {
            log.trace("to be sent to FSLO");
            var fslos = fsloRepo.findAll();

            for (var fslo : fslos) {
                String content = prepareFsloTemplate(fslo, sinceWhen, im);

                if (content != null) {
                    String subject = String.format("Currency Chest: Various Differences - %s", fslo.getBranchName());
                    sendMail(new String[] { fslo.getEmailId() }, content, new String[0], subject);
                } else {
                    log.debug("{} no content for sending mail", fslo.getBranchName());
                }
            }
        } else {
            throw new IllegalArgumentException("Invalid reminder to: " + im.getToBeSentTo());
        }

        // store the status
        saveStatus(im);
    }

    @Async
    public void sendMail(String[] to, String content, String[] cc, String subject) {
        log.debug(">> sendMail()");

        boolean isDev = env.acceptsProfiles(Profiles.of("dev"));
        boolean isProd = env.acceptsProfiles(Profiles.of("prod"));

        if (isDev) {
            log.debug("Sending email...");
        } else if (isProd) {
            log.trace("In prod mode");
            mail.sendEmailAsync(to, cc, subject, content, true);
        } else {
            log.trace("In non-prod mode");
            mail.sendEmailAsync(new String[] { app.getMailReceiverEmail() }, new String[] {}, subject, content, true);
        }
    }

    private void saveStatus(EmailReminderInputModel im) {
        EmailReminder emailReminder = new EmailReminder();
        emailReminder.setReminderFor(
            String.join(",", im.getReminderFor().stream().map(ReminderFor::toString).collect(Collectors.toList()))
        );
        emailReminder.setToBeSentTo(im.getToBeSentTo());
        emailReminder.setPendencyFor(im.getPendencyFor());
        emailReminder.setForDate(LocalDate.now().minusDays(1));
        emailReminder.setTriggeredBy(SecurityUtils.getLoggedInUser().getId());
        emailReminder.setTriggeredOn(LocalDateTime.now());

        repo.save(emailReminder);
    }

    private String prepareFsloTemplate(Fslo fslo, LocalDate sinceWhen, EmailReminderInputModel im) {
        Context context = new Context();
        boolean hasData = false;
        for (var t : im.getReminderFor()) {
            switch (t) {
                case EXCEPTIONS:
                    List<ExceptionReportDTO> exceptions = exRepo.forMailRemainder(fslo.getBranchCode(), sinceWhen);
                    hasData = !exceptions.isEmpty();
                    if (!exceptions.isEmpty()) {
                        context.setVariable("exceptions", exceptions);
                    }
                    break;
                case DIFF_IN_98908:
                    List<CcBglDiff> bgl98908 = csudRepo.bgl98908DiffCircleOrFslo(fslo.getBranchCode(), 999L, DateUtils.format(sinceWhen));
                    hasData = !bgl98908.isEmpty();
                    if (!bgl98908.isEmpty()) {
                        context.setVariable("bgl98908", bgl98908);
                    }
                    break;
                case DIFF_IN_98958:
                    List<CcBglDiff> bgl98958 = csudRepo.bgl98958DiffCircleOrFslo(fslo.getBranchCode(), 999L, DateUtils.format(sinceWhen));
                    hasData = !bgl98958.isEmpty();
                    if (!bgl98958.isEmpty()) {
                        context.setVariable("bgl98958", bgl98958);
                    }
                    break;
                case CHEST_SLIP_UPLOAD:
                    List<CurrenyChestForSms> csPending = csudRepo.chestSlipNotUploadedCircleOrFslo(
                        fslo.getBranchCode(),
                        999L,
                        DateUtils.format(sinceWhen)
                    );
                    hasData = !csPending.isEmpty();
                    if (!csPending.isEmpty()) {
                        context.setVariable("csPending", csPending);
                    }
                    break;
            }
        }
        if (hasData) {
            return templateEngine.process("emailRemainder.html", context);
        }
        return null;
    }

    private String prepareCircleTemplate(Circle circle, LocalDate sinceWhen, EmailReminderInputModel im) {
        Context context = new Context();
        boolean hasData = false;
        for (var t : im.getReminderFor()) {
            switch (t) {
                case EXCEPTIONS:
                    List<ExceptionReportDTO> exceptions = exRepo.forMailRemainder(circle.getCircleCode(), sinceWhen);
                    hasData = !exceptions.isEmpty();
                    if (!exceptions.isEmpty()) {
                        context.setVariable("exceptions", exceptions);
                    }
                    break;
                case DIFF_IN_98908:
                    List<CcBglDiff> bgl98908 = csudRepo.bgl98908DiffCircleOrFslo(0L, circle.getCircleCode(), DateUtils.format(sinceWhen));
                    hasData = !bgl98908.isEmpty();
                    if (!bgl98908.isEmpty()) {
                        context.setVariable("bgl98908", bgl98908);
                    }
                    break;
                case DIFF_IN_98958:
                    List<CcBglDiff> bgl98958 = csudRepo.bgl98958DiffCircleOrFslo(0L, circle.getCircleCode(), DateUtils.format(sinceWhen));
                    hasData = !bgl98958.isEmpty();
                    if (hasData) {
                        context.setVariable("bgl98958", bgl98958);
                    }
                    break;
                case CHEST_SLIP_UPLOAD:
                    List<CurrenyChestForSms> csPending = csudRepo.chestSlipNotUploadedCircleOrFslo(
                        0L,
                        circle.getCircleCode(),
                        DateUtils.format(sinceWhen)
                    );
                    hasData = !csPending.isEmpty();
                    if (hasData) {
                        context.setVariable("csPending", csPending);
                    }
                    break;
            }
        }

        if (hasData) {
            return templateEngine.process("emailRemainder", context);
        } else {
            return null;
        }
    }
}
