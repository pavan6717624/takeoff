package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.ChestSlips;
import sbi.sf.gocblr.cconline.domain.Denomination;
import sbi.sf.gocblr.cconline.model.AutoAlertReportDTO;
import sbi.sf.gocblr.cconline.model.DenomintaionAndPiecesDTO;

@Repository
public interface ChestSlipsRepository extends JpaRepository<ChestSlips, Long> {
    Optional<ChestSlips> findByCheckSlipUploadDetailsAndParticularsParticularLike(ChestSlipUploadDetails csd, String particular);

    @Query(
        "SELECT d.id as denominationId, " +
        "       d.value as denominationValue, " +
        "       d.type as denominationType, " +
        "       cs.value as noOfPieces " +
        "  FROM Denomination d " +
        "       LEFT JOIN ChestSlips cs " +
        "              ON cs.checkSlipUploadDetails = :chestSlipUploadDetails " +
        "             AND cs.denominations = d " +
        "             AND cs.particulars = :particular " +
        " WHERE d.type = :type "
    )
    List<DenomintaionAndPiecesDTO> getDetailsForDate(
        @Param("chestSlipUploadDetails") ChestSlipUploadDetails chestSlipUploadDetails,
        @Param("particular") ChestSlipParticular chestSlipParticular,
        @Param("type") String type
    );

    Optional<ChestSlips> findByCheckSlipUploadDetailsAndParticularsAndDenominations(
        ChestSlipUploadDetails checkSlipUploadDetails,
        ChestSlipParticular particulars,
        Denomination denominations
    );
    
    @Query("select t.checkSlipUploadDetails.currencyChest.branchCode as branchCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.branchName as branchName, "
    		+ " t.checkSlipUploadDetails.currencyChest.region.regionCode as regionCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleName as moduleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleCode as moduleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.network.networkCode as networkCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleCode as circleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleName as circleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.fslo.branchCode as fsloCode, "
    		
    		+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as branchManagerMobile from AutoAlertsDetails a where a.branch.branchCode=t.checkSlipUploadDetails.currencyChest.branchCode and a.forRole.receivers like 'Branch Manager') as branchManagerMobile, "
    		+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as cashOfficerMobile from AutoAlertsDetails a where a.branch.branchCode=t.checkSlipUploadDetails.currencyChest.branchCode and a.forRole.receivers like 'Cash Officer') as cashOfficerMobile, "
    		+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as accountantMobile from AutoAlertsDetails a where a.branch.branchCode=t.checkSlipUploadDetails.currencyChest.branchCode and a.forRole.receivers like 'Accountant') as accountantMobile, "
    		+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as branchEmail from AutoAlertsDetails a where a.branch.branchCode=t.checkSlipUploadDetails.currencyChest.branchCode and length(trim(email)) > 1 ) as branchEmail, "
    		    		
    		+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as rmMobile from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.region.regionCode=t.checkSlipUploadDetails.currencyChest.region.regionCode and a.branch.branchTypeCode=22 and a.forRole.receivers like 'Regional Manager') as rmMobile, "
    		+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as cmMobile from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.region.regionCode=t.checkSlipUploadDetails.currencyChest.region.regionCode and a.branch.branchTypeCode=22 and a.forRole.receivers like 'CM (C&O)') as cmMobile, "
    		+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as rmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.region.regionCode=t.checkSlipUploadDetails.currencyChest.region.regionCode and a.branch.branchTypeCode=22 and length(trim(email)) > 1 and a.forRole.receivers like 'Regional Manager' ) as rmEmail, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as cmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.region.regionCode=t.checkSlipUploadDetails.currencyChest.region.regionCode and a.branch.branchTypeCode=22 and length(trim(email)) > 1 and a.forRole.receivers like 'CM (C&O)' ) as cmEmail, "
    		
			+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as dgmMobileDirect from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and a.forRole.receivers like 'DGM (B&O)') as dgmMobileDirect, "
			+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as cmagmMobileDirect from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and a.forRole.receivers like 'CM/AGM (GB)') as cmagmMobileDirect, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmEmailDirect from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM (B&O)' ) as dgmEmailDirect, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as cmagmEmailDirect from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'CM/AGM (GB)' ) as cmagmEmailDirect, "
	

    		
			+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as dgmMobile from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and a.forRole.receivers like 'DGM (B&O)') as dgmMobile, "
			+ " (select distinct (case when count(distinct mobile)!=1 then null else min(mobile) end) as cmagmMobile from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and a.forRole.receivers like 'CM/AGM (GB)') as cmagmMobile, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM (B&O)' ) as dgmEmail, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as cmagmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and a.branch.network.networkCode=t.checkSlipUploadDetails.currencyChest.network.networkCode and a.branch.module.moduleCode=t.checkSlipUploadDetails.currencyChest.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'CM/AGM (GB)' ) as cmagmEmail, "


			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as agmfsloEmail from AutoAlertsDetails a where abs(a.branch.branchCode)=abs(t.checkSlipUploadDetails.currencyChest.fslo.branchCode) and length(trim(email)) > 1 and a.forRole.receivers like 'AGM FSLO' ) as agmfsloEmail, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmcfoEmail from AutoAlertsDetails a where a.branch.branchTypeCode=18 and a.branch.circle.circleCode=t.checkSlipUploadDetails.currencyChest.circle.circleCode and length(trim(email)) > 1 and a.forRole.receivers like 'DGM & CFO' ) as dgmcfoEmail, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmabdEmail from AutoAlertsDetails a where a.branch.branchCode=3999 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM ABD' ) as dgmabdEmail, "
			+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as abdEmail from AutoAlertsDetails a where a.branch.branchCode=3999 and length(trim(email)) > 1 and a.forRole.receivers like 'ABD DEPT.' ) as abdEmail, "
			
			+ " (select sum(case when sum(t1.totalValue) > t1.checkSlipUploadDetails.currencyChest.cashBalanceLimit*10000000 then 1 else 0 end) from TotalsTable t1 where t1.particular.pid in (10,21) and t1.checkSlipUploadDetails.currencyChest.branchCode = t.checkSlipUploadDetails.currencyChest.branchCode and t1.checkSlipUploadDetails.status like 'New' group by t1.checkSlipUploadDetails.currencyChest.branchCode, t1.checkSlipUploadDetails.status, t1.checkSlipUploadDetails.currencyChest.cashBalanceLimit,t1.checkSlipUploadDetails.chestSlipDate having month(t1.checkSlipUploadDetails.chestSlipDate) = month(t.checkSlipUploadDetails.chestSlipDate) and year(t1.checkSlipUploadDetails.chestSlipDate) = year(t.checkSlipUploadDetails.chestSlipDate)) as monthCount, "
	
			+ " (select NVL(sum(case when sum(t1.totalValue) > t1.checkSlipUploadDetails.currencyChest.cashBalanceLimit*10000000 then 1 else 0 end),-1) from TotalsTable t1 where t1.particular.pid in (10,21) and t1.checkSlipUploadDetails.currencyChest.branchCode = t.checkSlipUploadDetails.currencyChest.branchCode and t1.checkSlipUploadDetails.status like 'New' group by t1.checkSlipUploadDetails.currencyChest.branchCode, t1.checkSlipUploadDetails.status, t1.checkSlipUploadDetails.currencyChest.cashBalanceLimit,t1.checkSlipUploadDetails.chestSlipDate having month(t1.checkSlipUploadDetails.chestSlipDate) = month(t.checkSlipUploadDetails.chestSlipDate) and year(t1.checkSlipUploadDetails.chestSlipDate) = year(t.checkSlipUploadDetails.chestSlipDate) and t1.checkSlipUploadDetails.chestSlipDate > (select NVL(max(case when sum(t2.totalValue) < t2.checkSlipUploadDetails.currencyChest.cashBalanceLimit*10000000 then t2.checkSlipUploadDetails.chestSlipDate end), t.checkSlipUploadDetails.chestSlipDate  ) from TotalsTable t2 where t2.particular.pid in (10,21) and t2.checkSlipUploadDetails.currencyChest.branchCode = t.checkSlipUploadDetails.currencyChest.branchCode and t2.checkSlipUploadDetails.status like 'New' group by t2.checkSlipUploadDetails.currencyChest.branchCode, t2.checkSlipUploadDetails.status, t2.checkSlipUploadDetails.currencyChest.cashBalanceLimit,t2.checkSlipUploadDetails.chestSlipDate having month(t2.checkSlipUploadDetails.chestSlipDate) = month(t.checkSlipUploadDetails.chestSlipDate) and year(t2.checkSlipUploadDetails.chestSlipDate) = year(t.checkSlipUploadDetails.chestSlipDate)) ) as monthConsecutiveCount, "
	
    		
    		+ " sum(totalValue) as closingBalance, "
    		+ " t.checkSlipUploadDetails.currencyChest.cashBalanceLimit*10000000 as cbl, "
    		+ " (select concat(NVL(max(chestSlipDate),''),'')  as lastUploadDate from ChestSlipUploadDetails c where "
    		+ " c.currencyChest.branchCode=t.checkSlipUploadDetails.currencyChest.branchCode)  as lastUploadDate "
    		+ " from TotalsTable t where t.particular.pid in (10,21) and  t.checkSlipUploadDetails.chestSlipDate = (select max(chestSlipDate) from ChestSlipUploadDetails c where c.currencyChest.branchCode=t.checkSlipUploadDetails.currencyChest.branchCode) "
    	//	+ " and t.checkSlipUploadDetails.currencyChest.branchCode in (select distinct a.branch.branchCode from AutoAlertsDetails a) "
    		+ " and t.checkSlipUploadDetails.status like 'New' "
    		+ " group by t.checkSlipUploadDetails.currencyChest.branchCode,"
    		+"  t.checkSlipUploadDetails.chestSlipDate, "
    		+ " t.checkSlipUploadDetails.currencyChest.branchName , "
    		+ " t.checkSlipUploadDetails.currencyChest.region.regionCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.network.networkCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.cashBalanceLimit,"
    		+ " t.checkSlipUploadDetails.currencyChest.fslo.branchCode "
    		+ " having sum(totalValue) > (t.checkSlipUploadDetails.currencyChest.cashBalanceLimit*10000000) "
    		+ " order by t.checkSlipUploadDetails.currencyChest.circle.circleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.network.networkCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.region.regionCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.branchCode asc ")
    List<AutoAlertReportDTO> getAutoAlertBranches();
    
    
    @Query("select t.branchCode as branchCode, "
    		+ "t.branchName as branchName, "
    		+ " t.regionCode as regionCode, "
    		+ " t.moduleName as moduleName, "
    		+ " t.moduleCode as moduleCode, "
    		+ " t.networkCode as networkCode, "
    		+ " t.circleCode as circleCode, "
    		+ " t.circleName as circleName, "
    		+ " t.brachManagerMobileNumber as branchManagerMobile, "
    		+ " t.branchEmailId as branchEmail, "
    		+ " c.cashLimit as cashLimit, "
    		+ " c.reportDate as reportDate, "
    		+"  (c.cashBalance-c.cashLimit) as exceededBy, "
    		+ " (select NVL(sum(c1.exceededLimit),0) as daysExceededInMonth from CashRetentionLimit c1 where c1.branchCode=t.branchCode and MONTH(c1.reportDate) = MONTH(c.reportDate) and YEAR(c1.reportDate) = YEAR(c.reportDate)) as daysExceededInMonth, "
    		
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as cmEmail from AutoAlertsDetailsHbb a where a.branch.circle.circleCode=t.circleCode and a.branch.network.networkCode=t.networkCode and a.branch.module.moduleCode=t.moduleCode and a.branch.region.regionCode=t.regionCode and a.branch.branchTypeCode=22 and length(trim(email)) > 1 and a.forRole.receivers like 'CM (C&O)' ) as cmEmail, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as agmEmail from AutoAlertsDetailsHbb a where a.branch.circle.circleCode=t.circleCode and a.branch.network.networkCode=t.networkCode and a.branch.module.moduleCode=t.moduleCode and a.branch.region.regionCode=t.regionCode and a.branch.branchTypeCode=22 and length(trim(email)) > 1 and a.forRole.receivers like 'Regional Manager' ) as agmEmail, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as dgmEmailDirect from AutoAlertsDetailsHbb a where a.branch.circle.circleCode=t.circleCode and a.branch.network.networkCode=t.networkCode and a.branch.module.moduleCode=t.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM (B&O)' ) as dgmEmailDirect, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as cmagmEmailDirect from AutoAlertsDetailsHbb a where a.branch.circle.circleCode=t.circleCode and a.branch.network.networkCode=t.networkCode and a.branch.module.moduleCode=t.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'CM/AGM (GB)' ) as cmagmEmailDirect, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as dgmEmail from AutoAlertsDetailsHbb a where a.branch.circle.circleCode=t.circleCode and a.branch.network.networkCode=t.networkCode and a.branch.module.moduleCode=t.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM (B&O)' ) as dgmEmail, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as cmagmEmail from AutoAlertsDetailsHbb a where a.branch.circle.circleCode=t.circleCode and a.branch.network.networkCode=t.networkCode and a.branch.module.moduleCode=t.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'CM/AGM (GB)' ) as cmagmEmail, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as agmCircleEmail from AutoAlertsDetailsHbb a where a.branch.branchTypeCode=18 and a.branch.circle.circleCode=t.circleCode and length(trim(email)) > 1 and a.forRole.receivers like 'AGM' ) as agmCircleEmail, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as dgmcfoEmail from AutoAlertsDetailsHbb a where a.branch.branchTypeCode=18 and a.branch.circle.circleCode=t.circleCode and length(trim(email)) > 1 and a.forRole.receivers like 'DGM & CFO' ) as dgmcfoEmail, "
    		+ " (select distinct (case when count(distinct email)>1 then null else min(email) end) as dgmabdEmail from AutoAlertsDetailsHbb a where a.branch.branchCode=3999 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM ABD' ) as dgmabdEmail "

    		+ " from HandBalanceBranch t, CashRetentionLimit c where t.branchCode = c.branchCode and c.exceededLimit=1 and c.liveFlag like 'Y' and c.reportDate = TO_DATE(:date, 'yyyy-MM-dd') "
    		+ " order by t.circleName, t.networkCode, t.moduleCode,  t.regionCode, t.branchCode asc ")
    List<AutoAlertReportDTO> getAutoAlertBranchesHbb(@Param("date") String date);
    
    
}
