package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.RoleComplianceRole;
import sbi.sf.gocblr.cconline.domain.ValueStatement;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.view.VerificationSectionCount;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.repository.EditableRepository;
import sbi.sf.gocblr.cconline.repository.RejectAndSubmitStateRepository;
import sbi.sf.gocblr.cconline.repository.RoleComplianceRoleRepository;
import sbi.sf.gocblr.cconline.repository.ValueStatementRepository;
import sbi.sf.gocblr.cconline.repository.VerificationSectionCountRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.service.dto.ValueStatementComplianceDTO;
import sbi.sf.gocblr.cconline.service.dto.ValueStatementVerificationDTO;
import sbi.sf.gocblr.cconline.utils.TextUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.SubmitRejectVM;

@Service
@RequiredArgsConstructor
public class ValueStatementService {

    private final ValueStatementRepository repo;
    private final VerificationService verificationService;
    private final VerificationSectionService sectionService;
    private final VerificationComplianceService complianceService;

    private final EditableRepository editableRepo;
    private final VerificationSectionCountRepository countRepo;
    private final RejectAndSubmitStateRepository rejectAndSubmitStateRepo;
    private final RoleComplianceRoleRepository complRoleRepository;

    @Transactional(readOnly = true)
    public List<ValueStatementVerificationDTO> valueStatementsWithVerification(long verificationId, long sectionId) {
        Verification v = verificationService.getVerificationById(verificationId);
        VerificationSection section = sectionService.getById(sectionId);
        return repo.valueStatementWithVerification(v, section);
    }

    @Transactional(readOnly = true)
    public List<ValueStatementComplianceDTO> valueStatementsWithCompliance(long verificationId, long sectionId) {
        Verification v = verificationService.getVerificationById(verificationId);
        VerificationSection section = sectionService.getById(sectionId);
        return repo.valueStatementWithCompliance(v, section);
    }

    public ValueStatement getValueStatement(long vsId, long sectionId) {
        return repo
            .findByIdAndSectionId(vsId, sectionId)
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        String.format("No value statement found for verification id %d and section id %d", vsId, sectionId)
                    )
            );
    }

    @Transactional
    public String submitCompliance(long verificationId, SubmitRejectVM im, AppUser user) {
        Verification v = verificationService.getVerificationById(verificationId);

        String role = complianceService.getComplianceRole(user, v);
        var editable = editableRepo.findByVerificationTypeAndForRoleNameAndStatus(v.getType(), role, v.getStatus());

        if (editable.isPresent() && editable.get().getIsEditable().booleanValue()) {
            
        	// maker
            // check all have be attended; no pending
            if (role.equalsIgnoreCase(RoleConstants.BRANCH_USER)) {
                List<VerificationSectionCount> count = countRepo.findByVerificationId(v.getId());
                for (VerificationSectionCount c : count) {
                    if (c.getPending() > 0) {
                        VerificationSection pendingSection = sectionService.getById(c.getSectionId());
                        throw new ValidationException("There are some pending compliance in section", List.of(pendingSection.getName()));
                    }
                }
            } else {
                if (!TextUtils.hasText(im.getComments())) {
                    throw new ValidationException("No comment specified");
                }
            }
            
            var nextState = rejectAndSubmitStateRepo.findByVerificationTypeAndForRoleName(v.getType(), role);
            
            var complRole = complRoleRepository
                .findByVerificationTypeAndForRoleName(v.getType(), role)
                .orElseThrow(() -> new ResourceNotFoundException("No compliance role found for the user role " + role));
            
            if (nextState.isEmpty()) {
                throw new InvalidOperationException(
                    String.format("No next state found for type %s and role %s", v.getType().getName(), role)
                );
            }
            
            v.setStatus(nextState.get().getSubmitState());
            setCommentBasedOnRole(im, v, complRole, user.getId());
            
            return nextState.get().getSubmitStateActionLabel();
        } else {
            throw new InvalidOperationException("Compliance cannot be submitted; as it is not editable be you");
        }
    }

    private void setCommentBasedOnRole(SubmitRejectVM im, Verification v, RoleComplianceRole complRole, long userPfId) {
        switch (complRole.getComplianceRole()) {
            case BRANCH_HEAD:
                v.setBranchHeadComments(im.getComments());
                v.setBranchHeadPfId(userPfId);
                v.setBranchHeadSubmittedOn(LocalDateTime.now());
                break;
            case SCRUTINIZER:
                v.setScrutinizerComments(im.getComments());
                v.setScrutinizerPfId(userPfId);
                v.setScrutinizerSubmittedOn(LocalDateTime.now());
                break;
            case VERIFICATION_OFFICER:
                v.setVerificationOfficerComplianceComments(im.getComments());
                v.setVerificationOfficerCompliancePfId(userPfId);
                v.setVoComplianceSubmittedOn(LocalDateTime.now());
                break;
            case CLOSURE_AUTHORITY:
                v.setClosureComments(im.getComments());
                v.setClosureBy(userPfId);
                v.setClosureOn(LocalDate.now());
                break;
            default:
            	// do nothing
            	break;
        }
    }

    @Transactional
    public String rejectCompliance(Long verificationId, SubmitRejectVM model, AppUser user) {
        Verification v = verificationService.getVerificationById(verificationId);

        String role = complianceService.getComplianceRole(user, v);
        var editable = editableRepo.findByVerificationTypeAndForRoleNameAndStatus(v.getType(), role, v.getStatus());

        if (editable.isPresent() && editable.get().getIsEditable().booleanValue()) {
            var nextState = rejectAndSubmitStateRepo.findByVerificationTypeAndForRoleName(v.getType(), role);
            var complRole = complRoleRepository
                .findByVerificationTypeAndForRoleName(v.getType(), role)
                .orElseThrow(() -> new ResourceNotFoundException("No compliance role found for the user role " + role));
            if (nextState.isEmpty()) {
                throw new InvalidOperationException(
                    String.format("No next state found for type %s and role %s", v.getType().getName(), role)
                );
            }
            v.setStatus(nextState.get().getRejectState());
            setCommentBasedOnRole(model, v, complRole, 99999);
            return nextState.get().getRejectStateActionLabel();
        } else {
            throw new InvalidOperationException("Compliance cannot be rejected; as it is not editable be you");
        }
    }
}
