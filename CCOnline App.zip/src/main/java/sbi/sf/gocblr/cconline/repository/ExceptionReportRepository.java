package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ExceptionReport;
import sbi.sf.gocblr.cconline.service.dto.ExceptionReportDTO;

@Repository
public interface ExceptionReportRepository extends JpaRepository<ExceptionReport, Long> {
    List<ExceptionReport> findByReportDate(@Param("reportDate") LocalDate reportDate);

    List<ExceptionReport> findByReportDateGreaterThan(LocalDate reportDate);

    @Query(
        "SELECT b.circle.circleCode as circleCode, " +
        "       b.circle.circleName as circleName, " +
        "       b.branchCode as branchCode, " +
        "       b.branchName as branchName, " +
        "       e.reportDate as reportDate, " +
        "       e.status as message " +
        "  FROM ExceptionReport e " +
        "       LEFT JOIN Branch b " +
        "              ON e.branchCode = b.branchCode " +
        " WHERE b.circle.circleCode = :circleCode" +
        "   AND e.reportDate > :sinceDate "
    )
    List<ExceptionReportDTO> forMailRemainder(@Param("circleCode") long circleCode, @Param("sinceDate") LocalDate sinceDate);
}
