package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.Nsm;
import sbi.sf.gocblr.cconline.domain.enums.NsmType;

@Transactional
public interface NsmMasterRepository extends JpaRepository<Nsm, Long> {
    List<Nsm> findAll();

    Optional<Nsm> findByMakeIgnoreCaseAndModelIgnoreCaseAndNsmType(String make, String model, NsmType nsmType);
    //	Optional<Nsm> findByMakeIgnoreCaseAndModelIgnoreCaseAndType();

}
