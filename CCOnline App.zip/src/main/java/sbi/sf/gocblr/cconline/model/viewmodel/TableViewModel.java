package sbi.sf.gocblr.cconline.model.viewmodel;

import java.io.Serializable;
import lombok.Data;

@Data
public class TableViewModel<T extends Serializable> {

    private T list;
    private Integer total;
}
