package sbi.sf.gocblr.cconline.repository.custom;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.Module;
import sbi.sf.gocblr.cconline.domain.Network;
import sbi.sf.gocblr.cconline.domain.Region;
import sbi.sf.gocblr.cconline.domain.criteria.VerificationCriteria;
import sbi.sf.gocblr.cconline.domain.criteria.VerificationScrutinyCriteria;
import sbi.sf.gocblr.cconline.model.VerificationModel;
import sbi.sf.gocblr.cconline.model.VerificationsListFilters;
import sbi.sf.gocblr.cconline.service.dto.ForComplianceVerificationListDto;
import sbi.sf.gocblr.cconline.service.dto.VerificationForListModel;
import sbi.sf.gocblr.cconline.web.rest.vm.ComplianceVerificationFilters;
import sbi.sf.gocblr.cconline.web.vm.ClosureListFilter;
import sbi.sf.gocblr.cconline.web.vm.VerificationClosureDto;

public interface CustomizedVerificationRepository {
    List<VerificationForListModel> compliance(VerificationScrutinyCriteria criteria);
    List<VerificationForListModel> verificationsForScrutiny(VerificationScrutinyCriteria criteria);

    Page<VerificationModel> verifications(VerificationCriteria criteria, Pageable pageable);
    VerificationsListFilters filters(VerificationCriteria criteria);
    List<Circle> circles(VerificationCriteria criteria);
    List<Network> networks(VerificationCriteria criteria);
    List<Module> modules(VerificationCriteria criteria);
    List<Region> regions(VerificationCriteria criteria);

    List<ForComplianceVerificationListDto> listForComplianceVerification(ComplianceVerificationFilters filter);
    List<VerificationClosureDto> listForClosure(ClosureListFilter filter);
}
