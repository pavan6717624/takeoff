package sbi.sf.gocblr.cconline.domain.specification;

import org.springframework.data.jpa.domain.Specification;
import sbi.sf.gocblr.cconline.domain.Network;

public class NetworkSpecifications {

    private NetworkSpecifications() {
        // static class
    }

    public static Specification<Network> circleNetworks(long circleCode) {
        return (root, query, cb) -> cb.equal(root.get("circle").get("circleCode"), circleCode);
    }
}
