package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * CC Close Requests
 * @author 6227317
 *
 */
@Data
@Entity
@Table(name = "cc_close_requests")
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CcCloseRequests implements Serializable {

    private static final long serialVersionUID = -4307029167028718304L;

    @Id
    @Column(name = "branch_code")
    @EqualsAndHashCode.Include
    private Long ccCode;

    @MapsId
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "branch_code", foreignKey = @ForeignKey(name = "FK_CC_CLOSE_REQUESTS"))
    private CurrencyChest cc;

    @Column(name = "closed_on")
    private LocalDate closedOn;

    @Column(name = "closed_in_system")
    private LocalDate closedInSystem;

    @Column(name = "closed_by")
    private Long closedBy;
    //    @Column(name = "status")
    //    private CcCloseStatus status;

    //    @Column(name = "message")
    //    private String message;
}
