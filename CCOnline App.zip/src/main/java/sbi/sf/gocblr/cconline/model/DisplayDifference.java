package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DisplayDifference {

    private Double bgl98958balance;
    private Double bgl98908balance;
    private Double ccnotesclosing;
    private Double cccoinsclosing;
    private Double ccnotesdeposit;
    private Double ccnoteswithdrawal;
    private Double cccoinsdeposit;
    private Double cccoinswithdrawal;
    private LocalDate bgl98958Date;
    private LocalDate bgl98908Date;
    private LocalDate ccDate;
    private Long brCode;
    private String brName;
    private String circle;
    private Long region;
    private Long network;
    private Long module;
    private String moduleName;
}
