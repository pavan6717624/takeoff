package sbi.sf.gocblr.cconline.web;

import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.UserSession;
import sbi.sf.gocblr.cconline.model.SsoClaimsModel;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.AppUserDetailsService;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.security.jwt.TokenProvider;
import sbi.sf.gocblr.cconline.service.ActivityLogService;
import sbi.sf.gocblr.cconline.service.UserSessionService;
import sbi.sf.gocblr.cconline.utils.FrontEndUtils;
import sbi.sf.gocblr.cconline.utils.JsonUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.JustResponseMessage;
import sbi.sf.gocblr.cconline.web.vm.DummyLoginViewModel;

/**
 * Handle login related flows
 *
 * @author Kiran Marturu
 *
 */
@Profile("dev")
@Slf4j
@Controller
@RequestMapping("/api")
@RequiredArgsConstructor
public class LoginController {

    private static final String DEV_LOGIN = "devLogin.html";

    private final ApplicationProperties applicationProperties;
    private final TokenProvider tokenProvider;
    private final AppUserDetailsService appUserDetailsService;
    private final UserSessionService userSessionService;
    private final ActivityLogService activityService;

    /**
     * Show's a login page FOR DEV ENVIRONMENT ONLY
     *
     * @param returnUrl The front-end route to which to return after login
     * @param model     Spring model holder
     * @return devLogin thymeleaf template
     */
    @GetMapping("/login")
    public String login(String returnUrl, Model model) {
        if (FrontEndUtils.isValidRoute(returnUrl)) {
            model.addAttribute("returnUrl", returnUrl);
        }
        return DEV_LOGIN;
    }

    /**
     *
     * @param returnUrl
     * @param userId
     * @param model
     * @return
     */
    @PostMapping("/login")
    public String login(DummyLoginViewModel vm, Model model) {
        boolean isLoginSuccessful = false;
        String token = "";
        String message = "";
        String returnUrl = "";

        if (vm.getUserId() != null) {
            try {
                SsoClaimsModel ssoClaimModel = new SsoClaimsModel();
                ssoClaimModel.setPfId(vm.getUserId().longValue());
                ssoClaimModel.setBranchCode(vm.getBranchCode().longValue());
                ssoClaimModel.setPosition(vm.getPosition());
                ssoClaimModel.setEmployeeGroupCode(vm.getEmployeeGroupCode());
                ssoClaimModel.setEmployeeSubGroupCode(vm.getEmployeeSubGroupCode());

                String serializedSsoClaimModel = JsonUtils.toString(ssoClaimModel);

                AppUser appUser = appUserDetailsService.loadUserByUsername(serializedSsoClaimModel);

                UserSession session = userSessionService.createSession(appUser);

                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                    appUser,
                    null,
                    appUser.getAuthorities()
                );

                SecurityContextHolder.getContext().setAuthentication(authentication);

                activityService.logActivity(
                    "LOGIN",
                    Map.of("roles", String.join(",", session.getRoles().stream().map(Role::getAuthority).collect(Collectors.toList())))
                );

                isLoginSuccessful = true;
                token = tokenProvider.createToken(authentication, session.getId());

                if (!FrontEndUtils.isValidRoute(vm.getReturnUrl())) {
                    returnUrl = "";
                }
            } catch (AuthenticationException e) {
                log.trace("auth exception: {}", e.getMessage());
                message = e.getMessage();
            }
        } else {
            message = "User ID not provided.";
        }

        UriComponents frontEndCallBack = UriComponentsBuilder
            .fromHttpUrl(applicationProperties.getFrontEndLoginCallBackUrl())
            .queryParam("isSuccess", isLoginSuccessful)
            .queryParam("token", token)
            .queryParam("message", message)
            .queryParam("returnRoute", returnUrl)
            .build();

        return "redirect:" + frontEndCallBack.toUriString();
    }

    @PostMapping("/logout")
    public ResponseEntity<JustResponseMessage> logoutSession() {
        AppUser loggedInUser = SecurityUtils.getLoggedInUser();

        if (loggedInUser != null) {
            activityService.logActivity("LOGOUT");
            userSessionService.blackListUserSession(loggedInUser.getId(), loggedInUser.getSessionId(), "logged out");
        }

        return ResponseEntity.ok(new JustResponseMessage("Logged out"));
    }

    @GetMapping("/logout")
    public String logout(RedirectAttributes redirect) {
        log.debug(">> logout()");
        return "redirect:" + applicationProperties.getFrontEndUrl();
    }
}
