package sbi.sf.gocblr.cconline.model;

import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.Verification;

public interface BranchAndVerification {
    Branch getBranch();
    Verification getVerification();
}
