package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class StatusSummaryDTO implements StatusSummary {
	
	
	
	String circle;
    Long network;
    String module;
    Long region;
    Long totalCcs;
    Long voNotIdentified;
    Long notStarted;
    Long inProgress;
    Long voReportSubmitted;
    
    Long pendingAtBranch;
    Long pendingAtController;
    Long pendingAtCompliance;
    Long awaitingForClosure;
    Long closed;
	
	  String type;
	    String block;
	    
	    String rmEmail;
		String cmEmail;
		
		String dgmEmail;
		String cmAgmEmail;
		
		String dgmEmailDirect;
		String cmagmEmailDirect;
		
		String agmfsloEmail;
		String dgmcfoEmail;
		String dgmabdEmail;
		String abdEmail;
		String agmCircleEmail;
		
		
		public String toString()
		{
			return totalCcs+" - "+voNotIdentified+" - "+notStarted+" - "+inProgress+" - "+voReportSubmitted+" - "+pendingAtBranch+" - "+pendingAtController+" - "+pendingAtCompliance+" - "+awaitingForClosure+" - "+closed;
		}
		
		

}
