package sbi.sf.gocblr.cconline.exception;

public class InvalidOperationException extends ServiceException {

    private static final long serialVersionUID = -42330983268205839L;

    public InvalidOperationException(String msg) {
        super(msg);
    }
}
