package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Data;

@Data
public class CustomReport {

    String circle;
    Long network;
    Long module;
    String zone;
    Long region;
    Long fslocode;
    String fsloname;
    Long cccode;
    String brname;
    String popcd;
    String state;
    Long cbl;
    LocalDate date;
    Double[] data;
}
