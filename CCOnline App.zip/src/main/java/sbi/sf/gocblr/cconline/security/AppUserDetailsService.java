package sbi.sf.gocblr.cconline.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.User;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.model.SsoClaimsModel;
import sbi.sf.gocblr.cconline.repository.UserRepository;
import sbi.sf.gocblr.cconline.service.BranchMasterService;
import sbi.sf.gocblr.cconline.service.ComplianceVerificationOfficerService;
import sbi.sf.gocblr.cconline.service.CurrencyChestService;
import sbi.sf.gocblr.cconline.service.RoleConstants;
import sbi.sf.gocblr.cconline.service.RoleService;
import sbi.sf.gocblr.cconline.service.UserService;
import sbi.sf.gocblr.cconline.service.VerificationOfficerService;
import sbi.sf.gocblr.cconline.utils.JsonUtils;
import sbi.sf.gocblr.cconline.utils.TextUtils;

/**
 * User principal service
 *
 * @author Kiran Marturu
 *
 */
@Slf4j
@Component("userDetailsService")
@RequiredArgsConstructor
public class AppUserDetailsService implements UserDetailsService {

    private static final int AO_BRANCH_TYPE_CODE = 17;

    private final UserRepository userRepository;
    private final UserService userService;
    private final CurrencyChestService ccService;
    private final RoleService roleService;
    private final VerificationOfficerService voService;
    private final ComplianceVerificationOfficerService compVoService;
    private final BranchMasterService bmService;

    @Override
    @Transactional
    public AppUser loadUserByUsername(String ssoClaims) {
        log.debug(">> loadUserByUsername ({})", ssoClaims);

        ObjectMapper mapper = new ObjectMapper();
        try {
            SsoClaimsModel claims = mapper.readValue(ssoClaims, SsoClaimsModel.class);
            log.trace("sso claims: {}", claims);

            Optional<User> dbUser = userRepository.getById(claims.getPfId());
            log.trace("dbUser: {}", dbUser.isPresent());
            AppUser appUser = null;

            if (dbUser.isPresent() && dbUser.get().isApproved() && Boolean.FALSE.equals(dbUser.get().getIsDeleted())) {
                appUser = caseWhenUserIsPresentInDb(claims, dbUser.get());
            } else {
                // case when user is not present in DB

                // 1: is currency chest branch
                Optional<CurrencyChest> cc = ccService.byBranchCode(claims.getBranchCode());
                Branch branch = bmService.getBranch(claims.getBranchCode());

                if (cc.isPresent() && isOfficer(claims.getEmployeeGroupCode())) {
                    appUser = new AppUser();
                    appUser.setId(claims.getPfId());
                    appUser.setTitle(claims.getTitle());
                    appUser.setName(claims.getName());
                    appUser.setBranchCode(cc.get().getBranchCode());
                    appUser.setBranchName(cc.get().getBranchName());
                    appUser.setCircleCode(cc.get().getCircle().getCircleCode());
                    appUser.setNetworkCode(cc.get().getNetwork().getNetworkCode());
                    appUser.setModuleCode(cc.get().getModule().getModuleCode());
                    appUser.setRegionCode(cc.get().getRegion().getRegionCode());

                    Set<Role> newRoles = new HashSet<>();
                    if (claims.getPosition().endsWith("001")) {
                        newRoles.add(roleService.getByName(RoleConstants.BRANCH_HEAD));
                    } else {
                        newRoles.add(roleService.getByName(RoleConstants.BRANCH_USER));
                    }
                    appUser.setRoles(newRoles);
                }
                // RBO or AO
                else if (isRegionalManager(claims, branch)) {
                    appUser = createAppUserFromBranchAndSsoClaims(claims, branch);
                    appUser.getRoles().add(roleService.getByName(RoleConstants.RM));
                } else if (isCmAtRbo(claims, branch)) {
                    appUser = createAppUserFromBranchAndSsoClaims(claims, branch);
                    appUser.getRoles().add(roleService.getByName(RoleConstants.RBO_CM));
                } else if (isRboDeskOfficer(claims, branch)) {
                    appUser = createAppUserFromBranchAndSsoClaims(claims, branch);
                    appUser.getRoles().add(roleService.getByName(RoleConstants.RBO_DESK_OFFICER));
                } else if (isDgmAtAo(claims, branch)) {
                    appUser = createAppUserFromBranchAndSsoClaims(claims, branch);
                    appUser.getRoles().add(roleService.getByName(RoleConstants.DGM_BO));
                } else if (isAgmGb(claims, branch)) {
                    appUser = createAppUserFromBranchAndSsoClaims(claims, branch);
                    appUser.getRoles().add(roleService.getByName(RoleConstants.AGM_GB));
                } else if (isAoOfficer(claims, branch) && !isDgmAtAo(claims, branch)) {
                    appUser = createAppUserFromBranchAndSsoClaims(claims, branch);
                    appUser.getRoles().add(roleService.getByName(RoleConstants.AO_USER));
                } else if (isCgm(claims, branch)) {
                    appUser = createAppUserFromBranchAndSsoClaims(claims, branch);
                    appUser.getRoles().add(roleService.getByName(RoleConstants.CGM_CIRCLE));
                }
            }

            // Check if any verifications assigned
            if (
                voService.anyVerificationsAssigned(claims.getPfId()) || compVoService.anyComplianceVerificationsAssigned(claims.getPfId())
            ) {
                Role voRole = roleService.getByName(RoleConstants.VERIFICATION_OFFICER);
                if (appUser == null) {
                    // has other role also
                    appUser = new AppUser();
                    appUser.setId(claims.getPfId());
                    appUser.setTitle(claims.getTitle());
                    appUser.setName(claims.getName());
                    appUser.setBranchCode(claims.getBranchCode());
                    appUser.setBranchName(claims.getBranchName());
                    Set<Role> roles = new HashSet<>();
                    roles.add(voRole);
                    appUser.setRoles(roles);
                } else {
                    // only verifications
                    Set<Role> existingRoles = appUser.getRoles();
                    Set<Role> additionalRoles = new HashSet<>(existingRoles);
                    additionalRoles.add(voRole);
                    appUser.setRoles(additionalRoles);
                }
            }

            if (appUser == null) {
                throw new UsernameNotFoundException(
                    String.format("User not found/not authorized/no verification assigned for ID: %s", claims.getPfId())
                );
            }

            return appUser;
        } catch (JsonProcessingException e) {
            throw new BadCredentialsException("Invalid/no data recieved from sso");
        }
    }

    private AppUser caseWhenUserIsPresentInDb(SsoClaimsModel claims, User dbUser) {
        log.debug("User {} is present in DB", claims.getPfId());

        AppUser appUser = new AppUser();
        appUser.setId(dbUser.getId());
        appUser.setTitle(dbUser.getTitle());
        appUser.setName(dbUser.getName());
        appUser.setBranchCode(dbUser.getBranch().getBranchCode());
        appUser.setBranchName(dbUser.getBranch().getBranchName());
        appUser.setCircleCode(dbUser.getBranch().getCircle().getCircleCode());

        if (!dbUser.getBranch().getBranchCode().equals(claims.getBranchCode())) {
            log.debug("roles: {}", JsonUtils.toString(dbUser.getRoles()));

            if (dbUser.getRoles().stream().anyMatch(r -> RoleConstants.SECURITY_OFFICER.equalsIgnoreCase(r.getName()))) {
                try {
                    Branch newBranch = userService.updateUserBranchCode(dbUser, claims.getBranchCode());
                    appUser.setBranchCode(newBranch.getBranchCode());
                    appUser.setBranchName(newBranch.getBranchName());
                } catch (ResourceNotFoundException rnfe) {
                    throw new BadCredentialsException(
                        String.format("Branch not found for branch code: %d. Contact helpdesk.", claims.getBranchCode()),
                        rnfe
                    );
                }
            } else {
                // userService.updateUserBranchCodeAndRevertDeletion(dbUser, claims.getBranchCode());

                userService.deleteUser(
                    dbUser,
                    String.format("branch code changed from %d to %d", dbUser.getBranch().getBranchCode(), claims.getBranchCode())
                );

                throw new UsernameNotFoundException(
                    "User has been deleted as branch code is changed, try login again for autologin roles."
                );
            }
        }

        if (dbUser.getNetwork() != null) {
            appUser.setNetworkCode(dbUser.getNetwork().getNetworkCode());
        }

        // for fslo user fslo code to be updated with branch code
        if (dbUser.getRoles().stream().anyMatch(r -> RoleConstants.FSLO_USER.equalsIgnoreCase(r.getName()))) {
            if (dbUser.getFslo() != null) {
                appUser.setBranchCode(dbUser.getFslo().getBranchCode());
                appUser.setBranchName(dbUser.getFslo().getBranchName());
            }
        }

        appUser.setModuleCode(dbUser.getBranch().getModule().getModuleCode());
        appUser.setRegionCode(dbUser.getBranch().getRegion().getRegionCode());
        appUser.setRoles(dbUser.getRoles());

        log.debug("returning app user: {}", appUser);

        return appUser;
    }

    private boolean isAgmGb(SsoClaimsModel claims, Branch branch) {
        if (branch.getBranchTypeCode() != null && claims.getEmployeeSubGroupCode() != null) {
            return (
                branch.getBranchTypeCode() == AO_BRANCH_TYPE_CODE &&
                (
                    claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O5") ||
                    claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O4")
                )
            );
        }
        return false;
    }

    private boolean isAoOfficer(SsoClaimsModel claims, Branch branch) {
        if (branch.getBranchTypeCode() == null) {
            return false;
        }
        return branch.getBranchTypeCode() == AO_BRANCH_TYPE_CODE && isOfficer(claims.getEmployeeGroupCode());
    }

    private boolean isCmAtRbo(SsoClaimsModel claims, Branch branch) {
        if (branch.getBranchTypeCode() == null || claims.getEmployeeSubGroupCode() == null) {
            return false;
        }
        return isRbo(branch) && claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O4");
    }

    private boolean isDgmAtAo(SsoClaimsModel claims, Branch branch) {
        if (branch.getBranchTypeCode() == null || claims.getEmployeeSubGroupCode() == null) {
            return false;
        }
        return (
            isAo(branch) &&
            (
                claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O6") ||
                claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O7")
            )
        );
    }

    private boolean isCgm(SsoClaimsModel claims, Branch branch) {
        if (branch.getBranchTypeCode() == null || claims.getEmployeeSubGroupCode() == null) {
            return false;
        }
        return claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O8");
    }

    private boolean isRegionalManager(SsoClaimsModel claims, Branch branch) {
        if (branch.getBranchTypeCode() == null || claims.getEmployeeSubGroupCode() == null) {
            return false;
        }

        log.trace("isRegionalManager: {}", claims.getEmployeeSubGroupCode());

        return (
            isRbo(branch) &&
            (
                claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O5") ||
                claims.getEmployeeSubGroupCode().trim().equalsIgnoreCase("O6")
            )
        );
    }

    private boolean isRboDeskOfficer(SsoClaimsModel claims, Branch branch) {
        if (branch.getBranchTypeCode() == null) {
            return false;
        }
        return isRbo(branch) && isOfficer(claims.getEmployeeGroupCode());
    }

    private boolean isRbo(Branch branch) {
        if (branch.getBranchTypeCode() == null) {
            return false;
        }
        return branch.getBranchTypeCode() == 22 || branch.getBranchTypeCode() == 21;
    }

    private boolean isAo(Branch branch) {
        if (branch.getBranchTypeCode() == null) {
            return false;
        }
        return branch.getBranchTypeCode() == AO_BRANCH_TYPE_CODE;
    }

    private AppUser createAppUserFromBranchAndSsoClaims(SsoClaimsModel claims, Branch branch) {
        AppUser appUser;
        appUser = new AppUser();
        appUser.setId(claims.getPfId());
        appUser.setTitle(claims.getTitle());
        appUser.setName(claims.getName());
        appUser.setBranchCode(branch.getBranchCode());
        appUser.setBranchName(branch.getBranchName());
        appUser.setCircleCode(branch.getCircle().getCircleCode());
        appUser.setNetworkCode(branch.getNetwork().getNetworkCode());
        appUser.setModuleCode(branch.getModule().getModuleCode());
        appUser.setRegionCode(branch.getRegion().getRegionCode());
        return appUser;
    }

    private boolean isOfficer(String employeeGroupCode) {
        if (TextUtils.hasText(employeeGroupCode)) {
            return employeeGroupCode.trim().equalsIgnoreCase("O") || employeeGroupCode.trim().equalsIgnoreCase("S");
        }
        return false;
    }
}
