package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EisHrmsRequest {

    @JsonProperty("PF_NUMBER")
    private String pfNumber;

    @JsonProperty("SOURCE_ID")
    private String sourceId;
}
