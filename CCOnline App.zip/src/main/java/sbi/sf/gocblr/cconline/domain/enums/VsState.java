package sbi.sf.gocblr.cconline.domain.enums;

public enum VsState {
    NOT_COMMENTED("NC", "Not Commented"),
    COMMENTED("C", "Commented"),
    ACCEPTED("A", "Accepted"),
    REJECTED("R", "Rejected"),
    SUBMITTED("S", "Submitted"),
    CLOSURE("C", "Closure");

    private final String code;
    private final String description;

    VsState(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static VsState fromCode(String code) {
        for (var v : VsState.values()) {
            if (v.code().equalsIgnoreCase(code)) {
                return v;
            }
        }
        return NOT_COMMENTED;
    }
}
