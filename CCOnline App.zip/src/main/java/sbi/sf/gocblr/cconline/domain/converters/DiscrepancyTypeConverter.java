package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.DiscrepancyType;

@Converter(autoApply = true)
public class DiscrepancyTypeConverter implements AttributeConverter<DiscrepancyType, String> {

    @Override
    public String convertToDatabaseColumn(DiscrepancyType discrepancyType) {
        if (discrepancyType == null) {
            return null;
        }
        return discrepancyType.code();
    }

    @Override
    public DiscrepancyType convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return DiscrepancyType.fromCode(code);
    }
}
