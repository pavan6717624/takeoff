package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class SmsApiResponse {

    private String umid;
    private int errorCode;
    private String errorDescription;
}
