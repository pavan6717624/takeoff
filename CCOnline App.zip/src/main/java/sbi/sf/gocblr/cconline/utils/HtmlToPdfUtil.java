package sbi.sf.gocblr.cconline.utils;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import java.io.BufferedOutputStream;
import java.io.IOException;

public class HtmlToPdfUtil {

    public static void writePdfToStream(BufferedOutputStream bufOs, String html) throws IOException {
        final PdfRendererBuilder pdfBuilder = new PdfRendererBuilder();
        pdfBuilder.useFastMode();
        pdfBuilder.withHtmlContent(html, "");
        pdfBuilder.toStream(bufOs);
        pdfBuilder.run();
    }
}
