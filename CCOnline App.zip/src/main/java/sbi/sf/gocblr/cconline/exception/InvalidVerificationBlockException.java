package sbi.sf.gocblr.cconline.exception;

public class InvalidVerificationBlockException extends ServiceException {

    private static final long serialVersionUID = -5985513392225483061L;

    public InvalidVerificationBlockException(String msg) {
        super(msg);
    }
}
