package sbi.sf.gocblr.cconline.model;

import lombok.Value;
import sbi.sf.gocblr.cconline.domain.Verification;

@Value
public class VerificationModel {

    private String circleName;
    private Long networkCode;
    private Long moduleCode;
    private String moduleName;
    private Long regionCode;
    private Long branchCode;
    private String branchName;
    private Verification verification;

    private String verificationStatus;

    public VerificationModel(
        String circleName,
        Long networkCode,
        Long moduleCode,
        String moduleName,
        Long regionCode,
        Long branchCode,
        String branchName,
        Verification verification
    ) {
        this.circleName = circleName;
        this.networkCode = networkCode;
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
        this.regionCode = regionCode;
        this.branchCode = branchCode;
        this.branchName = branchName;
        this.verification = verification;

        if (verification == null || verification.getStatus() == null) {
            this.verificationStatus = "--";
        } else {
            this.verificationStatus = verification.getStatus().description();
        }
    }
}
