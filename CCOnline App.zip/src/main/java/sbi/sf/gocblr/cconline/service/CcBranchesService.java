package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.repository.CcBranchesRepository;
import sbi.sf.gocblr.cconline.service.dto.CcBranchesSummaryReport;
import sbi.sf.gocblr.cconline.service.dto.CcClosedBranchesReport;

@Slf4j
@Service
@RequiredArgsConstructor
public class CcBranchesService {

    private final CcBranchesRepository ccBranchesRepository;

    // for CC branches summary
    public List<CcBranchesSummaryReport> getCcBranchesSummaryReport(@NotNull LocalDate asOn) {
        log.trace("Month: {} ", asOn);

        return ccBranchesRepository.getCcBranchesSummaryReport(asOn);
    }

    // for CC closed branches list
    public List<CcClosedBranchesReport> getCcBranchesClosedReport(@NotNull LocalDate fromDate, @NotNull LocalDate toDate) {
        log.trace("fromDate: {} ", fromDate);
        log.trace("toDate: {} ", toDate);

        return ccBranchesRepository.getCcBranchesClosedReport(fromDate, toDate);
    }
}
