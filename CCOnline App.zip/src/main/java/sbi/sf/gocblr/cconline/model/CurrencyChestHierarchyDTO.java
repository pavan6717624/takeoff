package sbi.sf.gocblr.cconline.model;

public interface CurrencyChestHierarchyDTO {
    String getCircleName();
    Long getModuleCode();
    Long getNetworkCode();
    Long getRegionCode();
}
