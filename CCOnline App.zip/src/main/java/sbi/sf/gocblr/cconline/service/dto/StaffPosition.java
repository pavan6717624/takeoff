package sbi.sf.gocblr.cconline.service.dto;

import java.io.Serializable;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class StaffPosition implements Serializable {

    private static final long serialVersionUID = -2120797240322744553L;

    private Integer award;
    private Integer supervisory;

    public int total() {
        return award + supervisory;
    }
}
