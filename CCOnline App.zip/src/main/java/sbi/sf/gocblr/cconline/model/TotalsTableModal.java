package sbi.sf.gocblr.cconline.model;

import lombok.Data;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;

/**
 *
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
public class TotalsTableModal {

    private Long id;

    private Double totalPieces;

    private Double totalValue;

    private ChestSlipParticular particular;

    private ChestSlipUploadDetails checkSlipUploadDetails;
}
