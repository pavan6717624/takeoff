package sbi.sf.gocblr.cconline.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.EmailStatus;
import sbi.sf.gocblr.cconline.repository.EmailStatusRepository;
import sbi.sf.gocblr.cconline.utils.JsonUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class MailSenderService {

    private final ApplicationProperties app;
    private final Environment env;

    private final JavaMailSender javaMailSender;
    
    private final EmailStatusRepository emailRepository;
    
    private final BGLStatementService bglService;

    @Async
    public void sendEmailAsync(String[] to, String[] cc, String subject, String content, boolean isHtml) {
        log.trace(">> sendEmailAsync()");

        boolean isDev = env.acceptsProfiles(Profiles.of("dev"));
        boolean isProd = env.acceptsProfiles(Profiles.of("prod"));

        // only send to actual email in prod, else send to dummy email id from configuration
        if (isDev) {
            log.debug("Sending email (html: {})...", isHtml);
            log.debug("To: {} | CC: {}", to, cc);
            log.debug("Subject: {}", subject);
            log.debug("Content: {}", content);
            
            sendEmail(new String[] { app.getMailReceiverEmail() }, new String[0], subject, content, isHtml);
            
            
//            LocalDateTime localDateTime = LocalDateTime.now();
//            
//            ZonedDateTime zdt = ZonedDateTime.of(localDateTime, ZoneId.systemDefault());
//            long date = zdt.toInstant().toEpochMilli();
//            
//            FileOutputStream output;
//			try {
//				output = new FileOutputStream("e:\\email_"+date+".html");
//				  output.write(("TO :: "+Arrays.asList(to)+"<br/>").getBytes());
//		            output.write(("CC :: "+Arrays.asList(cc)+"<br/>").getBytes());
//		            output.write(("Subject :: "+subject+"<br/>").getBytes());
//		            output.write(("Content :: "+content+"<br/>").getBytes());
//		            output.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
          
            
        } else if (isProd) {
            sendEmail(to, cc, subject, content, isHtml);
        } else {
            sendEmail(new String[] { app.getMailReceiverEmail() }, new String[0], subject, content, isHtml);
        }
    }

    
    
    
    public void sendEmail(String[] to, String[] cc, String subject, String content, boolean isHtml) {
        log.info("sending email for to: '{}' | cc: '{}'", to, cc);
        log.debug("subject: {}", subject);
        log.debug("content: {}", content);

        JavaMailSender ms = javaMailSender;
        String from = app.getMailAppEmail();

        try {
            MimeMessage mimeMessage = ms.createMimeMessage();
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, StandardCharsets.UTF_8.name());

            message.setFrom(from);
            
            to = Arrays.stream(to)
                    .filter(s -> (s != null && s.trim().length() > 0))
                    .toArray(String[]::new);  
            
            if (to == null ||  to.length == 0) {
            	log.info("TO Email ids not found");
                return;
            }

            
            message.setTo(to);
            if (cc != null && cc.length > 0) {
                message.setCc(cc);
            }
            message.setSubject(subject);
            
            
            content=content.replaceAll(">null<","><");
            
            
            if(subject.startsWith("ABD - ") || subject.startsWith("Circle - "))
            {
            	
            	String attachment=content.replaceAll(",","");
              	attachment=attachment.substring(attachment.indexOf("<tr>")+4);
            	attachment=attachment.replaceAll("<tr>","\n");
            	attachment=attachment.replaceAll("<tr align='center'>","\n");
            	attachment=attachment.replaceAll("<tr align='left'>","\n");
            	attachment=attachment.replaceAll("<tr align='right'>","\n");
            	attachment=attachment.replaceAll("<th>",",");
            	attachment=attachment.replaceAll("<td>",",");
            	attachment=attachment.replaceAll("<td align='center'>",",");
            	attachment=attachment.replaceAll("<td align='left'>",",");
            	attachment=attachment.replaceAll("<td align='right'>",",");            	
            	attachment=attachment.replaceAll("</td>","");
            	attachment=attachment.replaceAll("</th>","");
            	attachment=attachment.replaceAll("</tr>","");
            	attachment=attachment.replaceAll("</table>","");
            	attachment=attachment.replaceAll("</html>","");
            	
            	String date=subject.substring(subject.indexOf(":")+1).trim();
            	String type="CC";
            	if(subject.contains("Hand"))
            		type="HB";
            	
            	
            byte[] doc = attachment.getBytes();

            message.addAttachment(type+"_Branches_"+date+".csv", new ByteArrayResource(doc));
            } 
            
            if(subject.startsWith("VERIFICATION - "))
            {
            	byte[] pdfReport = null;
            	try {
            		pdfReport=bglService.generatePDF(content);
            		String date=subject.substring(subject.indexOf(":")+1).trim();
            		
            		message.addAttachment("Verification_"+date+".pdf", new ByteArrayResource(pdfReport));
				} catch (IOException e) {
					 log.warn("error sending verification alert email to '{}' , {}", to, e.getMessage());
					
				}
            	
            }            
            
            message.setText(content, isHtml);

            send(mimeMessage);

            log.info("sent email to '{}' using PR", JsonUtils.toString(to));
        } catch (MailSendException mse) {
            try {
                MimeMessage mimeMessage = drMailSender().createMimeMessage();
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage, false, StandardCharsets.UTF_8.name());

                message.setFrom(from);
               
              
                
                to = Arrays.stream(to)
                        .filter(s -> (s != null && s.trim().length() > 0))
                        .toArray(String[]::new);  
                
                if (to == null ||  to.length == 0) {
                	log.info("TO Email ids not found");
                    return;
                }

                message.setTo(to);
                if (cc != null && cc.length > 0) {
                    message.setCc(cc);
                }
                
                
                
                message.setSubject(subject);

                send(mimeMessage);
                message.setText(content, isHtml);
            } catch (MailSendException | MessagingException e) {
                log.warn("error sending email to '{}' using DR : {}", to, e.getMessage());
            }
        } catch (MailException | MessagingException e) {
            log.warn("error sending email to '{}' using PR : {}", to, e.getMessage());
        }
    }

    private void send(MimeMessage mimeMessage)  {
        try {
            javaMailSender.send(mimeMessage);
            try
            {
            EmailStatus estatus=new EmailStatus();
           // estatus.setContent(mimeMessage.getContent().toString());
            estatus.setEmailId(mimeMessage.getRecipients(RecipientType.TO)[0].toString());
            estatus.setSubject(mimeMessage.getSubject());
            estatus.setSentOn(LocalDateTime.now());
            emailRepository.save(estatus);
            }
            catch(MessagingException ex)
            {
            	 log.warn("error email status logging to DB - 1  : {}", ex.getMessage());
            }
           } catch (MailSendException mse) {
            drMailSender().send(mimeMessage);
            try
            {
            EmailStatus estatus=new EmailStatus();
           // estatus.setContent(mimeMessage.getContent().toString());
            estatus.setEmailId(mimeMessage.getAllRecipients()[0].toString());
            estatus.setSubject(mimeMessage.getSubject());
            estatus.setSentOn(LocalDateTime.now());
            emailRepository.save(estatus);
            }
            catch(MessagingException ex)
            {
            	log.warn("error email status logging to DB - 2  : {}", ex.getMessage());
            }
        }
    }

    public JavaMailSender drMailSender() {
        JavaMailSenderImpl drMailSender = new JavaMailSenderImpl();
        drMailSender.setHost(app.getMailServerDr());
        drMailSender.setPort(app.getMailServerPortPr());
        drMailSender.setUsername(app.getMailServerUsername());
        drMailSender.setPassword(app.getMailServerPassword());
        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        drMailSender.setJavaMailProperties(props);

        return drMailSender;
    }
}
