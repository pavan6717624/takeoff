package sbi.sf.gocblr.cconline.constants;

public class ErrorMessage {

    private ErrorMessage() {
        // static utils class
    }

    public static final String CONTACT_HELPDESK = "An error occured. Contact application helpdesk";
}
