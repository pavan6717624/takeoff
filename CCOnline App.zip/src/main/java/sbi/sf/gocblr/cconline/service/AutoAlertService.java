package sbi.sf.gocblr.cconline.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.AutoAlertsDetails;
import sbi.sf.gocblr.cconline.domain.AutoAlertsDetailsHbb;
import sbi.sf.gocblr.cconline.domain.AutoAlertsRecipients;
import sbi.sf.gocblr.cconline.domain.AutoAlertsRecipientsHbb;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.CashRetentionLimit;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.HandBalanceBranch;
import sbi.sf.gocblr.cconline.domain.HandBalanceBranchDummy;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.SftpHbbStatus;
import sbi.sf.gocblr.cconline.model.AutoAlertReportDTO;
import sbi.sf.gocblr.cconline.model.AutoAlertsDTO;
import sbi.sf.gocblr.cconline.model.AutoAlertsData;
import sbi.sf.gocblr.cconline.model.StatusDTO;
import sbi.sf.gocblr.cconline.model.StatusSummary;
import sbi.sf.gocblr.cconline.model.StatusSummaryDTO;
import sbi.sf.gocblr.cconline.repository.AutoAlertsHbbRepository;
import sbi.sf.gocblr.cconline.repository.AutoAlertsRecipientsHbbRepository;
import sbi.sf.gocblr.cconline.repository.AutoAlertsRecipientsRepository;
import sbi.sf.gocblr.cconline.repository.AutoAlertsRepository;
import sbi.sf.gocblr.cconline.repository.AutoSmsResponseRepository;
import sbi.sf.gocblr.cconline.repository.BranchRepository;
import sbi.sf.gocblr.cconline.repository.CashRetentionLimitRepository;
import sbi.sf.gocblr.cconline.repository.ChestSlipsRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.HandBalanceBranchDummyRepository;
import sbi.sf.gocblr.cconline.repository.HandBalanceBranchRepository;
import sbi.sf.gocblr.cconline.repository.RoleRepository;
import sbi.sf.gocblr.cconline.repository.SftpHbbStatusRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.utils.DateUtils;

@Slf4j
@Service
@RequiredArgsConstructor

public class AutoAlertService {

	private Session session = null;
	private final AutoAlertsRepository alertsRepository;
	private final AutoAlertsHbbRepository alertsHbbRepository;
	private final RoleRepository roleRepository;
	private final BranchRepository branchRepository;
	private final CurrencyChestRepository currestChestRepository;
	private final AutoAlertsRecipientsRepository autoAlertsRecipientsRepository;
	private final AutoAlertsRecipientsHbbRepository autoAlertsRecipientsHbbRepository;

	private final ChestSlipsRepository chestSlipsRepository;
	private final SmsService smsService;
	private final ChestSlipUploadService chestSlipUploadService;
	private final MailSenderService mailSenderService;
	
	private final HandBalanceBranchRepository handBalanceBranchRepository;
	private final HandBalanceBranchDummyRepository handBalanceBranchDummyRepository;

	private final NumberFormat commaFormatter = new DecimalFormat("###.##");
	private final NumberFormat branchFormatter = new DecimalFormat("00000");

	private final AutoSmsResponseRepository autoSmsResponseRepository;

	private final ApplicationProperties applicationProperties;

	private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	private final CashRetentionLimitRepository crlRepository;
	
	private final SftpHbbStatusRepository sftpHbbStatusRepository;
	
	

	public List<AutoAlertsDTO> getAutoAlertSettings() {
		AppUser user = SecurityUtils.getLoggedInUser();
		Set<Role> roles = user.getRoles();

		Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
		Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
		Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
		Role RM = roleRepository.findByName(RoleConstants.RM).get();

		Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
		Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
		Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
		Role ABD_USER = roleRepository.findByName(RoleConstants.ABD_USER).get();
		Role DGM_BO = roleRepository.findByName(RoleConstants.DGM_BO).get();

		List<AutoAlertsDTO> alertDetails = null;

		if (roles.contains(BRANCH_USER) || roles.contains(BRANCH_HEAD)) {
			alertDetails = alertsRepository.findByBranchCode(user.getBranchCode(), "BRANCH");

		} else if (roles.contains(RBO_CM) || roles.contains(RM)) {
			alertDetails = alertsRepository.findByBranchCode(user.getBranchCode(), "RBO");
		} else if (roles.contains(AGM_GB) || roles.contains(DGM_BO)) {
			alertDetails = alertsRepository.findByBranchCode(user.getBranchCode(), "AO");
		} else if (roles.contains(FSLO_USER) || roles.contains(CIRCLE_ADMIN)) {

			List<AutoAlertsDTO> alerts = new ArrayList<>();

			if (roles.contains(FSLO_USER))
				alerts.addAll(alertsRepository.findByBranchCode(user.getBranchCode(), "FSLO"));
			if (roles.contains(CIRCLE_ADMIN))
				alerts.addAll(alertsRepository.findByBranchCode(user.getBranchCode(), "CIRCLE"));

			alertDetails = alerts;

		}

		else if (roles.contains(ABD_USER)) {
			alertDetails = alertsRepository.findByBranchCode(user.getBranchCode(), "CC");
		}

		return alertDetails;
	}

	public List<AutoAlertsDTO> getAutoAlertHbbSettings() {
		AppUser user = SecurityUtils.getLoggedInUser();
		Set<Role> roles = user.getRoles();

		Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
		Role RM = roleRepository.findByName(RoleConstants.RM).get();

		Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
		Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
		Role ABD_USER = roleRepository.findByName(RoleConstants.ABD_USER).get();
		Role DGM_BO = roleRepository.findByName(RoleConstants.DGM_BO).get();

		List<AutoAlertsDTO> alertDetails = null;

		if (roles.contains(RBO_CM) || roles.contains(RM)) {
			alertDetails = alertsHbbRepository.findByBranchCode(user.getBranchCode(), "RBO");
		} else if (roles.contains(AGM_GB) || roles.contains(DGM_BO)) {
			alertDetails = alertsHbbRepository.findByBranchCode(user.getBranchCode(), "AO");
		} else if (roles.contains(CIRCLE_ADMIN)) {
			alertDetails = alertsHbbRepository.findByBranchCode(user.getBranchCode(), "CIRCLE");
		}

		else if (roles.contains(ABD_USER)) {
			alertDetails = alertsHbbRepository.findByBranchCode(user.getBranchCode(), "CC");
		}

		return alertDetails;
	}

	@Transactional
	public Boolean updateAutoAlertSettings(AutoAlertsData alertDetails) {

		// System.out.println(alertDetails+" "+alertDetails.getBrcode());

		Branch branch = branchRepository.findById(alertDetails.getBrcode()).get();

		AutoAlertsRecipients forRole = autoAlertsRecipientsRepository.findById(alertDetails.getRoleId()).get();

		if (forRole.getForRole().equals("BRANCH")) {
			CurrencyChest chest = currestChestRepository.findById(alertDetails.getBrcode()).get();

			if (forRole.getReceivers().equals("Branch Manager")) {
				chest.getCcEmployeeDetails().setBmId(alertDetails.getPfid().intValue());
				chest.getCcEmployeeDetails().setBmName(alertDetails.getName());
				chest.getCcEmployeeDetails().setBmMobileNo(alertDetails.getMobile());
			}

			else if (forRole.getReceivers().equals("Cash Officer")) {
				chest.getCcEmployeeDetails().setCoId(alertDetails.getPfid().intValue());
				chest.getCcEmployeeDetails().setCoName(alertDetails.getName());
				chest.getCcEmployeeDetails().setCoMobileNo(alertDetails.getMobile());
			}

			else if (forRole.getReceivers().equals("Accountant")) {
				chest.getCcEmployeeDetails().setAccountantId(alertDetails.getPfid().intValue());
				chest.getCcEmployeeDetails().setAccountantName(alertDetails.getName());
				chest.getCcEmployeeDetails().setAccountantMobileNo(alertDetails.getMobile());
			}

			currestChestRepository.save(chest);
		}

		Optional<AutoAlertsDetails> saveAlert = alertsRepository.findByForRoleAndBranch(forRole, branch);

		AutoAlertsDetails saveAlertDetails = new AutoAlertsDetails();

		if (saveAlert.isPresent())

			saveAlertDetails = saveAlert.get();

		saveAlertDetails.setBranch(branchRepository.findById(alertDetails.getBrcode()).get());

		saveAlertDetails.setDesignation(alertDetails.getDesignation());
		saveAlertDetails.setEmail(alertDetails.getEmail());
		saveAlertDetails.setMobile(alertDetails.getMobile());
		saveAlertDetails.setName(alertDetails.getName());
		saveAlertDetails.setPfid(alertDetails.getPfid());
		saveAlertDetails.setUpdatedBy(SecurityUtils.getLoggedInUser().getId());
		saveAlertDetails.setForRole(autoAlertsRecipientsRepository.findById(alertDetails.getRoleId()).get());

		alertsRepository.save(saveAlertDetails);

		if (saveAlertDetails.getId() != null)
			return true;
		else
			return false;

	}

	@Transactional
	public StatusDTO updateAutoAlertHbbSettings(AutoAlertsData alertDetails) {

		// System.out.println(alertDetails+" "+alertDetails.getBrcode());
		
		StatusDTO status=new StatusDTO();
		
		Long checkSum=0l;
    	
    	checkSum+=alertDetails.getPfid()+alertDetails.getBrcode()+alertDetails.getMobile()+alertDetails.getRoleId();
    	
    	for(int i=0;i<alertDetails.getDesignation().length();i++)
    	    checkSum+=(int) alertDetails.getDesignation().charAt(i);
    	
       	for(int i=0;i<alertDetails.getEmail().length();i++)
    	    checkSum+=(int) alertDetails.getEmail().charAt(i);
       	
       	for(int i=0;i<alertDetails.getName().length();i++)
    	    checkSum+=(int) alertDetails.getName().charAt(i);
       	
       	for(int i=0;i<alertDetails.getRole().length();i++)
    	    checkSum+=(int) alertDetails.getRole().charAt(i);
       	
       	if(checkSum.compareTo(alertDetails.getCheckSum())!=0)
       	{
       		status.setMessage("Cannot Process the Data. Invalid Data Received.");
       		status.setStatus(false);
       		return status;
       	}
       	
    	
       	String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
 	   Pattern pattern = Pattern.compile(regex);
 	   Matcher matcher = pattern.matcher(alertDetails.getEmail());
 	   if(!matcher.matches())
 	   {
 		  status.setMessage("Cannot Process the Data. Invalid Email Id. Received.");
     		status.setStatus(false);
     		return status;
 	   }

        
		
		AppUser user = SecurityUtils.getLoggedInUser();
		
		//System.out.println(alertDetails.getEmail());
		
		if(user.getBranchCode().compareTo(alertDetails.getBrcode()) !=0)
		{
			status.setMessage("Cannot Process the Data. Invalid Branch Code Received.");
       		status.setStatus(false);
       		return status;
		}
		
		
		
		Branch branch = branchRepository.findById(alertDetails.getBrcode()).get();

		AutoAlertsRecipientsHbb forRole = autoAlertsRecipientsHbbRepository.findById(alertDetails.getRoleId()).get();

		Optional<AutoAlertsDetailsHbb> saveAlert = alertsHbbRepository.findByForRoleAndBranch(forRole, branch);

		AutoAlertsDetailsHbb saveAlertDetails = new AutoAlertsDetailsHbb();

		if (saveAlert.isPresent())

			saveAlertDetails = saveAlert.get();

		saveAlertDetails.setBranch(branchRepository.findById(alertDetails.getBrcode()).get());

		saveAlertDetails.setEmail(alertDetails.getEmail());

		saveAlertDetails.setUpdatedBy(SecurityUtils.getLoggedInUser().getId());
		saveAlertDetails.setForRole(autoAlertsRecipientsHbbRepository.findById(alertDetails.getRoleId()).get());

		alertsHbbRepository.save(saveAlertDetails);

		if (saveAlertDetails.getId() != null)
			{
			status.setMessage("");
       		status.setStatus(true);
       		return status;
			}
		else
		{
			status.setMessage("Could not Update the Details. Try Again.");
       		status.setStatus(true);
       		return status;
			}

	}

	public List<AutoAlertReportDTO> getAutoAlertBranches() {
		return chestSlipsRepository.getAutoAlertBranches();
	}

	public List<AutoAlertReportDTO> getAutoAlertBranchesHbb(String date) {
		return chestSlipsRepository.getAutoAlertBranchesHbb(date);
	}

	public void sendAutoAlerts(List<AutoAlertReportDTO> report) {
		sendAlertstoBranches(report);
		sendAlertstoRBOs(report);
		sendAlertstoDirectBranches(report);
		sendAlertstoAOs(report);
		sendAlertstoFSLOs(report);
		sendAlertstoCircles(report);
		sendAlertstoABD(report);

	}

	
	public void sendVerificationAutoAlerts(List<StatusSummary> report) throws IOException {
		
		sendVerificationAlertstoRBOs(report);
		sendVerificationAlertstoDirectBranches(report);
		sendVerificationAlertstoAOs(report);
		sendVerificationAlertstoCircles(report);
		sendVerificationAlertstoABD(report);

	}
	
	public void sendVerificationAlertstoRBOs(List<StatusSummary> report)
	{
		//sendVerificationEmailstoRBOs(report);
	}
	
	public void sendVerificationAlertstoDirectBranches(List<StatusSummary> report)
	{
		//sendVerificationEmailstoDirectBranches(report);
	}
	
	public void sendVerificationAlertstoAOs(List<StatusSummary> report)
	{
		//sendVerificationEmailstoAOs(report);
	}
	
	public void sendVerificationAlertstoCircles(List<StatusSummary> report)
	{
	//	sendVerificationEmailstoCircles(report);
	}
	
	public void sendVerificationAlertstoABD(List<StatusSummary> report) throws IOException
	{
		sendVerificationEmailstoABD(report);
	}
	
	public void sendAutoAlertsHbb(List<AutoAlertReportDTO> report) {
		sendAlertstoBranchesHbb(report);
		sendAlertstoRBOsHbb(report);
		sendAlertstoDirectBranchesHbb(report);
		sendAlertstoAOsHbb(report);
		sendAlertstoCirclesHbb(report);
		sendAlertstoABDHbb(report);

	}

	public void sendAlertstoBranches(List<AutoAlertReportDTO> report) {
		sendEmailtoBranches(report);
		sendSMStoBranches(report);

	}

	public void sendAlertstoBranchesHbb(List<AutoAlertReportDTO> report) {
		sendEmailtoBranchesHbb(report);
		sendSMStoBranchesHbb(report);

	}

	public void sendAlertstoRBOs(List<AutoAlertReportDTO> report) {
		sendEmailtoRBOs(report);

	}

	public void sendAlertstoRBOsHbb(List<AutoAlertReportDTO> report) {
		sendEmailtoRBOsHbb(report);

	}

	public void sendAlertstoDirectBranches(List<AutoAlertReportDTO> report) {
		sendEmailtoDirectBranches(report);

	}

	public void sendAlertstoDirectBranchesHbb(List<AutoAlertReportDTO> report) {
		sendEmailtoDirectBranchesHbb(report);

	}

	public void sendAlertstoAOs(List<AutoAlertReportDTO> report) {
		sendEmailtoAOs(report);

	}

	public void sendAlertstoAOsHbb(List<AutoAlertReportDTO> report) {
		sendEmailtoAOsHbb(report);

	}

	public void sendAlertstoFSLOs(List<AutoAlertReportDTO> report) {
		sendEmailtoFSLOs(report);

	}

	public void sendAlertstoCircles(List<AutoAlertReportDTO> report) {
		sendEmailtoCircles(report);

	}

	public void sendAlertstoCirclesHbb(List<AutoAlertReportDTO> report) {
		sendEmailtoCirclesHbb(report);

	}

	public void sendAlertstoABD(List<AutoAlertReportDTO> report) {
		sendEmailtoABD(report);

	}

	public void sendAlertstoABDHbb(List<AutoAlertReportDTO> report) {
		sendEmailtoABDHbb(report);

	}

	public void sendEmailtoRBOs(List<AutoAlertReportDTO> report) {

		LocalDate today = LocalDate.now();

		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> ((o.getRmEmail() != null && o.getRmEmail().trim().length() > 1)
						|| (o.getCmEmail() != null && o.getCmEmail().trim().length() > 1)) && o.getRegionCode() <= 6)
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "#" + w.getNetworkCode() + "#" + w.getModuleCode() + "#"
							+ w.getRegionCode();
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";

			text += "<html><h3> Following Currency Chest Branches exceeded Chest Balance Limit on Date : "
					+ dateTimeFormatter.format(today) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word;' width='100%' cellpadding='2'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Currency Chest Closing Balance </th><th> Chest Balance Limit </th>"
					+ "<th> CBL Exceeded By (Amount) </th><th> CBL Exceeded By (%) </th><th> Last Currency Chest Slip Uploaded Date </th>"
					+ "<th>No. of CBL Exceeded Days in Month</th><th>No. of CBL Exceeded Consecutive Days in Month</th></tr>";

			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getClosingBalance())) + "</td>";
				text += "<td align='right'>" + chestSlipUploadService.commas(commaFormatter.format(branch.getCbl()))
						+ "</td>";
				text += "<td align='right'>" + chestSlipUploadService
						.commas(commaFormatter.format((branch.getClosingBalance() - branch.getCbl()))) + "</td>";
				text += "<td align='center'>"
						+ chestSlipUploadService.commas(commaFormatter
								.format(((branch.getClosingBalance() - branch.getCbl()) / branch.getCbl()) * 100))
						+ "</td>";
				text += "<td>" + branch.getLastUploadDate() + "</td>";
				
				text += "<td>" + filterBranches.get(i).getMonthCount() + "</td>";
				text += "<td>" + (filterBranches.get(i).getMonthConsecutiveCount()==-1 ? filterBranches.get(i).getMonthCount() :  filterBranches.get(i).getMonthConsecutiveCount())+ "</td>";

				
				text += "</tr>";

			}

			

			text += "</table>";

			mailSenderService.sendEmailAsync(
					new String[] { mapBranches.get(0).getCmEmail(), mapBranches.get(0).getRmEmail() }, new String[] {},
					"RBO - Currency Chest Branches exceeded Chest Balance Limit on Date : "
							+ dateTimeFormatter.format(today),
					text, true);
		}
	}

	public void sendEmailtoRBOsHbb(List<AutoAlertReportDTO> report) {

		

		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> ((o.getRmEmail() != null && o.getRmEmail().trim().length() > 1)
						|| (o.getCmEmail() != null && o.getCmEmail().trim().length() > 1)) && o.getRegionCode() <= 6)
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "#" + w.getNetworkCode() + "#" + w.getModuleCode() + "#"
							+ w.getRegionCode();
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";

			text += "<html><h3> Following Hand Balance Branches exceeded Cash Retention Limit on Date : "
					+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Cash Retention Limit </th>"
					+ "<th> Balance Exceeded By Rs. </th><th> No.Of days CRL Exceeding in Month </th></tr>";

			
			
			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getCashLimit()))
						+ "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getExceededBy()))
						+ "</td>";
				text += "<td align='center'>" + branch.getDaysExceededInMonth() + "</td>";

				text += "</tr>";

			}

		

			text += "</table>";

			mailSenderService.sendEmailAsync(
					new String[] { mapBranches.get(0).getCmEmail(), mapBranches.get(0).getRmEmail() }, new String[] {},
					"RBO - Hand Balance Branches exceeded Cash Retention Limit on Date : "
							+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()),
					text, true);
		}
	}

	
	public void sendEmailtoDirectBranches(List<AutoAlertReportDTO> report) {
		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> ((o.getDgmEmailDirect() != null && o.getDgmEmailDirect().trim().length() > 1)
						|| (o.getCmagmEmailDirect() != null && o.getCmagmEmailDirect().trim().length() > 1))
						&& o.getRegionCode() > 6)
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "#" + w.getNetworkCode() + "#" + w.getModuleCode() + "#"
							+ w.getRegionCode();
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";
			LocalDate today = LocalDate.now();

			text += "<html><h3> Following Currency Chest Branches exceeded Chest Balance Limit on Date : "
					+ dateTimeFormatter.format(today) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word;' width='100%' cellpadding='2'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Currency Chest Closing Balance </th><th> Chest Balance Limit </th>"
					+ "<th> CBL Exceeded By (Amount) </th><th> CBL Exceeded By (%) </th><th> Last Currency Chest Slip Uploaded Date </th>"
					+ "<th>No. of CBL Exceeded Days in Month</th><th>No. of CBL Exceeded Consecutive Days in Month</th></tr>";



			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getClosingBalance())) + "</td>";
				text += "<td align='right'>" + chestSlipUploadService.commas(commaFormatter.format(branch.getCbl()))
						+ "</td>";
				text += "<td align='right'>" + chestSlipUploadService
						.commas(commaFormatter.format((branch.getClosingBalance() - branch.getCbl()))) + "</td>";
				text += "<td align='center'>"
						+ chestSlipUploadService.commas(commaFormatter
								.format(((branch.getClosingBalance() - branch.getCbl()) / branch.getCbl()) * 100))
						+ "</td>";
				text += "<td>" + branch.getLastUploadDate() + "</td>";
				text += "<td>" + filterBranches.get(i).getMonthCount() + "</td>";
				text += "<td>" + (filterBranches.get(i).getMonthConsecutiveCount()==-1 ? filterBranches.get(i).getMonthCount() :  filterBranches.get(i).getMonthConsecutiveCount())+ "</td>";

				text += "</tr>";

			}

		

			text += "</table>";

			mailSenderService.sendEmailAsync(
					new String[] { mapBranches.get(0).getDgmEmailDirect(), mapBranches.get(0).getCmagmEmailDirect() },
					new String[] {}, "DCB - Currency Chest Branches exceeded Chest Balance Limit on Date : "
							+ dateTimeFormatter.format(today),
					text, true);
		}
	}

	
	public void sendEmailtoDirectBranchesHbb(List<AutoAlertReportDTO> report) {
		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> ((o.getDgmEmailDirect() != null && o.getDgmEmailDirect().trim().length() > 1)
						|| (o.getCmagmEmailDirect() != null && o.getCmagmEmailDirect().trim().length() > 1))
						&& o.getRegionCode() > 6)
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "#" + w.getNetworkCode() + "#" + w.getModuleCode() + "#"
							+ w.getRegionCode();
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";
			

			text += "<html><h3> Following Hand Balance Branches exceeded Cash Retention Limit on Date : "
					+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Cash Retention Limit </th>"
					+ "<th> Balance Exceeded By Rs. </th><th> No.Of days CRL Exceeding in Month </th></tr>";

			
			
			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getCashLimit()))
						+ "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getExceededBy()))
						+ "</td>";
				text += "<td align='center'>" +branch.getDaysExceededInMonth() + "</td>";

				text += "</tr>";

			}



			text += "</table>";

			mailSenderService.sendEmailAsync(
					new String[] { mapBranches.get(0).getDgmEmailDirect(), mapBranches.get(0).getCmagmEmailDirect() },
					new String[] {}, "DCB - Hand Balance Branches exceeded Cash Retention Limit on Date : "
							+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()),
					text, true);
		}
	}

	
	
	public void sendEmailtoAOs(List<AutoAlertReportDTO> report) {
		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getDgmEmail() != null && o.getDgmEmail().trim().length() > 1)
						|| (o.getCmAgmEmail() != null && o.getCmAgmEmail().trim().length() > 1))
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "#" + w.getNetworkCode();
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";
			LocalDate today = LocalDate.now();
			text += "<html><h3> Following Currency Chest Branches exceeded Chest Balance Limit on Date : "
					+ dateTimeFormatter.format(today) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word;' width='100%' cellpadding='2'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Currency Chest Closing Balance </th><th> Chest Balance Limit </th>"
					+ "<th> CBL Exceeded By (Amount) </th><th> CBL Exceeded By (%) </th><th> Last Currency Chest Slip Uploaded Date </th>"
					+ "<th>No. of CBL Exceeded Days in Month</th><th>No. of CBL Exceeded Consecutive Days in Month</th></tr>";




			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getClosingBalance())) + "</td>";
				text += "<td align='right'>" + chestSlipUploadService.commas(commaFormatter.format(branch.getCbl()))
						+ "</td>";
				text += "<td align='right'>" + chestSlipUploadService
						.commas(commaFormatter.format((branch.getClosingBalance() - branch.getCbl()))) + "</td>";
				text += "<td align='center'>"
						+ chestSlipUploadService.commas(commaFormatter
								.format(((branch.getClosingBalance() - branch.getCbl()) / branch.getCbl()) * 100))
						+ "</td>";
				text += "<td>" + branch.getLastUploadDate() + "</td>";
				text += "<td>" + filterBranches.get(i).getMonthCount() + "</td>";
				text += "<td>" + (filterBranches.get(i).getMonthConsecutiveCount()==-1 ? filterBranches.get(i).getMonthCount() :  filterBranches.get(i).getMonthConsecutiveCount())+ "</td>";

				text += "</tr>";


			}

		
			text += "</table>";

			mailSenderService.sendEmailAsync(
					new String[] { mapBranches.get(0).getDgmEmail(), mapBranches.get(0).getCmAgmEmail() },
					new String[] {}, "AO - Currency Chest Branches exceeded Chest Balance Limit on Date : "
							+ dateTimeFormatter.format(today),
					text, true);
		}
	}

	public void sendEmailtoAOsHbb(List<AutoAlertReportDTO> report) {
		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getDgmEmail() != null && o.getDgmEmail().trim().length() > 1)
						|| (o.getCmAgmEmail() != null && o.getCmAgmEmail().trim().length() > 1))
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "#" + w.getNetworkCode();
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";
			
		
			text += "<html><h3> Following Hand Balance Branches exceeded Cash Retention Limit on Date : "
					+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Cash Retention Limit </th>"
					+ "<th> Balance Exceeded By Rs. </th><th> No.Of days CRL Exceeding in Month </th></tr>";

			
			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getCashLimit()))
						+ "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getExceededBy()))
						+ "</td>";
				text += "<td align='center'>" + branch.getDaysExceededInMonth() + "</td>";

				text += "</tr>";

			}

		

			text += "</table>";

			mailSenderService.sendEmailAsync(
					new String[] { mapBranches.get(0).getDgmEmail(), mapBranches.get(0).getCmAgmEmail() },
					new String[] {}, "AO - Hand Balance Branches exceeded Cash Retention Limit on Date : "
							+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()),
					text, true);
		}
	}

	

	public void sendEmailtoFSLOs(List<AutoAlertReportDTO> report) {
		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getAgmfsloEmail() != null && o.getAgmfsloEmail().trim().length() > 1))
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getFsloCode() + "";
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";
			LocalDate today = LocalDate.now();
			text += "<html><h3> Following Currency Chest Branches exceeded Chest Balance Limit on Date : "
					+ dateTimeFormatter.format(today) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word;' width='100%' cellpadding='2'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Currency Chest Closing Balance </th><th> Chest Balance Limit </th>"
					+ "<th> CBL Exceeded By (Amount) </th><th> CBL Exceeded By (%) </th><th> Last Currency Chest Slip Uploaded Date </th>"
					+ "<th>No. of CBL Exceeded Days in Month</th><th>No. of CBL Exceeded Consecutive Days in Month</th></tr>";



			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getClosingBalance())) + "</td>";
				text += "<td align='right'>" + chestSlipUploadService.commas(commaFormatter.format(branch.getCbl()))
						+ "</td>";
				text += "<td align='right'>" + chestSlipUploadService
						.commas(commaFormatter.format((branch.getClosingBalance() - branch.getCbl()))) + "</td>";
				text += "<td align='center'>"
						+ chestSlipUploadService.commas(commaFormatter
								.format(((branch.getClosingBalance() - branch.getCbl()) / branch.getCbl()) * 100))
						+ "</td>";
				text += "<td>" + branch.getLastUploadDate() + "</td>";
				text += "<td>" + filterBranches.get(i).getMonthCount() + "</td>";
				text += "<td>" + (filterBranches.get(i).getMonthConsecutiveCount()==-1 ? filterBranches.get(i).getMonthCount() :  filterBranches.get(i).getMonthConsecutiveCount())+ "</td>";

				text += "</tr>";

			}

			

			text += "</table>";

			mailSenderService.sendEmailAsync(new String[] { mapBranches.get(0).getAgmfsloEmail() }, new String[] {},
					"FSLO - Currency Chest Branches exceeded Chest Balance Limit on Date : "
							+ dateTimeFormatter.format(today),
					text, true);
		}
	}

	public void sendEmailtoCircles(List<AutoAlertReportDTO> report) {

		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getDgmcfoEmail() != null && o.getDgmcfoEmail().trim().length() > 1))
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "";
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";
			LocalDate today = LocalDate.now();
			text += "<html><h3> Following Currency Chest Branches exceeded Chest Balance Limit on Date : "
					+ dateTimeFormatter.format(today) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word;' width='100%' cellpadding='2'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Currency Chest Closing Balance </th><th> Chest Balance Limit </th>"
					+ "<th> CBL Exceeded By (Amount) </th><th> CBL Exceeded By (%) </th><th> Last Currency Chest Slip Uploaded Date </th>"
					+ "<th>No. of CBL Exceeded Days in Month</th><th>No. of CBL Exceeded Consecutive Days in Month</th></tr>";




			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getClosingBalance())) + "</td>";
				text += "<td align='right'>" + chestSlipUploadService.commas(commaFormatter.format(branch.getCbl()))
						+ "</td>";
				text += "<td align='right'>" + chestSlipUploadService
						.commas(commaFormatter.format((branch.getClosingBalance() - branch.getCbl()))) + "</td>";
				text += "<td align='center'>"
						+ chestSlipUploadService.commas(commaFormatter
								.format(((branch.getClosingBalance() - branch.getCbl()) / branch.getCbl()) * 100))
						+ "</td>";
				text += "<td>" + branch.getLastUploadDate() + "</td>";
				text += "<td>" + filterBranches.get(i).getMonthCount() + "</td>";
				text += "<td>" + (filterBranches.get(i).getMonthConsecutiveCount()==-1 ? filterBranches.get(i).getMonthCount() :  filterBranches.get(i).getMonthConsecutiveCount())+ "</td>";

				text += "</tr>";

			}

		

			text += "</table>";

			mailSenderService.sendEmailAsync(new String[] { mapBranches.get(0).getDgmcfoEmail() }, new String[] {},
					"Circle - Currency Chest Branches exceeded Chest Balance Limit on Date : "
							+ dateTimeFormatter.format(today),
					text, true);
		}

	}

	
	public void sendEmailtoCirclesHbb(List<AutoAlertReportDTO> report) {

		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getDgmcfoEmail() != null && o.getDgmcfoEmail().trim().length() > 1) 
						|| (o.getAgmCircleEmail() != null && o.getAgmCircleEmail().trim().length() > 1))
				.collect(Collectors.toList());

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterBranches.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "";
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int j = 0; j < keySet.length; j++) {

			List<AutoAlertReportDTO> mapBranches = map.get(keySet[j]);

			String text = "";
			
		
			text += "<html><h3> Following Hand Balance Branches exceeded Cash Retention Limit on Date : "
					+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Cash Retention Limit </th>"
					+ "<th> Balance Exceeded By Rs. </th><th> No.Of days CRL Exceeding in Month </th></tr>";

			
			for (int i = 0; i < mapBranches.size(); i++) {

				AutoAlertReportDTO branch = mapBranches.get(i);
				text += "<tr align='center'>";
				text += "<td>" + (i + 1) + "</td>";
				text += "<td>" + branchFormatter.format(branch.getBranchCode()) + "</td>";
				text += "<td>" + branch.getBranchName() + "</td>";
				text += "<td>" + branch.getRegionCode() + "</td>";
				text += "<td>" + branch.getModuleName() + "</td>";
				text += "<td>" + branch.getNetworkCode() + "</td>";
				text += "<td>" + branch.getCircleName() + "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getCashLimit()))
						+ "</td>";
				text += "<td align='right'>"
						+ chestSlipUploadService.commas(commaFormatter.format(branch.getExceededBy()))
						+ "</td>";
				text += "<td align='center'>" + branch.getDaysExceededInMonth() + "</td>";

				text += "</tr>";

			}

		

			text += "</table>";

			mailSenderService.sendEmailAsync(new String[] { mapBranches.get(0).getDgmcfoEmail(), mapBranches.get(0).getAgmCircleEmail(), }, new String[] {},
					"Circle - Hand Balance Branches exceeded Cash Retention Limit on Date : "
							+ dateTimeFormatter.format(mapBranches.get(0).getReportDate()),
					text, true);
		}

	}


	public void sendVerificationEmailstoABD(List<StatusSummary> report) throws IOException
	{
		List<StatusSummary> filterBranches = report;
		
		Map<String, List<StatusSummary>> summary = new TreeMap<>(filterBranches.stream().collect(Collectors.groupingBy(o->o.getCircle())));
		
		Map<String, List<String>> blockSummary = new TreeMap<>(filterBranches.stream().collect(Collectors.groupingBy(StatusSummary::getType, Collectors.mapping(StatusSummary::getBlock,Collectors.toList()))));
		
				
		List<String> circles=new ArrayList<>(summary.keySet());
		
		List<String> types=new ArrayList<>(blockSummary.keySet());
		
		
		

		
		
		
		for(int j=0;j<types.size();j++)
		{
			
			List<String> blocks = blockSummary.get(types.get(j)).stream().distinct().collect(Collectors.toList());
			
			String type=types.get(j);
			
			String subject = "VERIFICATION - CConline - Summary of Verifications/Visits Status for Current and Previous block as on Date : "+ dateTimeFormatter.format(LocalDate.now());
			
			
			
			String htmlData="<html><body> <h3> "+ subject+"</h3> <table width='100%' style='text-align:center;border-collapse:collapse;' border='1' cellpadding= '2'><tr><th colspan='23'>"+type.toUpperCase()+" VERIFICATION REPORT</th></tr><tr><th rowspan='2'>Circle</th> ";
			
			for(int k=0;k<blocks.size();k++)
			{
				htmlData+="<th colspan='10'>"+blocks.get(k)+"</th>";
			}
		
			
			htmlData+="</tr>";
			
			htmlData+="<tr><th>Total CCs</th><th>VO Not Identified</th><th>Not Started</th><th>In-Progress</th><th>Report Submitted</th><th>At Branch</th><th>At Scrutinizer</th><th>At Compliance</th><th>For Closure</th><th>Closed</th><th>Total CCs</th><th>VO Not Identified</th><th>Not Started</th><th>In-Progress</th><th>Report Submitted</th><th>At Branch</th><th>At Scrutinizer</th><th>At Compliance</th><th>For Closure</th><th>Closed</th></tr>";
			
			
			
			for(int i=0;i<circles.size();i++)
			{
				System.out.print("  |-- "+circles.get(i));
				List<StatusSummary> circleSummary = summary.get(circles.get(i));

				
				htmlData+="<tr><td>"+circles.get(i)+"</td>";
			
		for(int k=0;k<blocks.size();k++)
		{
			
			
			String block=blocks.get(k);
			
	//		System.out.println(" |-- "+ block +" :: ");
		
		
			
			
				
				
			
					
					StatusSummary
					s = 	 circleSummary.stream().filter(o->o.getType().equals(type) && o.getBlock().equals(block)).reduce((a,b) -> {  
						
						
						
						StatusSummaryDTO c = new StatusSummaryDTO();
						
						c.setTotalCcs(a.getTotalCcs()+b.getTotalCcs());
						c.setVoNotIdentified(a.getVoNotIdentified()+b.getVoNotIdentified());
						c.setNotStarted(a.getNotStarted()+b.getNotStarted());
						c.setInProgress(a.getInProgress()+b.getInProgress());
						c.setVoReportSubmitted(a.getVoReportSubmitted()+b.getVoReportSubmitted());
						c.setPendingAtBranch(a.getPendingAtBranch()+b.getPendingAtBranch());
						c.setPendingAtController(a.getPendingAtController()+b.getPendingAtController());
						c.setPendingAtCompliance(a.getPendingAtCompliance()+b.getPendingAtCompliance());
						c.setAwaitingForClosure(a.getAwaitingForClosure()+b.getAwaitingForClosure());
						c.setClosed(a.getClosed()+b.getClosed());
					
					
					
					
					return c; })
					.orElseGet(() -> null);
					
			//		System.out.println(s);
					
					if(s!=null)
					
					htmlData+="<td>"+s.getTotalCcs()+"</td><td>"+s.getVoNotIdentified()+"</td><td>"+s.getNotStarted()+"</td><td>"+s.getInProgress()
					+"</td><td>"+s.getVoReportSubmitted()+"</td><td>"+s.getPendingAtBranch()+"</td><td>"+s.getPendingAtController()+"</td><td>"+s.getPendingAtCompliance()+"</td><td>"
							+s.getAwaitingForClosure()+"</td><td>"+s.getClosed()+"</td>";
				
					else
						htmlData+="<td> 0 </td><td> 0 </td><td> 0 </td><td> 0 </td><td> 0 </td><td> 0 </td><td> 0 </td><td> 0 </td><td> 0 </td><td> 0 </td>";
					
				
					
				}
				
				htmlData+="</tr>";
				
					
			}
					
		
		htmlData+="</table></body></html>";
		
		FileOutputStream output=new FileOutputStream("file"+j+".html");
		output.write(htmlData.getBytes());
		output.close();
		
		
		
		
		mailSenderService.sendEmailAsync(
				new String[] { filterBranches.get(0).getAbdEmail(), filterBranches.get(0).getDgmabdEmail() },
				new String[] {}, subject,htmlData, true);
		
		
		
		}
		
		
		
		
		
		
		
		
		
	}
	
	
	public void sendEmailtoABD(List<AutoAlertReportDTO> report) {

		List<AutoAlertReportDTO> filterBranches = report;

		if (filterBranches.get(0).getAbdEmail() == null || filterBranches.get(0).getAbdEmail().length() == 0 || filterBranches.get(0).getDgmabdEmail() == null || filterBranches.get(0).getDgmabdEmail().length() == 0) {
			return;
		}

		String text = "";
		LocalDate today = LocalDate.now();
		text += "<html><h3> Following Currency Chest Branches exceeded Chest Balance Limit on Date : "
				+ dateTimeFormatter.format(today) + "</h3>";

		text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
				+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
				+ "<th> Network </th><th> Circle </th><th> Currency Chest Closing Balance </th><th> Chest Balance Limit </th>"
				+ "<th> CBL Exceeded By (Amount) </th><th> CBL Exceeded By (%) </th><th> Last Currency Chest Slip Uploaded Date </th>"
				+ "<th>No. of CBL Exceeded Days in Month</th><th>No. of CBL Exceeded Consecutive Days in Month</th></tr>";

	

		for (int i = 0; i < filterBranches.size(); i++) {

			text += "<tr align='center'>";
			text += "<td>" + (i + 1) + "</td>";
			text += "<td>" + branchFormatter.format(filterBranches.get(i).getBranchCode()) + "</td>";
			text += "<td>" + filterBranches.get(i).getBranchName() + "</td>";
			text += "<td>" + filterBranches.get(i).getRegionCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getModuleName() + "</td>";
			text += "<td>" + filterBranches.get(i).getNetworkCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getCircleName() + "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getClosingBalance()))
					+ "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getCbl())) + "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter
							.format((filterBranches.get(i).getClosingBalance() - filterBranches.get(i).getCbl())))
					+ "</td>";
			text += "<td align='center'>" + chestSlipUploadService.commas(
					commaFormatter.format(((filterBranches.get(i).getClosingBalance() - filterBranches.get(i).getCbl())
							/ filterBranches.get(i).getCbl()) * 100))
					+ "</td>";
			text += "<td>" + filterBranches.get(i).getLastUploadDate() + "</td>";
			text += "<td>" + filterBranches.get(i).getMonthCount() + "</td>";
			text += "<td>" + (filterBranches.get(i).getMonthConsecutiveCount()==-1 ? filterBranches.get(i).getMonthCount() :  filterBranches.get(i).getMonthConsecutiveCount())+ "</td>";

			text += "</tr>";

		}

		

		text += "</table>";

		mailSenderService.sendEmailAsync(
				new String[] { filterBranches.get(0).getAbdEmail(), filterBranches.get(0).getDgmabdEmail() },
				new String[] {}, "ABD - Currency Chest Branches exceeded Chest Balace Limit on Date : "
						+ dateTimeFormatter.format(today),
				text, true);

	}

	public void sendEmailtoABDHbb(List<AutoAlertReportDTO> report) {

		List<AutoAlertReportDTO> filterBranches = report;

		//System.out.println(report);
		
		if (filterBranches==null || filterBranches.size() == 0 ||  filterBranches.get(0).getDgmabdEmail() == null || filterBranches.get(0).getDgmabdEmail().length() == 0) {
			return;
		}

		String text = "";
		
		
		text += "<html><h3> Following Hand Balance Branches exceeded Cash Retention Limit on Date : "
				+ dateTimeFormatter.format(filterBranches.get(0).getReportDate()) + "</h3>";

		text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
				+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
				+ "<th> Network </th><th> Circle </th><th> Cash Retention Limit </th>"
				+ "<th> Balance Exceeded By Rs. </th><th> No.Of days CRL Exceeding in Month </th></tr>";


		for (int i = 0; i < filterBranches.size(); i++) {

			text += "<tr align='center'>";
			text += "<td>" + (i + 1) + "</td>";
			text += "<td>" + branchFormatter.format(filterBranches.get(i).getBranchCode()) + "</td>";
			text += "<td>" + filterBranches.get(i).getBranchName() + "</td>";
			text += "<td>" + filterBranches.get(i).getRegionCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getModuleName() + "</td>";
			text += "<td>" + filterBranches.get(i).getNetworkCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getCircleName() + "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getCashLimit()))
					+ "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getExceededBy()))
					+ "</td>";
			text += "<td align='center'>" + filterBranches.get(i).getDaysExceededInMonth() + "</td>";

			text += "</tr>";

		}

		

		text += "</table>";

		mailSenderService.sendEmailAsync(
				new String[] { filterBranches.get(0).getDgmabdEmail() },
				new String[] {}, "ABD - Hand Balance Branches exceeded Cash Retention Limit on Date : "
						+ dateTimeFormatter.format(filterBranches.get(0).getReportDate()),
				text, true);

	}



	public List<AutoAlertReportDTO> sendEmailtoBranches(List<AutoAlertReportDTO> report) {
		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getBranchEmail() != null && o.getBranchEmail().trim().length() > 1))
				.collect(Collectors.toList());

		for (int i = 0; i < filterBranches.size(); i++) {

			String text = "";
			LocalDate today = LocalDate.now();
			text += "<html><h3> Following Currency Chest Branches exceeded Chest Balance Limit on Date : "
					+ dateTimeFormatter.format(today) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Currency Chest Closing Balance </th><th> Chest Balance Limit </th>"
					+ "<th> CBL Exceeded By (Amount) </th><th> CBL Exceeded By (%) </th><th> Last Currency Chest Slip Uploaded Date </th>"
					+ "<th>No. of CBL Exceeded Days in Month</th><th>No. of CBL Exceeded Consecutive Days in Month</th></tr>";

			text += "<tr align='center'>";
			text += "<td> 1 </td>";
			text += "<td>" + branchFormatter.format(filterBranches.get(i).getBranchCode()) + "</td>";
			text += "<td>" + filterBranches.get(i).getBranchName() + "</td>";
			text += "<td>" + filterBranches.get(i).getRegionCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getModuleName() + "</td>";
			text += "<td>" + filterBranches.get(i).getNetworkCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getCircleName() + "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getClosingBalance()))
					+ "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getCbl())) + "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter
							.format((filterBranches.get(i).getClosingBalance() - filterBranches.get(i).getCbl())))
					+ "</td>";
			text += "<td align='center'>" + chestSlipUploadService.commas(
					commaFormatter.format(((filterBranches.get(i).getClosingBalance() - filterBranches.get(i).getCbl())
							/ filterBranches.get(i).getCbl()) * 100))
					+ "%</td>";
			text += "<td>" + filterBranches.get(i).getLastUploadDate() + "</td>";
			text += "<td>" + filterBranches.get(i).getMonthCount() + "</td>";
			text += "<td>" + (filterBranches.get(i).getMonthConsecutiveCount()==-1 ? filterBranches.get(i).getMonthCount() :  filterBranches.get(i).getMonthConsecutiveCount())+ "</td>";

			text += "</tr>";

			text += "</table>";

			mailSenderService.sendEmailAsync(new String[] { filterBranches.get(i).getBranchEmail() }, new String[] {},
					"Branch - Currency Chest Branches exceeded Chest Balance Limit on Date : "
							+ dateTimeFormatter.format(today),
					text, true);

		}

		return null;
	}

	public List<AutoAlertReportDTO> sendEmailtoBranchesHbb(List<AutoAlertReportDTO> report) {
		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getBranchEmail() != null && o.getBranchEmail().trim().length() > 1))
				.collect(Collectors.toList());

		for (int i = 0; i < filterBranches.size(); i++) {
			//System.out.println("Balance is :: " + filterBranches.get(i).getCashLimit());
			String text = "";
			
			text += "<html><h3> Following Hand Balance Branches exceeded Cash Retention Limit on Date : "
					+ dateTimeFormatter.format(filterBranches.get(0).getReportDate()) + "</h3>";

			text += "<table border=1 style=' border-collapse: collapse;border: 2px solid grey; word-wrap:break-word' width='100%'>"
					+ "<tr><th>SLNO</th><th> Branch Code </th><th> Branch Name </th><th> Region Code </th><th> Module Name </th>"
					+ "<th> Network </th><th> Circle </th><th> Cash Retention Limit </th>"
					+ "<th> Balance Exceeded By Rs. </th><th> No.Of days CRL Exceeding in Month </th></tr>";

			text += "<tr align='center'>";
			text += "<td> 1 </td>";
			text += "<td>" + branchFormatter.format(filterBranches.get(i).getBranchCode()) + "</td>";
			text += "<td>" + filterBranches.get(i).getBranchName() + "</td>";
			text += "<td>" + filterBranches.get(i).getRegionCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getModuleName() + "</td>";
			text += "<td>" + filterBranches.get(i).getNetworkCode() + "</td>";
			text += "<td>" + filterBranches.get(i).getCircleName() + "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getCashLimit()))
					+ "</td>";
			text += "<td align='right'>"
					+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getExceededBy()))
					+ "</td>";
			text += "<td align='center'>" + filterBranches.get(i).getDaysExceededInMonth() + "</td>";

			text += "</tr>";

			text += "</table>";

			mailSenderService.sendEmailAsync(new String[] { filterBranches.get(i).getBranchEmail() }, new String[] {},
					"Branch - Hand Balance Branches exceeded Cash Retention Limit on Date : "
							+ dateTimeFormatter.format(filterBranches.get(0).getReportDate()),
					text, true);

		}

		return null;
	}

	public List<AutoAlertReportDTO> sendSMStoBranches(List<AutoAlertReportDTO> report) {
		log.debug("in send sms to Branches");

		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getBranchManagerMobile() != null && o.getBranchManagerMobile().trim().length() > 1)
						|| (o.getCashOfficerMobile() != null && o.getCashOfficerMobile().trim().length() > 1)
						|| (o.getAccountantMobile() != null && o.getAccountantMobile().trim().length() > 1))
				.collect(Collectors.toList());

		for (int i = 0; i < filterBranches.size(); i++) {
			AutoAlertReportDTO branch = filterBranches.get(i);
			String branchManagerMobile = branch.getBranchManagerMobile();
			String cashOfficerMobile = branch.getCashOfficerMobile();
			String accountantMobile = branch.getAccountantMobile();
			Double cbl = branch.getCbl();
			Double closing = branch.getClosingBalance();
			Double exceeded = (closing - cbl);
			String date = branch.getLastUploadDate();
			Long branchCode = branch.getBranchCode();

			if (branchManagerMobile != null && branchManagerMobile.trim().length() == 10) {
				smsService.sendAutoSms("91" + branchManagerMobile.trim(),
						"CBL is exceeded by " + chestSlipUploadService.commas(commaFormatter.format(exceeded))
								+ " on dt. " + date + " for branch code " + branchFormatter.format(branchCode)
								+ "\\n- SBI CC Online");

			}
			if (cashOfficerMobile != null && cashOfficerMobile.trim().length() == 10) {
				smsService.sendAutoSms("91" + cashOfficerMobile.trim(),
						"CBL is exceeded by " + chestSlipUploadService.commas(commaFormatter.format(exceeded))
								+ " on dt. " + date + " for branch code " + branchFormatter.format(branchCode)
								+ "\\n- SBI CC Online");

			}
			if (accountantMobile != null && accountantMobile.trim().length() == 10) {
				smsService.sendAutoSms("91" + accountantMobile.trim(),
						"CBL is exceeded by " + chestSlipUploadService.commas(commaFormatter.format(exceeded))
								+ " on dt. " + date + " for branch code " + branchFormatter.format(branchCode)
								+ "\\n- SBI CC Online");

			}

		}

		return filterBranches;

	}

	public List<AutoAlertReportDTO> sendSMStoBranchesHbb(List<AutoAlertReportDTO> report) {
		log.debug("in send sms to Branches");

		List<AutoAlertReportDTO> filterBranches = report.stream()
				.filter(o -> (o.getBranchManagerMobile() != null && o.getBranchManagerMobile().trim().length() > 1))
				.collect(Collectors.toList());
		
		//System.out.println("In SMS :: "+filterBranches.size());

		for (int i = 0; i < filterBranches.size(); i++) {
			AutoAlertReportDTO branch = filterBranches.get(i);
			String branchManagerMobile = branch.getBranchManagerMobile();
			
//			Double cbl = branch.getCbl();
//			Double closing = branch.getClosingBalance();
//			Double exceeded = (closing - cbl);
//			String date = branch.getLastUploadDate();
			Long branchCode = branch.getBranchCode();
			
			String smsText=
					"Cash Balance of " + branchFormatter.format(branchCode)
						+ " is exceeding the CRL "+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getCashLimit())) 
						+" by Rs."+ chestSlipUploadService.commas(commaFormatter.format(filterBranches.get(i).getExceededBy()))
						+" on date "+filterBranches.get(0).getReportDate()+". Please rectify the position immediately."
						+ "\\n-SBICRLBRS";
			
			//System.out.println(smsText);

					

			if (branchManagerMobile != null && branchManagerMobile.trim().length() == 10) {
				smsService.sendAutoSms("91" + branchManagerMobile.trim(),smsText);

			}

		}

		return filterBranches;

	}

	public List<AutoAlertReportDTO> sendSMStoRBOs(List<AutoAlertReportDTO> report) {

		List<AutoAlertReportDTO> filterRBO = report.stream()
				.filter(o -> (o.getCmMobile() != null && o.getCmMobile().trim().length() > 1)
						|| (o.getRmMobile() != null && o.getRmMobile().trim().length() > 1))
				.collect(Collectors.toList());
		;

		Map<String, List<AutoAlertReportDTO>> map = new TreeMap<>(
				filterRBO.stream().collect(Collectors.groupingBy(w -> {
					String group = w.getCircleCode() + "#" + w.getNetworkCode() + "#" + w.getModuleCode() + "#"
							+ w.getRegionCode();
					return group;
				})));

		Object[] keySet = map.keySet().toArray();

		for (int i = 0; i < keySet.length; i++) {

			List<AutoAlertReportDTO> testing = map.get(keySet[i]);

			List<Long> branchCodes = testing.stream().map(o -> o.getBranchCode()).collect(Collectors.toList());

			String branches = branchCodes.toString().replace("[", "").replace("]", "");
			LocalDate today = LocalDate.now();
			smsService.sendAutoSms("91" + testing.get(0).getCmMobile(), "CBL has exceeded on dt. "
					+ dateTimeFormatter.format(today) + " for branches " + branches + "\\n- SBI CC Online");
			smsService.sendAutoSms("91" + testing.get(0).getRmMobile(), "CBL has exceeded on dt. "
					+ dateTimeFormatter.format(today) + " for branches " + branches + "\\n- SBI CC Online");

		}
		return report;

	}

	public List<String> hbbFilesRead() {
		String BGLS_FILE_PATH = applicationProperties.getBglsFilePath();
		String HBB_FILE_PATH = applicationProperties.getHbbFilePath();

		File bglsFilePath = new File(BGLS_FILE_PATH);

		if (!bglsFilePath.exists()) {
			if (!bglsFilePath.mkdirs()) {
				return null;
			}
		}
		
		File hbbFilePath = new File(HBB_FILE_PATH);

		if (!hbbFilePath.exists()) {
			if (!hbbFilePath.mkdirs()) {
				return null;
			}
		}
		
		List<String> directories = null;
		try {
			connect();
			directories = download();
			disconnect();
		} catch (JSchException e1) {
			log.error(e1.getMessage(), e1);
		}
		return directories;
	}
	
	@Transactional
	public void filesToDB(List<String> directories) throws IOException {
		
		
		String HBB_FILE_PATH = applicationProperties.getHbbFilePath();
		
		
		
		for(int i=0;i<directories.size();i++)
		{
			String source1 = "crl_"+directories.get(i)+".csv";
			String source2 = "brhm_"+directories.get(i)+".csv";
		String filePath1 = HBB_FILE_PATH + directories.get(i)+"/"+source1;
		String filePath2 = HBB_FILE_PATH + directories.get(i)+"/"+source2;
		
		FileInputStream file1 = new FileInputStream(filePath1);
		FileInputStream file2 = new FileInputStream(filePath2);
		
		
		
		try (BufferedReader br = new BufferedReader(new InputStreamReader(file1)))
		{
		StringBuffer output=new StringBuffer("");
		String line="";
		
	
		
		line = br.readLine();
		int count=0;

		while((line=br.readLine())!=null)
		{
			String fields[]=line.split("\\|");
			CashRetentionLimit crl=new CashRetentionLimit();
			String reportDate=fields[0];
			String branchCode=fields[1];
			String cglBalance=fields[2];
			String cashBalance=fields[3];
			String currencyChestFlag=fields[4];
			String branchTypeCode=fields[5];
			String cashLimit=fields[6];
			String closeDate=fields[7];
			String liveFlag=fields[8];
			String withinLimit=fields[9];
			String exceededLimit=fields[10];
					
			
			if(branchCode!= null && branchCode.trim().length() > 0)
			crl.setBranchCode(Long.valueOf(branchCode));
			
			if(branchTypeCode!= null && branchTypeCode.trim().length() > 0)
			crl.setBranchType(Long.valueOf(branchTypeCode));
			
			if(cashBalance!= null && cashBalance.trim().length() > 0)
			crl.setCashBalance(Double.parseDouble(cashBalance));
			
			if(cashLimit!= null && cashLimit.trim().length() > 0)
				crl.setCashLimit(Double.parseDouble(cashLimit));
			
			if(cglBalance!= null && cglBalance.trim().length() > 0)
			crl.setCglBalance(Double.parseDouble(cglBalance));
			
			if(closeDate!= null && closeDate.trim().length() > 0)
			crl.setCloseDate(DateUtils.parseDate(closeDate,"yyyy-MM-dd"));
			
			crl.setCurrencyChestFlag(currencyChestFlag);
			
			if(exceededLimit!= null && exceededLimit.trim().length() > 0)
			crl.setExceededLimit(Integer.parseInt(exceededLimit));
			
			crl.setLiveFlag(liveFlag);
			
			if(reportDate!= null && reportDate.trim().length() > 0)
			crl.setReportDate(DateUtils.parseDate(reportDate,"yyyy-MM-dd"));
			
			if(withinLimit!= null && withinLimit.trim().length() > 0)
			crl.setWithinLimit(Integer.parseInt(withinLimit));
			
			log.debug((count++)+"");
			crlRepository.save(crl);
			
		
		}
		
		br.close();
		
		}
		
		
		try (BufferedReader br=new BufferedReader(new InputStreamReader(file2)))
		{
		StringBuffer output=new StringBuffer("");
		String line="";
		
	
		
		line = br.readLine();
		int count=0;
		
		List<HandBalanceBranchDummy> branches=new ArrayList<>();
		

		while((line=br.readLine())!=null)
		{
			String fields[]=line.split("\\|");
			HandBalanceBranchDummy branch=new HandBalanceBranchDummy();
			String reportDate=fields[0];
			String branchCode=fields[1];
			String branchName=fields[2];
			String circleCode=fields[3];
			String circleName=fields[4];
			String networkCode=fields[5];
			String moduleCode= fields[6]; 
			String moduleName=fields[7]; 
			String regionCode=fields[8];
			String branchManagerMobileNumber = fields[9];
			String branchManagerEmailId = fields[10];
			String rboBranchCode=fields[11].trim();
			String branchTypeCode=fields[12];
			String branchDesc=fields[13];
			String liveFlag=fields[14];
			
			
			
			branch.setBranchCode(Long.valueOf(branchCode));
			
			
			if(branchManagerMobileNumber!=null && branchManagerMobileNumber.trim().length()>0)
			branch.setBrachManagerMobileNumber(Long.valueOf(branchManagerMobileNumber));
			
			branch.setBranchEmailId(branchManagerEmailId);
			branch.setBranchName(branchName);
						
			branch.setBranchType(branchDesc);
			
			if(branchTypeCode!=null && branchTypeCode.trim().length()>0)
			branch.setBranchTypeCode(Long.valueOf(branchTypeCode));
			
			if(circleCode!=null && circleCode.trim().length()>0)
			branch.setCircleCode(Long.valueOf(circleCode));
			
			branch.setCircleName(circleName);
			
			branch.setLiveFlag(liveFlag);
			
			if(moduleCode!=null && moduleCode.trim().length()>0)
			branch.setModuleCode(Long.valueOf(moduleCode));
			
			branch.setModuleName(moduleName);
			
			if(networkCode!=null && networkCode.trim().length()>0)
			branch.setNetworkCode(Long.valueOf(networkCode));
			
			if(rboBranchCode!=null && rboBranchCode.trim().length()>0)
			branch.setRboBranchCode(Long.valueOf(rboBranchCode));
			
			if(regionCode!=null && regionCode.trim().length()>0)
			branch.setRegionCode(Long.valueOf(regionCode));
			log.debug((count++)+"");
			
			insertBranch(branch);
			
		
		}
		
		
		
		
		br.close();

		}
		
		
		}
		
	}

	public void insertBranch(HandBalanceBranchDummy branch)
	{
		Optional<HandBalanceBranch> dbBranch  = handBalanceBranchRepository.findByBranchCode(branch.getBranchCode());
		HandBalanceBranch updateBranch = null;
		Boolean status = false;
		if(dbBranch.isEmpty())
			{
					updateBranch=new HandBalanceBranch();
					status = false;
			}
		else
		{
			if(branch.getBrachManagerMobileNumber() == dbBranch.get().getBrachManagerMobileNumber() 
					&& branch.getBranchEmailId().equals(dbBranch.get().getBranchEmailId())
					&& branch.getBranchTypeCode() == dbBranch.get().getBranchTypeCode()
					&& branch.getCircleCode() == dbBranch.get().getCircleCode()
					&& branch.getLiveFlag().equals(dbBranch.get().getLiveFlag())
					&& branch.getModuleCode() == dbBranch.get().getModuleCode()
					&& branch.getNetworkCode() == dbBranch.get().getNetworkCode()
					&& branch.getRegionCode() == dbBranch.get().getRegionCode())
					status= true;
			else
			{
				updateBranch= dbBranch.get();
		status= false;
			}
		}
		
		if(!status)
		{
			updateBranch.setBrachManagerMobileNumber(branch.getBrachManagerMobileNumber());
			updateBranch.setBranchCode(branch.getBranchCode());
			updateBranch.setBranchEmailId(branch.getBranchEmailId());
			updateBranch.setBranchName(branch.getBranchName());
			updateBranch.setBranchType(branch.getBranchType());
			
			
			updateBranch.setBranchTypeCode(branch.getBranchTypeCode());
			updateBranch.setCircleCode(branch.getCircleCode());
			
			updateBranch.setCircleName(branch.getCircleName());
			
			updateBranch.setLiveFlag(branch.getLiveFlag());
			updateBranch.setModuleCode(branch.getModuleCode());
			
			updateBranch.setModuleName(branch.getModuleName());
			
			updateBranch.setNetworkCode(branch.getNetworkCode());
			updateBranch.setRboBranchCode(branch.getRboBranchCode());
			updateBranch.setRegionCode(branch.getRegionCode());
			handBalanceBranchRepository.save(updateBranch);
			
		}
		
	}
	public void connect() throws JSchException {
		String SFTP_PASSWORD = applicationProperties.getHbbSftpPassword();
		String SFTP_USERNAME = applicationProperties.getHbbSftpUsername();
		String SFTP_HOST = applicationProperties.getSftpHost();
		int SFTP_PORT = Integer.parseInt(applicationProperties.getSftpPort());

		JSch jsch = new JSch();

		session = jsch.getSession(SFTP_USERNAME, SFTP_HOST, SFTP_PORT);
		session.setPassword(SFTP_PASSWORD);

		session.setConfig("StrictHostKeyChecking", "no");
		session.connect();

		log.debug("connected..");
	}

	public List<String> download() throws JSchException {

		String SFTP_FOLDER = applicationProperties.getHbbSftpFolder();
		String HBB_FILE_PATH = applicationProperties.getHbbFilePath();

		List<String> directories = null;

		Channel channel;
		try {
			channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			sftpChannel.cd(SFTP_FOLDER);
			Vector<LsEntry> files = sftpChannel.ls("*");
			
			
			String tillDate = DateUtils.format(sftpHbbStatusRepository.getLatestUploadDate(),DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			
			
			directories = files.stream()
					.filter(o -> (o.getFilename().substring(o.getFilename().indexOf("_")+1).replace(".csv","").compareTo(tillDate.replaceAll("-", "")) > 0))
					.collect(Collectors.toList()).stream().map(o->o.getFilename().substring(o.getFilename().indexOf("_")+1).toLowerCase().replace(".csv","")).distinct().collect(Collectors.toList());


			System.out.println(directories+" "+tillDate);
			
			for(int i=0; directories!=null && directories.size() > 0 && i< directories.size();i++)
			{
				SftpHbbStatus hbbStatus = new SftpHbbStatus();
				hbbStatus.setFileDate(DateUtils.parseDate(directories.get(i),"yyyyMMdd"));
				hbbStatus.setLoadedDate(LocalDate.now());
				String source1 = "crl_"+directories.get(i)+".csv";
				String source2 = "brhm_"+directories.get(i)+".csv";
				String destination = HBB_FILE_PATH + directories.get(i);
				File folder=new File(destination);
				
				folder.mkdirs();
					
				log.debug(source1+" -- "+ destination+"/"+source1);
				
			try {
				sftpChannel.get(source1, destination+"/"+source1);
				sftpChannel.get(source2, destination+"/"+source2);
				hbbStatus.setStatus("Success");
			} catch (SftpException e) {
				hbbStatus.setStatus("Failed");
				//e.printStackTrace();
			}
			
			
			sftpHbbStatusRepository.save(hbbStatus);
	        
			
			
			}
			sftpChannel.exit();
		} catch (JSchException | SftpException e) {
			
			//e.printStackTrace();
			return null;
		}
		
		return directories;
		
	}

	public void disconnect() throws JSchException {
		if (session != null) {
			session.disconnect();
		}

		log.debug("disconnected..");
	}

}
