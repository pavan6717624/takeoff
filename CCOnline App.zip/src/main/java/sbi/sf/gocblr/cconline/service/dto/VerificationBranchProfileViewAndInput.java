package sbi.sf.gocblr.cconline.service.dto;

import java.util.List;
import lombok.Data;
import sbi.sf.gocblr.cconline.web.rest.vm.IdNameDesc;

@Data
public class VerificationBranchProfileViewAndInput {

    private VerificationBranchProfileIM inputModel;
    private VerificationBranchProfileVM viewModel;

    private List<IdNameDesc> ccTypes;

    private boolean securityOfficer;
    private boolean balancesUpdatedLater = false;
    private boolean topOfficialsVisit;
}
