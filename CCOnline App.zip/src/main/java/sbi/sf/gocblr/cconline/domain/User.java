package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * User entity
 *
 * @author Kiran Marturu
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
public class User extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 2748998274408928804L;

    @Id
    @EqualsAndHashCode.Include
    private Long id;

    @Column(length = 10)
    private String title;

    @Column(length = 100)
    private String name;

    @Column(length = 100)
    private String designation;

    @OneToOne
    @JoinColumn(name = "branch_code", foreignKey = @ForeignKey(name = "fk_users_branches"))
    private Branch branch;

    @OneToOne
    @JoinColumn(name = "fslo_code", foreignKey = @ForeignKey(name = "fk_users_fslo"))
    private Fslo fslo;

    @OneToOne
    @JoinColumns(
        value = {
            @JoinColumn(name = "circle_code", referencedColumnName = "circle_code"),
            @JoinColumn(name = "network_code", referencedColumnName = "network_code"),
        },
        foreignKey = @ForeignKey(name = "fk_users_networks")
    )
    private Network network;

    private Long position;

    @Column(name = "mobile_no")
    private Long mobileNo;

    @Column(name = "email_id", length = 300)
    private String emailId;

    @ManyToMany
    @JoinTable(
        name = "user_roles",
        joinColumns = {
            @JoinColumn(name = "user_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_user_roles_users")),
        },
        inverseJoinColumns = {
            @JoinColumn(
                name = "role_id",
                referencedColumnName = "id",
                updatable = false,
                foreignKey = @ForeignKey(name = "fk_user_roles_roles")
            ),
        }
    )
    private Set<Role> roles = new HashSet<>();

    @Column(name = "is_approved")
    private boolean approved = false;

    @Column(name = "is_enabled")
    private Boolean isEnabled = false;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    @Column(name = "last_login")
    private LocalDateTime lastLogin;

    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    private UserRequest userRequest;

    @Column(name = "reason_for_auto_deletion", length = 250)
    private String reasonForAutoDeletion;
}
