package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class MisBglDifferenceModal {

    String circle;
    Long network;
    Long module;
    String moduleName;
    Long region;

    Long brCode;
    String brName;

    Double bgl98958balance;
    Double bgl98908balance;

    Double closingBalance;
    Double net;

    Long closingDifference;
    Long netDifference;

    String lastTalliedDateBgl98958;
    String lastTalliedDateBgl98908;
}
