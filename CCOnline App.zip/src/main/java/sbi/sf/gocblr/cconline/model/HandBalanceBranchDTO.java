package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class HandBalanceBranchDTO {
	
	Long circleCode;
	 String circleName;
	 Long networkCode;
	 Long moduleCode;
	 String moduleName;
	 Long regionCode;
	 Long branchCode;
	 String branchName;
	 String liveFlag;
	 Long branchTypeCode;
	 String branchType;
	 String branchEmailId;
	 Long brachManagerMobileNumber;
	 Long rboBranchCode;
	 
	

}
