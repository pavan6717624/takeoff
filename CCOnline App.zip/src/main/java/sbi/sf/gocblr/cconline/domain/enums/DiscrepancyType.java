package sbi.sf.gocblr.cconline.domain.enums;

public enum DiscrepancyType {
    SHORTAGE("S", "Shortage"),
    EXCESS("E", "Excess");

    private final String code;
    private final String description;

    DiscrepancyType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static DiscrepancyType fromCode(String code) {
        for (DiscrepancyType d : DiscrepancyType.values()) {
            if (d.code.equalsIgnoreCase(code)) {
                return d;
            }
        }
        return null;
    }
}
