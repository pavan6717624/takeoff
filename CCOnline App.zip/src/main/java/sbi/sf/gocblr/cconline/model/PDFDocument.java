package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class PDFDocument {

    String date;
    Integer cccode;
    String ccname;
    PDFTable notesTable;

    PDFTable coinsTable;
    String status;
    String message;
    String uploaddate;
    String filename;
}
