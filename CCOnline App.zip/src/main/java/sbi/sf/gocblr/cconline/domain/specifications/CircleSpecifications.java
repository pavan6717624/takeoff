package sbi.sf.gocblr.cconline.domain.specifications;

import org.springframework.data.jpa.domain.Specification;
import sbi.sf.gocblr.cconline.domain.Network;

public class CircleSpecifications {

    public static Specification<Network> circles(long circleCode) {
        return (root, query, cb) -> cb.equal(root.get("circle").get("circleCode"), circleCode);
    }
}
