package sbi.sf.gocblr.cconline.service;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Fslo;
import sbi.sf.gocblr.cconline.domain.PenaltyData;
import sbi.sf.gocblr.cconline.domain.RBIBGLStatementCC;
import sbi.sf.gocblr.cconline.domain.RBIBGLStatementFslo;
import sbi.sf.gocblr.cconline.domain.RBIBGLStatementUploadDetails;
import sbi.sf.gocblr.cconline.domain.RBIFSLOMapping;
import sbi.sf.gocblr.cconline.model.BGLStatement;
import sbi.sf.gocblr.cconline.model.BGLStatementData;
import sbi.sf.gocblr.cconline.model.BGLStatementDisplay;
import sbi.sf.gocblr.cconline.model.BGLStatementDisplayChild;
import sbi.sf.gocblr.cconline.model.BGLStatementDisplayParent;
import sbi.sf.gocblr.cconline.model.BGLStatementFile;
import sbi.sf.gocblr.cconline.model.DownloadFsloEkuber;
import sbi.sf.gocblr.cconline.model.PenaltyDisplayData;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.FsloRepository;
import sbi.sf.gocblr.cconline.repository.PenaltyDataRepository;
import sbi.sf.gocblr.cconline.repository.RBIBGLStatementCCRepository;
import sbi.sf.gocblr.cconline.repository.RBIBGLStatementFsloRepository;
import sbi.sf.gocblr.cconline.repository.RBIBGLStatementUploadDetailsRepository;
import sbi.sf.gocblr.cconline.repository.RBIFSLOMappingRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;

@Service
@RequiredArgsConstructor
@Slf4j
public class BGLStatementService {

    private final FsloRepository fsloRepository;

    private final CurrencyChestRepository ccRepository;
    public static final String UPLOADED_FOLDER = "UPLOADS" + File.separator + "BGLSTATEMENTS" + File.separator;
    public static final String TRICKLEFEED_FOLDER = "GENERATE" + File.separator + "TRAICKLEFEEDS" + File.separator;

    private final RBIBGLStatementFsloRepository rbiBGLFSLORepository;

    private final RBIBGLStatementCCRepository rbiBGLCCRepository;

    private final RBIBGLStatementUploadDetailsRepository bglStatementUploadDetailsRepository;

    private final RBIFSLOMappingRepository rbiFsloMappingRepository;

    private final PenaltyDataRepository penaltyDataRepository;

    private final PenaltyDataService penaltyDataService;

    public String generateHTML(BGLStatementDisplayParent parent, LocalDate fileDate) {
        DecimalFormat formatter = new DecimalFormat("#0.00");

        StringBuilder htmlData = new StringBuilder(2000);
        htmlData.append(
            "<html><body style='font-family: courier, serif;font-size:10px;'><center><h3>STATE BANK OF INDIA</h3><h3>FUND SETTLEMENT LINK OFFICE</h3></center>"
        );

        List<BGLStatementDisplayChild> child = parent.getStatementChild();

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        htmlData.append(
            "<table width='100%' border='0'><tr><td style='align:left'>" +
            parent.getFsloCode() +
            " : " +
            parent.getFsloName() +
            "</td><td style='align:right'>e-Kuber data Dated:" +
            dateFormatter.format(fileDate) +
            "</td></tr></table>"
        );
        htmlData.append("<table width='100%' style='border-collapse:collapse;' border='1' cellpadding= '2'>");
        htmlData.append(
            "<thead><tr style='background:lightgrey'><th>CC CD</th><th>BR CD</th><th>BR NM</th><th>DEPOSITS</th><th>WITHDRAWALS</th><th>CT</th></tr></thead>"
        );
        htmlData.append("<tbody>");

        for (int j = 0; j < child.size(); j++) {
            htmlData.append(
                "<tr><td>" +
                child.get(j).getCccd() +
                "</td><td style='text-align: right;'>" +
                child.get(j).getBrcd() +
                "</td><td style='text-align: left;'>" +
                child.get(j).getBrname() +
                "</td><td style='text-align: right;'>" +
                formatter.format(child.get(j).getDeposit()) +
                "</td><td style='text-align: right;'>" +
                formatter.format(child.get(j).getWithdrawal()) +
                "</td><td style='text-align: right;'>" +
                formatter.format(child.get(j).getCt()) +
                "</td></tr>"
            );
        }
        htmlData.append(
            "<tr style='background:lightgrey'><td colspan='3'>GRAND TOTAL</td><td>" +
            formatter.format(parent.getDeposit()) +
            "</td><td>" +
            formatter.format(parent.getWithdrawal()) +
            "</td><td>" +
            formatter.format(parent.getCt()) +
            "</td></tr>"
        );

        htmlData.append("</tbody></table></body></html>");

        return htmlData.toString();
    }

    public byte[] generatePDF(BGLStatementDisplayParent parent, LocalDate date) throws IOException {
        String htmlData = generateHTML(parent, date);
       return generatePDF(htmlData);
    }
    
    public byte[] generatePDF(String htmlData) throws IOException {
   
    	
        byte[] pdfBytes = null;
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream(); BufferedOutputStream bufOs = new BufferedOutputStream(bos)) {
            final PdfRendererBuilder pdfBuilder = new PdfRendererBuilder();
            pdfBuilder.useDefaultPageSize(500, 500, null);
            
            pdfBuilder.useFastMode();
            pdfBuilder.withHtmlContent(htmlData, "");
            pdfBuilder.toStream(bufOs);
            pdfBuilder.run();
            pdfBytes = bos.toByteArray();
        }
        
        FileOutputStream output=new FileOutputStream("f:\\output.pdf");
        output.write(pdfBytes);
        output.close();
        
        return pdfBytes;
    }

    public String generateCSV(BGLStatementDisplayParent parent) {
        List<BGLStatementDisplayChild> child = parent.getStatementChild();
        StringBuilder exportcsv = new StringBuilder(2000);
        exportcsv.append("CC CD,BR CD,BR NM,DEPOSITS,WITHDRAWALS,CT\n");
        DecimalFormat formatter = new DecimalFormat("#0.00");
        for (int j = 0; j < child.size(); j++) {
            exportcsv.append(
                child.get(j).getCccd() +
                "," +
                child.get(j).getBrcd() +
                "," +
                child.get(j).getBrname().replace(",", "") +
                "," +
                formatter.format(child.get(j).getDeposit()) +
                "," +
                formatter.format(child.get(j).getWithdrawal()) +
                "," +
                formatter.format(child.get(j).getCt()) +
                "\n"
            );
        }
        exportcsv.append(
            ",,GRAND TOTAL," +
            formatter.format(parent.getDeposit()) +
            "," +
            formatter.format(parent.getWithdrawal()) +
            "," +
            formatter.format(parent.getCt())
        );
        return exportcsv.toString();
    }

    public String generateTrickleFeed(BGLStatementDisplayParent parent, LocalDate date) {
        DecimalFormat branchFormat = new DecimalFormat("#00000");
        DecimalFormat ccFormat = new DecimalFormat("#000000");
        DecimalFormat bglFormat = new DecimalFormat("#00000000000");
        DecimalFormat amountFormat = new DecimalFormat("#00000000000000.00");
        //   SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        DateTimeFormatter dateFormat1 = DateTimeFormatter.ofPattern("yyyyMMdd");
        // SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyyMMdd");

        List<BGLStatementDisplayChild> child = parent.getStatementChild();
        StringBuilder tricklefeed = new StringBuilder(2000);

        if (parent.getCt() >= 0) {
            tricklefeed.append("54");
        } else {
            tricklefeed.append("04");
        }

        String accountNumber = bglFormat.format(98956) + branchFormat.format(parent.getFsloCode());

        tricklefeed.append(accountNumber);

        int checkDigit = generateCheckDigit(Long.valueOf(accountNumber));

        tricklefeed.append(checkDigit);
        tricklefeed.append(amountFormat.format(Math.abs(parent.getCt())).replace(".", ""));

        tricklefeed.append("EKUBER REPORTING DATED " + dateFormat.format(date) + "            ");
        tricklefeed.append(branchFormat.format(parent.getFsloCode()) + dateFormat1.format(date) + "       ");
        tricklefeed.append("\r\n");

        if (parent.getCt() >= 0) {
            tricklefeed.append("04");
            accountNumber = bglFormat.format(98908) + branchFormat.format(parent.getFsloCode());
            tricklefeed.append(accountNumber);
            checkDigit = generateCheckDigit(Long.valueOf(accountNumber));
            tricklefeed.append(checkDigit);
            tricklefeed.append(amountFormat.format(Math.abs(parent.getCt())).replace(".", ""));
            tricklefeed.append("EKUBER REPORTING DATED " + dateFormat.format(date) + "            ");
            tricklefeed.append(branchFormat.format(parent.getFsloCode()) + dateFormat1.format(date) + "       ");
            tricklefeed.append("\r\n");

            tricklefeed.append("54");
            accountNumber = bglFormat.format(98908) + branchFormat.format(parent.getFsloCode());
            tricklefeed.append(accountNumber);
            checkDigit = generateCheckDigit(Long.valueOf(accountNumber));
            tricklefeed.append(checkDigit);
            tricklefeed.append(amountFormat.format(Math.abs(parent.getCt())).replace(".", ""));
            tricklefeed.append("EKUBER REPORTING DATED " + dateFormat.format(date) + "            ");
            tricklefeed.append(branchFormat.format(parent.getFsloCode()) + dateFormat1.format(date) + "       ");
            tricklefeed.append("\r\n");
        } else {
            tricklefeed.append("54");
            accountNumber = bglFormat.format(98908) + branchFormat.format(parent.getFsloCode());
            tricklefeed.append(accountNumber);
            checkDigit = generateCheckDigit(Long.valueOf(accountNumber));
            tricklefeed.append(checkDigit);
            tricklefeed.append(amountFormat.format(Math.abs(parent.getCt())).replace(".", ""));
            tricklefeed.append("EKUBER REPORTING DATED " + dateFormat.format(date) + "            ");
            tricklefeed.append(branchFormat.format(parent.getFsloCode()) + dateFormat1.format(date) + "       ");
            tricklefeed.append("\r\n");

            tricklefeed.append("04");
            accountNumber = bglFormat.format(98908) + branchFormat.format(parent.getFsloCode());
            tricklefeed.append(accountNumber);
            checkDigit = generateCheckDigit(Long.valueOf(accountNumber));
            tricklefeed.append(checkDigit);
            tricklefeed.append(amountFormat.format(Math.abs(parent.getCt())).replace(".", ""));
            tricklefeed.append("EKUBER REPORTING DATED " + dateFormat.format(date) + "            ");
            tricklefeed.append(branchFormat.format(parent.getFsloCode()) + dateFormat1.format(date) + "       ");
            tricklefeed.append("\r\n");
        }

        Collections.sort(
            child,
            new Comparator<BGLStatementDisplayChild>() {
                @Override
                public int compare(BGLStatementDisplayChild a1, BGLStatementDisplayChild a2) {
                    return (int) (a1.getCccd() - a2.getCccd());
                }
            }
        );

        for (int j = 0; j < child.size(); j++) {
            if (child.get(j).getCt() == 0) {
                continue;
            } else if (child.get(j).getCt() > 0) {
                tricklefeed.append("04");
            } else {
                tricklefeed.append("54");
            }
            accountNumber = bglFormat.format(98908) + branchFormat.format(child.get(j).getBrcd());
            tricklefeed.append(accountNumber);
            checkDigit = generateCheckDigit(Long.valueOf(accountNumber));
            tricklefeed.append(checkDigit);
            tricklefeed.append(amountFormat.format(Math.abs(child.get(j).getCt())).replace(".", ""));
            tricklefeed.append(
                "E-Kuber Reporting: " + dateFormat.format(date) + " CC CD: " + ccFormat.format(child.get(j).getCccd()) + "  "
            );
            tricklefeed.append(branchFormat.format(child.get(j).getBrcd()) + dateFormat1.format(date) + "       ");
            tricklefeed.append("\r\n");
        }

        return tricklefeed.toString();
    }

    public String generateZipFile(BGLStatementDisplayParent parent, LocalDate filedate) throws IOException, NoSuchAlgorithmException {
        DecimalFormat branchFormat = new DecimalFormat("#00000");
        // SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        //SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyMMdd");
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        DateTimeFormatter dateFormat2 = DateTimeFormatter.ofPattern("yyMMdd");

        String date = dateFormat.format(filedate);
        String date1 = dateFormat2.format(filedate);

        String zipFileName = TRICKLEFEED_FOLDER + date + File.separator + branchFormat.format(parent.getFsloCode()) + ".zip";
        File folder = new File(TRICKLEFEED_FOLDER + date);
        if (!folder.exists()) {
            if (!folder.mkdirs()) {
                log.error("Error while creating folder: {}", TRICKLEFEED_FOLDER);
                throw new IOException("An error occured. Contact helpdesk");
            }
        }

        FileOutputStream fos = new FileOutputStream(zipFileName);

        try (ZipOutputStream zos = new ZipOutputStream(fos)) {
            byte[] bytes = null;

            zos.putNextEntry(new ZipEntry("EKUBER_SUMMARY_" + date1 + "_" + branchFormat.format(parent.getFsloCode()) + ".PDF"));
            bytes = generatePDF(parent, filedate);
            zos.write(bytes, 0, bytes.length);
            zos.closeEntry();

            zos.putNextEntry(new ZipEntry("REPORT_" + branchFormat.format(parent.getFsloCode()) + "_" + date1 + ".csv"));
            String csvData = generateCSV(parent);
            bytes = csvData.getBytes();
            zos.write(bytes, 0, bytes.length);
            zos.closeEntry();

            String tricklefeedName = "CTTFD_" + branchFormat.format(parent.getFsloCode()) + "_" + date1;

            String tricklefeed = generateTrickleFeed(parent, filedate);

            List<String> fields = generateTrickleFeedFields(tricklefeed, tricklefeedName);

            tricklefeedName += "-[" + fields.get(0) + "].txt";
            String passKey = fields.get(1);

            zos.putNextEntry(new ZipEntry(tricklefeedName));
            bytes = tricklefeed.getBytes();
            zos.write(bytes, 0, bytes.length);
            zos.closeEntry();

            String passKeyFileName = "PASS_KEY_" + branchFormat.format(parent.getFsloCode()) + "_" + date1 + ".txt";
            String passKeyFileData = "Filename: " + date + File.separator + tricklefeedName + ": Pass key : " + passKey;

            zos.putNextEntry(new ZipEntry(passKeyFileName));
            bytes = passKeyFileData.getBytes();
            zos.write(bytes, 0, bytes.length);
            zos.closeEntry();

            return "tricklefeed/" + date + "/" + branchFormat.format(parent.getFsloCode()) + ".zip";
        }
    }

    public String save(MultipartFile file) throws IOException {
        byte[] bytes;

        Long timeStamp = Instant.now().toEpochMilli();

        try {
            bytes = file.getBytes();
        } catch (IOException e1) {
            log.error(e1.getMessage() + "\n in Saving BGL Statement getting Bytes", e1);
            return "";
        }
        File folder = new File(UPLOADED_FOLDER);
        if (!folder.exists()) {
            if (!folder.mkdirs()) {
                log.error("Error while creating uploads folder: {}", UPLOADED_FOLDER);
                throw new IOException("Error while creating upload folder");
            }
        }
        String filename = file.getOriginalFilename();

        if (filename != null && filename.contains(File.separator)) filename = filename.substring(filename.lastIndexOf(File.separator) + 1);

        filename = timeStamp + "_" + filename;

        Path path = Paths.get(UPLOADED_FOLDER + filename);
        try {
            Files.write(path, bytes);
        } catch (IOException e) {
            log.error(e.getMessage() + "\n in Saving BGL Statement in writing Bytes", e);

            return "";
        }
        return UPLOADED_FOLDER + filename;
    }

    private String convertToHex(byte[] data) {
        StringBuilder buf = new StringBuilder(2000);

        for (int i = 0; i < data.length; ++i) {
            int halfbyte = data[i] >>> 4 & 15;
            int var4 = 0;

            do {
                if (0 <= halfbyte && halfbyte <= 9) {
                    buf.append((char) (48 + halfbyte));
                } else {
                    buf.append((char) (97 + (halfbyte - 10)));
                }

                halfbyte = data[i] & 15;
            } while (var4++ < 1);
        }

        return buf.toString();
    }

    public String MD5(String text) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] md5hash = new byte[32];
        md.update(text.getBytes(StandardCharsets.UTF_8), 0, text.length());
        md5hash = md.digest();
        return convertToHex(md5hash);
    }

    public List<String> generateTrickleFeedFields(String fileContent, String fileName) throws NoSuchAlgorithmException {
        String partialHash = MD5(fileContent);
        String finalHash = MD5(fileName + partialHash);
        String passKey = finalHash.substring(5, 7) + finalHash.substring(8, 10) + finalHash.substring(15, 17);

        List<String> fields = new ArrayList<>();
        fields.add(finalHash);
        fields.add(passKey);

        return fields;
    }

    public int generateCheckDigit(Long accountNumber) {
        int[][] checkDigitArray = new int[17][10];

        checkDigitArray[1][1] = 10;
        checkDigitArray[1][2] = 9;
        checkDigitArray[1][3] = 8;
        checkDigitArray[1][4] = 7;
        checkDigitArray[1][5] = 6;
        checkDigitArray[1][6] = 5;
        checkDigitArray[1][7] = 4;
        checkDigitArray[1][8] = 3;
        checkDigitArray[1][9] = 2;
        checkDigitArray[2][1] = 5;
        checkDigitArray[2][2] = 10;
        checkDigitArray[2][3] = 4;
        checkDigitArray[2][4] = 9;
        checkDigitArray[2][5] = 3;
        checkDigitArray[2][6] = 8;
        checkDigitArray[2][7] = 2;
        checkDigitArray[2][8] = 7;
        checkDigitArray[2][9] = 1;
        checkDigitArray[3][1] = 8;
        checkDigitArray[3][2] = 5;
        checkDigitArray[3][3] = 2;
        checkDigitArray[3][4] = 10;
        checkDigitArray[3][5] = 7;
        checkDigitArray[3][6] = 4;
        checkDigitArray[3][7] = 1;
        checkDigitArray[3][8] = 9;
        checkDigitArray[3][9] = 6;
        checkDigitArray[4][1] = 4;
        checkDigitArray[4][2] = 8;
        checkDigitArray[4][3] = 1;
        checkDigitArray[4][4] = 5;
        checkDigitArray[4][5] = 9;
        checkDigitArray[4][6] = 2;
        checkDigitArray[4][7] = 6;
        checkDigitArray[4][8] = 10;
        checkDigitArray[4][9] = 3;
        checkDigitArray[5][1] = 2;
        checkDigitArray[5][2] = 4;
        checkDigitArray[5][3] = 6;
        checkDigitArray[5][4] = 8;
        checkDigitArray[5][5] = 10;
        checkDigitArray[5][6] = 1;
        checkDigitArray[5][7] = 3;
        checkDigitArray[5][8] = 5;
        checkDigitArray[5][9] = 7;
        checkDigitArray[6][1] = 1;
        checkDigitArray[6][2] = 2;
        checkDigitArray[6][3] = 3;
        checkDigitArray[6][4] = 4;
        checkDigitArray[6][5] = 5;
        checkDigitArray[6][6] = 6;
        checkDigitArray[6][7] = 7;
        checkDigitArray[6][8] = 8;
        checkDigitArray[6][9] = 9;
        checkDigitArray[7][1] = 6;
        checkDigitArray[7][2] = 1;
        checkDigitArray[7][3] = 7;
        checkDigitArray[7][4] = 2;
        checkDigitArray[7][5] = 8;
        checkDigitArray[7][6] = 3;
        checkDigitArray[7][7] = 9;
        checkDigitArray[7][8] = 4;
        checkDigitArray[7][9] = 10;
        checkDigitArray[8][1] = 3;
        checkDigitArray[8][2] = 6;
        checkDigitArray[8][3] = 9;
        checkDigitArray[8][4] = 1;
        checkDigitArray[8][5] = 4;
        checkDigitArray[8][6] = 7;
        checkDigitArray[8][7] = 10;
        checkDigitArray[8][8] = 2;
        checkDigitArray[8][9] = 5;
        checkDigitArray[9][1] = 7;
        checkDigitArray[9][2] = 3;
        checkDigitArray[9][3] = 10;
        checkDigitArray[9][4] = 6;
        checkDigitArray[9][5] = 2;
        checkDigitArray[9][6] = 9;
        checkDigitArray[9][7] = 5;
        checkDigitArray[9][8] = 1;
        checkDigitArray[9][9] = 8;
        checkDigitArray[10][1] = 9;
        checkDigitArray[10][2] = 7;
        checkDigitArray[10][3] = 5;
        checkDigitArray[10][4] = 3;
        checkDigitArray[10][5] = 1;
        checkDigitArray[10][6] = 10;
        checkDigitArray[10][7] = 8;
        checkDigitArray[10][8] = 6;
        checkDigitArray[10][9] = 4;
        checkDigitArray[11][1] = 10;
        checkDigitArray[11][2] = 9;
        checkDigitArray[11][3] = 8;
        checkDigitArray[11][4] = 7;
        checkDigitArray[11][5] = 6;
        checkDigitArray[11][6] = 5;
        checkDigitArray[11][7] = 4;
        checkDigitArray[11][8] = 3;
        checkDigitArray[11][9] = 2;
        checkDigitArray[12][1] = 5;
        checkDigitArray[12][2] = 10;
        checkDigitArray[12][3] = 4;
        checkDigitArray[12][4] = 9;
        checkDigitArray[12][5] = 3;
        checkDigitArray[12][6] = 8;
        checkDigitArray[12][7] = 2;
        checkDigitArray[12][8] = 7;
        checkDigitArray[12][9] = 1;
        checkDigitArray[13][1] = 8;
        checkDigitArray[13][2] = 5;
        checkDigitArray[13][3] = 2;
        checkDigitArray[13][4] = 10;
        checkDigitArray[13][5] = 7;
        checkDigitArray[13][6] = 4;
        checkDigitArray[13][7] = 1;
        checkDigitArray[13][8] = 9;
        checkDigitArray[13][9] = 6;
        checkDigitArray[14][1] = 4;
        checkDigitArray[14][2] = 8;
        checkDigitArray[14][3] = 1;
        checkDigitArray[14][4] = 5;
        checkDigitArray[14][5] = 9;
        checkDigitArray[14][6] = 2;
        checkDigitArray[14][7] = 6;
        checkDigitArray[14][8] = 10;
        checkDigitArray[14][9] = 3;
        checkDigitArray[15][1] = 2;
        checkDigitArray[15][2] = 4;
        checkDigitArray[15][3] = 6;
        checkDigitArray[15][4] = 8;
        checkDigitArray[15][5] = 10;
        checkDigitArray[15][6] = 1;
        checkDigitArray[15][7] = 3;
        checkDigitArray[15][8] = 5;
        checkDigitArray[15][9] = 7;
        checkDigitArray[16][1] = 1;
        checkDigitArray[16][2] = 2;
        checkDigitArray[16][3] = 3;
        checkDigitArray[16][4] = 4;
        checkDigitArray[16][5] = 5;
        checkDigitArray[16][6] = 6;
        checkDigitArray[16][7] = 7;
        checkDigitArray[16][8] = 8;
        checkDigitArray[16][9] = 9;

        Long macno = accountNumber;

        if (macno < 0) {
            return -1;
        }
        int je = 16;
        int mchkdig = 0;
        int mdig = 0;

        while (macno > 0) {
            mdig = (int) (macno % 10);
            if (mdig != 0) {
                mchkdig = mchkdig + checkDigitArray[je][mdig];
            }
            macno = (macno / 10);
            je--;
        }

        return (mchkdig % 10);
    }

    public String validatePenaltyData(BGLStatementData bglData, String date, String ipAddress) {
        DecimalFormat formatter = new DecimalFormat("#0.00");
        String fileData = bglData.getData();
        DateTimeFormatter dateFormatter = null;

        if (bglData.getDate().indexOf("-") != -1) {
            if (bglData.getDate().replace("-", "").matches("[0-9]+")) {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            } else {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
            }
        } else if (bglData.getDate().indexOf("/") != -1) dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate receivedFileDate = LocalDate.parse(bglData.getDate(), dateFormatter);
        String fileDate = receivedFileDate.toString();
        if (!date.equals(fileDate)) {
            return "Dates Mismatch. Please Select Appropriate Date." + date + "," + fileDate;
        }

        if (
            Double.valueOf(
                formatter.format(
                    bglData.getOpeningBalance() + bglData.getCreditTotal() - bglData.getDebitTotal() - bglData.getClosingBalance()
                )
            ) !=
            0
        ) {
            return "Cannot Continue as Closing Balance is not correct";
        }

        if (fileData.length() == 0) {
            /*NoPenaltyDataFoundDates noPenaltyDataFoundDates =  new NoPenaltyDataFoundDates();
        	noPenaltyDataFoundDates.setReportDate(receivedFileDate);
        	noPenaltyDataFoundDatesRepository.save(noPenaltyDataFoundDates);*/
            penaltyDataService.saveWithPenaltyWithNoData(receivedFileDate, ipAddress);

            return "";
        }

        if (fileData.indexOf("LBB") == -1 || fileData.indexOf("LBB Wdl") == -1 || fileData.indexOf("LBB Dep") == -1) {
            return "Please Upload RBI BGL Statement File of Correct Format";
        }

        LocalDate latestUploadedDate = penaltyDataRepository.findByLatestUploadedDate();

        if (latestUploadedDate != null && receivedFileDate != null && receivedFileDate.compareTo(latestUploadedDate) <= 0) {
            return "";
        } else if (latestUploadedDate != null && receivedFileDate != null && !receivedFileDate.equals(latestUploadedDate.plusDays(1))) {
            return "Sorry..Cannot Continue. Please Upload RBI BGL Statement of " + dateFormatter.format(latestUploadedDate.plusDays(1));
        }

        return "";
    }

    public String validateData(BGLStatementData bglData, String date, String ipAddress) {
        DecimalFormat formatter = new DecimalFormat("#0.00");
        String fileData = bglData.getData();
        DateTimeFormatter dateFormatter = null;

        if (bglData.getDate().indexOf("-") != -1) {
            if (bglData.getDate().replace("-", "").matches("[0-9]+")) {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            } else {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
            }
        } else if (bglData.getDate().indexOf("/") != -1) dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate receivedFileDate = LocalDate.parse(bglData.getDate(), dateFormatter);
        String fileDate = receivedFileDate.toString();
        if (!date.equals(fileDate)) {
            return "Dates Mismatch. Please Select Appropriate Date." + date + "," + fileDate;
        }

        if (
            Double.valueOf(
                formatter.format(
                    bglData.getOpeningBalance() + bglData.getCreditTotal() - bglData.getDebitTotal() - bglData.getClosingBalance()
                )
            ) !=
            0
        ) {
            return "Cannot Continue as Closing Balance is not correct";
        }

        RBIBGLStatementUploadDetails latestUploadData = bglStatementUploadDetailsRepository.getLatestUploadData();

        if (latestUploadData != null) {
            LocalDate latestDate = latestUploadData.getFileDate();
            double latestClosingBalance = latestUploadData.getClosingBalance();

            if (!receivedFileDate.equals(latestDate.plusDays(1))) {
                return "Sorry..Cannot Continue. Please Upload RBI BGL Statement of " + latestDate.plusDays(1);
            }

            if (Double.valueOf(formatter.format(latestClosingBalance - bglData.getOpeningBalance())) != 0) {
                return "Sorry..Cannot Continue. Closing Balance of Latest Uploaded File is not tallied with Opening Balance of current File";
            }
        }

        if (fileData.length() == 0) {
            RBIBGLStatementUploadDetails uploadDetails = new RBIBGLStatementUploadDetails();
            uploadDetails.setClosingBalance(bglData.getClosingBalance());
            uploadDetails.setOpeningBalance(bglData.getOpeningBalance());
            uploadDetails.setIpAddress(ipAddress);
            uploadDetails.setFileDate(receivedFileDate);
            uploadDetails.setUploadFile("");
            uploadDetails.setUploadDate(LocalDate.now());
            uploadDetails.setPfid(SecurityUtils.getLoggedInUser().getId());
            bglStatementUploadDetailsRepository.save(uploadDetails);

            return "";
        }

        if (fileData.indexOf("LBB") == -1 || fileData.indexOf("LBB Wdl") == -1 || fileData.indexOf("LBB Dep") == -1) {
            return "Please Upload RBI BGL Statement File of Correct Format";
        }

        return "";
    }

    public List<BGLStatementDisplay> processTrickleFeed(BGLStatementFile file, String ipAddress)
        throws IOException, NoSuchAlgorithmException {
        BGLStatementFile bglStatementFile = file;

        List<BGLStatement> bglStatements = bglStatementFile.getBglStatementTable();
        List<BGLStatementDisplay> displayReport = new ArrayList<>();
        HashMap<Long, BGLStatementDisplayChild> mapChild = new HashMap<>();
        HashMap<Long, BGLStatementDisplayParent> mapParent = new HashMap<>();

        for (int i = 0; i < bglStatements.size(); i++) {
            BGLStatement bglStatement = bglStatements.get(i);

            BGLStatementDisplayChild bglStatementDisplayChild = mapChild.getOrDefault(bglStatement.getBranchCode(), null);

            if (bglStatementDisplayChild == null) {
                bglStatementDisplayChild = new BGLStatementDisplayChild();
                bglStatementDisplayChild.setBrcd(bglStatement.getBranchCode());
                bglStatementDisplayChild.setBrname(bglStatement.getCcName());
                bglStatementDisplayChild.setCccd(bglStatement.getCcCode());
                bglStatementDisplayChild.setFslocode(bglStatement.getFsloCode());
                bglStatementDisplayChild.setDeposit(0);
                bglStatementDisplayChild.setWithdrawal(0);
                bglStatementDisplayChild.setCt(0);
            }

            bglStatementDisplayChild.setDeposit(bglStatement.getDeposit() + bglStatementDisplayChild.getDeposit());
            bglStatementDisplayChild.setWithdrawal(bglStatement.getWithdrawal() + bglStatementDisplayChild.getWithdrawal());
            bglStatementDisplayChild.setCt(bglStatementDisplayChild.getDeposit() - bglStatementDisplayChild.getWithdrawal());

            mapChild.put(bglStatement.getBranchCode(), bglStatementDisplayChild);
        }

        Long[] cccodes = new TreeMap<Long, BGLStatementDisplayChild>(mapChild).keySet().toArray(new Long[0]);

        for (int i = 0; i < cccodes.length; i++) {
            BGLStatementDisplayChild child = mapChild.get(cccodes[i]);
            BGLStatementDisplayParent bglStatementDisplayParent = mapParent.getOrDefault(child.getFslocode(), null);

            if (bglStatementDisplayParent == null) {
                bglStatementDisplayParent = new BGLStatementDisplayParent();
                bglStatementDisplayParent.setFsloCode(child.getFslocode());
                Fslo fsloProfile = fsloRepository.findByBranchCode(child.getFslocode()).get();
                if (fsloProfile != null) {
                    bglStatementDisplayParent.setFsloName(fsloProfile.getBranchName());
                } else {
                    bglStatementDisplayParent.setFsloName("");
                }
                bglStatementDisplayParent.setCt(0);
                bglStatementDisplayParent.setDeposit(0);
                bglStatementDisplayParent.setWithdrawal(0);
                bglStatementDisplayParent.setStatementChild(new ArrayList<>());
            }

            bglStatementDisplayParent.setDeposit(bglStatementDisplayParent.getDeposit() + child.getDeposit());
            bglStatementDisplayParent.setWithdrawal(bglStatementDisplayParent.getWithdrawal() + child.getWithdrawal());
            bglStatementDisplayParent.setCt(bglStatementDisplayParent.getDeposit() - bglStatementDisplayParent.getWithdrawal());

            List<BGLStatementDisplayChild> parentchild = bglStatementDisplayParent.getStatementChild();
            parentchild.add(child);
            bglStatementDisplayParent.setStatementChild(parentchild);

            mapParent.put(child.getFslocode(), bglStatementDisplayParent);
        }

        BGLStatementDisplayParent[] fslos = new TreeMap<Long, BGLStatementDisplayParent>(mapParent)
            .values()
            .toArray(new BGLStatementDisplayParent[0]);

        RBIBGLStatementUploadDetails uploadDetails = new RBIBGLStatementUploadDetails();
        uploadDetails.setClosingBalance(file.getClosingBalance());
        uploadDetails.setOpeningBalance(file.getOpeningBalance());
        uploadDetails.setIpAddress(ipAddress);
        uploadDetails.setFileDate(file.getDate());
        uploadDetails.setUploadFile(file.getFileName());
        uploadDetails.setUploadDate(LocalDate.now());
        uploadDetails.setPfid(SecurityUtils.getLoggedInUser().getId());
        bglStatementUploadDetailsRepository.save(uploadDetails);

        for (int i = 0; i < fslos.length; i++) {
            BGLStatementDisplayParent parent = fslos[i];
            BGLStatementDisplay displayData = new BGLStatementDisplay();

            displayData.setCt(parent.getCt());
            displayData.setDeposit(parent.getDeposit());
            displayData.setFsloCode(parent.getFsloCode());
            displayData.setFsloName(parent.getFsloName());
            displayData.setWithdrawal(parent.getWithdrawal());

            String zipFilePath = generateZipFile(parent, file.getDate());

            /* GeneratedEKuberZipFile zipFile = new GeneratedEKuberZipFile();
            zipFile.setFilePath(zipFilePath);
            zipFile.setBglStatementUploadDetails(uploadDetails);
            zipFileRepository.save(zipFile);*/

            RBIBGLStatementFslo fsloStatment = new RBIBGLStatementFslo();

            fsloStatment.setFsloProfile(fsloRepository.findByBranchCode(parent.getFsloCode()).get());
            fsloStatment.setCt(parent.getCt());
            fsloStatment.setDeposit(parent.getDeposit());
            fsloStatment.setWithdrawal(parent.getWithdrawal());
            // Optional<GeneratedEKuberZipFile> zipFileId = zipFileRepository.findById(zipFile.getId());
            //fsloStatment.setZipFile(zipFile);

            fsloStatment.setFilePath(zipFilePath);
            fsloStatment.setBglStatementUploadDetails(uploadDetails);

            rbiBGLFSLORepository.save(fsloStatment);

            List<BGLStatementDisplayChild> children = fslos[i].getStatementChild();
            for (int j = 0; j < children.size(); j++) {
                BGLStatementDisplayChild child = children.get(j);
                RBIBGLStatementCC currencyChest = new RBIBGLStatementCC();
                currencyChest.setBranchProfile(ccRepository.findByBranchCode(child.getBrcd()).get());
                currencyChest.setCt(child.getCt());
                currencyChest.setDeposits(child.getDeposit());
                currencyChest.setFslo(rbiBGLFSLORepository.findById(fsloStatment.getId()).get());
                currencyChest.setWithdrawals(child.getWithdrawal());
                rbiBGLCCRepository.save(currencyChest);
            }

            displayData.setFileurl(zipFilePath);

            displayReport.add(displayData);
        }

        return displayReport;
    }

    public BGLStatementData read(String filename) throws IOException {
        if (filename.toLowerCase().endsWith(".xls")) {
            return readExcel(filename);
        } else if (filename.toLowerCase().endsWith(".csv")) {
            return readCSV(filename);
        } else {
            return null;
        }
    }

    public BGLStatementFile parse(BGLStatementData bglData, String filename) throws ParseException, IOException {
        BGLStatementFile bglStatementFile = null;
        if (filename.toLowerCase().endsWith(".xls")) {
            bglStatementFile = parseExcel(bglData);
        } else if (filename.toLowerCase().endsWith(".csv")) {
            bglStatementFile = parseCSV(bglData);
        } else {
            return null;
        }
        bglStatementFile.setFileName(new File(filename).getName());
        return bglStatementFile;
    }

    public BGLStatementData readCSV(String filename) throws IOException {
        StringBuilder output = new StringBuilder(2000);
        BGLStatementData bglData = null;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)))) {
            String line = "";
            while ((line = br.readLine()) != null) {
                while (true) {
                    int index1 = line.indexOf("\"");
                    if (index1 == -1) break;
                    String str1 = line.substring(0, index1);
                    int index2 = line.indexOf("\"", index1 + 1);
                    String str2 = line.substring(index1, index2 + 1);
                    String str3 = line.substring(index2 + 1);

                    line = str1 + str2.replace(",", "").replace("\"", "").replace("Cr", "").trim() + str3;
                }
                if (line.indexOf(",") == -1) line = ",,,,,," + line;

                output.append(line + "\n");
            }

            String csvData = output.toString().trim();
            bglData = structureCSVData(csvData);
        }
        return bglData;
    }

    public BGLStatementData readExcel(String filename) throws IOException {
        DecimalFormat formatter = new DecimalFormat("#0.00");
        BGLStatementData bglData = null;
        String exceldata = "";

        StringBuilder out = new StringBuilder(2000);
        File file = new File(filename); //creating a new file instance

        try (FileInputStream fis = new FileInputStream(file); HSSFWorkbook wb = new HSSFWorkbook(fis);) {
            HSSFSheet sheet = wb.getSheetAt(0); //creating a Sheet object to retrieve object
            Iterator<Row> itr = sheet.iterator(); //iterating over excel file
            while (itr.hasNext()) {
                Row row = itr.next();

                out.append("\n");
                for (int i = 0; i < row.getLastCellNum() && row.getLastCellNum() >= 6; i++) {
                    Cell cell = row.getCell(i);

                    if (cell == null) {
                        out.append(",");
                        continue;
                    }

                    if (cell.getCellType() == CellType.NUMERIC) {
                        out.append(formatter.format(cell.getNumericCellValue()) + ",");
                    } else if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().replace(",", "").trim().length() > 0) {
                        out.append(cell.getStringCellValue().replace(",", "").trim() + ",");
                    } else if (cell.getCellType() == CellType.FORMULA) {
                        FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
                        if (evaluator.evaluateInCell(cell).getCellType() == CellType.NUMERIC) {
                            out.append(formatter.format(cell.getNumericCellValue()) + ",");
                        }
                    } else if (cell.getCellType() == CellType.BLANK && (cell.getColumnIndex() == 4 || cell.getColumnIndex() == 5)) {
                        out.append(",");
                    }
                }
            }
        }
        exceldata = out.toString().replace(",,,,,,", "").trim();

        bglData = structureExcelData(exceldata);

        return bglData;
    }

    public BGLStatementData structureCSVData(String filedata) {
        String[] data = filedata.split("\n");
        double debitTotal = 0;
        double creditTotal = 0;
        double openingBalance = 0;
        double closingBalance = 0;

        openingBalance = Double.parseDouble(data[2].split(",")[5].replace("Cr", "").trim());
        closingBalance = Double.parseDouble(data[data.length - 1].split(",")[6].replace("Cr", "").trim());
        String date = data[4].split(",")[0];
        StringBuilder requiredData = new StringBuilder(2000);
        StringBuilder removedData = new StringBuilder(2000);

        for (int i = 4; i < data.length - 1; i++) {
            double debit = 0;
            double credit = 0;
            String[] fields = data[i].split(",");
            if (fields[4] != null && !fields[4].trim().equals("")) debit = Double.parseDouble(fields[4]);
            if (fields[5] != null && !fields[5].trim().equals("")) credit = Double.parseDouble(fields[5]);
            debitTotal += debit;
            creditTotal += credit;
            if ((fields[3].startsWith("LBB"))) {
                requiredData.append(data[i] + "\n");
            } else {
                removedData.append(data[i] + "\n");
            }
        }

        BGLStatementData bglData = new BGLStatementData();
        bglData.setClosingBalance(closingBalance);
        bglData.setOpeningBalance(openingBalance);
        bglData.setData(requiredData.toString().trim());
        bglData.setRemovedData(removedData.toString().trim());
        bglData.setCreditTotal(creditTotal);
        bglData.setDebitTotal(debitTotal);
        bglData.setDate(date);

        return bglData;
    }

    public BGLStatementData structureExcelData(String filedata) {
        String[] data = filedata.split("\n");
        double debitTotal = 0;
        double creditTotal = 0;
        double openingBalance = 0;
        double closingBalance = 0;

        openingBalance = Double.parseDouble(data[1].split(",")[6].replace("Cr", "").trim());
        closingBalance = Double.parseDouble(data[data.length - 1].split(",")[6].replace("Cr", "").trim());
        String date = data[2].split(",")[0];
        StringBuilder requiredData = new StringBuilder(2000);
        StringBuilder removedData = new StringBuilder(2000);

        for (int i = 2; i < data.length - 2; i++) {
            double debit = 0;
            double credit = 0;
            String[] fields = data[i].split(",");
            if (fields[4] != null && !fields[4].trim().equals("")) debit = Double.parseDouble(fields[4]);
            if (fields[5] != null && !fields[5].trim().equals("")) credit = Double.parseDouble(fields[5]);
            debitTotal += debit;
            creditTotal += credit;
            if ((fields[3].startsWith("LBB"))) {
                requiredData.append(data[i] + "\n");
            } else {
                removedData.append(data[i] + "\n");
            }
        }

        BGLStatementData bglData = new BGLStatementData();
        bglData.setClosingBalance(closingBalance);
        bglData.setOpeningBalance(openingBalance);
        bglData.setData(requiredData.toString().trim());
        bglData.setRemovedData(removedData.toString().trim());
        bglData.setCreditTotal(creditTotal);
        bglData.setDebitTotal(debitTotal);
        bglData.setDate(date);

        return bglData;
    }

    public BGLStatementFile parseCSV(BGLStatementData data) throws ParseException, IOException {
        // String exceldata = data;
        String[] lines = data.getData().split("\n");
        BGLStatementFile bglStat = new BGLStatementFile();
        bglStat.setOpeningBalance(data.getOpeningBalance());
        bglStat.setClosingBalance(data.getClosingBalance());

        DateTimeFormatter dateFormatter = null;

        if (data.getDate().indexOf("-") != -1) {
            if (data.getDate().replace("-", "").matches("[0-9]+")) {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            } else {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
            }
        } else if (data.getDate().indexOf("/") != -1) dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        /*  SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
      java.util.Date parsed = format.parse(data.getDate());
        java.sql.Date sqlDate = new java.sql.Date(parsed.getTime());*/

        LocalDate sqlDate = LocalDate.parse(data.getDate(), dateFormatter);

        bglStat.setDate(sqlDate);
        List<BGLStatement> bglStatementTable = new ArrayList<>();
        BGLStatement bglStatement = null;
        CurrencyChest branchProfile = null;

        for (int i = 0; i < lines.length; i++) {
            String[] line = lines[i].split(",");

            bglStatement = new BGLStatement();

            int index1 = line[3].indexOf(":") + 1;
            int index2 = line[3].indexOf(" ", index1);

            Long ccCode = Long.valueOf(line[3].substring(index1, index2));
            try
            {
            branchProfile = ccRepository.findByCcCode(ccCode).get();
            }
            catch(NoSuchElementException ex)
            {
            	 throw new IOException(ccCode+" CC Code not Found.");
            }
            Long fsloCode = Math.abs(branchProfile.getFslo().getBranchCode());
            Long branchCode = branchProfile.getBranchCode();
            String brName = branchProfile.getBranchName();

            sqlDate = LocalDate.parse(line[0], dateFormatter);

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss").withZone(ZoneId.systemDefault());

            Instant instant = Instant.from(formatter.parse(line[1].replace("-", "/") + " 00:00:00"));

            /* java.util.Date timest = format.parse(line[1]);
            Timestamp timestamp = new Timestamp(timest.getTime());*/
            double region = Double.parseDouble(line[2]);
            String transaction = line[3];
            double deposit = 0;
            double withdrawal = 0;
            double balance = 0;

            bglStatement.setDate(sqlDate);

            bglStatement.setTimestamp(instant);

            if (line[4] != null && !line[4].trim().equals("")) {
                withdrawal = Double.parseDouble(line[4]);
            }
            if (line[5] != null && !line[5].trim().equals("")) {
                deposit = Double.parseDouble(line[5]);
            }
            balance = Double.parseDouble(line[6]);

            bglStatement =
                new BGLStatement(sqlDate, instant, region, transaction, deposit, ccCode, fsloCode, branchCode, withdrawal, balance, brName);

            bglStatementTable.add(bglStatement);
        }

        bglStat.setBglStatementTable(bglStatementTable);

        return bglStat;
    }

    public BGLStatementFile parseExcel(BGLStatementData data) throws ParseException, IOException {
        String[] lines = data.getData().split("\n");

        BGLStatementFile bglStat = new BGLStatementFile();
        bglStat.setOpeningBalance(data.getOpeningBalance());
        bglStat.setClosingBalance(data.getClosingBalance());

        /*  SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
        java.util.Date parsed = format.parse(data.getDate());
        java.sql.Date sqlDate = new java.sql.Date(parsed.getTime());

        SimpleDateFormat format1 = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
        format1.setTimeZone(TimeZone.getTimeZone("UTC"));
*/

        DateTimeFormatter dateFormatter = null;

        if (data.getDate().indexOf("-") != -1) {
            if (data.getDate().replace("-", "").matches("[0-9]+")) {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            } else {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
            }
        } else if (data.getDate().indexOf("/") != -1) dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate sqlDate = LocalDate.parse(data.getDate(), dateFormatter);

        bglStat.setDate(sqlDate);
        List<BGLStatement> bglStatementTable = new ArrayList<>();
        BGLStatement bglStatement = null;
        CurrencyChest branchProfile = null;

        for (int i = 0; i < lines.length; i++) {
            String[] line = lines[i].split(",");

            int index1 = line[3].indexOf(":") + 1;
            int index2 = line[3].indexOf(" ", index1);

            Long ccCode = Long.valueOf(line[3].substring(index1, index2));
            try
            {
            branchProfile = ccRepository.findByCcCode(ccCode).get();
            }
            catch(NoSuchElementException ex)
            {
            	throw new IOException(ccCode+" CC Code not Found");
            }
            Long fsloCode = Math.abs(branchProfile.getFslo().getBranchCode());
            Long branchCode = branchProfile.getBranchCode();
            String brName = branchProfile.getBranchName();
            /*parsed = format.parse(line[0]);
            sqlDate = new java.sql.Date(parsed.getTime());
            java.util.Date timest = format1.parse(line[1]);
            Timestamp timestamp = new Timestamp(timest.getTime());*/

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss").withZone(ZoneId.systemDefault());
            Instant instant = Instant.from(formatter.parse(line[1]));

            double region = Double.parseDouble(line[2]);
            String transaction = line[3];
            double deposit = 0;
            double withdrawal = 0;
            double balance = 0;

            if (line[4] != null && !line[4].trim().equals("")) {
                withdrawal = Double.parseDouble(line[4]);
            }
            if (line[5] != null && !line[5].trim().equals("")) {
                deposit = Double.parseDouble(line[5]);
            }
            balance = Double.parseDouble(line[6]);

            bglStatement =
                new BGLStatement(sqlDate, instant, region, transaction, deposit, ccCode, fsloCode, branchCode, withdrawal, balance, brName);

            bglStatementTable.add(bglStatement);
        }

        bglStat.setBglStatementTable(bglStatementTable);

        return bglStat;
    }

    public LocalDate getLatestUploadDate() {
        return bglStatementUploadDetailsRepository.getLatestUploadDate();
    }

    public DownloadFsloEkuber getRBIBGLStatement(String date) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate localDate = LocalDate.parse(date, dateFormatter);
        DownloadFsloEkuber downloadFsloEkuber = new DownloadFsloEkuber();
        Optional<RBIBGLStatementUploadDetails> uploadDetailsOpt = bglStatementUploadDetailsRepository.findByFileDate(localDate);
        AppUser user = SecurityUtils.getLoggedInUser();
        Long brcode = user.getBranchCode();
        if (uploadDetailsOpt.isPresent()) {
            Optional<Fslo> fsloOpt = fsloRepository.findByBranchCode(brcode);
            if (fsloOpt.isEmpty()) return downloadFsloEkuber;
            Optional<RBIBGLStatementFslo> rbiBGLStatementFsloOpt = rbiBGLFSLORepository.findByFsloProfileAndBglStatementUploadDetails(
                fsloOpt.get(),
                uploadDetailsOpt.get()
            );
            if (rbiBGLStatementFsloOpt.isPresent()) {
                RBIBGLStatementFslo rbiBGLStatementFslo = rbiBGLStatementFsloOpt.get();
                downloadFsloEkuber.setCt(rbiBGLStatementFslo.getCt());
                downloadFsloEkuber.setDate(rbiBGLStatementFslo.getBglStatementUploadDetails().getFileDate());
                downloadFsloEkuber.setDeposit(rbiBGLStatementFslo.getDeposit());
                downloadFsloEkuber.setFilePath(rbiBGLStatementFslo.getFilePath());
                downloadFsloEkuber.setFsloCode(rbiBGLStatementFslo.getFsloProfile().getBranchCode());
                downloadFsloEkuber.setFsloName(rbiBGLStatementFslo.getFsloProfile().getBranchName());
                downloadFsloEkuber.setWithdrawal(rbiBGLStatementFslo.getWithdrawal());
                return downloadFsloEkuber;
            }
        }

        return downloadFsloEkuber;
    }

    @Transactional
    public PenaltyDisplayData filterPenalty(BGLStatementData bglData, String[] receivedKeywords) {
        PenaltyDisplayData penaltyDisplayData = new PenaltyDisplayData();
        String[] defaultKeywords = { "PENAL", "NALTY", "PANAL", "PNT", "NULT", "PEN" };

        List<String> keywords = new ArrayList<>();

        for (int i = 0; i < defaultKeywords.length; i++) keywords.add(defaultKeywords[i]);

        for (int i = 0; i < receivedKeywords.length; i++) {
            String keyword = receivedKeywords[i].replace("\"", "").replace("]", "").replace("[", "").trim();
            if (keyword.length() > 0) keywords.add(keyword);
        }

        DateTimeFormatter dateFormatter = null;

        if (bglData.getDate().indexOf("-") != -1) {
            if (bglData.getDate().replace("-", "").matches("[0-9]+")) {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            } else {
                dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
            }
        } else if (bglData.getDate().indexOf("/") != -1) dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        List<PenaltyData> penaltyDataProvided = penaltyDataRepository.findByReportDateAndStatus(
            LocalDate.parse(bglData.getDate(), dateFormatter),
            "New"
        );

        String[] lines = bglData.getRemovedData().split("\n");
        List<PenaltyData> penaltyRows = new ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            for (int j = 0; j < keywords.size(); j++) {
                if (lines[i].split(",")[3].toLowerCase().indexOf(keywords.get(j).toLowerCase()) != -1) {
                    String fields[] = lines[i].split(",");
                    if (fields[4].trim().equals("") || fields[4] == null) continue;

                    PenaltyData penaltyRowData = new PenaltyData();

                    Optional<RBIFSLOMapping> rbiFsloMapping = rbiFsloMappingRepository.findByRbiRegionCode(
                        Integer.parseInt(fields[2].trim())
                    );

                    if (rbiFsloMapping.isPresent()) {
                        penaltyRowData.setFslo(rbiFsloMapping.get());
                    } else continue;

                    penaltyRowData.setReportDate(LocalDate.parse(bglData.getDate(), dateFormatter));
                    penaltyRowData.setParticulars(fields[3].trim());
                    penaltyRowData.setDebit(Double.parseDouble(fields[4].trim()));
                    penaltyRowData.setStatus("Not Submitted");

                    for (int k = 0; k < penaltyDataProvided.size(); k++) {
                        PenaltyData temp = penaltyDataProvided.get(k);

                        if (
                            temp.getDebit().compareTo(penaltyRowData.getDebit()) == 0 &&
                            temp.getFslo() == penaltyRowData.getFslo() &&
                            temp.getParticulars().equals(penaltyRowData.getParticulars()) &&
                            temp.getReportDate().equals(penaltyRowData.getReportDate())
                        ) {
                            penaltyRowData.setStatus("Submitted");
                            penaltyRowData.setId(temp.getId());
                            break;
                        }
                    }

                    penaltyRows.add(penaltyRowData);

                    break;
                }
            }
        }

        penaltyDisplayData.setClosingBalance(bglData.getClosingBalance());
        penaltyDisplayData.setCreditTotal(bglData.getCreditTotal());
        penaltyDisplayData.setDebitTotal(bglData.getDebitTotal());
        penaltyDisplayData.setOpeningBalance(bglData.getOpeningBalance());

        for (int i = 0; i < penaltyDataProvided.size(); i++) {
            PenaltyData temp = penaltyDataProvided.get(i);
            int j = 0;
            for (j = 0; j < penaltyRows.size(); j++) {
                if (
                    temp.getDebit().compareTo(penaltyRows.get(j).getDebit()) == 0 &&
                    temp.getFslo() == penaltyRows.get(j).getFslo() &&
                    temp.getParticulars().equals(penaltyRows.get(j).getParticulars()) &&
                    temp.getReportDate().equals(penaltyRows.get(j).getReportDate())
                ) {
                    break;
                }
            }

            if (j == penaltyRows.size()) {
                temp.setStatus("Submitted");
                penaltyRows.add(temp);
            }
        }

        penaltyDisplayData.setPenaltyData(penaltyRows);
        return penaltyDisplayData;
    }
}
