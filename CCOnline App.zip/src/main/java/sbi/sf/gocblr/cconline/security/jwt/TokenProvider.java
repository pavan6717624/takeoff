package sbi.sf.gocblr.cconline.security.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import java.security.Key;
import java.util.Date;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.service.UserSessionService;

/**
 *
 * @author Kiran Marturu
 *
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TokenProvider {

    private static final String SESSION_ID_JWT_ID = "sessionId";

    private Key key;
    private long tokenValidityInMillis;

    private final ApplicationProperties appProperties;
    private final UserSessionService userSessionService;

    @PostConstruct
    public void init() {
        // can be generated using 'openssl rand -base64 128'
        byte[] keyBytes = Decoders.BASE64.decode(appProperties.getJwtSecret());
        this.key = Keys.hmacShaKeyFor(keyBytes);

        this.tokenValidityInMillis = 60 * 60000L; // 30 minutes
    }

    public String createToken(Authentication authentication, long sessionId) {
        AppUser appUser = (AppUser) authentication.getPrincipal();

        Date validity = new Date(System.currentTimeMillis() + tokenValidityInMillis);
        log.debug("JWT valid upto: {}", validity);

        return Jwts
            .builder()
            .setSubject(appUser.getId() + "")
            .claim(SESSION_ID_JWT_ID, sessionId)
            .setIssuedAt(new Date())
            .signWith(key, SignatureAlgorithm.HS512)
            .setExpiration(validity)
            .compact();
    }

    public boolean validateToken(String authToken) {
        try {
            Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(authToken);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            log.warn("JWT validation error: {}", e.getMessage());
        }
        return false;
    }

    public Authentication getAuthentication(String token) {
        Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();

        long userId = Long.parseLong(claims.getSubject());
        long sessionId = Long.parseLong(claims.get(SESSION_ID_JWT_ID).toString());

        AppUser user = userSessionService.loadUserByIdAndSession(userId, sessionId);
        if (user == null) {
            throw new BadCredentialsException("Invalid user id " + userId);
        }
        return new UsernamePasswordAuthenticationToken(user, token, user.getRoles());
    }
}
