package sbi.sf.gocblr.cconline.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SsoUser {

    private String pfIndex;
    private String employeeName;
    private String employeeGroupCode; // cadre O, S, C
    private String employeeSubGroupDesc; // designation
    private String personalSubAreaCode; // branch code
    private String personalSubAreaDesc;
    private String position;
    private String officialMailId;
    private String mobileNo;
}
