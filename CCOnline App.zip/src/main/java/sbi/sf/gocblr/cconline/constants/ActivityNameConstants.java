package sbi.sf.gocblr.cconline.constants;

public class ActivityNameConstants {

    private ActivityNameConstants() {
        /* static class not to be initialized */
    }

    public static final String LOGIN = "LOGIN";
    public static final String LOGOUT = "LOGOUT";

    public class Users {

        private Users() {
            /* static class */
        }

        public static final String APPROVE = "APPROVE_USER_REQUEST";
    }
}
