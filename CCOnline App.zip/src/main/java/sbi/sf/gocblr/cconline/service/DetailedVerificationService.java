package sbi.sf.gocblr.cconline.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.constants.SectionRouteConstants;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.Denomination;
import sbi.sf.gocblr.cconline.domain.DetailedVerification;
import sbi.sf.gocblr.cconline.domain.DetailedVerificationDetails;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.enums.DenominationType;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.repository.DetailedVerificationDetailsRepository;
import sbi.sf.gocblr.cconline.repository.DetailedVerificationRepository;
import sbi.sf.gocblr.cconline.service.dto.DetailedVerificationDTO;
import sbi.sf.gocblr.cconline.utils.NumberUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.NotesVerificationVM;

@Slf4j
@Service
@RequiredArgsConstructor
public class DetailedVerificationService {

    private final DetailedVerificationRepository repo;
    private final DetailedVerificationDetailsRepository detailsRepo;
    private final VerificationService verificationService;
    private final DenominationService denominationService;
    private final VerificationSectionService sectionService;
    private final VerificationSectionStatusService statusService;
    private final BalanceVerificationService balVerificationService;

    private static final String BAL_VER_NOT_SAVED = "Please save balance verification section before proceeding";

    @Transactional(readOnly = true)
    public List<DetailedVerificationDTO> getDetails(long verificationId) {
        var v = verificationService.getVerificationById(verificationId);

        var section = sectionService.getByTypeAndRoute(v.getType(), SectionRouteConstants.BALANCE_VERIFICATION);
        if (statusService.isSectionSaved(v, section)) {
            return detailsRepo.detailedVerification(v);
        } else {
            throw new InvalidOperationException(BAL_VER_NOT_SAVED);
        }
    }

    public void isCountAsPerPercentage(long verificationId, Map<Long, NotesVerificationVM> model) {
        var v = verificationService.getVerificationById(verificationId);
        var bvs = sectionService.getByTypeAndRoute(v.getType(), SectionRouteConstants.BALANCE_VERIFICATION);

        if (statusService.isSectionSaved(v, bvs)) {
            int per = 0;
            if (v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY)) {
                per = 2;
            } else if (v.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.HALF_YEARLY)) {
                per = 5;
            }

            int[] denominations = { 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1 };

            List<String> validationErrors = new ArrayList<>();

            for (int d : denominations) {
                var dd = denominationService.getByValueAndType(d, DenominationType.NOTE);
                var id = model.get(dd.getId());
                var sd = balVerificationService.getDetailsByDenomination(v.getId(), dd);

                double minToCount = sd.getNoOfPieces() * (per / 100d);

                log.debug("input: {} | saved: {} | min: {}", id.getNoOfPieces(), sd.getNoOfPieces(), minToCount);

                if (id.getNoOfPieces() < minToCount) {
                    validationErrors.add(
                        String.format(
                            "%s pieces should be counted for denomination Rs. %d; against current %s",
                            NumberUtils.inrFormat(Math.round(minToCount) + 1),
                            dd.getValue(),
                            NumberUtils.inrFormat(id.getNoOfPieces())
                        )
                    );
                }
            }

            // throw exception
            if (!validationErrors.isEmpty()) {
                throw new ValidationException(String.format("Min %d%% to be verified", per), validationErrors);
            }
        } else {
            throw new InvalidOperationException(BAL_VER_NOT_SAVED);
        }
    }

    @Transactional
    public void save(long verificationId, Map<Long, NotesVerificationVM> model) {
        Verification verification = verificationService.notSubmitted(verificationId);

        var bvs = sectionService.getByTypeAndRoute(verification.getType(), SectionRouteConstants.BALANCE_VERIFICATION);
        if (statusService.isSectionSaved(verification, bvs)) {
            isCountAsPerPercentage(verification.getId(), model);

            var existing = repo.findByVerificationId(verificationId);

            DetailedVerification dv;
            if (existing.isPresent()) {
                dv = existing.get();

                for (Map.Entry<Long, NotesVerificationVM> entry : model.entrySet()) {
                    var denomination = denominationService.getById(entry.getKey());
                    var details = detailsRepo.findByDetailedVerificationAndDenomination(dv, denomination);
                    DetailedVerificationDetails dvd;
                    if (details.isPresent()) {
                        setDetailsData(details.get(), entry.getValue(), denomination);
                        dv.addDetails(detailsRepo.save(details.get()));
                    } else {
                        dvd = new DetailedVerificationDetails();
                        dvd.setDetailedVerification(dv);
                        setDetailsData(dvd, entry.getValue(), denomination);
                        dv.addDetails(dvd);
                    }
                }
            } else {
                log.trace("new detailed verification");
                dv = new DetailedVerification();
                dv.setVerification(verification);
                dv = repo.save(dv);

                for (Map.Entry<Long, NotesVerificationVM> entry : model.entrySet()) {
                    var denomination = denominationService.getById(entry.getKey());
                    var dvd = new DetailedVerificationDetails();
                    dvd.setDetailedVerification(dv);
                    setDetailsData(dvd, entry.getValue(), denomination);

                    dv.addDetails(dvd);
                }
            }
            repo.save(dv);

            var section = sectionService.getByTypeAndRoute(verification.getType(), SectionRouteConstants.NOTES_VERIFICATION);
            statusService.updateSavedStatus(verification, section);
        } else {
            throw new InvalidOperationException(BAL_VER_NOT_SAVED);
        }
    }

    private void setDetailsData(DetailedVerificationDetails dvd, NotesVerificationVM value, Denomination denom) {
        dvd.setDenomination(denom);
        dvd.setNoOfPieces(value.getNoOfPieces());
        dvd.setDiscrepancyType(value.getDiscrepancyType());
        dvd.setDiscrepancyPieces(value.getDiscrepancyPieces() == null ? 0L : value.getDiscrepancyPieces());
        dvd.setFicn(value.getFicn() == null ? 0L : value.getFicn());
        dvd.setSoiledWronglyClassified(value.getSoiledWronglyClassified() == null ? 0L : value.getSoiledWronglyClassified());
        dvd.setMutilatedWronglyClassified(value.getMutilatedWronglyClassified() == null ? 0L : value.getMutilatedWronglyClassified());
    }
}
