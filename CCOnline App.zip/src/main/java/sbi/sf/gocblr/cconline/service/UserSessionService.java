package sbi.sf.gocblr.cconline.service;

import java.util.HashSet;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.User;
import sbi.sf.gocblr.cconline.domain.UserSession;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.BranchRepository;
import sbi.sf.gocblr.cconline.repository.UserRepository;
import sbi.sf.gocblr.cconline.repository.UserSessionRepository;
import sbi.sf.gocblr.cconline.security.AppUser;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserSessionService {

    private final UserSessionRepository repo;
    private final UserRepository userRepo;
    private final BranchRepository branchRepo;

    @Transactional
    public UserSession createSession(AppUser user) {
        blackListPreviousSessions(user.getId(), "logged in to new session");

        UserSession newSession = new UserSession();

        newSession.setPfId(user.getId());
        newSession.setTitle(user.getTitle());
        newSession.setName(user.getName());
        newSession.setBranchCode(user.getBranchCode());
        newSession.setBranchName(user.getBranchName());
        newSession.setRoles(new HashSet<>(user.getRoles()));
        newSession.setBlackListed(false);
        newSession.setNetworkCode(user.getNetworkCode());

        return repo.save(newSession);
    }

    @Transactional(readOnly = true)
    public Optional<UserSession> getSession(long sessionId) {
        return repo.findById(sessionId);
    }

    @Transactional(readOnly = true)
    public AppUser loadUserByIdAndSession(long userId, long sessionId) {
        Optional<UserSession> session = repo.findByIdAndPfId(sessionId, userId);
        if (session.isPresent()) {
            if (session.get().getBlackListed() != null && session.get().getBlackListed().booleanValue()) {
                throw new AuthenticationCredentialsNotFoundException(
                    session.get().getReasonForBlackListing() == null ? "Session expired" : session.get().getReasonForBlackListing()
                );
            }

            AppUser user = new AppUser();
            user.setId(session.get().getPfId());
            user.setSessionId(sessionId);
            user.setTitle(session.get().getTitle());
            user.setName(session.get().getName());

            Branch branch = branchRepo
                .findById(session.get().getBranchCode())
                .orElseThrow(
                    () -> new ResourceNotFoundException(String.format("No branch found with branch code %d", session.get().getBranchCode()))
                );

            user.setBranchCode(branch.getBranchCode());
            user.setBranchName(branch.getBranchName());
            user.setRegionCode(branch.getRegion().getRegionCode());
            user.setModuleCode(branch.getModule().getModuleCode());
            user.setModuleName(branch.getModule().getModuleName());
            user.setNetworkCode(branch.getNetwork().getNetworkCode());
            user.setCircleCode(branch.getCircle().getCircleCode());
            user.setCircleName(branch.getCircle().getCircleName());

            user.setRoles(session.get().getRoles());

            // update network for GM
            Optional<User> u = userRepo.findById(userId);
            if (u.isPresent() && u.get().getNetwork() != null) {
                user.setNetworkCode(u.get().getNetwork().getNetworkCode());
            }

            return user;
        } else {
            return null;
        }
    }

    @Transactional
    public void blackListUserSession(long userId, long sessionId, String reasonForBlackListing) {
        log.trace(">> blackListUserSession({}, {}, {})", userId, sessionId, reasonForBlackListing);

        Optional<UserSession> session = repo.findByIdAndPfId(sessionId, userId);
        if (session.isPresent()) {
            session.get().setBlackListed(true);
            session.get().setReasonForBlackListing(reasonForBlackListing);
            repo.save(session.get());
        }
    }

    @Transactional
    public void blackListPreviousSessions(long userId, String reasonForBlacklisting) {
        var notBlackListedSessions = repo.findByPfIdAndBlackListed(userId, false);

        notBlackListedSessions.forEach(
            s -> {
                s.setBlackListed(true);
                s.setReasonForBlackListing(reasonForBlacklisting);
            }
        );

        repo.saveAll(notBlackListedSessions);
    }
}
