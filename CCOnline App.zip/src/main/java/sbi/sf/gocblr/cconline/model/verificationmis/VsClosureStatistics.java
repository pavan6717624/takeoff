package sbi.sf.gocblr.cconline.model.verificationmis;

import sbi.sf.gocblr.cconline.domain.ValueStatement;
import sbi.sf.gocblr.cconline.domain.enums.InputType;

public interface VsClosureStatistics {
    ValueStatement getValueStatement();

    long getVsId();

    long getSectionId();
    int getSectionDisplayOrder();
    String getSectionDisplayNo();

    int getDisplayOrder();
    String getDisplayNumber();

    int getIndentLevel();
    String getDescription();
    boolean getIsOnlyAsHeader();
    InputType getInputType();

    Long getDiscrepanciesObserved();
    Long getNoDiscrepancyObserved();
    Long getDiscrepanciesClosed();
}
