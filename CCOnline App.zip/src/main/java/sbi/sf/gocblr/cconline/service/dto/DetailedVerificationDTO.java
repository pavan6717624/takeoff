package sbi.sf.gocblr.cconline.service.dto;

import sbi.sf.gocblr.cconline.domain.enums.DiscrepancyType;

public interface DetailedVerificationDTO {
    Long getDenominationId();
    String getDenominationType();
    Integer getDenominationValue();
    Long getNoOfPieces();
    DiscrepancyType getDiscrepancyType();
    Long getDiscrepancyPieces();
    Long getFicn();
    Long getSoiledWronglyClassified();
    Long getMutilatedWronglyClassified();
}
