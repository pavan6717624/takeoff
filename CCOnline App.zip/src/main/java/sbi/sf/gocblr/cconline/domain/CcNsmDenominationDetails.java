package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.NaturalId;

@Data
@Entity
@Table(name = "cc_nsm_denomination_details")
public class CcNsmDenominationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "cc_nsm_id", foreignKey = @ForeignKey(name = "fk_cc_nsm_denomination_details_cc_nsm_id"))
    private CcNsm ccNsm;

    @NaturalId
    private LocalDate month;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "denomination_id", foreignKey = @ForeignKey(name = "fk_cc_nsm_denomination_details_denomination_id"))
    private Denomination denomination;

    private Integer count; // in thousands

    private String status;
}
