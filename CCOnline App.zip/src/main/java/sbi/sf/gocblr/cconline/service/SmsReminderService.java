package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.SmsNotification;
import sbi.sf.gocblr.cconline.domain.SmsStatus;
import sbi.sf.gocblr.cconline.domain.enums.NotificationType;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.dto.BglDiffForSmsDTO;
import sbi.sf.gocblr.cconline.service.dto.CblExceededSmsDTO;
import sbi.sf.gocblr.cconline.service.dto.CsNotUploadedSmsDTO;
import sbi.sf.gocblr.cconline.service.dto.IBranchAndContactsDTO;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.utils.NumberUtils;
import sbi.sf.gocblr.cconline.web.rest.CblExceededSmsModel;
import sbi.sf.gocblr.cconline.web.vm.NotificationTypes;
import sbi.sf.gocblr.cconline.web.vm.SendSmsModel;

@Slf4j
@Service
@RequiredArgsConstructor
public class SmsReminderService {

    private final SmsService smsService;
    private final Environment env;
    private final ApplicationProperties app;
    private final CurrencyChestService ccService;
    private final SmsStatusService smsStatusService;
    private final CurrencyChestRepository ccRepo;
    private final NotificationTypeService notificationTypeService;

    @Transactional
    public void chestSlipNotUploaded(@Valid SendSmsModel im, LocalDate forDate) {
        AppUser loggedInUser = SecurityUtils.getLoggedInUser();

        NotificationType nt = notificationTypeService.getByName(NotificationTypes.CS_NOT_UPLOADED.toString());

        List<CsNotUploadedSmsDTO> data = ccRepo.chestSlipNotUploaded(
            loggedInUser.getBranchCode(),
            im.getBranches(),
            forDate,
            Pageable.unpaged()
        );

        for (var branch : data) {
            String text = prepareCsNotUploadedTemplate(branch, forDate);
            prepareForBranch(nt, branch, text, forDate);
        }
    }

    private void prepareForBranch(NotificationType nt, IBranchAndContactsDTO branch, String text, LocalDate forDate) {
        log.trace(">> prepareForBranch()");
        boolean isDev = env.acceptsProfiles(Profiles.of("dev"));
        boolean isProd = env.acceptsProfiles(Profiles.of("prod"));

        SmsStatus status = new SmsStatus(nt, ccService.getByBranchCode(branch.getBranchCode()), forDate, true);
        if (isProd) {
            addMessage(status, branch.getBmMobileNo(), text, forDate);
            addMessage(status, branch.getAccountantMobileNo(), text, forDate);
            addMessage(status, branch.getCoMobileNo(), text, forDate);
        } else {
            addMessage(status, app.getSmsPreProdNumber(), text, forDate);
        }

        SmsStatus sent = smsStatusService.save(status);
        if (!isDev) {
            smsService.sendSms(sent.getMessages());
        } else {
            log.info("SMS not sent to API in dev");
        }
    }

    // CyM chest slip is not uploaded in CC Online of branch code %d dtd. %s. Kindly upload ASAP%n- SBI CC Online
    private String prepareCsNotUploadedTemplate(CsNotUploadedSmsDTO branch, LocalDate forDate) {
        return String.format(app.getSmsCsNotUploadedText(), branch.getBranchCode(), DateUtils.format(forDate));
    }

    // CyM and BGL %d difference of %s dtd. %s for branch code %d. Reconcile today itself\n- SBI CC Online
    private String prepareBglDiffTemplate(int bgl, BglDiffForSmsDTO branch, LocalDate forDate) {
        return String.format(
            app.getSmsBglDiffText(),
            bgl,
            NumberUtils.inrFormat(branch.getDifference()),
            DateUtils.format(forDate),
            branch.getBranchCode()
        );
    }

    // CBL is exceeded by %s on dt. %s for branch code %d\n- SBI CC Online
    private String prepareCblExceededTemplate(CblExceededSmsDTO branch, LocalDate forDate) {
        return String.format(
            app.getSmsCblExceededText(),
            NumberUtils.inrFormat(branch.getExceededBy()),
            DateUtils.format(forDate),
            branch.getBranchCode()
        );
    }

    @Transactional
    public void bgl98908NotMatchingWithCym(@Valid SendSmsModel im, LocalDate forDate) {
        AppUser loggedInUser = SecurityUtils.getLoggedInUser();

        NotificationType nt = notificationTypeService.getByName(sbi.sf.gocblr.cconline.web.vm.NotificationTypes.DIFF_BGL_98908.toString());

        List<BglDiffForSmsDTO> data = ccRepo.bgl98908Diff(loggedInUser.getBranchCode(), im.getBranches(), forDate, Pageable.unpaged());

        for (var branch : data) {
            String text = prepareBglDiffTemplate(98908, branch, forDate);
            prepareForBranch(nt, branch, text, forDate);
        }
    }

    public void bgl98958NotMatchingWithCym(@Valid SendSmsModel im, LocalDate forDate) {
        AppUser loggedInUser = SecurityUtils.getLoggedInUser();

        NotificationType nt = notificationTypeService.getByName(NotificationTypes.DIFF_BGL_98958.toString());

        Page<BglDiffForSmsDTO> data = ccRepo.bgl98958Diff(loggedInUser.getBranchCode(), im.getBranches(), forDate, Pageable.unpaged());

        List<SmsStatus> statuses = new ArrayList<>();
        for (var branch : data.getContent()) {
            String text = prepareBglDiffTemplate(98958, branch, forDate);
            prepareForBranch(nt, branch, text, forDate);
        }
        smsStatusService.saveAll(statuses);
    }

    public void cblExceeded(@Valid CblExceededSmsModel im, LocalDate forDate) {
        AppUser loggedInUser = SecurityUtils.getLoggedInUser();

        NotificationType nt = notificationTypeService.getByName(NotificationTypes.CBL_EXCEEDED.toString());

        Page<CblExceededSmsDTO> data = ccRepo.cblExceededFilterByBranches(
            loggedInUser.getBranchCode(),
            im.getBranches(),
            forDate,
            im.getExceededBy(),
            nt,
            Pageable.unpaged()
        );

        for (var branch : data.getContent()) {
            String text = prepareCblExceededTemplate(branch, forDate);
            prepareForBranch(nt, branch, text, forDate);
        }
    }

    private void addMessage(SmsStatus status, Long mob, String msg, LocalDate forDate) {
        if (mob != null) {
            status.addMessage(new SmsNotification(mob, msg, forDate));
        }
    }
}
