package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.CenterType;

@Converter(autoApply = true)
public class CenterTypeConverter implements AttributeConverter<CenterType, String> {

    @Override
    public String convertToDatabaseColumn(CenterType centerType) {
        if (centerType == null) {
            return null;
        }
        return centerType.code();
    }

    @Override
    public CenterType convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return CenterType.fromCode(code);
    }
}
