package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class BGLStatementDisplay {

    private Long fsloCode;
    private String fsloName;
    private double deposit;
    private double withdrawal;
    private double ct;
    private String fileurl;
}
