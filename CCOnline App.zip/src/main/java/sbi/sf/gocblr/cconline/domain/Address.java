package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Embeddable;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import sbi.sf.gocblr.cconline.domain.enums.CenterType;
import sbi.sf.gocblr.cconline.domain.enums.PopulationGroup;

/**
 * Address details of Currency Chest
 *
 * @author Kiran Marturu
 *
 */
@Embeddable
@Getter
@Setter
@ToString
public class Address implements Serializable {

    private static final long serialVersionUID = 421200877977067751L;

    private String line1;
    private String line2;
    private String line3;

    private Long pincode;
    private String district;
    private String telephone;

    @ManyToOne
    @JoinColumn(name = "state_code", foreignKey = @ForeignKey(name = "fk_currency_chests_state"))
    private State state;

    private String centerName;
    private CenterType centerType;

    private String policeStation;

    private PopulationGroup populationGroup;
}
