package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
@Entity
@Table(name = "chest_slip_upload_details")
public class ChestSlipUploadDetails implements Serializable {

    private static final long serialVersionUID = 7325334760967207299L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cs_date")
    private LocalDate chestSlipDate;

    @Column(name = "cs_upload_date")
    private LocalDate chestSlipUploadDate;

    @Column(name = "upload_file")
    private String uploadFile;

    @ManyToOne
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_chest_slip_upload_details_cc"))
    private CurrencyChest currencyChest;

    private String status;

    String ipaddress;
    Long pfid;

    String printDetails;
}
