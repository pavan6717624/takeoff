package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "cash_retention_limit")
public class CashRetentionLimit implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 310734978694594486L;
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    Long id;
	 
	 LocalDate reportDate;
	 Long branchCode;
	 @Column(columnDefinition = "NUMBER(20, 2)")
	 Double cglBalance;
	 @Column(columnDefinition = "NUMBER(20, 2)")
	 Double cashBalance;
	 String currencyChestFlag;
	 Long branchType;
	 @Column(columnDefinition = "NUMBER(20, 2)")
	 Double cashLimit;
	 LocalDate closeDate;
	 String liveFlag;
	 Integer withinLimit;
	 Integer exceededLimit;
	 



}
