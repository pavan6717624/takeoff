package sbi.sf.gocblr.cconline.exception;

public class NoDataException extends ServiceException {

    private static final long serialVersionUID = 4100633668735441327L;

    public NoDataException(String filter, String entityName) {
        super(String.format("Not found '%s' in %s", filter, entityName));
    }
}
