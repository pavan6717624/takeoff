package sbi.sf.gocblr.cconline.model;

import java.util.List;

import lombok.Data;
@Data
public class ConsecutiveReportDTO {
	
	List<String> keys;
	
	List<List<CBLExceedingDaysReport>> values;
	
	List<Long> monthCount;
	
	List<Long> monthConsecutiveCount;
}
