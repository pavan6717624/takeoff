package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ComplianceVerificationOfficer;
import sbi.sf.gocblr.cconline.service.dto.DetailsForNotify;

@Repository
public interface ComplianceVerificationOfficerRepository extends JpaRepository<ComplianceVerificationOfficer, Long> {
    List<ComplianceVerificationOfficer> findByPfIdAndVerificationTypeKeyIn(long pfId, String[] types);

    @Query(
        "SELECT c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       cvo.mobileNo as mobileNo, " +
        "       cvo.emailId as emailId, " +
        "       v.type as verificationType " +
        "  FROM ComplianceVerificationOfficer cvo " +
        "       JOIN Verification v " +
        "         ON v.id = cvo.id " +
        "       JOIN CurrencyChest c " +
        "         ON c = v.currencyChest " +
        " WHERE cvo.id = :verificationId"
    )
    DetailsForNotify detailsForNotification(@Param("verificationId") long verificationId);
}
