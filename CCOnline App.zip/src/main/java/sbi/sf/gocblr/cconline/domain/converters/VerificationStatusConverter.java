package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;

@Converter(autoApply = true)
public class VerificationStatusConverter implements AttributeConverter<VerificationStatus, String> {

    @Override
    public String convertToDatabaseColumn(VerificationStatus vs) {
        if (vs == null) {
            return null;
        }
        return vs.code();
    }

    @Override
    public VerificationStatus convertToEntityAttribute(String vsCode) {
        if (vsCode == null) {
            return null;
        }
        return VerificationStatus.fromCode(vsCode);
    }
}
