package sbi.sf.gocblr.cconline.model;

import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.Denomination;

public interface ChestSlipDTO {
    Long getCsid();

    ChestSlipParticular getParticulars();

    Denomination getDenominations();

    Double getValue();

    ChestSlipUploadDetails getCheckSlipUploadDetails();
}
/*
 * package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import sbi.sf.gocblr.cconline.domain.enums.DenominationType;

public interface DenomintaionAndPiecesDTO {
    Long getDenominationId();
    Integer getDenominationValue();

    @JsonIgnore
    DenominationType getDenominationType();

    Long getNoOfPieces();
}

 */
