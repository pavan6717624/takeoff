package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.RBIBGLStatementUploadDetails;

@Repository
public interface RBIBGLStatementUploadDetailsRepository extends JpaRepository<RBIBGLStatementUploadDetails, Long> {
    @Query("select max(fileDate) from RBIBGLStatementUploadDetails")
    LocalDate getLatestUploadDate();

    @Query(
        "select uploadDetails from RBIBGLStatementUploadDetails uploadDetails where uploadDetails.id = (select max(id) from RBIBGLStatementUploadDetails)"
    )
    RBIBGLStatementUploadDetails getLatestUploadData();

    Optional<RBIBGLStatementUploadDetails> findByFileDate(LocalDate date);
}
