package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Module;
import sbi.sf.gocblr.cconline.domain.ModuleId;

public interface ModuleRepository extends JpaRepository<Module, ModuleId>, JpaSpecificationExecutor<Module> {
    @Query(
        "SELECT m " +
        "  FROM Module m " +
        " WHERE m.moduleCode = :moduleCode " +
        "   AND m.network.networkCode = :networkCode " +
        "   AND m.network.circle.circleCode = :circleCode "
    )
    Optional<Module> module(@Param("circleCode") long cc, @Param("networkCode") long nc, @Param("moduleCode") long mc);

    @Query(
        "select moduleCode from Module m where m.network.circle.circleCode=:circleCode and m.network.networkCode=:networkCode and m.moduleName like :moduleName "
    )
    Long getModuleCode(
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode,
        @Param("moduleName") String moduleName
    );

    List<Module> findAll(Specification<Module> spec);
}
