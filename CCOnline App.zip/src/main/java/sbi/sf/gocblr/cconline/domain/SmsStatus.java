package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.NaturalId;
import sbi.sf.gocblr.cconline.domain.enums.NotificationType;

@Getter
@Setter
@Entity
@Table(name = "sms_notification_status")
@NoArgsConstructor
public class SmsStatus extends AbstractAuditingEntity {

    private static final long serialVersionUID = 5561960528681051751L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @NaturalId
    @JoinColumn(name = "notification_type_id", foreignKey = @ForeignKey(name = "fk_sms_notification_status_notification_type"))
    private NotificationType notificationType;

    @ManyToOne
    @NaturalId
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_sms_notification_status_currency_chest"))
    private CurrencyChest currencyChest;

    @NaturalId
    @Column(name = "for_date")
    private LocalDate forDate;

    @Column(name = "is_sent")
    private Boolean sent;

    @OneToMany(mappedBy = "smsStatus", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<SmsNotification> messages = new HashSet<>();

    public SmsStatus(NotificationType nt, CurrencyChest cc, LocalDate forDate, boolean sent) {
        this.notificationType = nt;
        this.currencyChest = cc;
        this.forDate = forDate;
        this.sent = sent;
    }

    /* for keeping bi-directional in sync */
    public void addMessage(SmsNotification msg) {
        messages.add(msg);
        msg.setSmsStatus(this);
    }

    public void removeMessage(SmsNotification msg) {
        messages.remove(msg);
        msg.setSmsStatus(null);
    }
}
