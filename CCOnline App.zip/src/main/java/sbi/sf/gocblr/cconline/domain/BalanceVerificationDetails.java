package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.NaturalId;

@Entity
@Table(
    name = "balance_verification_details",
    uniqueConstraints = @UniqueConstraint(
        columnNames = { "balance_verification_id", "denomination_id" },
        name = "uk_balance_verification_details_natural_id"
    )
)
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class BalanceVerificationDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "balance_verification_id", foreignKey = @ForeignKey(name = "fk_bal_verification_details_bal_verification"))
    private BalanceVerification balanceVerification;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "denomination_id", foreignKey = @ForeignKey(name = "fk_bal_verification_details_denomination"))
    @EqualsAndHashCode.Include
    private Denomination denomination;

    @Column(name = "no_of_pieces")
    private Long noOfPieces;
}
