package sbi.sf.gocblr.cconline.domain;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "audit_events")
public class PersistentAuditEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    @EqualsAndHashCode.Include
    private Long id;

    @NotNull
    @Column(name = "user_id", nullable = false)
    private String user;

    @Column(name = "event_at")
    private ZonedDateTime eventDate;

    @Column(name = "event_type")
    private String eventType;

    @ElementCollection
    @MapKeyColumn(name = "name")
    @Column(name = "value")
    @CollectionTable(
        name = "audit_events_data",
        joinColumns = @JoinColumn(name = "event_id", foreignKey = @ForeignKey(name = "fk_audit_events_data_event_id"))
    )
    private Map<String, String> data = new HashMap<>();
}
