package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.CcNsm;
import sbi.sf.gocblr.cconline.service.dto.NsmReport;
import sbi.sf.gocblr.cconline.service.dto.NsmSubmissionSummary;

public interface CcNsmRepository extends JpaRepository<CcNsm, Long> {
    List<CcNsm> findByCurrencyChestBranchCode(Long branchCode);
    List<CcNsm> findByCurrencyChestBranchCodeAndActive(long branchCode, boolean isActive);

    // FSLO
    @Query(
        "SELECT SUM(CASE WHEN s IS NULL THEN 1 ELSE 0 END) as notSubmitted, " +
        "       SUM(CASE WHEN s IS NULL THEN 0 ELSE 1 END) as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE abs(c.fslo.branchCode)= :fsloCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month "
    )
    NsmSubmissionSummary getReportSummary(@Param("month") LocalDate month, @Param("fsloCode") long fsloCode);

    // FSLO
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE abs(c.fslo.branchCode)= :fsloCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<NsmReport> getNsmStatusDetails(@Param("month") LocalDate month, @Param("fsloCode") long fsloCode);

    // Circle_Admin
    @Query(
        "SELECT SUM(CASE WHEN s IS NULL THEN 1 ELSE 0 END) as notSubmitted, " +
        "       SUM(CASE WHEN s IS NULL THEN 0 ELSE 1 END) as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month "
    )
    NsmSubmissionSummary getReportSummaryCircleAdmin(@Param("month") LocalDate month, @Param("circleCode") long circleCode);

    // Circle_Admin
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<NsmReport> getNsmStatusDetailsCircleAdmin(@Param("month") LocalDate month, @Param("circleCode") long circleCode);

    // AO_User and AGM_GB
    @Query(
        "SELECT SUM(CASE WHEN s IS NULL THEN 1 ELSE 0 END) as notSubmitted, " +
        "       SUM(CASE WHEN s IS NULL THEN 0 ELSE 1 END) as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month "
    )
    NsmSubmissionSummary getReportSummaryAoUser(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode
    );

    // AO_User and AGM_GB
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<NsmReport> getNsmStatusDetailsAoUser(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode
    );

    // RM and RBO_CM
    @Query(
        "SELECT SUM(CASE WHEN s IS NULL THEN 1 ELSE 0 END) as notSubmitted, " +
        "       SUM(CASE WHEN s IS NULL THEN 0 ELSE 1 END) as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND c.region.regionCode = :regionCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month "
    )
    NsmSubmissionSummary getReportSummaryRBO(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("regionCode") long regionCode
    );

    // RM and RBO_CM
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleCode as moduleCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       CASE WHEN s IS NULL THEN 'No' ELSE 'Yes' END as submitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN CcNsmMonthStatus s " +
        "              ON s.cc = c " +
        "             AND s.month = :month " +
        "  WHERE c.circle.circleCode = :circleCode " +
        "    AND c.network.networkCode = :networkCode " +
        "    AND c.module.moduleCode = :moduleCode " +
        "    AND c.region.regionCode = :regionCode " +
        "    AND NVL(c.dateOfOpening, :month) <=  :month \n" +
        "    AND NVL(c.closedDate, :month) >= :month " +
        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    )
    List<NsmReport> getNsmStatusDetailsRBO(
        @Param("month") LocalDate month,
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("regionCode") long regionCode
    );
}
