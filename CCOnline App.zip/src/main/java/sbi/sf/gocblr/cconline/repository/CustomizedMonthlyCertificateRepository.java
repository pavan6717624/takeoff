package sbi.sf.gocblr.cconline.repository;

import sbi.sf.gocblr.cconline.domain.criteria.MonthlyCertificateCriteria;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateSubmissionSummary;

public interface CustomizedMonthlyCertificateRepository {
    MonthlyCertificateSubmissionSummary submissionSummary(MonthlyCertificateCriteria criteria);
}
