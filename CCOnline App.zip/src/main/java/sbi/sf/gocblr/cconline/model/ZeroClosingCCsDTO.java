package sbi.sf.gocblr.cconline.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ZeroClosingCCsDTO {

    String circle;
    Long network;
    Long module;
    String moduleName;
    Long region;
    Long brcode;
    String brname;
    String csdate;
    Long openingBalance;
    Long closingBalance;
}
