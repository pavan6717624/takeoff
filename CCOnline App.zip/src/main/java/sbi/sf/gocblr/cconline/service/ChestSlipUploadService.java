package sbi.sf.gocblr.cconline.service;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.constants.ErrorMessage;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.ChestSlips;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.TotalsTable;
import sbi.sf.gocblr.cconline.exception.ParsingException;
import sbi.sf.gocblr.cconline.model.ChestSlip;
import sbi.sf.gocblr.cconline.model.MISReport;
import sbi.sf.gocblr.cconline.model.PDFTable;
import sbi.sf.gocblr.cconline.model.ViewChestSlip;
import sbi.sf.gocblr.cconline.repository.ChestSlipUploadDetailsRepository;
import sbi.sf.gocblr.cconline.repository.ChestSlipsRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.DenominationRepository;
import sbi.sf.gocblr.cconline.repository.ParticularsRepository;
import sbi.sf.gocblr.cconline.repository.RoleRepository;
import sbi.sf.gocblr.cconline.repository.TotalsTableRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChestSlipUploadService {

    private final ApplicationProperties applicationProperties;
    private final PdfParsingService pdfParsingService;
    private final DenominationRepository denominationsRepository;
    private final ParticularsRepository particularsRepository;
    private final ChestSlipsRepository checkSlipsRepository;
    private final TotalsTableRepository totalsTableRepository;
    private final ChestSlipUploadDetailsRepository checkSlipUploadDetailsRepository;
    private final CurrencyChestRepository currencyChestRepository;
    private final RoleRepository roleRepository;

    @Transactional
    public ChestSlip saveFile(MultipartFile file, LocalDate date, Long brcode, String ipaddress, Long timeStamp) {
        ChestSlip pdfDocument = uploadFile(file, date, brcode, timeStamp);

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        String structuredPath = dateFormatter.format(date) + File.separator + brcode + File.separator + timeStamp + File.separator;

        if (pdfDocument.getStatus().equals("Error")) return pdfDocument;

        ChestSlipUploadDetails checkSlipUploadDetails = new ChestSlipUploadDetails();

        CurrencyChest cc = currencyChestRepository.findByCcCode(pdfDocument.getCcCode()).orElseThrow();
        Optional<ChestSlipUploadDetails> checkSlipUploadDetails1 = checkSlipUploadDetailsRepository.findByCurrencyChestAndChestSlipDate(
            cc,
            pdfDocument.getDate()
        );

        if (checkSlipUploadDetails1.isPresent()) {
            ChestSlipUploadDetails checkSlipUploadDetailstemp = checkSlipUploadDetails1.get();
            checkSlipUploadDetailstemp.setStatus("Deleted");
            checkSlipUploadDetailsRepository.save(checkSlipUploadDetailstemp);
        }

        checkSlipUploadDetails.setChestSlipUploadDate(LocalDate.now());
        checkSlipUploadDetails.setChestSlipDate(pdfDocument.getDate());
        checkSlipUploadDetails.setStatus("New");

        String filename = file.getOriginalFilename();

        if (filename.contains("\\")) filename = filename.substring(filename.lastIndexOf("\\") + 1);

        checkSlipUploadDetails.setUploadFile(applicationProperties.getFileUploadsBasePath() + structuredPath + filename);
        //checkSlipUploadDetails.setBranchprofile(branchProfileRepository.findByCCCode(Long.parseLong(pdfDocument.getCccode() + "")));
        checkSlipUploadDetails.setCurrencyChest(cc);
        checkSlipUploadDetails.setPrintDetails(pdfDocument.getPrintDetails());
        checkSlipUploadDetails.setIpaddress(ipaddress);
        checkSlipUploadDetails.setPfid(SecurityUtils.getLoggedInUser().getId());
        checkSlipUploadDetailsRepository.save(checkSlipUploadDetails);

        Long uploadId = checkSlipUploadDetails.getId();

        PDFTable notesTable = pdfDocument.getNotesTable();

        for (int i = 0; i < notesTable.getData().length; i++) {
            int j = 1;
            for (j = 1; j < notesTable.getData()[i].length - 2; j++) {
                ChestSlips chestSlips = new ChestSlips();
                chestSlips.setParticulars(particularsRepository.particularByKeyword(notesTable.getParticulars().get(i) + "", "Notes"));

                chestSlips.setDenominations(
                    denominationsRepository.denominationsByValue(Integer.parseInt(notesTable.getDenominations()[j - 1]), "N")
                );
                if (!notesTable.getData()[i][j].equals("NA")) chestSlips.setValue(
                    Double.parseDouble(notesTable.getData()[i][j].replace(",", ""))
                ); else chestSlips.setValue(0.00);
                chestSlips.setCheckSlipUploadDetails(checkSlipUploadDetailsRepository.findChestSlipUploadDetails(uploadId));
                checkSlipsRepository.save(chestSlips);
            }

            TotalsTable totalsTable = new TotalsTable();
            totalsTable.setCheckSlipUploadDetails(checkSlipUploadDetailsRepository.findChestSlipUploadDetails(uploadId));
            totalsTable.setParticular(particularsRepository.particularByKeyword(notesTable.getParticulars().get(i) + "", "Notes"));

            if (!notesTable.getData()[i][j].equals("NA")) totalsTable.setTotalPieces(
                Double.parseDouble(notesTable.getData()[i][j].replace(",", ""))
            ); else totalsTable.setTotalPieces(0.00);
            if (!notesTable.getData()[i][j + 1].equals("NA")) totalsTable.setTotalValue(
                Double.parseDouble(notesTable.getData()[i][j + 1].replace(",", ""))
            ); else totalsTable.setTotalValue(0.00);

            totalsTableRepository.save(totalsTable);
        }

        PDFTable coinsTable = pdfDocument.getCoinsTable();

        for (int i = 0; i < coinsTable.getData().length; i++) {
            int j = 1;
            for (j = 1; j < coinsTable.getData()[i].length - 2; j++) {
                ChestSlips chestSlips = new ChestSlips();
                chestSlips.setParticulars(particularsRepository.particularByKeyword(coinsTable.getParticulars().get(i) + "", "Coins"));
                chestSlips.setDenominations(
                    denominationsRepository.denominationsByValue(Integer.parseInt(coinsTable.getDenominations()[j - 1]), "C")
                );
                if (!coinsTable.getData()[i][j].equals("NA")) chestSlips.setValue(
                    Double.parseDouble(coinsTable.getData()[i][j].replace(",", ""))
                ); else chestSlips.setValue(0.00);
                chestSlips.setCheckSlipUploadDetails(checkSlipUploadDetailsRepository.findChestSlipUploadDetails(uploadId));
                checkSlipsRepository.save(chestSlips);
            }

            TotalsTable totalsTable = new TotalsTable();
            totalsTable.setCheckSlipUploadDetails(checkSlipUploadDetailsRepository.findChestSlipUploadDetails(uploadId));
            totalsTable.setParticular(particularsRepository.particularByKeyword(coinsTable.getParticulars().get(i) + "", "Coins"));

            if (!coinsTable.getData()[i][j].equals("NA")) totalsTable.setTotalPieces(
                Double.parseDouble(coinsTable.getData()[i][j].replace(",", ""))
            ); else totalsTable.setTotalPieces(0.00);
            if (!coinsTable.getData()[i][j + 1].equals("NA")) totalsTable.setTotalValue(
                Double.parseDouble(coinsTable.getData()[i][j + 1].replace(",", ""))
            ); else totalsTable.setTotalValue(0.00);

            totalsTableRepository.save(totalsTable);

            pdfDocument.setStatus("Success");
            pdfDocument.setMessage("File - " + pdfDocument.getFileName() + " Uploaded Successfully");
        }
        return pdfDocument;
    }

    

    
    public String uploadFileAdmin(MultipartFile file) {
    	
    	String text="";
        Long timeStamp = Instant.now().toEpochMilli();
        
        ChestSlip pdfDocument = new ChestSlip();

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        String structuredPath = dateFormatter.format(LocalDate.now()) + File.separator + "03999" + File.separator + timeStamp + File.separator;

        try {
            if (file.isEmpty()) {
                pdfDocument.setStatus("Failed");
                pdfDocument.setMessage("No file attached");
            } else {
                byte[] bytes = file.getBytes();
                String filename = file.getOriginalFilename();

                if (filename != null && filename.contains("\\")) filename = filename.substring(filename.lastIndexOf("\\") + 1);

                File uploadFolder = new File(applicationProperties.getFileUploadsBasePath() + structuredPath);
                if (!uploadFolder.exists()) {
                    if (!uploadFolder.mkdirs()) {
                        throw new IOException(ErrorMessage.CONTACT_HELPDESK);
                    }
                }

                Path path = Paths.get(applicationProperties.getFileUploadsBasePath() + structuredPath + filename);

                Files.write(path, bytes);
                
                text=pdfParsingService.splitIntoLinesAdmin(applicationProperties.getFileUploadsBasePath() + structuredPath + filename);    
                
            }
        } catch (ParsingException invalidekuber) {
            text="";
            log.error(invalidekuber.getMessage() + " - Invalid E Kuber File");
        } catch (IOException e) {
            text="";
            log.error(e.getMessage() + " - File Reading Error. Please check the File Uploaded", e);
        }
        return text; 
    }
    
    public ChestSlip uploadFile(MultipartFile file, LocalDate date, Long brcode, Long timeStamp) {
        ChestSlip pdfDocument = new ChestSlip();

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        String structuredPath = dateFormatter.format(date) + File.separator + brcode + File.separator + timeStamp + File.separator;

        try {
            if (file.isEmpty()) {
                pdfDocument.setStatus("Failed");
                pdfDocument.setMessage("No file attached");
            } else {
                byte[] bytes = file.getBytes();
                String filename = file.getOriginalFilename();

                if (filename != null && filename.contains("\\")) filename = filename.substring(filename.lastIndexOf("\\") + 1);

                File uploadFolder = new File(applicationProperties.getFileUploadsBasePath() + structuredPath);
                if (!uploadFolder.exists()) {
                    if (!uploadFolder.mkdirs()) {
                        throw new IOException(ErrorMessage.CONTACT_HELPDESK);
                    }
                }

                Path path = Paths.get(applicationProperties.getFileUploadsBasePath() + structuredPath + filename);

                Files.write(path, bytes);

                pdfDocument =
                    pdfParsingService.parsePdf(applicationProperties.getFileUploadsBasePath() + structuredPath + filename, date, brcode);
            }
        } catch (ParsingException invalidekuber) {
            pdfDocument.setStatus("Failed");
            pdfDocument.setMessage(invalidekuber.getMessage());
            log.error(invalidekuber.getMessage() + " - Invalid E Kuber File");
        } catch (IOException e) {
            pdfDocument.setStatus("Failed");
            pdfDocument.setMessage("File Reading Error. Please check the File Uploaded - " + file.getOriginalFilename());
            log.error(e.getMessage() + " - File Reading Error. Please check the File Uploaded", e);
        }
        return pdfDocument;
    }

    @Transactional
    public List<MISReport> getUploadedBranches(LocalDate chestSlipDate) {
        List<CurrencyChest> currencyChests = checkSlipUploadDetailsRepository.listOfUploadedBranches(chestSlipDate);

        currencyChests =
            currencyChests
                .stream()
                .filter(
                    o ->
                        (o.getClosedDate() == null || (o.getClosedDate() != null && o.getClosedDate().compareTo(chestSlipDate) >= 0)) &&
                        o.getDateOfOpening() != null &&
                        o.getDateOfOpening().compareTo(chestSlipDate) <= 0
                )
                .collect(Collectors.toList());

        AppUser user = SecurityUtils.getLoggedInUser();

        Set<Role> roles = user.getRoles();

        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        List<MISReport> misReport = new ArrayList<>();
        for (int i = 0; i < currencyChests.size(); i++) {
            CurrencyChest ccchest = currencyChests.get(i);

            if (roles.contains(FSLO_USER) && ccchest.getFslo().getBranchCode().compareTo(user.getBranchCode()) != 0) continue;

            if (
                (roles.contains(BRANCH_USER) || roles.contains(BRANCH_HEAD)) && ccchest.getBranchCode().compareTo(user.getBranchCode()) != 0
            ) continue;

            if (
                (roles.contains(RBO_CM) || roles.contains(RM)) &&
                (
                    ccchest.getRegion().getRegionCode().compareTo(user.getRegionCode()) != 0 ||
                    ccchest.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(AO_USER) || roles.contains(AGM_GB)) &&
                (
                    ccchest.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(CIRCLE_ADMIN) || roles.contains(DGM_CFO)) &&
                ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
            ) continue;

            MISReport report = new MISReport();

            report.setBrcode(ccchest.getBranchCode());
            report.setBrname(ccchest.getBranchName());
            report.setCccode(ccchest.getCcCode());
            report.setCircle(ccchest.getCircle().getCircleName());
            report.setFsloName(ccchest.getFslo().getBranchName());
            report.setFslocode(ccchest.getFslo().getBranchCode());
            report.setModuleName(ccchest.getModule().getModuleName());
            report.setModule(ccchest.getModule().getModuleCode());
            report.setModuleName(ccchest.getModule().getModuleName());
            report.setNetwork(ccchest.getNetwork().getNetworkCode());
            report.setRegion(ccchest.getRegion().getRegionCode());

            misReport.add(report);

            Collections.sort(
                misReport,
                new Comparator<MISReport>() {
                    @Override
                    public int compare(MISReport o1, MISReport o2) {
                        String circle1 = o1.getCircle() + "";
                        String network1 = o1.getNetwork() + "";
                        String module1 = o1.getModule() + "";
                        String region1 = o1.getRegion() + "";
                        String brcode1 = o1.getBrcode() + "";

                        String circle2 = o2.getCircle() + "";
                        String network2 = o2.getNetwork() + "";
                        String module2 = o2.getModule() + "";
                        String region2 = o2.getRegion() + "";
                        String brcode2 = o2.getBrcode() + "";

                        String compare1 = circle1 + "" + network1 + "" + module1 + "" + region1 + "" + brcode1;
                        String compare2 = circle2 + "" + network2 + "" + module2 + "" + region2 + "" + brcode2;

                        return compare1.compareTo(compare2);
                    }
                }
            );
        }

        return misReport;
    }

    @Transactional
    public List<MISReport> getNotUploadedBranches(LocalDate chestSlipDate) {
        List<CurrencyChest> currencyChests = checkSlipUploadDetailsRepository.listOfNotUploadedBranches(chestSlipDate);

        currencyChests =
            currencyChests
                .stream()
                .filter(
                    o ->
                        (o.getClosedDate() == null || (o.getClosedDate() != null && o.getClosedDate().compareTo(chestSlipDate) >= 0)) &&
                        o.getDateOfOpening() != null &&
                        o.getDateOfOpening().compareTo(chestSlipDate) <= 0
                )
                .collect(Collectors.toList());

        AppUser user = SecurityUtils.getLoggedInUser();

        Set<Role> roles = user.getRoles();

        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        List<MISReport> misReport = new ArrayList<>();
        for (int i = 0; i < currencyChests.size(); i++) {
            CurrencyChest ccchest = currencyChests.get(i);

            if (roles.contains(FSLO_USER) && ccchest.getFslo().getBranchCode().compareTo(user.getBranchCode()) != 0) continue;

            if (
                (roles.contains(BRANCH_USER) || roles.contains(BRANCH_HEAD)) && ccchest.getBranchCode().compareTo(user.getBranchCode()) != 0
            ) continue;

            if (
                (roles.contains(RBO_CM) || roles.contains(RM)) &&
                (
                    ccchest.getRegion().getRegionCode().compareTo(user.getRegionCode()) != 0 ||
                    ccchest.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(AO_USER) || roles.contains(AGM_GB)) &&
                (
                    ccchest.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(CIRCLE_ADMIN) || roles.contains(DGM_CFO)) &&
                ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
            ) continue;

            MISReport report = new MISReport();

            report.setBrcode(ccchest.getBranchCode());
            report.setBrname(ccchest.getBranchName());
            report.setCccode(ccchest.getCcCode());
            report.setCircle(ccchest.getCircle().getCircleName());
            report.setFsloName(ccchest.getFslo().getBranchName());
            report.setFslocode(ccchest.getFslo().getBranchCode());
            report.setModule(ccchest.getModule().getModuleCode());
            report.setModuleName(ccchest.getModule().getModuleName());
            report.setNetwork(ccchest.getNetwork().getNetworkCode());
            report.setRegion(ccchest.getRegion().getRegionCode());

            LocalDate latestUploadedDate = null;

            if (checkSlipUploadDetailsRepository.getMaxUploadId(ccchest) != null) {
                latestUploadedDate =
                    checkSlipUploadDetailsRepository
                        .findById(checkSlipUploadDetailsRepository.getMaxUploadId(ccchest))
                        .get()
                        .getChestSlipDate();
            }

            report.setLastUploadedDate(latestUploadedDate);
            misReport.add(report);
        }

        Collections.sort(
            misReport,
            new Comparator<MISReport>() {
                @Override
                public int compare(MISReport o1, MISReport o2) {
                    String circle1 = o1.getCircle() + "";
                    String network1 = o1.getNetwork() + "";
                    String module1 = o1.getModule() + "";
                    String region1 = o1.getRegion() + "";
                    String brcode1 = o1.getBrcode() + "";

                    String circle2 = o2.getCircle() + "";
                    String network2 = o2.getNetwork() + "";
                    String module2 = o2.getModule() + "";
                    String region2 = o2.getRegion() + "";
                    String brcode2 = o2.getBrcode() + "";

                    String compare1 = circle1 + "" + network1 + "" + module1 + "" + region1 + "" + brcode1;
                    String compare2 = circle2 + "" + network2 + "" + module2 + "" + region2 + "" + brcode2;

                    return compare1.compareTo(compare2);
                }
            }
        );

        return misReport;
    }

    @Transactional
    public List<MISReport> getListofCCAboveCBL(LocalDate chestSlipDate) {
        List<CurrencyChest> currencyChests = checkSlipUploadDetailsRepository.getListofCCAboveCBL(chestSlipDate);

        currencyChests =
            currencyChests
                .stream()
                .filter(
                    o ->
                        (o.getClosedDate() == null || (o.getClosedDate() != null && o.getClosedDate().compareTo(chestSlipDate) >= 0)) &&
                        o.getDateOfOpening() != null &&
                        o.getDateOfOpening().compareTo(chestSlipDate) <= 0
                )
                .collect(Collectors.toList());

        AppUser user = SecurityUtils.getLoggedInUser();

        Set<Role> roles = user.getRoles();

        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        List<MISReport> misReport = new ArrayList<>();
        for (int i = 0; i < currencyChests.size(); i++) {
            CurrencyChest ccchest = currencyChests.get(i);
            if (roles.contains(FSLO_USER) && ccchest.getFslo().getBranchCode().compareTo(user.getBranchCode()) != 0) continue;

            if (
                (roles.contains(BRANCH_USER) || roles.contains(BRANCH_HEAD)) && ccchest.getBranchCode().compareTo(user.getBranchCode()) != 0
            ) continue;

            if (
                (roles.contains(RBO_CM) || roles.contains(RM)) &&
                (
                    ccchest.getRegion().getRegionCode().compareTo(user.getRegionCode()) != 0 ||
                    ccchest.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(AO_USER) || roles.contains(AGM_GB)) &&
                (
                    ccchest.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(CIRCLE_ADMIN) || roles.contains(DGM_CFO)) &&
                ccchest.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
            ) continue;

            MISReport report = new MISReport();

            report.setBrcode(ccchest.getBranchCode());
            report.setBrname(ccchest.getBranchName());
            report.setCccode(ccchest.getCcCode());
            report.setCircle(ccchest.getCircle().getCircleName());
            report.setFsloName(ccchest.getFslo().getBranchName());
            report.setFslocode(ccchest.getFslo().getBranchCode());
            report.setModule(ccchest.getModule().getModuleCode());
            report.setModuleName(ccchest.getModule().getModuleName());
            report.setNetwork(ccchest.getNetwork().getNetworkCode());
            report.setRegion(ccchest.getRegion().getRegionCode());
            report.setCbl(ccchest.getCashBalanceLimit() * 10000000);
            report.setTotal(totalsTableRepository.getTotal(chestSlipDate, ccchest));
            misReport.add(report);
        }

        Collections.sort(
            misReport,
            new Comparator<MISReport>() {
                @Override
                public int compare(MISReport o1, MISReport o2) {
                    String circle1 = o1.getCircle() + "";
                    String network1 = o1.getNetwork() + "";
                    String module1 = o1.getModule() + "";
                    String region1 = o1.getRegion() + "";
                    String brcode1 = o1.getBrcode() + "";

                    String circle2 = o2.getCircle() + "";
                    String network2 = o2.getNetwork() + "";
                    String module2 = o2.getModule() + "";
                    String region2 = o2.getRegion() + "";
                    String brcode2 = o2.getBrcode() + "";

                    String compare1 = circle1 + "" + network1 + "" + module1 + "" + region1 + "" + brcode1;
                    String compare2 = circle2 + "" + network2 + "" + module2 + "" + region2 + "" + brcode2;

                    return compare1.compareTo(compare2);
                }
            }
        );

        return misReport;
    }

    public String commas(String temp) {
        temp = new BigDecimal(Double.parseDouble(temp)).toPlainString();
        StringBuffer s = new StringBuffer(temp).reverse();
        if (temp.startsWith("-")) s = new StringBuffer(s.substring(0, s.length() - 1));
        int len = 0;
        if (s.indexOf(".") != -1) len = s.indexOf(".") + 1;
        StringBuffer s1 = new StringBuffer(s.substring(len));

        for (int k = 3; k < s1.length(); k += 2) s1.insert(k++, ',');

        s1 = s1.reverse();
        if (temp.startsWith("-")) s1 = new StringBuffer("-" + s1);
        return s1.toString();
    }

    public byte[] getPDFFile(LocalDate date, Long brcode) {
        String fileName = checkSlipUploadDetailsRepository.getPDFFile(date, brcode);

        byte[] targetArray = null;

        try (FileInputStream fis = new FileInputStream(new File(fileName))) {
            targetArray = new byte[fis.available()];

            int read = fis.read(targetArray);

            if (read <= 0) {
                byte[] pdfBytes = null;
                try (ByteArrayOutputStream bos = new ByteArrayOutputStream(); BufferedOutputStream bufOs = new BufferedOutputStream(bos)) {
                    final PdfRendererBuilder pdfBuilder = new PdfRendererBuilder();
                    pdfBuilder.useFastMode();
                    pdfBuilder.withHtmlContent("<html><body>Error while reading PDF File</body></html>", "");
                    pdfBuilder.toStream(bufOs);
                    pdfBuilder.run();
                    pdfBytes = bos.toByteArray();
                } catch (IOException ex1) {
                    log.error(ex1.getMessage() + "Error while generated on reading of PDF File", ex1);
                }
                targetArray = pdfBytes;
            }
        } catch (IOException ex) {
          //  System.out.println("file not found.");

            log.error(ex.getMessage() + " No PDF file found", ex);

            byte[] pdfBytes = null;
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream(); BufferedOutputStream bufOs = new BufferedOutputStream(bos)) {
                final PdfRendererBuilder pdfBuilder = new PdfRendererBuilder();
                pdfBuilder.useFastMode();
                pdfBuilder.withHtmlContent("<html><body>No PDF File Found</body></html>", "");
                pdfBuilder.toStream(bufOs);
                pdfBuilder.run();
                pdfBytes = bos.toByteArray();
            } catch (IOException ex1) {
                log.error(ex1.getMessage() + "Error while generated on no PDF File", ex1);
            }
            targetArray = pdfBytes;
        }

        return targetArray;
    }

    public ChestSlip viewChestSlip(LocalDate localDate, Long brcode) {
        /* CurrencyChest currencyChest = currencyChestRepository.findByBranchCode(brcode).get();
        ChestSlipUploadDetails chestSlipUploadDetails = checkSlipUploadDetailsRepository.findChestSlipUploadDetailsBySlipDateBrcode(
            localDate,
            currencyChest
        );
        ChestSlip chestSlip = new ChestSlip();
        if (chestSlipUploadDetails == null) {
            chestSlip.setStatus("No Data Found");
            return chestSlip;
        }

        chestSlip.setBrCode(currencyChest.getBranchCode());
        chestSlip.setCcName(currencyChest.getBranchName());
        chestSlip.setCcCode(currencyChest.getCcCode());
        chestSlip.setUploadedDate(chestSlipUploadDetails.getChestSlipUploadDate());
        chestSlip.setDate(chestSlipUploadDetails.getChestSlipDate());

        List<ChestSlipParticular> particulars = particularsRepository.allParticularsByType("Notes");
        List<Denomination> denominations = denominationsRepository.allDenominationsByType("N");

        String data[][] = new String[particulars.size()][denominations.size() + 3];

        for (int i = 0; i < particulars.size(); i++) {
            data[i][0] = particulars.get(i).getParticular();
            int j = 0;
            for (j = 0; j < denominations.size(); j++) {
                Optional<ChestSlips> optChestSlip = checkSlipsRepository.findByCheckSlipUploadDetailsAndParticularsAndDenominations(
                    chestSlipUploadDetails,
                    particulars.get(i),
                    denominations.get(j)
                );

                if (optChestSlip.isPresent()) data[i][j + 1] = commas(optChestSlip.get().getValue() + ""); else data[i][j + 1] = "0";
            }

            Optional<TotalsTable> totalsTableOpt = totalsTableRepository.findTotal(particulars.get(i), chestSlipUploadDetails);
            if (totalsTableOpt.isPresent()) {
                data[i][j + 1] = commas(totalsTableOpt.get().getTotalPieces() + "");
                data[i][j + 2] = commas(totalsTableOpt.get().getTotalValue() + "");
            } else {
                data[i][j + 1] = "0";
                data[i][j + 2] = "0";
            }
        }

        PDFTable notesTable = new PDFTable();
        notesTable.setData(data);
        notesTable.setSize(denominations.size() + 2);
        notesTable.setDenominations(denominationsRepository.allDenominationValuesByType("N").toArray(new String[denominations.size()]));
        notesTable.setParticulars(particularsRepository.allParticularByType("Notes"));

        particulars = particularsRepository.allParticularsByType("Coins");
        denominations = denominationsRepository.allDenominationsByType("C");

        data = new String[particulars.size()][denominations.size() + 3];

        for (int i = 0; i < particulars.size(); i++) {
            data[i][0] = particulars.get(i).getParticular();
            int j = 0;
            for (j = 0; j < denominations.size(); j++) {
                Optional<ChestSlips> optChestSlip = checkSlipsRepository.findByCheckSlipUploadDetailsAndParticularsAndDenominations(
                    chestSlipUploadDetails,
                    particulars.get(i),
                    denominations.get(j)
                );

                if (optChestSlip.isPresent()) data[i][j + 1] = commas(optChestSlip.get().getValue() + ""); else data[i][j + 1] = "0";
            }

            Optional<TotalsTable> totalsTableOpt = totalsTableRepository.findTotal(particulars.get(i), chestSlipUploadDetails);
            if (totalsTableOpt.isPresent()) {
                data[i][j + 1] = commas(totalsTableOpt.get().getTotalPieces() + "");
                data[i][j + 2] = commas(totalsTableOpt.get().getTotalValue() + "");
            } else {
                data[i][j + 1] = "0";
                data[i][j + 2] = "0";
            }
        }

        PDFTable coinsTable = new PDFTable();
        coinsTable.setData(data);
        coinsTable.setSize(denominations.size() + 2);
        coinsTable.setDenominations(denominationsRepository.allDenominationValuesByType("C").toArray(new String[denominations.size()]));
        coinsTable.setParticulars(particularsRepository.allParticularByType("Coins"));

        chestSlip.setCoinsTable(coinsTable);
        chestSlip.setNotesTable(notesTable);*/

        Long[] did = denominationsRepository.getIndices().toArray(new Long[0]);

        List<ViewChestSlip> viewChestSlip = checkSlipUploadDetailsRepository.viewChestSlipNew(
            localDate,
            brcode,
            did[0],
            did[1],
            did[2],
            did[3],
            did[4],
            did[5],
            did[6],
            did[7],
            did[8],
            did[9],
            did[10],
            did[11],
            did[12],
            did[13],
            did[14],
            did[15]
        );

        ChestSlip chestSlip = new ChestSlip();
        if (viewChestSlip == null || (viewChestSlip.size() == 0)) {
            chestSlip.setStatus("No Data Found");
            return chestSlip;
        }

        chestSlip.setCcCode(viewChestSlip.get(0).getCccode());
        chestSlip.setBrCode(brcode);
        chestSlip.setDate(localDate);

        PDFTable notesTable = new PDFTable();
        notesTable.setDenominations(
            denominationsRepository
                .allDenominationValuesByType("N")
                .toArray(new String[denominationsRepository.allDenominationsByType("N").size()])
        );
        String[][] notesData = new String[particularsRepository.allParticularsByType("Notes").size()][denominationsRepository
            .allDenominationsByType("N")
            .size() +
        3];

        PDFTable coinsTable = new PDFTable();
        coinsTable.setDenominations(
            denominationsRepository
                .allDenominationValuesByType("C")
                .toArray(new String[denominationsRepository.allDenominationsByType("C").size()])
        );
        String[][] coinsData = new String[particularsRepository.allParticularsByType("Coins").size()][denominationsRepository
            .allDenominationsByType("C")
            .size() +
        3];

        int notesIndex = 0, coinsIndex = 0;
        for (int i = 0; i < viewChestSlip.size(); i++) {
            if (viewChestSlip.get(i).getType().equals("Notes")) {
                notesData[notesIndex][0] = viewChestSlip.get(i).getParticular();
                notesData[notesIndex][1] = commas(viewChestSlip.get(i).getN1() + "");
                notesData[notesIndex][2] = commas(viewChestSlip.get(i).getN2() + "");
                notesData[notesIndex][3] = commas(viewChestSlip.get(i).getN5() + "");
                notesData[notesIndex][4] = commas(viewChestSlip.get(i).getN10() + "");
                notesData[notesIndex][5] = commas(viewChestSlip.get(i).getN20() + "");
                notesData[notesIndex][6] = commas(viewChestSlip.get(i).getN50() + "");
                notesData[notesIndex][7] = commas(viewChestSlip.get(i).getN100() + "");
                notesData[notesIndex][8] = commas(viewChestSlip.get(i).getN200() + "");
                notesData[notesIndex][9] = commas(viewChestSlip.get(i).getN500() + "");
                notesData[notesIndex][10] = commas(viewChestSlip.get(i).getN1000() + "");
                notesData[notesIndex][11] = commas(viewChestSlip.get(i).getN2000() + "");
                notesData[notesIndex][12] = commas(viewChestSlip.get(i).getTotalpieces() + "");
                notesData[notesIndex][13] = commas(viewChestSlip.get(i).getTotalvalue() + "");
                notesIndex++;
            } else if (viewChestSlip.get(i).getType().equals("Coins")) {
                coinsData[coinsIndex][0] = viewChestSlip.get(i).getParticular();
                coinsData[coinsIndex][1] = commas(viewChestSlip.get(i).getC1() + "");
                coinsData[coinsIndex][2] = commas(viewChestSlip.get(i).getC2() + "");
                coinsData[coinsIndex][3] = commas(viewChestSlip.get(i).getC5() + "");
                coinsData[coinsIndex][4] = commas(viewChestSlip.get(i).getC10() + "");
                coinsData[coinsIndex][5] = commas(viewChestSlip.get(i).getC20() + "");
                coinsData[coinsIndex][6] = commas(viewChestSlip.get(i).getTotalpieces() + "");
                coinsData[coinsIndex][7] = commas(viewChestSlip.get(i).getTotalvalue() + "");
                coinsIndex++;
            }
        }

        notesTable.setData(notesData);
        coinsTable.setData(coinsData);

        chestSlip.setNotesTable(notesTable);
        chestSlip.setCoinsTable(coinsTable);

        return chestSlip;
    }
}
