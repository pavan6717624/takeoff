package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EisDecryptedResponse {

    @JsonProperty("RESPONSE_STATUS")
    private int responseStatus;

    @JsonProperty("ERROR_CODE")
    private String errorCode;

    @JsonProperty("ERROR_DESCRIPTION")
    private String errorDescription;

    @JsonProperty("PF_NUMBER")
    private String pfNumber;

    @JsonProperty("TITLE")
    private String title;

    @JsonProperty("FIRST_NAME")
    private String firstName;

    @JsonProperty("MIDDLE_NAME")
    private String middleName;

    @JsonProperty("LAST_NAME")
    private String lastName;

    @JsonProperty("GENDER")
    private String gender;

    @JsonProperty("EMPLOYEE_GROUP")
    private String employeeGroup;

    @JsonProperty("EMPLOYEE_GROUP_NAME")
    private String employeeGroupName;

    @JsonProperty("EMPLOYEE_SUB_GROUP")
    private String employeeSubGroup;

    @JsonProperty("DESIGNATION")
    private String designation;

    @JsonProperty("EMPLOYEE_POSITION")
    private String employeePosition;

    @JsonProperty("EMPLOYEE_POSITION_DESCRIPTION")
    private String employeePositionDescription;

    @JsonProperty("DATE_OF_BIRTH")
    private String dateOfBirth;

    @JsonProperty("DATE_OF_JOINING")
    private String dateOfJoining;

    @JsonProperty("PAYROLL")
    private String payroll;

    @JsonProperty("BRANCH_CODE")
    private String branchCode;

    @JsonProperty("BRANCH_NAME")
    private String branchName;

    @JsonProperty("ORGANISATION_UNIT")
    private String organisationUnit;

    @JsonProperty("NAME_OF_ORGANISATION_UNIT")
    private String nameOfOrganisationUnit;

    @JsonProperty("MOBILE_NUMBER")
    private String mobileNumber;

    @JsonProperty("REPORTING_PF")
    private String reportingPf;

    @JsonProperty("CDS_ROLE_CODE")
    private String cdsRoleCode;

    @JsonProperty("CDS_ROLE_DESCRIPTION")
    private String cdsRoleDescription;

    @JsonProperty("EMPLOYEE_STATUS")
    private String employeeStatus;

    @JsonProperty("PARENT_BANK")
    private String parentBank;

    @JsonProperty("EMAIL")
    private String email;
}
