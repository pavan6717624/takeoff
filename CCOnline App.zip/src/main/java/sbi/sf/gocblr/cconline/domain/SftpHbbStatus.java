package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name = "sftp_hbb_status")
public class SftpHbbStatus implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = -3676866536339008024L;

	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private LocalDate loadedDate;
	    private LocalDate fileDate;
	    private String status;

}
