package sbi.sf.gocblr.cconline.model.enums;

public enum ReminderFor {
    EXCEPTIONS,
    DIFF_IN_98908,
    DIFF_IN_98958,
    CHEST_SLIP_UPLOAD,
}
