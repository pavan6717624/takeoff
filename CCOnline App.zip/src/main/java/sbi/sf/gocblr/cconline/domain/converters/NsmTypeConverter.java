package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.NsmType;

/**
 * Attribute convert for @see sbi.sf.gocblr.cconline.domain.enum.NsmType
 * @author Kiran Marturu
 *
 */
@Converter(autoApply = true)
public class NsmTypeConverter implements AttributeConverter<NsmType, Integer> {

    @Override
    public Integer convertToDatabaseColumn(NsmType nsmType) {
        return nsmType.code();
    }

    @Override
    public NsmType convertToEntityAttribute(Integer nsmTypeCode) {
        if (nsmTypeCode == null) {
            return null;
        }
        return NsmType.fromCode(nsmTypeCode);
    }
}
