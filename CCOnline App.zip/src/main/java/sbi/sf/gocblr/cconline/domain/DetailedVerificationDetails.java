package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.NaturalId;
import sbi.sf.gocblr.cconline.domain.enums.DiscrepancyType;

@Entity
@Table(
    name = "detailed_verification_details",
    uniqueConstraints = @UniqueConstraint(
        columnNames = { "detailed_verification_id", "denomination_id" },
        name = "uk_detailed_verification_details_natural_id"
    )
)
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DetailedVerificationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "detailed_verification_id", foreignKey = @ForeignKey(name = "fk_detailed_verification"))
    @EqualsAndHashCode.Include
    private DetailedVerification detailedVerification;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "denomination_id", foreignKey = @ForeignKey(name = "fk_denomination_wise_verification_denomination"))
    @EqualsAndHashCode.Include
    private Denomination denomination;

    @Column(name = "no_of_pieces", columnDefinition = "NUMBER(15)")
    private Long noOfPieces;

    @Column(name = "discrepancy_type")
    private DiscrepancyType discrepancyType;

    @Column(name = "discrepancy_pieces")
    private long discrepancyPieces;

    @Column(columnDefinition = "NUMBER(15)")
    private Long ficn;

    @Column(name = "soild_noted_wrongly_classified")
    private Long soiledWronglyClassified;

    @Column(name = "mutilated_notes_wrongly_classified")
    private Long mutilatedWronglyClassified;
}
