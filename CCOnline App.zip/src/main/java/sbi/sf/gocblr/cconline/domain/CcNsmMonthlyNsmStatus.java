package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.NaturalId;

@Data
@Entity
@Table(name = "cc_nsm_monthly_nsm_status")
public class CcNsmMonthlyNsmStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "cc_nsm_id", foreignKey = @ForeignKey(name = "fk_cc_nsm_monthly_nsm_status_cc_nsm_id"))
    private CcNsm ccNsm;

    @NaturalId
    private LocalDate month;

    @Column(name = "is_saved")
    private Boolean saved;
}
