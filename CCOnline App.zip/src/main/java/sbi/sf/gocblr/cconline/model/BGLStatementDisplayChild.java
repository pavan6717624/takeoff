package sbi.sf.gocblr.cconline.model;

public class BGLStatementDisplayChild {

    public Long getCccd() {
        return cccd;
    }

    public void setCccd(Long cccd) {
        this.cccd = cccd;
    }

    public Long getBrcd() {
        return brcd;
    }

    public void setBrcd(Long brcd) {
        this.brcd = brcd;
    }

    public String getBrname() {
        return brname;
    }

    public void setBrname(String brname) {
        this.brname = brname;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public double getWithdrawal() {
        return withdrawal;
    }

    public void setWithdrawal(double withdrawal) {
        this.withdrawal = withdrawal;
    }

    public double getCt() {
        return ct;
    }

    public void setCt(double ct) {
        this.ct = ct;
    }

    public Long getFslocode() {
        return Math.abs(fslocode);
    }

    public void setFslocode(Long fslocode) {
        this.fslocode = fslocode;
    }

    private Long cccd;
    private Long brcd;
    private String brname;
    private double deposit;
    private double withdrawal;
    private double ct;
    private Long fslocode;
}
