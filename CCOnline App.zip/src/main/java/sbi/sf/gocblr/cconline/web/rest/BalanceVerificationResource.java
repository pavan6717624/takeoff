package sbi.sf.gocblr.cconline.web.rest;

import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sbi.sf.gocblr.cconline.domain.BalanceVerification;
import sbi.sf.gocblr.cconline.service.BalanceVerificationService;
import sbi.sf.gocblr.cconline.service.dto.NotesAndCoinsDenominationAndPiecesDTO;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.BalanceVerificationSaveVM;
import sbi.sf.gocblr.cconline.web.rest.vm.FetchBalancesVM;
import sbi.sf.gocblr.cconline.web.rest.vm.JustResponseMessage;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class BalanceVerificationResource {

    private final BalanceVerificationService service;

    @GetMapping("/balance-verification/{verificationId}")
    public BalanceVerification getBalanceVerificationDetails(@PathVariable("verificationId") Long verificationId) {
        return service.getBalanceVerification(verificationId);
    }

    @PostMapping("/balance-verification/fetch-balances")
    public NotesAndCoinsDenominationAndPiecesDTO fetchBalances(@RequestBody @Valid FetchBalancesVM model) {
        return service.getBalanceDetails(model.getVerificationId(), DateUtils.getLocalDate(model.getBalancesAsOn()));
    }

    @PostMapping("/balance-verification/{verificationId}/save")
    public ResponseEntity<JustResponseMessage> saveBalanceVerification(
        @PathVariable("verificationId") Long verificationId,
        @RequestBody @Valid BalanceVerificationSaveVM model
    ) {
        service.save(verificationId, model);
        return ResponseEntity.ok(new JustResponseMessage("Data saved successfully"));
    }
}
