package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "penalty_disposal")
public class PenaltyDisposal implements Serializable {

    private static final long serialVersionUID = -829570028038565804L;

    @Id
    Long id;

    String disposal;
}
