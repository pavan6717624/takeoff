package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

/**
 * For storing FLSO staff details
 * @author Kiran Marturu
 *
 */
@Embeddable
@Getter
@Setter
public class FsloStaff implements Serializable {

    private static final long serialVersionUID = 7498204796744473921L;

    private Integer pfId;
    private String name;
    private String emailId;
    private Long mobileNo;
}
