package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.NaturalId;

/**
 *
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "verification_types", uniqueConstraints = { @UniqueConstraint(columnNames = "key", name = "uk_verification_types_key") })
public class VerificationType implements Serializable {

    private static final long serialVersionUID = -7401662327139473290L;

    @Id // not auto generated as these will be loaded from back-end
    private Integer id;

    @NaturalId
    @EqualsAndHashCode.Include
    private String key;

    private String name;

    @Column(name = "certificate_text")
    private String certificateText;
}
