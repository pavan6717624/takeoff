package sbi.sf.gocblr.cconline.domain.view;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "view_verification_section_counts")
@Immutable
@IdClass(VerificationSectionCountId.class)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class VerificationSectionCount {

    @Id
    @Column(name = "verification_id")
    private Long verificationId;

    @Id
    @Column(name = "verification_section_id")
    private Long sectionId;

    @Column(name = "pending_count")
    private Integer pending;

    private Integer total;
}
