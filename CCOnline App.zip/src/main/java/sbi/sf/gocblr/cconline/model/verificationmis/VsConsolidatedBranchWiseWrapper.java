package sbi.sf.gocblr.cconline.model.verificationmis;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class VsConsolidatedBranchWiseWrapper {

    private List<VsMinimal> valueStatements;
    private List<VsConsolidatedBranchWise> data;
}
