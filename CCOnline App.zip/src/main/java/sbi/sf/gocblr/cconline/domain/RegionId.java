package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author Kiran Marturu
 *
 */
@Data
public class RegionId implements Serializable {

    private static final long serialVersionUID = 8839647484430647139L;

    private Module module;
    private Long regionCode;
}
