package sbi.sf.gocblr.cconline.service.dto;

import lombok.Data;

@Data
public class VerificationBranchProfileVM {

    private Long branchCode;
    private String branchName;
    private Long circleCode;
    private String circleName;
    private Long networkCode;
    private Long moduleCode;
    private String moduleName;
    private Long regionCode;
    private Long strongRoomSize;
    private Long cashBalanceLimit;
    //private Long holdingCapacityOfBins;
    private Long capacityToStoreCashInBundles;
    private Long averageDailyReciepts;
    private Long averageDailyPayments;
    private Long bgl98958Balance;
    private Long soiledNotesBalanceReported;
}
