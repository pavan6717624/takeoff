package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class LastUploadDTO implements LastUploadModal {

    @JsonProperty(value = "maxDate")
    String maxDate;

    @JsonProperty(value = "ccBranchCode")
    Long ccBranchCode;
}
