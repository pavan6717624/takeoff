package sbi.sf.gocblr.cconline.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.enums.InputType;

/**
 * Entity representing a value statement in verification report
 *
 * @author Kiran Marturu
 */
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "value_statements")
public class ValueStatement implements Serializable {

    private static final long serialVersionUID = -5183245349445093264L;

    @Id
    @EqualsAndHashCode.Include
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "verification_section_id", foreignKey = @ForeignKey(name = "fk_verification_section"))
    private VerificationSection section;

    @Column(name = "display_order")
    private Integer displayOrder;

    @Column(name = "display_no", length = 6)
    private String displayNumber;

    @Column(name = "indent_level")
    private Integer indentLevel;

    @Column(length = 400)
    private String description;

    @Column(name = "info_text", length = 200)
    private String infoText;

    @Column(name = "is_only_as_header")
    private Boolean isOnlyAsHeader;

    @Enumerated(EnumType.STRING)
    @Column(name = "input_type", length = 50)
    private InputType inputType;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_value_statement_id", foreignKey = @ForeignKey(name = "fk_value_statements_parent_vs_id"))
    private ValueStatement parentValueStatement;

    @OneToMany(mappedBy = "parentValueStatement")
    private Set<ValueStatement> subValueStatements = new HashSet<>();

    @OneToMany(mappedBy = "valueStatement")
    private Set<ValueStatementVerification> valueStatementVerifications;
}
