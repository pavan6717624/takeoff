package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.TotalsTable;
import sbi.sf.gocblr.cconline.model.ZeroClosingCCs;

@Repository
public interface TotalsTableRepository extends JpaRepository<TotalsTable, Long> {
    @Query(
        "SELECT totalsTable.totalValue FROM TotalsTable totalsTable where totalsTable.particular =(:particular) and totalsTable.checkSlipUploadDetails =(:checkSlipUploadDetails)"
    )
    Double findTotalValues(
        @Param("particular") ChestSlipParticular particular,
        @Param("checkSlipUploadDetails") ChestSlipUploadDetails checkSlipUploadDetails
    );

    @Query(
        "SELECT totalsTable FROM TotalsTable totalsTable where totalsTable.particular =(:particular) and totalsTable.checkSlipUploadDetails =(:checkSlipUploadDetails)"
    )
    Optional<TotalsTable> findTotal(
        @Param("particular") ChestSlipParticular particular,
        @Param("checkSlipUploadDetails") ChestSlipUploadDetails checkSlipUploadDetails
    );

    @Query(
        "select sum(totalValue) from TotalsTable t where t.particular in  (select p from ChestSlipParticular p where p.keyword like 'Closing%') group by  t.checkSlipUploadDetails having t.checkSlipUploadDetails =  (select c1 from ChestSlipUploadDetails c1 where status like 'New' and c1.chestSlipDate = (:chestSlipDate) and c1.currencyChest = (:c)) "
    )
    Double getTotal(@Param("chestSlipDate") LocalDate chestSlipDate, @Param("c") CurrencyChest c);

    @Query(
        nativeQuery = true,
        value = "select c.circle_name as circle,b.network_code as network,m.module_name as moduleName,b.region_code as region, b.branch_code as brcode,b.branch_name as brname,TO_CHAR(t.cs_date, 'DD/MM/YYYY') as csdate,t.opening_balance as openingBalance,t.closing_balance as closingBalance from (select u.cs_date,u.cc_branch_code,sum(case when (p.pid = :closingId1 or p.pid=:closingId2) then total_value end) as closing_balance,sum(case when (p.pid = :openingId1 or p.pid=:openingId2) then total_value end) as opening_balance from {h-schema}chest_slip_particular_totals t, {h-schema}particulars p, {h-schema}chest_slip_upload_details u " +
        "where u.status='New' and u.id=t.cs_upload_id and p.pid = t.cs_particular_id and p.pid in (:closingId1,:closingId2,:openingId1,:openingId2)  " +
        "group by u.cs_date,u.cc_branch_code order by u.cs_date,u.cc_branch_code asc) t, {h-schema}branches b, {h-schema}circles c, {h-schema}modules m, {h-schema}currency_chests cc where closing_balance=0 and t.cc_branch_code =  b.branch_code and c.circle_code=b.circle_code and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code = b.network_code and cc.branch_code= b.branch_code and cc.is_closed=0"
    )
    List<ZeroClosingCCs> getZeroClosingBalanceCCs(
        @Param("closingId1") Long closingId1,
        @Param("closingId2") Long closingId2,
        @Param("openingId1") Long openingId1,
        @Param("openingId2") Long openingId2
    );

    Optional<TotalsTable> findByCheckSlipUploadDetailsIdAndParticular(long csUploadId, ChestSlipParticular particular);
}
