package sbi.sf.gocblr.cconline.constants;

public class AppMessages {

	private AppMessages() {
		// static class not to be initialised
	}
	
	public static final String NOT_AUTHORIZED_TO_ACCESS = "You are not authorized to access this resource/action";
	
}
