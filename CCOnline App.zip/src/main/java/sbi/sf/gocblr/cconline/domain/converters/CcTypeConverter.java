package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.CcType;

/**
 * Attribute converter for @see sbi.sf.gocblr.cconline.domain.enums.CcType
 * @author Kiran Marturu
 *
 */
@Converter(autoApply = true)
public class CcTypeConverter implements AttributeConverter<CcType, String> {

    @Override
    public String convertToDatabaseColumn(CcType ccType) {
        if (ccType == null) {
            return null;
        }
        return ccType.code();
    }

    @Override
    public CcType convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return CcType.fromCode(code);
    }
}
