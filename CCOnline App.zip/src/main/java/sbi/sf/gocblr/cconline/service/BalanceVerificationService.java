package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.constants.SectionRouteConstants;
import sbi.sf.gocblr.cconline.domain.BalanceVerification;
import sbi.sf.gocblr.cconline.domain.BalanceVerificationDetails;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Denomination;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.BalanceVerificationDetailsRepository;
import sbi.sf.gocblr.cconline.repository.BalanceVerificationRepository;
import sbi.sf.gocblr.cconline.service.dto.NotesAndCoinsDenominationAndPiecesDTO;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.BalanceVerificationSaveVM;

@Service
@RequiredArgsConstructor
public class BalanceVerificationService {

    private final BalanceVerificationRepository repo;
    private final BalanceVerificationDetailsRepository detailsRepo;

    private final ChestSlipService chestSlipService;
    private final VerificationService verificationService;
    private final CurrencyChestService ccService;
    private final DenominationService denominationService;

    private final VerificationSectionService sectionService;
    private final VerificationSectionStatusService statusService;

    private final VerificationBranchProfileService branchProfileService;

    public Optional<BalanceVerification> find(long verificationId) {
        return repo.findByVerificationId(verificationId);
    }

    public BalanceVerification getBalanceVerification(long verificationId) {
        var bv = repo.findByVerificationId(verificationId);
        if (bv.isPresent()) {
            return bv.get();
        } else {
            BalanceVerification newBalanceVerification = new BalanceVerification();
            newBalanceVerification.setVerification(verificationService.getVerificationById(verificationId));
            return newBalanceVerification;
        }
    }

    @Transactional(readOnly = true)
    public NotesAndCoinsDenominationAndPiecesDTO getBalanceDetails(long verificationId, LocalDate balancesAsOn) {
        var v = verificationService.getVerificationById(verificationId);
        CurrencyChest cc = ccService.getByBranchCode(v.getCurrencyChest().getBranchCode());
        return chestSlipService.getNotesClosingBalance(cc, balancesAsOn);
    }

    @Transactional
    public void save(long verificationId, BalanceVerificationSaveVM saveModel) {
        Verification v = verificationService.notSubmitted(verificationId);
        CurrencyChest cc = ccService.getByBranchCode(v.getCurrencyChest().getBranchCode());

        var existing = repo.findByVerificationId(verificationId);

        var data = chestSlipService.getNotesClosingBalance(cc, DateUtils.getLocalDate(saveModel.getBalancesAsOn()));

        BalanceVerification bv;
        if (existing.isPresent()) {
            bv = existing.get();
            bv.setBalancesAsOn(DateUtils.getLocalDate(saveModel.getBalancesAsOn()));
            bv.setHasDiscrepancy(saveModel.getHasDiscrepancy());
            bv.setDiscrepancyDetails(saveModel.getDiscrepancyDetails());

            for (var coinData : data.getCoins()) {
                var existingCoinData = detailsRepo.findByBalanceVerificationAndDenomination(
                    bv,
                    denominationService.getById(coinData.getDenominationId())
                );
                if (existingCoinData.isPresent()) {
                    existingCoinData.get().setNoOfPieces(coinData.getNoOfPieces());
                    bv.addDenominationWiseDetails(detailsRepo.save(existingCoinData.get()));
                } else {
                    var detail = new BalanceVerificationDetails();
                    detail.setBalanceVerification(bv);
                    detail.setDenomination(denominationService.getById(coinData.getDenominationId()));
                    detail.setNoOfPieces(coinData.getNoOfPieces());
                    bv.addDenominationWiseDetails(detail);
                }
            }
            for (var noteData : data.getNotes()) {
                var existingNoteData = detailsRepo.findByBalanceVerificationAndDenomination(
                    bv,
                    denominationService.getById(noteData.getDenominationId())
                );
                if (existingNoteData.isPresent()) {
                    existingNoteData.get().setNoOfPieces(noteData.getNoOfPieces());
                    bv.addDenominationWiseDetails(detailsRepo.save(existingNoteData.get()));
                } else {
                    var detail = new BalanceVerificationDetails();
                    detail.setBalanceVerification(bv);
                    detail.setDenomination(denominationService.getById(noteData.getDenominationId()));
                    detail.setNoOfPieces(noteData.getNoOfPieces());
                    bv.addDenominationWiseDetails(detail);
                }
            }
        } else {
            bv = new BalanceVerification();
            bv.setVerification(v);
            bv.setBalancesAsOn(DateUtils.getLocalDate(saveModel.getBalancesAsOn()));
            bv.setHasDiscrepancy(saveModel.getHasDiscrepancy());
            bv.setDiscrepancyDetails(saveModel.getDiscrepancyDetails());
            bv = repo.save(bv);

            for (var coinData : data.getCoins()) {
                var detail = new BalanceVerificationDetails();
                detail.setBalanceVerification(bv);
                detail.setDenomination(denominationService.getById(coinData.getDenominationId()));
                detail.setNoOfPieces(coinData.getNoOfPieces());

                bv.addDenominationWiseDetails(detail);
            }
            for (var noteData : data.getNotes()) {
                var detail = new BalanceVerificationDetails();
                detail.setBalanceVerification(bv);
                detail.setDenomination(denominationService.getById(noteData.getDenominationId()));
                detail.setNoOfPieces(noteData.getNoOfPieces());

                bv.addDenominationWiseDetails(detail);
            }
        }
        repo.save(bv);

        VerificationSection section = sectionService.getByTypeAndRoute(v.getType(), SectionRouteConstants.BALANCE_VERIFICATION);
        statusService.updateSavedStatus(v, section);

        // after changes make detailed verification section to not-saved as they are dependent
        VerificationSection dependentSection = sectionService.getByTypeAndRoute(v.getType(), SectionRouteConstants.NOTES_VERIFICATION);
        statusService.markSectionDirty(v, dependentSection);

        // update balances in branch profile
        branchProfileService.update98958AndSoiledBalanaceReported(v.getId(), bv.getBalancesAsOn());
    }

    public BalanceVerificationDetails getDetailsByDenomination(long verificationId, Denomination denom) {
        return detailsRepo
            .findByBalanceVerificationIdAndDenomination(verificationId, denom)
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        String.format(
                            "No BalanceVerificationDetails found for verification id: %d and denomination: %d",
                            verificationId,
                            denom.getValue()
                        )
                    )
            );
    }

    public BalanceVerification getSavedBalanceVerification(long id) {
        return repo.getById(id).orElseThrow(() -> new ResourceNotFoundException("No BalanceVerification found for id: " + id));
    }
}
