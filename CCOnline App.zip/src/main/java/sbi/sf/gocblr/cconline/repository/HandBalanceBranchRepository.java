package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sbi.sf.gocblr.cconline.domain.HandBalanceBranch;
import sbi.sf.gocblr.cconline.model.HandBalanceBranchDTO;

public interface HandBalanceBranchRepository extends JpaRepository<HandBalanceBranch, Long> {
	
	
	@Query("select h.circleCode as circleCode,"
			+ "h.circleName as circleName,"
			+ "h.networkCode as networkCode,"
			+ "h.moduleCode as moduleCode, "
			+ "h.moduleName as moduleName,"
			+ "h.regionCode as regionCode,"
			+ "h.branchCode as branchCode ,"
			+ "h.branchName as branchName, "
			+ "h.liveFlag as liveFlag,"
			+ "h.branchTypeCode as branchTypeCode,"
			+ "h.branchType as branchType,"
			+ "h.branchEmailId as branchEmailId,"
			+ "h.brachManagerMobileNumber as brachManagerMobileNumber,"
			+ "h.rboBranchCode as rboBranchCode from HandBalanceBranch h order by h.branchCode asc")
	List<HandBalanceBranchDTO> findAllOrderByBranchCode();
	
	Optional<HandBalanceBranch> findByBranchCode(@Param("branchCode") Long branchCode);

}
