package sbi.sf.gocblr.cconline.service.enums;

public enum ControllerFilter {
    BANK,
    FSLO,
    CIRCLE,
    MODULE,
    REGION,
}
