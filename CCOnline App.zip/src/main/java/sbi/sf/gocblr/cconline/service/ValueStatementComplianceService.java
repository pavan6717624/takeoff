package sbi.sf.gocblr.cconline.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.ValueStatementCompliance;
import sbi.sf.gocblr.cconline.domain.ValueStatementVerification;
import sbi.sf.gocblr.cconline.exception.NothingSpecificException;
import sbi.sf.gocblr.cconline.repository.ValueStatementComplianceRepository;
import sbi.sf.gocblr.cconline.repository.VerificationSectionCountRepository;
import sbi.sf.gocblr.cconline.web.rest.vm.SaveVsComplianceVM;

@Service
@RequiredArgsConstructor
public class ValueStatementComplianceService {

    private final VerificationService verificationService;
    private final ValueStatementService vsService;
    private final ValueStatementVerificationService vsVerificationService;

    private final ValueStatementComplianceRepository complianceRepo;
    private final VerificationSectionCountRepository countRepo;

    @Transactional
    public int saveVsCompliance(SaveVsComplianceVM model) {
        var v = verificationService.getVerificationById(model.getVerificationId());
        var vs = vsService.getValueStatement(model.getVsId(), model.getSectionId());
        var vsv = vsVerificationService.getValueStatementVerification(v, vs);

        var vsc = complianceRepo.findByVsVerification(vsv);
        ValueStatementCompliance toSave;
        if (vsc.isPresent()) {
            toSave = vsc.get();
            setData(model, toSave, vsv);
        } else {
            toSave = new ValueStatementCompliance();
            setData(model, toSave, vsv);
        }
        complianceRepo.save(toSave);

        var updatedCount = countRepo
            .findByVerificationIdAndSectionId(v.getId(), vs.getSection().getId())
            .orElseThrow(() -> new NothingSpecificException(""));

        return updatedCount.getPending();
    }

    private void setData(SaveVsComplianceVM model, ValueStatementCompliance toSave, ValueStatementVerification vsv) {
        toSave.setVsVerification(vsv);
        toSave.setBranchCompliance(model.getBranchCompliance());
        toSave.setBranchComments(model.getBranchComments());
    }
}
