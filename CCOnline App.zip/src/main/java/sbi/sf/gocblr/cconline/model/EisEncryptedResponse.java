package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EisEncryptedResponse {

    @JsonProperty("REQUEST_REFERENCE_NUMBER")
    private String requestReferenceNumber;

    @JsonProperty("RESPONSE")
    private String response;

    @JsonProperty("RESPONSE_DATE")
    private String responseDate;

    @JsonProperty("DIGI_SIGN")
    private String digiSign;
}
