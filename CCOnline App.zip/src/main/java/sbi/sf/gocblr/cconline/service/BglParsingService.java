package sbi.sf.gocblr.cconline.service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.CcBglBalance;
import sbi.sf.gocblr.cconline.domain.ChestClosingFields;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.ExceptionReport;
import sbi.sf.gocblr.cconline.domain.SftpBglStatus;
import sbi.sf.gocblr.cconline.repository.BranchRepository;
import sbi.sf.gocblr.cconline.repository.CcBglBalanceRepository;
import sbi.sf.gocblr.cconline.repository.ChestClosingFieldsRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.ExceptionReportRepository;
import sbi.sf.gocblr.cconline.repository.SftpBglStatusRepository;

@Service
@RequiredArgsConstructor
@Slf4j
public class BglParsingService {

    private Session session = null;
    private final DateTimeFormatter BGL_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private final String BGL98958 = "BGL_98908_";
    private final String BGL98908 = "BGL_98958_";

    private final ApplicationProperties applicationProperties;

    private final CcBglBalanceRepository ccbglBalanceRepository;
    private final ChestClosingFieldsRepository checkClosingFieldsRepository;
    private final CurrencyChestRepository currencyChestRepository;
    private final BranchRepository branchRepository;
    private final ExceptionReportRepository exReportRepository;
    private final SftpBglStatusRepository sftpBglStatusRepository;

    public void connect() throws JSchException {
        String SFTP_PASSWORD = applicationProperties.getSftpPassword();
        String SFTP_USERNAME = applicationProperties.getSftpUsername();
        String SFTP_HOST = applicationProperties.getSftpHost();
        int SFTP_PORT = Integer.parseInt(applicationProperties.getSftpPort());

        JSch jsch = new JSch();

        session = jsch.getSession(SFTP_USERNAME, SFTP_HOST, SFTP_PORT);
        session.setPassword(SFTP_PASSWORD);

        session.setConfig("StrictHostKeyChecking", "no");
        session.connect();
    }

    public void upload(String source, String destination) throws JSchException, SftpException {
        Channel channel = session.openChannel("sftp");
        channel.connect();
        ChannelSftp sftpChannel = (ChannelSftp) channel;
        sftpChannel.put(source, destination);
        sftpChannel.exit();
    }

    public void download() {
        LocalDate today = LocalDate.now();
        LocalDate getForDate = null;

        LocalDate latestUploadedDate = sftpBglStatusRepository.getLatestUploadDate();
        String BGLS_FILE_PATH = applicationProperties.getBglsFilePath();

        if (latestUploadedDate == null) {
            getForDate = today.minusDays(1);
        } else {
            getForDate = latestUploadedDate.plusDays(1);
        }

        if (getForDate.equals(today)) {
            log.trace("Files UP TO DATE.");
            return;
        }
        SftpBglStatus bglStatus = new SftpBglStatus();
        bglStatus.setFileDate(getForDate);
        bglStatus.setLoadedDate(today);

        String SFTP_FOLDER = applicationProperties.getSftpFolder();

        String source1 = SFTP_FOLDER + "/" + BGL98908 + getForDate.format(BGL_DATE_FORMAT) + ".txt";
        String destination1 = BGLS_FILE_PATH + BGL98908 + getForDate.format(BGL_DATE_FORMAT) + ".txt";
        String source2 = SFTP_FOLDER + "/" + BGL98958 + getForDate.format(BGL_DATE_FORMAT) + ".txt";
        String destination2 = BGLS_FILE_PATH + BGL98958 + getForDate.format(BGL_DATE_FORMAT) + ".txt";

        Channel channel;
        try {
            channel = session.openChannel("sftp");
            channel.connect();
            ChannelSftp sftpChannel = (ChannelSftp) channel;
            sftpChannel.get(source1, destination1);
            sftpChannel.get(source2, destination2);
            sftpChannel.exit();
        } catch (JSchException | SftpException e) {
            bglStatus.setStatus("Failed");

            sftpBglStatusRepository.save(bglStatus);
            return;
        }

        List<CurrencyChest> closedCCBranches = currencyChestRepository.findByIsClosed(true);

        String save1 = saveToDB(destination1, closedCCBranches);
        String save2 = saveToDB(destination2, closedCCBranches);

        if (save1.equals("Saved") && save2.equals("Saved")) bglStatus.setStatus("Success"); else bglStatus.setStatus("Failed");
        sftpBglStatusRepository.save(bglStatus);
    }

    public void disconnect() {
        if (session != null) {
            session.disconnect();
        }
    }

    public void bglRead() {
        String BGLS_FILE_PATH = applicationProperties.getBglsFilePath();

        File bglsFilePath = new File(BGLS_FILE_PATH);

        if (!bglsFilePath.exists()) {
            if (!bglsFilePath.mkdirs()) {
                return;
            }
        }

        try {
            connect();
            download();
            disconnect();
        } catch (JSchException e1) {
            log.error(e1.getMessage(), e1);
        }
    }

    @Transactional
    public String saveToDB(String filePath, List<CurrencyChest> closedCCBranches) {
        File file = new File(filePath);

        List<CcBglBalance> bglSaveAll = new ArrayList<>();

        String filename = file.getName();
        if (filename.startsWith(BGL98958) || filename.startsWith(BGL98908)) {
            try (
                FileInputStream input = new FileInputStream(file);
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            ) {
                String line = "";

                while ((line = reader.readLine()) != null) {
                    CcBglBalance ccbglBalance = new CcBglBalance();
                    String date = line.substring(0, 8);
                    String bgl = line.substring(8, 13);
                    String brcode = line.substring(13, 18);
                    String balance = line.substring(18);
                    LocalDate bglDate = LocalDate.parse(date, BGL_DATE_FORMAT);
                    if (Double.parseDouble(balance) == 0d) continue;

                    Optional<CurrencyChest> cc = currencyChestRepository.findByBranchCode(Long.valueOf(brcode));

                    if (cc.isEmpty()) {
                        ExceptionReport exreport = new ExceptionReport();
                        if (bgl.equals("98958")) {
                            exreport.setBgl98958Balance(Double.parseDouble(balance));
                            exreport.setBgl98908Balance(0d);
                        } else if (bgl.equals("98908")) {
                            exreport.setBgl98908Balance(Double.parseDouble(balance));
                            exreport.setBgl98958Balance(0d);
                        }
                        exreport.setBranchCode(Long.valueOf(brcode));

                        Optional<Branch> branch = branchRepository.findById(Long.valueOf(brcode));

                        if (branch.isPresent()) {
                            exreport.setBranchName(branch.get().getBranchName());
                        }

                        exreport.setReportDate(bglDate);
                        exreport.setStatus("Not Found Branch");
                        exReportRepository.save(exreport);

                        log.debug("could not found - " + brcode + " - " + date);
                        continue;
                    }

                    ccbglBalance.setCurrencyChest(cc.get());

                    ChestClosingFields checkClosingFields = null;
                    if (bgl.equals("98958")) {
                        checkClosingFields = checkClosingFieldsRepository.findByFieldName("BGL98958Closing");
                    } else if (bgl.equals("98908")) {
                        checkClosingFields = checkClosingFieldsRepository.findByFieldName("BGL98908Closing");
                    }

                    ccbglBalance.setCheckClosingFields(checkClosingFields);

                    ccbglBalance.setDate(bglDate);

                    ccbglBalance.setValue(Double.parseDouble(balance));

                    if (closedCCBranches.contains(cc.get())) {
                        ExceptionReport exreport = new ExceptionReport();
                        if (bgl.equals("98958")) {
                            exreport.setBgl98958Balance(Double.parseDouble(balance));
                            exreport.setBgl98908Balance(0d);
                        } else if (bgl.equals("98908")) {
                            exreport.setBgl98908Balance(Double.parseDouble(balance));
                            exreport.setBgl98958Balance(0d);
                        }
                        exreport.setBranchCode(Long.valueOf(brcode));
                        exreport.setBranchName(cc.get().getBranchName());
                        exreport.setReportDate(bglDate);
                        exreport.setStatus("Closed Branch");
                        exReportRepository.save(exreport);
                        continue;
                    }

                    bglSaveAll.add(ccbglBalance);
                }
                reader.close();
            } catch (NumberFormatException | IOException e) {
                log.error(e.getMessage(), e);
            }
        }

        ccbglBalanceRepository.saveAll(bglSaveAll);
        return "Saved";
    }
}
