package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.PenaltyData;

@Repository
public interface PenaltyDataRepository extends JpaRepository<PenaltyData, Long> {
    List<PenaltyData> findByReportDateAndStatus(@Param("reportDate") LocalDate reportDate, @Param("status") String status);

    @Query(
        "select p from PenaltyData p where month(p.reportDate)=(:month) and year(p.reportDate)=(:year) and p.status in ((:status),'Submitted') and p in (select distinct narration from PenaltyUpdation pu where status like 'Submitted' and ABS(pu.currencyChest.fslo.branchCode) = (:branchCode)) order by p.reportDate desc"
    )
    List<PenaltyData> findByMonthAndYearAndStatusAndBranchCode(
        @Param("month") Integer month,
        @Param("year") Integer year,
        @Param("status") String status,
        @Param("branchCode") Long branchCode
    );

    @Query(
        "select p from PenaltyData p where month(p.reportDate)=(:month) and year(p.reportDate)=(:year) and p.status in ((:status),'Submitted') and p.fslo in (select r from RBIFSLOMapping r where r.fslo = (select f from Fslo f where abs(f.branchCode) = (:branchCode)))"
    )
    List<PenaltyData> findByReportDateAndStatusAndFsloCode(
        @Param("month") Integer month,
        @Param("year") Integer year,
        @Param("status") String status,
        @Param("branchCode") Long branchCode
    );

    @Query("select p from PenaltyData p where p.reportDate between (:fromdate) and (:todate) and p.status in ((:status),'Submitted')")
    List<PenaltyData> findByStatusOrderByFsloFsloBranchCodeAsc(
        @Param("status") String status,
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate
    );

    @Query(
        "select case when max(p.reportDate) > max(p1.reportDate) then max(p.reportDate) else max(p1.reportDate) end from PenaltyData p,NoPenaltyDataFoundDates p1 where status in ('New','Submitted')"
    )
    LocalDate findByLatestUploadedDate();
}
