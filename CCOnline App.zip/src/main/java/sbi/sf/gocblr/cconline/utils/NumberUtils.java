package sbi.sf.gocblr.cconline.utils;

import com.ibm.icu.text.DecimalFormat;

/**
 * Number utility methods
 *
 * @author Kiran Marturu
 *
 */
public class NumberUtils {

    private static final DecimalFormat DF_WITH_DECIMALS = new DecimalFormat("#,##,##0.00");
    private static final DecimalFormat DF_WITHOUT_DECIMALS = new DecimalFormat("#,##,##0");

    private NumberUtils() {
        throw new IllegalArgumentException("Static utils class, not to be initalized");
    }

    public static boolean isValidInt(String num) {
        if (num == null) {
            return false;
        }
        try {
            Integer.parseInt(num.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static String inrFormat(Integer i) {
        if (i == null) {
            return "0";
        }
        return DF_WITHOUT_DECIMALS.format(i);
    }

    public static String inrFormat(Double d) {
        if (d == null) {
            return "0";
        }
        return DF_WITH_DECIMALS.format(d);
    }

    public static String inrFormat(Long num) {
        if (num == null) {
            return "0";
        }
        return DF_WITHOUT_DECIMALS.format(num);
    }

    public static long parseLongWithDefault(String num) {
        try {
            return Long.parseLong(num);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    public static int nullSafe(Integer num) {
        if (num == null) {
            return 0;
        } else {
            return num.intValue();
        }
    }

    public static long nullSafe(Long num) {
        if (num == null) {
            return 0L;
        } else {
            return num.longValue();
        }
    }

    public static long nullSafe(Long num, long replacement) {
        if (num == null) {
            return replacement;
        } else {
            return num.longValue();
        }
    }
}
