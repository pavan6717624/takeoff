package sbi.sf.gocblr.cconline.exception;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;

/**
 * Generic exception for capturing any validation related issues which are not
 * captured part of Spring/JavaX Validations Not for business constraint
 * exceptions
 *
 * Modeled for see <a href="https://tools.ietf.org/html/rfc7807">RFC7807</a>
 * @see <a href="https://docs.microsoft.com/en-us/dotnet/api/microsoft.aspnetcore.mvc.validationproblemdetails?view=aspnetcore-5.0">ASP.NET Implementation</a>
 *
 * NOTE: Changed later to simplify errors, error messages constructed as list of error messages, easy to display in frontend
 *
 * @author Kiran Marturu
 *
 */
public class ValidationException extends RuntimeException {

    private static final long serialVersionUID = -3649136235044486398L;

    @Getter
    private final String detail;

    @Getter
    private final List<String> errors;

    public ValidationException(String detail) {
        super(detail);
        this.detail = detail;
        this.errors = new ArrayList<>();
    }

    public ValidationException(String detail, List<String> errors) {
        this.detail = detail;
        this.errors = errors;
    }
}
