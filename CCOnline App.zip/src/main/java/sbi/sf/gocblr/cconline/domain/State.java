package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * States master
 * this is required as some reports are based on state wise
 * @author Kiran Marturu
 *
 */
@Entity
@Table(name = "states")
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class State implements Serializable {

    private static final long serialVersionUID = -8680596145964467179L;

    @Id
    @EqualsAndHashCode.Include
    private Integer code;

    private String name;
}
