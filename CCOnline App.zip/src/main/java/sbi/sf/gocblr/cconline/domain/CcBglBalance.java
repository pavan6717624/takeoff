package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.Data;

/**
 *
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
@Entity
@Table(
    name = "cc_bgl_balances",
    uniqueConstraints = @UniqueConstraint(
        name = "uk_cc_bgl_balances",
        columnNames = { "balance_on", "cc_closing_balance_id", "cc_branch_code" }
    )
)
public class CcBglBalance implements Serializable {

    private static final long serialVersionUID = -8971320628388047910L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long balanceId;

    @ManyToOne
    @JoinColumn(
        name = "cc_branch_code",
        referencedColumnName = "branch_code",
        foreignKey = @ForeignKey(name = "fk_cc_bgl_balances_currency_chest")
    )
    private CurrencyChest currencyChest;

    @Column(name = "balance_on")
    private LocalDate date; // TODO is it date or timestamp

    @OneToOne
    @JoinColumn(name = "cc_closing_balance_id", foreignKey = @ForeignKey(name = "fk_cc_bgl_bals_cc_closing_bals"))
    private ChestClosingFields checkClosingFields;

    @Column(name = "bgl_value", columnDefinition = "NUMBER(20,2)")
    private Double value;
}
