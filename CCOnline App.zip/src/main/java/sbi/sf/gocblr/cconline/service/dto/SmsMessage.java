package sbi.sf.gocblr.cconline.service.dto;

import lombok.Data;

@Data
public class SmsMessage {

    private String contentType;
    private String senderId;
    private Long mobileNo;
    private String message;
    private boolean international;
    private boolean chargable;

    private SmsMessage() {}

    public static SmsMessage build(String senderId, long mobileNo, String message) {
        SmsMessage m = new SmsMessage();
        m.setContentType("text");
        m.setSenderId(senderId);
        m.setMobileNo(mobileNo);
        m.setInternational(false);
        m.setChargable(false);
        return m;
    }
}
