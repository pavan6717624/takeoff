package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import sbi.sf.gocblr.cconline.model.VerificationSectionStatusDto;

interface CustomizedVerificationSectionStatusRepository {
    List<VerificationSectionStatusDto> somethingSomething();
}
