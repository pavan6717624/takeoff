package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Currency Chest NSM's
 *
 * @author Kiran Marturu
 *
 */
@Entity
@Table(name = "cc_nsms")
@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CcNsm implements Serializable {

    private static final long serialVersionUID = -5456621729850276713L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "year_of_purchase")
    private int yearOfPurchase;

    @Column(name = "is_active")
    private boolean active = true;

    @ManyToOne
    @JoinColumn(name = "nsm_id", foreignKey = @ForeignKey(name = "fk_cc_nsms_nsm_id"))
    private Nsm nsm;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_cc_nsms_cc_branch_code"))
    private CurrencyChest currencyChest;
}
