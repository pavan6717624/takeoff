package sbi.sf.gocblr.cconline.exception;

public class NotificationFailureException extends RuntimeException {

    private static final long serialVersionUID = 667836419021187359L;

    public NotificationFailureException(String msg) {
        super(msg);
    }
}
