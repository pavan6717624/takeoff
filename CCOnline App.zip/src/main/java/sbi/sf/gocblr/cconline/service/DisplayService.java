package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import sbi.sf.gocblr.cconline.domain.CcBglBalance;
import sbi.sf.gocblr.cconline.domain.ChestClosingFields;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.ExceptionReport;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.model.DifferenceReport;
import sbi.sf.gocblr.cconline.model.DisplayDifference;
import sbi.sf.gocblr.cconline.repository.CcBglBalanceRepository;
import sbi.sf.gocblr.cconline.repository.ChestClosingFieldsRepository;
import sbi.sf.gocblr.cconline.repository.ChestSlipUploadDetailsRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.ExceptionReportRepository;
import sbi.sf.gocblr.cconline.repository.ParticularsRepository;
import sbi.sf.gocblr.cconline.repository.RoleRepository;
import sbi.sf.gocblr.cconline.repository.TotalsTableRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;

@Service
@RequiredArgsConstructor
public class DisplayService {

    private final ParticularsRepository particularsRepository;
    private final TotalsTableRepository totalsTableRepository;
    private final ChestSlipUploadDetailsRepository checkSlipUploadDetailsRepository;
    private final CcBglBalanceRepository ccbglBalanceRepository;
    private final ChestClosingFieldsRepository checkClosingFieldsRepository;
    private final CurrencyChestRepository currencyChestRepository;
    private final RoleRepository roleRepository;
    private final ExceptionReportRepository exceptionReportRepository;

    public List<DifferenceReport> displayDifferenceReport(Long brcode, @RequestParam("bgl") String bgl) {
        DisplayDifference displayDiff = displayDifference(brcode);
        LocalDate bglDate = null;
        LocalDate ccDate = displayDiff.getCcDate();
        if (bgl.equals("98958")) {
            bglDate = displayDiff.getBgl98958Date();
        } else if (bgl.equals("98908")) {
            bglDate = displayDiff.getBgl98908Date();
        }

        //BranchProfile branchProfile = branchProfileRepository.findByBranchCode(Long.valueOf(brcode));
        CurrencyChest cc = currencyChestRepository.findByBranchCode(brcode).orElseThrow();

        //Date maxDate = bglDate;
        LocalDate maxDate = bglDate;

        if (bglDate == null && ccDate == null) {
            return new ArrayList<>();
        } else if (bglDate == null) {
            maxDate = ccDate;
        } else if (ccDate != null && bglDate.compareTo(ccDate) < 0) {
            maxDate = ccDate;
        }

        //Calendar cal = Calendar.getInstance();
        LocalDate today = LocalDate.now();
        //cal.setTime(maxDate);
        //cal.add(Calendar.DATE, -31);

        //Date tillDate = new java.sql.Date(cal.getTimeInMillis());
        LocalDate displayTill = maxDate.minusDays(31);
        //cal.setTime(tillDate);

        List<DifferenceReport> differenceReportList = new ArrayList<>();

        for (int i = 0; i <= 30; i++) {
            double notesClosing = 0;
            double coinsClosing = 0;
            double bglBalance = 0;
            double ccnotesdeposit = 0;
            double ccnoteswithdrawal = 0;
            double cccoinsdeposit = 0;
            double cccoinswithdrawal = 0;
            String file = "";
            //cal.add(Calendar.DATE, 1);
            //Date date = new Date(cal.getTimeInMillis());
            displayTill = displayTill.plusDays(1);

            ChestSlipUploadDetails checkSlipUploadDetails = checkSlipUploadDetailsRepository.findChestSlipUploadDetailsBySlipDateBrcode(
                displayTill,
                cc
            );

            CcBglBalance ccbglBalance = null;
            if (bgl.equals("98958")) {
              
                    List<CcBglBalance> balances = ccbglBalanceRepository.getBalance(cc, checkClosingFieldsRepository.findByFieldName("BGL98958Closing"), displayTill);
                    if(balances.size() > 0 )
                        ccbglBalance=balances.get(0);
                    	
            } else if (bgl.equals("98908")) {
            	
            	List<CcBglBalance> balances = ccbglBalanceRepository.getBalance(cc, checkClosingFieldsRepository.findByFieldName("BGL98908Closing"), displayTill);
                if(balances.size() > 0 )
                    ccbglBalance=balances.get(0);
               
            }

            if (ccbglBalance != null) bglBalance = ccbglBalance.getValue();

            ChestSlipParticular notesClosingParticular = particularsRepository.particularByPhrase("Closing Balance", "Notes");
            ChestSlipParticular coinsClosingParticular = particularsRepository.particularByPhrase("Closing Balance", "Coins");
            ChestSlipParticular coinsDepositParticular = particularsRepository.particularByPhrase("Deposits", "Coins");
            ChestSlipParticular coinsWithdrawalParticular = particularsRepository.particularByPhrase("Withdrawals", "Coins");
            ChestSlipParticular notesDepositParticular = particularsRepository.particularByPhrase("Deposits", "Notes");
            ChestSlipParticular notesWithdrawalParticular = particularsRepository.particularByPhrase("Withdrawals", "Notes");

            if (checkSlipUploadDetails != null) {
                if (bgl.equals("98958")) {
                    notesClosing = totalsTableRepository.findTotalValues(notesClosingParticular, checkSlipUploadDetails);
                    coinsClosing = totalsTableRepository.findTotalValues(coinsClosingParticular, checkSlipUploadDetails);
                } else if (bgl.equals("98908")) {
                    ccnotesdeposit = totalsTableRepository.findTotalValues(notesDepositParticular, checkSlipUploadDetails);
                    ccnoteswithdrawal = totalsTableRepository.findTotalValues(notesWithdrawalParticular, checkSlipUploadDetails);
                    cccoinsdeposit = totalsTableRepository.findTotalValues(coinsDepositParticular, checkSlipUploadDetails);
                    cccoinswithdrawal = totalsTableRepository.findTotalValues(coinsWithdrawalParticular, checkSlipUploadDetails);
                }
                //  file = checkSlipUploadDetails.getUploadFile().split("\\\\")[3];
            }

            DifferenceReport differenceReport = new DifferenceReport();
            differenceReport.setDate(displayTill);
            differenceReport.setBglBalance(bglBalance);
            differenceReport.setReport(bgl);
            if (bgl.equals("98958")) {
                differenceReport.setCcBalance(notesClosing + coinsClosing);
            } else if (bgl.equals("98908")) {
                differenceReport.setCcBalance(ccnoteswithdrawal + cccoinswithdrawal - ccnotesdeposit - cccoinsdeposit);
                differenceReport.setDeposits(ccnotesdeposit + cccoinsdeposit);
                differenceReport.setWithdrawals(ccnoteswithdrawal + cccoinswithdrawal);
            }
            // differenceReport.setFile(file);

            differenceReportList.add(differenceReport);
        }

        return differenceReportList;
    }

    public DisplayDifference displayDifference(@RequestParam("brcode") Long brcode) {
        DisplayDifference displayDiff = new DisplayDifference();

        // TODO: return a proper error message
        if (brcode == null) {
            return null;
        }

        //BranchProfile branchProfile = branchProfileRepository.findByBranchCode(Long.valueOf(brcode));
        // TODO: properly handle the case when not found
        CurrencyChest cc = currencyChestRepository.findByBranchCode(brcode).orElseThrow();

        Double bgl98958Closing = 0d;
        Double bgl98908Closing = 0d;
        Double ccnotesclosing = 0d;
        Double cccoinsclosing = 0d;
        Double ccnotesdeposit = 0d;
        Double ccnoteswithdrawal = 0d;
        Double cccoinsdeposit = 0d;
        Double cccoinswithdrawal = 0d;

        LocalDate bgl98958Date = null;
        LocalDate bgl98908Date = null;
        LocalDate ccDate = null;

        Long id;

        ChestClosingFields checkClosingFields = checkClosingFieldsRepository.findByFieldName("BGL98958Closing");
        id = ccbglBalanceRepository.getLatestBalanceId(cc, checkClosingFields);

        Optional<CcBglBalance> optCCBGLBalance;
        if (id != null) {
            optCCBGLBalance = ccbglBalanceRepository.findById(id);
            if (optCCBGLBalance.isPresent()) {
                CcBglBalance ccbglBalance = optCCBGLBalance.get();
                bgl98958Closing = ccbglBalance.getValue();
                bgl98958Date = ccbglBalance.getDate();
            }
        }

        checkClosingFields = checkClosingFieldsRepository.findByFieldName("BGL98908Closing");
        id = ccbglBalanceRepository.getLatestBalanceId(cc, checkClosingFields);
        if (id != null) {
            optCCBGLBalance = ccbglBalanceRepository.findById(id);
            if (optCCBGLBalance.isPresent()) {
                CcBglBalance ccbglBalance = optCCBGLBalance.get();
                bgl98908Closing = ccbglBalance.getValue();
                bgl98908Date = ccbglBalance.getDate();
            }
        }
        ChestSlipParticular notesClosingParticular = particularsRepository.particularByPhrase("Closing Balance", "Notes");
        ChestSlipParticular coinsClosingParticular = particularsRepository.particularByPhrase("Closing Balance", "Coins");
        ChestSlipParticular coinsDepositParticular = particularsRepository.particularByPhrase("Deposits", "Coins");
        ChestSlipParticular coinsWithdrawalParticular = particularsRepository.particularByPhrase("Withdrawals", "Coins");
        ChestSlipParticular notesDepositParticular = particularsRepository.particularByPhrase("Deposits", "Notes");
        ChestSlipParticular notesWithdrawalParticular = particularsRepository.particularByPhrase("Withdrawals", "Notes");

        id = checkSlipUploadDetailsRepository.getMaxUploadId(cc);
        if (id != null) {
            Optional<ChestSlipUploadDetails> optCheckSlipUploadDetails = checkSlipUploadDetailsRepository.findById(id);
            if (optCheckSlipUploadDetails.isPresent()) {
                ChestSlipUploadDetails checkSlipUploadDetails = optCheckSlipUploadDetails.get();
                ccDate = checkSlipUploadDetails.getChestSlipDate();

                ccnotesclosing = totalsTableRepository.findTotalValues(notesClosingParticular, checkSlipUploadDetails);
                cccoinsclosing = totalsTableRepository.findTotalValues(coinsClosingParticular, checkSlipUploadDetails);
                ccnotesdeposit = totalsTableRepository.findTotalValues(notesDepositParticular, checkSlipUploadDetails);
                ccnoteswithdrawal = totalsTableRepository.findTotalValues(notesWithdrawalParticular, checkSlipUploadDetails);
                cccoinsdeposit = totalsTableRepository.findTotalValues(coinsDepositParticular, checkSlipUploadDetails);
                cccoinswithdrawal = totalsTableRepository.findTotalValues(coinsWithdrawalParticular, checkSlipUploadDetails);
            }
        }
        displayDiff.setBgl98908balance(bgl98908Closing);
        displayDiff.setBgl98908Date(bgl98908Date);
        displayDiff.setBgl98958balance(bgl98958Closing);
        displayDiff.setBgl98958Date(bgl98958Date);
        displayDiff.setCccoinsclosing(cccoinsclosing);
        displayDiff.setCccoinsdeposit(cccoinsdeposit);
        displayDiff.setCccoinswithdrawal(cccoinswithdrawal);
        displayDiff.setCcDate(ccDate);
        displayDiff.setCcnotesclosing(ccnotesclosing);
        displayDiff.setCcnotesdeposit(ccnotesdeposit);
        displayDiff.setCcnoteswithdrawal(ccnoteswithdrawal);

        return displayDiff;
    }

    @Transactional
    public List<DisplayDifference> displayDifferenceOnDate(@RequestParam("date") LocalDate date) {
        List<DisplayDifference> displayDiffList = new ArrayList<>();
        List<CurrencyChest> currencyChests = currencyChestRepository.findAll();

        currencyChests =
            currencyChests
                .stream()
                .filter(
                    o ->
                        (o.getClosedDate() == null || (o.getClosedDate() != null && o.getClosedDate().compareTo(date) > 0)) &&
                        o.getDateOfOpening() != null &&
                        o.getDateOfOpening().compareTo(date) <= 0
                )
                .collect(Collectors.toList());

        Double bgl98958Closing = 0d;
        Double bgl98908Closing = 0d;
        Double ccnotesclosing = 0d;
        Double cccoinsclosing = 0d;
        Double ccnotesdeposit = 0d;
        Double ccnoteswithdrawal = 0d;
        Double cccoinsdeposit = 0d;
        Double cccoinswithdrawal = 0d;

        LocalDate bgl98958Date = null;
        LocalDate bgl98908Date = null;
        LocalDate ccDate = null;

        ChestClosingFields checkClosingFields1 = checkClosingFieldsRepository.findByFieldName("BGL98958Closing");
        ChestClosingFields checkClosingFields2 = checkClosingFieldsRepository.findByFieldName("BGL98908Closing");

        AppUser user = SecurityUtils.getLoggedInUser();

        Set<Role> roles = user.getRoles();

        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        for (int i = 0; i < currencyChests.size(); i++) {
            CurrencyChest cc = currencyChests.get(i);

            if (roles.contains(FSLO_USER) && cc.getFslo().getBranchCode().compareTo(user.getBranchCode()) != 0) continue;

            if (
                (roles.contains(BRANCH_USER) || roles.contains(BRANCH_HEAD)) && cc.getBranchCode().compareTo(user.getBranchCode()) != 0
            ) continue;

            if (
                (roles.contains(RBO_CM) || roles.contains(RM)) &&
                (
                    cc.getRegion().getRegionCode().compareTo(user.getRegionCode()) != 0 ||
                    cc.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    cc.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(AO_USER) || roles.contains(AGM_GB)) &&
                (
                    cc.getModule().getModuleCode().compareTo(user.getModuleCode()) != 0 ||
                    cc.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
                )
            ) continue;

            if (
                (roles.contains(CIRCLE_ADMIN) || roles.contains(DGM_CFO)) &&
                cc.getCircle().getCircleCode().compareTo(user.getCircleCode()) != 0
            ) continue;

            bgl98958Closing = 0d;
            bgl98908Closing = 0d;
            ccnotesclosing = 0d;
            cccoinsclosing = 0d;
            ccnotesdeposit = 0d;
            ccnoteswithdrawal = 0d;
            cccoinsdeposit = 0d;
            cccoinswithdrawal = 0d;

            bgl98958Date = null;
            bgl98908Date = null;
            ccDate = null;
            
            CcBglBalance bglBalance = null;
            
            List<CcBglBalance> balances = ccbglBalanceRepository.getBalance(cc, checkClosingFields1, date);
            if(balances.size() > 0 )
            	bglBalance=balances.get(0);

           // CcBglBalance bglBalance = ccbglBalanceRepository.getBalance(cc, checkClosingFields1, date);

            if (bglBalance != null) {
                bgl98958Closing = bglBalance.getValue();
                bgl98958Date = bglBalance.getDate();
            }

            
           balances = ccbglBalanceRepository.getBalance(cc, checkClosingFields2, date);
            if(balances.size() > 0 )
            	bglBalance=balances.get(0);
            
           // bglBalance = ccbglBalanceRepository.getBalance(cc, checkClosingFields2, date);
            if (bglBalance != null) {
                bgl98908Closing = bglBalance.getValue();
                bgl98908Date = bglBalance.getDate();
            }
            ChestSlipParticular notesClosingParticular = particularsRepository.particularByPhrase("Closing Balance", "Notes");
            ChestSlipParticular coinsClosingParticular = particularsRepository.particularByPhrase("Closing Balance", "Coins");
            ChestSlipParticular coinsDepositParticular = particularsRepository.particularByPhrase("Deposits", "Coins");
            ChestSlipParticular coinsWithdrawalParticular = particularsRepository.particularByPhrase("Withdrawals", "Coins");
            ChestSlipParticular notesDepositParticular = particularsRepository.particularByPhrase("Deposits", "Notes");
            ChestSlipParticular notesWithdrawalParticular = particularsRepository.particularByPhrase("Withdrawals", "Notes");

            Optional<ChestSlipUploadDetails> optCheckSlipUploadDetails = checkSlipUploadDetailsRepository.findByCurrencyChestAndChestSlipDate(
                cc,
                date
            );

            if (optCheckSlipUploadDetails.isPresent()) {
                ChestSlipUploadDetails checkSlipUploadDetails = optCheckSlipUploadDetails.get();
                ccDate = checkSlipUploadDetails.getChestSlipDate();

                ccnotesclosing = totalsTableRepository.findTotalValues(notesClosingParticular, checkSlipUploadDetails);
                cccoinsclosing = totalsTableRepository.findTotalValues(coinsClosingParticular, checkSlipUploadDetails);
                ccnotesdeposit = totalsTableRepository.findTotalValues(notesDepositParticular, checkSlipUploadDetails);
                ccnoteswithdrawal = totalsTableRepository.findTotalValues(notesWithdrawalParticular, checkSlipUploadDetails);
                cccoinsdeposit = totalsTableRepository.findTotalValues(coinsDepositParticular, checkSlipUploadDetails);
                cccoinswithdrawal = totalsTableRepository.findTotalValues(coinsWithdrawalParticular, checkSlipUploadDetails);
            }
            DisplayDifference displayDiff = new DisplayDifference();
            displayDiff.setBgl98908balance(bgl98908Closing);
            displayDiff.setBgl98908Date(bgl98908Date);
            displayDiff.setBgl98958balance(bgl98958Closing);
            displayDiff.setBgl98958Date(bgl98958Date);
            displayDiff.setCccoinsclosing(cccoinsclosing);
            displayDiff.setCccoinsdeposit(cccoinsdeposit);
            displayDiff.setCccoinswithdrawal(cccoinswithdrawal);
            displayDiff.setCcDate(ccDate);
            displayDiff.setCcnotesclosing(ccnotesclosing);
            displayDiff.setCcnotesdeposit(ccnotesdeposit);
            displayDiff.setCcnoteswithdrawal(ccnoteswithdrawal);
            displayDiff.setBrCode(cc.getBranchCode());
            displayDiff.setBrName(cc.getBranchName());
            displayDiff.setCircle(cc.getCircle().getCircleName());
            displayDiff.setModuleName(cc.getModule().getModuleName());
            displayDiff.setModule(cc.getModule().getModuleCode());
            displayDiff.setNetwork(cc.getNetwork().getNetworkCode());
            displayDiff.setRegion(cc.getRegion().getRegionCode());
            displayDiffList.add(displayDiff);
        }

        Collections.sort(
            displayDiffList,
            new Comparator<DisplayDifference>() {
                @Override
                public int compare(DisplayDifference o1, DisplayDifference o2) {
                    String circle1 = o1.getCircle() + "";
                    String network1 = o1.getNetwork() + "";
                    String module1 = o1.getModule() + "";
                    String region1 = o1.getRegion() + "";
                    String brcode1 = o1.getBrCode() + "";

                    String circle2 = o2.getCircle() + "";
                    String network2 = o2.getNetwork() + "";
                    String module2 = o2.getModule() + "";
                    String region2 = o2.getRegion() + "";
                    String brcode2 = o2.getBrCode() + "";

                    String compare1 = circle1 + "" + network1 + "" + module1 + "" + region1 + "" + brcode1;
                    String compare2 = circle2 + "" + network2 + "" + module2 + "" + region2 + "" + brcode2;

                    return compare1.compareTo(compare2);
                }
            }
        );

        return displayDiffList;
    }

    public List<ExceptionReport> exceptionReportOnDate(LocalDate localDate) {
        return exceptionReportRepository.findByReportDate(localDate);
    }
}
