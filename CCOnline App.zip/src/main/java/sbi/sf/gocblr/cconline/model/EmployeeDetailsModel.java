package sbi.sf.gocblr.cconline.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import sbi.sf.gocblr.cconline.utils.NumberUtils;

@Data
@NoArgsConstructor
public class EmployeeDetailsModel {

    private Long pfId;
    private String title;
    private String name;
    private Long branchCode;
    private String branchName;
    private String designation;
    private String emailId;
    private Long mobileNo;
    private String employeeSubGroup;
    private String employeeGroup;

    public static EmployeeDetailsModel build(EisDecryptedResponse ed) {
        EmployeeDetailsModel edm = new EmployeeDetailsModel();
        edm.setPfId(Long.parseLong(ed.getPfNumber()));
        edm.setTitle(ed.getTitle());
        edm.setName(String.format("%s %s %s", ed.getFirstName(), ed.getMiddleName(), ed.getLastName()));
        edm.setBranchCode(Long.parseLong(ed.getBranchCode()));
        edm.setBranchName(ed.getBranchName());
        edm.setDesignation(ed.getDesignation());
        edm.setEmailId(ed.getEmail());
        edm.setMobileNo(NumberUtils.parseLongWithDefault(ed.getMobileNumber()));
        edm.setEmployeeSubGroup(ed.getEmployeeSubGroup());
        edm.setEmployeeGroup(ed.getEmployeeGroup());
        return edm;
    }
}
