package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.enums.ComplianceStatus;

/**
 *
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "value_statements_compliances")
public class ValueStatementCompliance {

    @Id
    private Long id;

    @MapsId
    @OneToOne
    @JoinColumn(name = "id", foreignKey = @ForeignKey(name = "fk_value_statements_compliance_vs_verification"))
    @EqualsAndHashCode.Include
    private ValueStatementVerification vsVerification;

    @Column(name = "branch_compliance")
    private ComplianceStatus branchCompliance;

    @Column(name = "branch_comments", length = 400)
    private String branchComments;
}
