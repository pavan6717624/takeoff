package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Value statement option input types
 *
 * @author Kiran Marturu
 *
 */
public enum InputType {
    YES_NO,
    NO_YES,
    YES_NO_NA,
    YES_NO_NCD,
    OPTIONS,
    DATE,
    NUMBER,
    ONLY_COMMENTS,
    TEXT,
}
