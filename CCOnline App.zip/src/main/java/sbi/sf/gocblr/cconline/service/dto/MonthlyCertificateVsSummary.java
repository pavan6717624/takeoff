package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public interface MonthlyCertificateVsSummary {
    String getDisplayNo();
    Integer getDisplayOrder();
    boolean getHeaderOnly();
    String getDescription();
    Integer getInputYes();
    Integer getInputNo();
}
