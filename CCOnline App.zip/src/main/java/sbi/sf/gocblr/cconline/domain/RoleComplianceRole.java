package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.enums.ComplianceRole;

@Getter
@Setter
@Entity
@Table(name = "role_compliance_role_mapping")
public class RoleComplianceRole {

    @Id
    private Long id;

    @ManyToOne
    @JoinColumn(name = "verification_type_id", foreignKey = @ForeignKey(name = "fk_role_compl_role_verification_type"))
    @EqualsAndHashCode.Include
    private VerificationType verificationType;

    @ManyToOne
    @JoinColumn(name = "for_role", referencedColumnName = "name", foreignKey = @ForeignKey(name = "fk_role_compl_role_roles"))
    @EqualsAndHashCode.Include
    private Role forRole;

    @Column(name = "compliance_role", length = 100)
    @Enumerated(EnumType.STRING)
    private ComplianceRole complianceRole;
}
