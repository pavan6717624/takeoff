package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.Data;
import org.hibernate.annotations.NaturalId;
import sbi.sf.gocblr.cconline.domain.enums.OptionCompliance;

/**
 *
 * @author Kiran Marturu
 *
 */
@Data
@Entity
@Table(
    name = "verification_value_statements",
    uniqueConstraints = @UniqueConstraint(
        name = "uk_verification_value_statements_natural_id",
        columnNames = { "verification_id", "value_statement_id" }
    )
)
public class ValueStatementVerification implements Serializable {

    private static final long serialVersionUID = -2214709842341947245L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "verification_id", foreignKey = @ForeignKey(name = "fk_vs_verification_verification"))
    private Verification verification;

    @NaturalId
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "value_statement_id", foreignKey = @ForeignKey(name = "fk_verification_value_statements_vs_id"))
    private ValueStatement valueStatement;

    @Column(name = "option_input", length = 50)
    private String optionInput;

    @Column(name = "verification_compliance", length = 3)
    private OptionCompliance compliance;

    @Column(name = "date_input")
    private LocalDate dateInput;

    @Column(name = "number_input", columnDefinition = "NUMBER(20, 2)")
    private Double numberInput;

    @Column(length = 400)
    private String comments;
}
