package sbi.sf.gocblr.cconline.model.verificationmis;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.ValueStatement;

@Data
@AllArgsConstructor
public class VsConsolidatedCircleWise {

    //	private String sectionDisplayNo;
    //	private String displayNo;
    //	int indentLevel;
    //	String description;
    //	boolean onlyAsHeader;

    private ValueStatement vs;
    private List<Integer> notCompliedCounts;
}
