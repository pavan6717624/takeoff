package sbi.sf.gocblr.cconline.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Circles
 *
 * @author Kiran Marturu
 *
 */
@Entity
@Table(name = "circles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Circle implements Serializable {

    private static final long serialVersionUID = -4383327449565082506L;

    @Id
    @EqualsAndHashCode.Include
    @Column(name = "circle_code")
    private Long circleCode;

    @Column(name = "circle_name")
    private String circleName;

    @JsonIgnore
    @OneToMany(mappedBy = "circle")
    private Set<Network> networks = new HashSet<>();

    @Column(name = "cfo_email_id", length = 300)
    private String cfoEmailId;

    @Column(name = "cgm_email_id", length = 300)
    private String cgmEmailId;
}
