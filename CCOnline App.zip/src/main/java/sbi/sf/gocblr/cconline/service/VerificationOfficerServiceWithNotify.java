package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;

import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.AssignVerificationOfficerVM;

@Slf4j
@Service
@RequiredArgsConstructor
public class VerificationOfficerServiceWithNotify {

	private final VerificationOfficerService verificationOfficerService;
    private final SmsService smsService;
    private final MailSenderService emailService;
    private final ApplicationProperties app;
    private final SpringTemplateEngine templateEngine;
	
	public Verification assignVerificationOfficer(String verificationType, AssignVerificationOfficerVM details) {
		log.trace(">> assignVerificationOfficer()");
		
		Verification assignedVerification = verificationOfficerService.assign(verificationType, details);
		
		sendEmailNotification(
			assignedVerification.getOfficer().getEmailId(),
			assignedVerification.getType().getName(),
			assignedVerification.getCurrencyChest().getBranchName(),
			assignedVerification.getCurrencyChest().getBranchCode(),
			assignedVerification.getToBeCompletedBefore()
        );

		smsService.sendSmsAsync(
		    String.valueOf(assignedVerification.getOfficer().getMobileNo()),
		    String.format(
	    		app.getSmsVerificationAssigned(),
	    		assignedVerification.getType().getName(),
	    		assignedVerification.getCurrencyChest().getBranchCode(),
	    		DateUtils.format(assignedVerification.getToBeCompletedBefore())
    		)
		);
		
		return assignedVerification;
	}
	
	public void sendEmailNotification(
        String email,
        String verificationType,
        String branchName,
        long branchCode,
        LocalDate toBeCompletedBefore
    ) {
        // send email
        log.debug(">> sendEmailNotification()");

        // 1. prepare template
        Context context = new Context();
        context.setVariable("verificationType", verificationType);
        context.setVariable("branchName", branchName);
        context.setVariable("branchCode", branchCode);
        context.setVariable("toBeCompletedBefore", DateUtils.format(toBeCompletedBefore));

        String htmlTemplate = templateEngine.process("email/verificationAssignment.html", context);

        // 2. send email
        emailService.sendEmailAsync(
            new String[] { email },
            new String[0],
            String.format("%s verification assigned", verificationType),
            htmlTemplate,
            true
        );
    }
}
