package sbi.sf.gocblr.cconline.exception;

public class InvalidCurrencyChestException extends RuntimeException {

    private static final long serialVersionUID = 4558837732854872094L;

    public InvalidCurrencyChestException(String string) {
        super(string);
    }
}
