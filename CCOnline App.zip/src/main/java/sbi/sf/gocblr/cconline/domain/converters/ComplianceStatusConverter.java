package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.ComplianceStatus;

/**
 * Attribute converter for @see sbi.sf.gocblr.cconline.domain.enums.ComplianceStatus
 * @author Kiran Marturu
 *
 */
@Converter(autoApply = true)
public class ComplianceStatusConverter implements AttributeConverter<ComplianceStatus, String> {

    @Override
    public String convertToDatabaseColumn(ComplianceStatus complianceStatus) {
        if (complianceStatus == null) {
            return null;
        }
        return complianceStatus.code();
    }

    @Override
    public ComplianceStatus convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return ComplianceStatus.fromCode(code);
    }
}
