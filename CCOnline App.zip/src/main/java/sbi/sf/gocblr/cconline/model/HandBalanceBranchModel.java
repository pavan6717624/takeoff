package sbi.sf.gocblr.cconline.model;

public interface HandBalanceBranchModel {
	 public Long getCircleCode();
	 public String getCircleName();
	 public Long getNetworkCode();
	 public Long getModuleCode();
	 public String getModuleName();
	 public Long getRegionCode();
	 public Long getBranchCode();
	 public String getBranchName();
	 public String getLiveFlag();
	 public Long getBranchTypeCode();
	 public String getBranchType();
	 public String getBranchEmailId();
	 public Long getBrachManagerMobileNumber();
	 public Long getRboBranchCode();
}
