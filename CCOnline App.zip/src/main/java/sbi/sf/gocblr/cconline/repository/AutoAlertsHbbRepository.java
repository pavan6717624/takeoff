package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sbi.sf.gocblr.cconline.domain.AutoAlertsDetailsHbb;
import sbi.sf.gocblr.cconline.domain.AutoAlertsRecipientsHbb;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.model.AutoAlertsDTO;

public interface AutoAlertsHbbRepository extends JpaRepository<AutoAlertsDetailsHbb, Long> { 

	@Query("select "
			+ "r.receivers as role, r.receivers.id as roleId, a.email as email from "
			+ "AutoAlertsDetailsHbb  a  "
			+ "right join AutoAlertsRecipientsHbb r on a.forRole = r and a.branch.branchCode=(:branchCode) where r.forRole like (:forRole)")
	List<AutoAlertsDTO> findByBranchCode(@Param("branchCode") Long branchCode, @Param("forRole") String forRole);
	
	
	@Query("select a from AutoAlertsDetailsHbb a where "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'Regional Manager') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'CM (C&O)') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'DGM (B&O)') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'CM/AGM (GB)') or "
			
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and (:#{#branch.branchTypeCode})=17 and a.branch.branchTypeCode=17 and a.forRole.receivers like 'DGM (B&O)') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and (:#{#branch.branchTypeCode})=17 and a.branch.branchTypeCode=17 and a.forRole.receivers like 'CM/AGM (GB)') or "
			
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and (:#{#branch.branchTypeCode})=18 and a.branch.branchTypeCode=18 and a.forRole.receivers like 'DGM & CFO') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and (:#{#branch.branchTypeCode})=18 and a.branch.branchTypeCode=18 and a.forRole.receivers like 'AGM') or "
			+ " (a.branch.branchCode=:#{#branch.branchCode} and  a.branch.branchCode=3999 and a.forRole.receivers like :#{#forRole.receivers} and a.forRole.receivers like 'DGM ABD') or "
			+ " (a.branch.branchCode=:#{#branch.branchCode} and  a.branch.branchCode=3999 and a.forRole.receivers like :#{#forRole.receivers} and a.forRole.receivers like 'ABD USER') "
			)	
	
	Optional<AutoAlertsDetailsHbb> findByForRoleAndBranch(@Param("forRole") AutoAlertsRecipientsHbb forRole, @Param("branch") Branch branch);

	
}
