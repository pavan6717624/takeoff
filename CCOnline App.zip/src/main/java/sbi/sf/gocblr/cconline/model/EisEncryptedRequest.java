package sbi.sf.gocblr.cconline.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EisEncryptedRequest {

    @JsonProperty("REQUEST_REFERENCE_NUMBER")
    private String requestReferenceNumber;

    @JsonProperty("REQUEST")
    private String request;

    @JsonProperty("DIGI_SIGN")
    private String digiSign;
}
