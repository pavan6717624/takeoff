package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Currency chest employee types
 * @author Kiran Marturu
 *
 */
public enum CurrencyChestEmployeeType {
    ACCOUNTANT("A", "Accountant"),
    CASH_OFFICER("C", "Cash Officer"),
    BRANCH_MANAGER("B", "Branch Manager");

    private final String code;
    private final String description;

    CurrencyChestEmployeeType(String code, String desc) {
        this.code = code;
        this.description = desc;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static CurrencyChestEmployeeType fromCode(String code) {
        for (CurrencyChestEmployeeType j : CurrencyChestEmployeeType.values()) {
            if (j.code.equalsIgnoreCase(code)) {
                return j;
            }
        }

        throw new IllegalArgumentException("Invalid JointCustodianType code: " + code);
    }
}
