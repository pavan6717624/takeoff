package sbi.sf.gocblr.cconline;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import sbi.sf.gocblr.cconline.utils.DefaultProfileUtil;

@SpringBootApplication
public class CcOnlineApplication {

    private static final Logger log = LoggerFactory.getLogger(CcOnlineApplication.class);

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(CcOnlineApplication.class);
        DefaultProfileUtil.addDefaultProfile(app);
        Environment env = app.run(args).getEnvironment();
        logApplicationStartup(env);
    }

    private static void logApplicationStartup(Environment env) {
        log.info(">>>>> CC Online is running!, profile(s): {}", (Object[]) env.getActiveProfiles());
    }
}
