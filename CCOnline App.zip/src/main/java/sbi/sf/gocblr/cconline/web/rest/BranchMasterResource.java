package sbi.sf.gocblr.cconline.web.rest;

import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.Module;
import sbi.sf.gocblr.cconline.domain.Network;
import sbi.sf.gocblr.cconline.domain.Region;
import sbi.sf.gocblr.cconline.repository.BranchRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.RoleConstants;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class BranchMasterResource {

    private static final String USER_NOT_HAVING_APPROPRIATE_ROLE = "User not having appropriate role for accessing this resource.";

    private final BranchRepository branchRepo;

    @GetMapping("/circles")
    public List<Circle> userCircles() {
        AppUser lu = SecurityUtils.getLoggedInUser();
        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER, RoleConstants.DGM_ABD)) {
            return branchRepo.circles(null);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return branchRepo.circles(lu.getCircleCode());
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB, RoleConstants.AO_USER)) {
            return branchRepo.circles(lu.getCircleCode());
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RM, RoleConstants.RBO_CM)) {
            return branchRepo.circles(lu.getCircleCode());
        }

        throw new AccessDeniedException(USER_NOT_HAVING_APPROPRIATE_ROLE);
    }

    @GetMapping("/networks")
    public List<Network> userNetworks(@NotNull Long circleCode) {
        AppUser lu = SecurityUtils.getLoggedInUser();
        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER, RoleConstants.DGM_ABD)) {
            return branchRepo.networks(circleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return branchRepo.networks(lu.getCircleCode());
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB, RoleConstants.AO_USER)) {
            return branchRepo.networks(lu.getCircleCode());
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RM, RoleConstants.RBO_CM)) {
            return branchRepo.networks(lu.getCircleCode());
        }

        throw new AccessDeniedException(USER_NOT_HAVING_APPROPRIATE_ROLE);
    }

    @GetMapping("/modules")
    public List<Module> modules(@NotNull Long circleCode, @NotNull Long networkCode) {
        AppUser lu = SecurityUtils.getLoggedInUser();

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER, RoleConstants.DGM_ABD)) {
            return branchRepo.modules(circleCode, networkCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return branchRepo.modules(lu.getCircleCode(), networkCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB, RoleConstants.AO_USER)) {
            return branchRepo.modules(lu.getCircleCode(), lu.getNetworkCode());
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RM, RoleConstants.RBO_CM)) {
            return branchRepo.modules(lu.getCircleCode(), lu.getNetworkCode());
        }

        throw new AccessDeniedException(USER_NOT_HAVING_APPROPRIATE_ROLE);
    }

    @GetMapping("/regions")
    public List<Region> regions(@NotNull Long circleCode, @NotNull Long moduleCode) {
        AppUser lu = SecurityUtils.getLoggedInUser();
        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER, RoleConstants.DGM_ABD)) {
            return branchRepo.regions(circleCode, moduleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return branchRepo.regions(lu.getCircleCode(), moduleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB, RoleConstants.AO_USER)) {
            return branchRepo.regions(lu.getCircleCode(), lu.getModuleCode());
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RM, RoleConstants.RBO_CM)) {
            return branchRepo.regions(lu.getCircleCode(), lu.getModuleCode());
        }

        throw new AccessDeniedException(USER_NOT_HAVING_APPROPRIATE_ROLE);
    }
}
