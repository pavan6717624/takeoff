package sbi.sf.gocblr.cconline.domain;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * For tracking user sessions as well as dynamic role assignment
 *
 * @author Kiran
 *
 */
@Entity
@Table(name = "user_sessions")
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class UserSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "pf_id")
    private Long pfId;

    @Column(length = 10)
    private String title;

    @Column(length = 100)
    private String name;

    // O, S, C, E etc..
    @Column(name = "employee_group", length = 10)
    private String employeeGroupCode;

    // O4, O3 etc...
    @Column(name = "employee_sub_group", length = 10)
    private String employeeSubGroupCode;

    // employee sub group description
    @Column(length = 100)
    private String designation;

    @Column(length = 300)
    private String emailId;

    @Column(name = "mobile_no")
    private Long mobileNo;

    @Column(name = "branch_code")
    private Long branchCode;

    @Column(name = "branch_name")
    private String branchName;

    @Column(name = "network_code")
    private Long networkCode;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "user_session_roles",
        joinColumns = {
            @JoinColumn(
                name = "session_id",
                referencedColumnName = "id",
                foreignKey = @ForeignKey(name = "fk_user_sesssion_roles_user_session_id")
            ),
        },
        inverseJoinColumns = {
            @JoinColumn(
                name = "role_id",
                referencedColumnName = "id",
                updatable = false,
                foreignKey = @ForeignKey(name = "fk_user_session_roles_role_id")
            ),
        }
    )
    private Set<Role> roles = new HashSet<>();

    @Column(name = "jwt_iat")
    private Long jwtIat;

    @Column(name = "session_expires_on")
    private Instant sessionExpiresOn;

    @Column(name = "is_black_listed")
    private Boolean blackListed = false;

    @Column(name = "reason_for_blacklisting")
    private String reasonForBlackListing;
}
