package sbi.sf.gocblr.cconline.model.verificationmis;

import java.time.LocalDate;

public interface VsConsolidatedBranchDetails {
    String getCircleName();
    Long getNetworkCode();
    String getModuleName();
    Long getRegionCode();
    long getBranchCode();
    String getBranchName();
    LocalDate getVerificationDate();
}
