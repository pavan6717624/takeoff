package sbi.sf.gocblr.cconline.utils;

import java.util.regex.Pattern;

/**
 * Front-end related utility methods
 * @author Kiran Marturu
 *
 */
public class FrontEndUtils {

    private static final Pattern VALID_ROUTE = Pattern.compile("[a-zA-Z0-9\\-/]*");

    private FrontEndUtils() {
        throw new IllegalArgumentException("Static utils class, not to be initialized");
    }

    public static boolean isValidRoute(String route) {
        return TextUtils.hasText(route) && VALID_ROUTE.matcher(route).matches();
    }
}
