package sbi.sf.gocblr.cconline.domain.specification;

import org.springframework.data.jpa.domain.Specification;
import sbi.sf.gocblr.cconline.domain.Module;

public class ModuleSpecification {

    private ModuleSpecification() {
        // static class
    }

    public static Specification<Module> modules(long circleCode, long networkCode) {
        return (root, query, cb) ->
            cb.and(
                cb.equal(root.get("network").get("circle").get("circleCode"), circleCode),
                cb.equal(root.get("network").get("networkCode"), networkCode)
            );
    }
}
