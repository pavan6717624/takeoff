package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDate;
import java.util.List;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.enums.ComplianceRole;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VerificationSectionsViewModel {

    private String verificationType;
    private Long branchCode;
    private String branchName;
    private String block;
    private List<VerificationSectionDTO> sections;
    private Boolean isEditable;
    private Action rejectAction;
    private Action submitAction;
    private ComplianceRole userRole;
    private VerificationStatus status;
    private String statusDescription;
    private String VerificationOfficerComments;
    private String branchHeadComments;
    private String scrutinizerComments;
    private String verificationOfficerComplianceComments;
    private String closureComments;
    private String certificateText;

    // added for front end verification date validation
    private LocalDate blockFrom;
    private LocalDate blockTo;
    
    public String getStatusDescription() {
    	if (status != null) {
    		return status.description();
    	}
    	return "";
    }
}
