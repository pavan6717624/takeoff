package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.OptionCompliance;

@Converter(autoApply = true)
public class OptionComplianceConverter implements AttributeConverter<OptionCompliance, String> {

    @Override
    public String convertToDatabaseColumn(OptionCompliance attribute) {
        return attribute.code();
    }

    @Override
    public OptionCompliance convertToEntityAttribute(String dbData) {
        return OptionCompliance.fromCode(dbData);
    }
}
