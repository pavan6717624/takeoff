package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Value;

@Value
public class AssignedVerificationsDto {

    private Integer branchCode;
    private LocalDate toBeCompletedBy;
}
