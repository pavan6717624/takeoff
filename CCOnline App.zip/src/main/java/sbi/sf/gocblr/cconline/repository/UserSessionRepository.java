package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.UserSession;

public interface UserSessionRepository extends JpaRepository<UserSession, Long> {
    /**
     * Session for given PF id and black listed or not
     * @param pfId PF id of the user
     * @param isBlacklisted true in case of blacklisted; false for vice versa
     * @return List<UserSession>
     */
    List<UserSession> findByPfIdAndBlackListed(long pfId, boolean isBlacklisted);

    Optional<UserSession> findByIdAndPfId(long id, long pfId);
}
