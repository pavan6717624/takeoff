package sbi.sf.gocblr.cconline.model;

import lombok.Data;
import sbi.sf.gocblr.cconline.domain.Denomination;

@Data
public class NsmSaveData {

    Denomination[] denomination;
    String date;
    CcNsmModal nsmData;
    Integer[] count;
}
