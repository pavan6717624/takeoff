package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(
    name = "sms_messages",
    uniqueConstraints = @UniqueConstraint(name = "uk_sms_messages", columnNames = { "mobile_no", "text", "for_date" })
)
@NoArgsConstructor
public class SmsNotification extends AbstractAuditingEntity {

    private static final long serialVersionUID = 4988439009530610458L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sms_status", foreignKey = @ForeignKey(name = "fk_sms_messages_sms_status"))
    private SmsStatus smsStatus;

    @Column(name = "mobile_no")
    private long mobileNo;

    @Column(name = "text", length = 160)
    private String text;

    @Column(name = "for_date")
    private LocalDate forDate;

    @Column(name = "success")
    private Boolean success;

    @Column(name = "message", length = 500)
    private String message;

    public SmsNotification(long mobileNo, String text, LocalDate forDate) {
        this.mobileNo = mobileNo;
        this.text = text;
        this.forDate = forDate;
    }
}
