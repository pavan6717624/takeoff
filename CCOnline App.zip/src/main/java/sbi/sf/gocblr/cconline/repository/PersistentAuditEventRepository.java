package sbi.sf.gocblr.cconline.repository;

import java.time.Instant;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.PersistentAuditEvent;

@Repository
public interface PersistentAuditEventRepository extends JpaRepository<PersistentAuditEvent, Long> {
    List<PersistentAuditEvent> findByUser(String user);

    List<PersistentAuditEvent> findByEventDateAfter(Instant after);

    List<PersistentAuditEvent> findByUserAndEventDateAfter(String principal, Instant after);

    List<PersistentAuditEvent> findByUserAndEventDateAfterAndEventType(String user, Instant after, String type);

    Page<PersistentAuditEvent> findAllByEventDateBetween(Instant fromDate, Instant toDate, Pageable pageable);
}
