package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.ValueStatement;
import sbi.sf.gocblr.cconline.domain.ValueStatementVerification;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.enums.InputType;
import sbi.sf.gocblr.cconline.domain.enums.OptionCompliance;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.repository.ValueStatementRepository;
import sbi.sf.gocblr.cconline.repository.ValueStatementVerificationRepository;
import sbi.sf.gocblr.cconline.utils.TextUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.SaveVsVerificationVM;

@Slf4j
@Service
@RequiredArgsConstructor
public class ValueStatementVerificationService {

    private final ValueStatementVerificationRepository repo;

    private final VerificationService verificationService;
    private final ValueStatementService vsService;
    private final VerificationSectionService sectionService;
    private final ValueStatementRepository vsRepo;
    private final VerificationSectionStatusService statusService;

    private static final Pattern YES_NO_MATCHER = Pattern.compile("((YES)|(NO))");
    private static final Pattern YES_NO_NA_MATCHER = Pattern.compile("((YES)|(NO)|(NA))");
    private static final Pattern YES_NO_NCD_MATCHER = Pattern.compile("((YES)|(NO)|(NCD))");

    private static final Pattern DATE_PATTERN = Pattern.compile("(\\d{4}-\\d{2}-\\d{2}).+");

    @Transactional
    public void saveVs(SaveVsVerificationVM model) {
        Verification v = verificationService.notSubmitted(model.getVerificationId());
        ValueStatement vs = vsService.getValueStatement(model.getVsId(), model.getSectionId());

        Optional<ValueStatementVerification> existing = repo.findByVerificationAndValueStatement(v, vs);

        if (isValidSelectedOption(model.getSelectedOption(), vs.getInputType())) {
            ValueStatementVerification vsV;
            if (existing.isPresent()) {
                vsV = existing.get();

                vsV.setOptionInput(null);
                vsV.setDateInput(null);
                vsV.setNumberInput(null);

                if (vs.getInputType() == InputType.DATE) {
                    vsV.setDateInput(parseIsoDate(model.getSelectedOption()));
                } else if (vs.getInputType() == InputType.NUMBER) {
                    vsV.setNumberInput(Double.parseDouble(model.getSelectedOption()));
                } else {
                    vsV.setOptionInput(model.getSelectedOption());
                }
                vsV.setCompliance(getOptionCompliance(model.getSelectedOption(), vs.getInputType()));
                vsV.setComments(model.getComments());
            } else {
                vsV = new ValueStatementVerification();
                vsV.setVerification(v);
                vsV.setValueStatement(vs);

                if (vs.getInputType() == InputType.DATE) {
                    vsV.setDateInput(parseIsoDate(model.getSelectedOption()));
                } else if (vs.getInputType() == InputType.NUMBER) {
                    vsV.setNumberInput(Double.parseDouble(model.getSelectedOption()));
                } else {
                    vsV.setOptionInput(model.getSelectedOption());
                }
                vsV.setCompliance(getOptionCompliance(model.getSelectedOption(), vs.getInputType()));
                vsV.setComments(model.getComments());
            }
            repo.save(vsV);
            updateSectionStatus(v.getId(), model.getSectionId());
        } else {
            throw new ValidationException("Invalid option " + model.getSelectedOption());
        }
    }

    public ValueStatementVerification getValueStatementVerification(Verification v, ValueStatement vs) {
        return repo
            .findByVerificationAndValueStatement(v, vs)
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        String.format("Not vs verification found for verification %d, vs %d", v.getId(), vs.getId())
                    )
            );
    }

    private void updateSectionStatus(long verificationId, long sectionId) {
        var v = verificationService.getVerificationById(verificationId);
        var s = sectionService.getById(sectionId);

        int pendingCount = vsRepo.pendingCount(v, s);
        log.debug("pending count: {}", pendingCount);

        if (pendingCount == 0) {
            statusService.updateSavedStatus(v, s);
        }
    }

    private boolean isValidSelectedOption(String selectedOption, InputType inputType) {
        log.debug("selectedOption: {} | inputType: {}", selectedOption, inputType);

        String so = TextUtils.toUpperCase(selectedOption, true);

        switch (inputType) {
            case YES_NO:
            case NO_YES:
                Matcher m = YES_NO_MATCHER.matcher(so);
                return m.matches();
            case YES_NO_NA:
                Matcher m2 = YES_NO_NA_MATCHER.matcher(so);
                return m2.matches();
            case YES_NO_NCD:
                Matcher m3 = YES_NO_NCD_MATCHER.matcher(so);
                return m3.matches();
            case DATE:
                try {
                    parseIsoDate(so);
                    return true;
                } catch (DateTimeParseException e) {
                    return false;
                }
            case NUMBER:
                try {
                    Double.parseDouble(so);
                    return true;
                } catch (NumberFormatException e) {
                    return false;
                }
            case ONLY_COMMENTS:
                return true;
            default:
                return false;
        }
    }

    private OptionCompliance getOptionCompliance(String selectedOption, InputType inputType) {
        String so = TextUtils.toUpperCase(selectedOption, true);

        switch (inputType) {
            case YES_NO:
                if (so.equals("YES")) {
                    return OptionCompliance.COMPLIED;
                }
                return OptionCompliance.NOT_COMPLIED;
            case NO_YES:
                if (so.equals("NO")) {
                    return OptionCompliance.COMPLIED;
                }
                return OptionCompliance.NOT_COMPLIED;
            case YES_NO_NA:
                if (so.equals("YES")) {
                    return OptionCompliance.COMPLIED;
                } else if (so.equals("NO")) {
                    return OptionCompliance.NOT_COMPLIED;
                } else {
                    return OptionCompliance.NOT_APPLICABLE;
                }
            case YES_NO_NCD:
                if (so.equals("YES")) {
                    return OptionCompliance.COMPLIED;
                } else if (so.equals("NO")) {
                    return OptionCompliance.NOT_COMPLIED;
                } else {
                    return OptionCompliance.NOT_APPLICABLE;
                }
            case DATE:
            case NUMBER:
            case ONLY_COMMENTS:
                return OptionCompliance.NOT_APPLICABLE;
            default:
                throw new IllegalArgumentException("Invalid selected option " + selectedOption);
        }
    }

    public LocalDate parseIsoDate(String strDate) {
        String dateString = null;
        Matcher m = DATE_PATTERN.matcher(strDate);

        if (m.find()) {
            dateString = m.group(1);
        }
        if (dateString == null) {
            throw new DateTimeParseException("Invalid date", strDate, -1);
        }
        return LocalDate.parse(dateString);
    }
}
