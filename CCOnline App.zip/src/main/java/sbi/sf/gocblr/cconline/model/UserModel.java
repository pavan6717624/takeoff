package sbi.sf.gocblr.cconline.model;

import java.util.HashSet;
import java.util.Set;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.User;

@Data
public class UserModel {

    private Long id;
    private String title;
    private String name;
    private String designation;
    private long branchCode;
    private String branchName;
    private Long mobileNo;
    private String emailId;
    private Set<Role> roles = new HashSet<>();
    private boolean approved = false;
    private boolean enabled;
    private boolean deleted;
    private UserRequestModel userRequest;

    public UserModel(User u) {
        this.id = u.getId();
        this.title = u.getTitle();
        this.name = u.getName();
        this.designation = u.getDesignation();
        this.branchCode = u.getBranch().getBranchCode();
        this.branchName = u.getBranch().getBranchName();
        this.mobileNo = u.getMobileNo();
        this.emailId = u.getEmailId();
        this.roles = u.getRoles();
        this.approved = u.isApproved();
        this.enabled = Boolean.TRUE.equals(u.getIsEnabled());
        this.deleted = Boolean.TRUE.equals(u.getIsDeleted());
        if (u.getUserRequest() != null) {
            this.userRequest = new UserRequestModel(u.getUserRequest());
        }
    }
}
