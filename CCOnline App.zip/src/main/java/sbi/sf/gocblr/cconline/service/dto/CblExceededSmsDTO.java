package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.time.LocalDate;

@JsonInclude(value = Include.NON_NULL)
public interface CblExceededSmsDTO extends IBranchAndContactsDTO {
    Long getCashBalanceLimit();
    Long getCymClosingBalance();
    Long getExceededBy();
    LocalDate getLastUploadedOn();
    Boolean getSmsSent();
}
