package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DownloadFsloEkuber {

    Long fsloCode;
    String fsloName;
    LocalDate date;
    Double deposit;
    Double withdrawal;
    Double ct;
    String filePath;
}
