package sbi.sf.gocblr.cconline.model;

public class HrmsUser {}
