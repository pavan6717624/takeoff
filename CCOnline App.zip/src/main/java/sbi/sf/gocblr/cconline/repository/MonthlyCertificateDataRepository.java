package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateData;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateDataDTO;

public interface MonthlyCertificateDataRepository extends JpaRepository<MonthlyCertificateData, Long> {
    @Query(
        "SELECT s as statement, d.optionInput as optionInput, d.dateInput as dateInput " +
        "  FROM MonthlyCertificateStmts s " +
        "       LEFT JOIN MonthlyCertificateData d " +
        "         ON d.statement = s " +
        "        AND d.cc.branchCode = :branchCode " +
        "        AND d.month = :month"
    )
    List<MonthlyCertificateDataDTO> dataForMonth(@Param("branchCode") long branchCode, @Param("month") LocalDate month);

    Optional<MonthlyCertificateData> findByMonthAndCcBranchCodeAndStatementId(LocalDate month, long branchCode, int stmtId);
}
