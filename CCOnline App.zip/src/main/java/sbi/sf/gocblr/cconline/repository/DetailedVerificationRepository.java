package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.DetailedVerification;

@Repository
public interface DetailedVerificationRepository extends JpaRepository<DetailedVerification, Long> {
    Optional<DetailedVerification> findByVerificationId(Long verificationId);
}
