package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "balance_verification")
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class BalanceVerification implements Serializable {

    private static final long serialVersionUID = -629560650064233474L;

    @Id
    private Long id;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id", foreignKey = @ForeignKey(name = "fk_balance_verification_verification"))
    @EqualsAndHashCode.Include
    private Verification verification;

    @OneToMany(mappedBy = "balanceVerification", cascade = CascadeType.ALL)
    private Set<BalanceVerificationDetails> denominationWiseDetails = new HashSet<>();

    @Column(name = "balances_as_on")
    private LocalDate balancesAsOn;

    @Column(name = "has_discrepancy")
    private Boolean hasDiscrepancy;

    @Column(name = "discrepancy_details", length = 400)
    private String discrepancyDetails;

    public void addDenominationWiseDetails(BalanceVerificationDetails denomDetails) {
        denominationWiseDetails.add(denomDetails);
        denomDetails.setBalanceVerification(this);
    }
}
