package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "monthly_certificate_data")
public class MonthlyCertificateData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_monthly_certificate_data_cc_branch_code"))
    private CurrencyChest cc;

    private LocalDate month;

    @ManyToOne
    @JoinColumn(name = "stmt_id", foreignKey = @ForeignKey(name = "fk_monthly_certificate_data_stmt_id"))
    private MonthlyCertificateStmts statement;

    @Column(name = "option_input")
    private String optionInput;

    @Column(name = "date_input")
    private LocalDate dateInput;
}
