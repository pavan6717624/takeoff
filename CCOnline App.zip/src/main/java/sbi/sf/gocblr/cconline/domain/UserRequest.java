package sbi.sf.gocblr.cconline.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.enums.RequestStatus;
import sbi.sf.gocblr.cconline.domain.enums.UserRequestType;

@Getter
@Setter
@Entity
@Table(name = "user_requests")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class UserRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @EqualsAndHashCode.Include
    private Long id;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY)
    @JsonIgnore
    @JoinColumn(name = "id", foreignKey = @ForeignKey(name = "fk_user_requests_user_id"))
    private User user;

    @Column(name = "fslo_code")
    private Long fsloCode;

    @Column(name = "network_code")
    private Long networkCode;

    @ManyToMany
    @JoinTable(
        name = "user_requests_roles",
        joinColumns = {
            @JoinColumn(name = "user_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_user_requests_user_id")),
        },
        inverseJoinColumns = {
            @JoinColumn(
                name = "role_id",
                referencedColumnName = "id",
                updatable = false,
                foreignKey = @ForeignKey(name = "fk_user_requests_role_id")
            ),
        }
    )
    private Set<Role> roles = new HashSet<>();

    @Column(name = "type", length = 10)
    @Enumerated(EnumType.STRING)
    private UserRequestType requestType;

    @Column(name = "requested_by")
    private Long requestedBy;

    @Column(name = "requested_on")
    private LocalDateTime requestedOn = LocalDateTime.now();

    @Column(name = "request_status", length = 1)
    private RequestStatus requestStatus = RequestStatus.PENDING;

    @Column(name = "status_by")
    private Long statusBy;

    @Column(name = "status_on")
    private LocalDateTime statusOn = LocalDateTime.now();

    @Column(name = "request_message")
    private String requestMessage;
}
