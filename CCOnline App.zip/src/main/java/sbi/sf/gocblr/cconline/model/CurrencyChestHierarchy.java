package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class CurrencyChestHierarchy implements CurrencyChestHierarchyDTO {

    String circleName;
    Long networkCode;
    Long moduleCode;
    Long regionCode;
}
