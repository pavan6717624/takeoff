package sbi.sf.gocblr.cconline.service.dto;

public interface NotesAdjudicatedDetailsDTO {
    Long getDenominationId();
    String getDenominationType();
    Integer getDenominationValue();
    Integer getFullValuePieces();
    Integer getHalfValuePieces();
    Integer getRejectedPieces();
}
