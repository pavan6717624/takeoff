package sbi.sf.gocblr.cconline.model;

import java.util.List;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;
import org.hibernate.validator.constraints.Range;
import sbi.sf.gocblr.cconline.model.enums.ReminderFor;
import sbi.sf.gocblr.cconline.model.enums.ReminderTo;

@Data
public class EmailReminderInputModel {

    @NotNull(message = "Reminder for is required")
    @Size(min = 1, message = "At least one reminder for to be selected")
    private List<ReminderFor> reminderFor;

    @NotNull(message = "To be sent to is required")
    private ReminderTo toBeSentTo;

    @NotNull(message = "Pendency for is required")
    @Range(min = 1, max = 10, message = "Pendency for should be 1 to 10 (inclusive)")
    private Integer pendencyFor;
}
