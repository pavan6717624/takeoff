package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.VerificationBlock;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.web.rest.vm.VerificationBlockDTO;

/**
 * Verification block repository
 *
 * @author Kiran Marturu
 *
 */
public interface VerificationBlockRepository extends JpaRepository<VerificationBlock, Long> {
    List<VerificationBlock> findByType(VerificationType type, Sort sort);

    Optional<VerificationBlock> findByTypeAndBlockFromAndBlockTo(VerificationType type, LocalDate pf, LocalDate pt);

    Optional<VerificationBlock> findByTypeKeyAndBlockFromAndBlockTo(String type, LocalDate periodStart, LocalDate periodEnd);

    Optional<VerificationBlock> findByTypeAndBlockTo(VerificationType type, LocalDate blockTo);

    Optional<VerificationBlock> findByTypeAndBlockFromLessThanAndBlockToGreaterThan(VerificationType type, LocalDate pf, LocalDate pt);

    abstract List<VerificationBlock> findByTypeEqualsAndBlockFromGreaterThanEqualAndBlockToLessThanEqual(
        VerificationType t,
        LocalDate s,
        LocalDate e
    );

    default List<VerificationBlock> getBlocksInBetween(VerificationType t, LocalDate s, LocalDate e) {
        return findByTypeEqualsAndBlockFromGreaterThanEqualAndBlockToLessThanEqual(t, s, e);
    }

    Optional<VerificationBlock> findTopByTypeOrderByBlockToDesc(VerificationType vt);

    List<VerificationBlock> findByType(VerificationType type);

    @Query(
        "SELECT vb.id as id,vb.type as type, vb.blockFrom as blockFrom, vb.blockTo as blockTo " +
        "  FROM VerificationBlock vb " +
        " WHERE vb.type = :type " +
        "   AND (vb.blockFrom <= CURRENT_DATE OR vb.type.key IN (:assignableTypes)) " +
        " ORDER BY vb.blockFrom DESC"
    )
    List<VerificationBlockDTO> getVerificationBlocks(
        @Param("type") VerificationType type,
        @Param("assignableTypes") List<String> assignableTypes
    );

    @Query(
        "SELECT vb.blockFrom as blockFrom, " +
        "       vb.blockTo as blockTo " +
        "  FROM VerificationBlock vb " +
        " WHERE vb.type = :type " +
        "   AND vb.blockFrom < CURRENT_DATE " +
        " ORDER BY vb.blockFrom DESC"
    )
    List<VerificationBlockDTO> getPastBlocks(@Param("type") VerificationType type);

    @Query(
        "SELECT vb.blockFrom as blockFrom, " +
        "       vb.blockTo as blockTo " +
        "  FROM VerificationBlock vb " +
        " WHERE vb.type = :type " +
        "   AND vb.blockTo < CURRENT_DATE"
    )
    List<VerificationBlockDTO> getCompletedBlocks(@Param("type") VerificationType type);

    @Query(
		"SELECT COUNT(1) " + 
		"  FROM VerificationBlock " + 
		" WHERE blockFrom > :selectedPeriodTo " +
		"   AND blockFrom <= CURRENT_DATE " +
		"   AND type = :type"
	)
    int isAllowedToStart(@Param("selectedPeriodTo") LocalDate periodTo, @Param("type") VerificationType type);
}
