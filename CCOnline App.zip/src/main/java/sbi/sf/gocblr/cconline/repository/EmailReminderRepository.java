package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.EmailReminder;
import sbi.sf.gocblr.cconline.model.enums.ReminderTo;

public interface EmailReminderRepository extends JpaRepository<EmailReminder, Long> {
    Optional<EmailReminder> findByReminderForAndToBeSentToAndForDate(String r, ReminderTo t, LocalDate forDate);
}
