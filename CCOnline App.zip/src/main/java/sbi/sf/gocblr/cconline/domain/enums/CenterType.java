package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Enum for representing currency chest center types
 *
 * @author Kiran
 *
 */
public enum CenterType {
    DIST_HQ("DIST_HQ", "District HQ"),
    SUB_DIV_HQ("SUB_DIV_HQ", "Sub Divisional HQ");

    private final String code;
    private final String description;

    CenterType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static CenterType fromCode(String code) {
        for (CenterType n : CenterType.values()) {
            if (n.toString().equalsIgnoreCase(code)) {
                return n;
            }
        }
        return null;
    }
}
