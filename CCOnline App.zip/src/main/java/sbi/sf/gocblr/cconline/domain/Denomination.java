package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Data;

/**
 * Denominations master
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
@Entity
public class Denomination implements Serializable {

    private static final long serialVersionUID = 6485811419295987875L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer value;
    private String description;
    private String type;
}
