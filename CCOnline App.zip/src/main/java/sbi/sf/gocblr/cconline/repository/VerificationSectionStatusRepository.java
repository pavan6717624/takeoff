package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.VerificationSectionStatus;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.model.VerificationSectionStatusDto;

/**
 * Verification sections status repository
 *
 * @author Kiran Marturu
 *
 */
public interface VerificationSectionStatusRepository extends JpaRepository<VerificationSectionStatus, Long> {
    /**
     * Sections with status
     * @param page Pagination parameters
     * @return List of VerificationSectionStatusDtos
     */
    @Query(
        "SELECT section AS section, status AS status " +
        "  FROM VerificationSection section " +
        "       LEFT JOIN VerificationSectionStatus status " +
        "            ON section = status.section" +
        "           AND status.verification = :verification" +
        "  WHERE section.verificationType = :verificationType"
    )
    public List<VerificationSectionStatusDto> sectionsWithStatus(
        @Param("verification") Verification verification,
        @Param("verificationType") VerificationType verificationType,
        Pageable page
    );

    Optional<VerificationSectionStatus> findByVerificationAndSection(Verification v, VerificationSection vs);
}
