package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.RequestStatus;

/**
 * Attribute converter for @see sbi.sf.gocblr.cconline.domain.enums.CcType
 *
 * @author Kiran Marturu
 *
 */
@Converter(autoApply = true)
public class RequestStatusConverter implements AttributeConverter<RequestStatus, String> {

    @Override
    public String convertToDatabaseColumn(RequestStatus requestStatus) {
        return requestStatus.getCode();
    }

    @Override
    public RequestStatus convertToEntityAttribute(String code) {
        return RequestStatus.fromCode(code);
    }
}
