package sbi.sf.gocblr.cconline.repository;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.stereotype.Component;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateStatus;
import sbi.sf.gocblr.cconline.domain.criteria.MonthlyCertificateCriteria;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateSubmissionSummary;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateSubmissionSummaryImpl;

@Component
public class CustomizedMonthlyCertificateRepositoryImpl implements CustomizedMonthlyCertificateRepository {

    @PersistenceContext
    EntityManager em;

    @Override
    public MonthlyCertificateSubmissionSummary submissionSummary(MonthlyCertificateCriteria criteria) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<MonthlyCertificateSubmissionSummaryImpl> query = cb.createQuery(MonthlyCertificateSubmissionSummaryImpl.class);

        Root<CurrencyChest> root = query.from(CurrencyChest.class);
        Join<CurrencyChest, MonthlyCertificateStatus> join = root.join("monthlyCertificateStatuses", JoinType.LEFT);
        join.on(cb.equal(join.get("month"), criteria.getMonth()));

        query.select(
            cb.construct(
                MonthlyCertificateSubmissionSummaryImpl.class,
                cb.sum(cb.selectCase().when(join.isNull(), 1).otherwise(0).as(Long.class)),
                cb.sum(cb.selectCase().when(join.isNull(), 0).otherwise(1).as(Long.class))
            )
        );

        List<Predicate> predicates = createPredicatesFromCriteria(criteria, cb, root);

        query.where(
            cb.and(predicates.toArray(new Predicate[predicates.size()])),
            cb.lessThanOrEqualTo(cb.coalesce(root.get("dateOfOpening"), criteria.getMonth()), criteria.getMonth()),
            cb.greaterThanOrEqualTo(cb.coalesce(root.get("closedDate"), criteria.getMonth()), criteria.getMonth())
        );

        TypedQuery<MonthlyCertificateSubmissionSummaryImpl> q = em.createQuery(query);

        return q.getSingleResult();
    }

    private List<Predicate> createPredicatesFromCriteria(
        MonthlyCertificateCriteria criteria,
        CriteriaBuilder cb,
        Root<CurrencyChest> root
    ) {
        List<Predicate> predicates = new ArrayList<>();

        if (criteria.getCircleCode() != null && criteria.getFsloCode() != null) {
            predicates.add(
                cb.or(
                    cb.equal(root.get("circle").get("circleCode"), criteria.getCircleCode()),
                    cb.equal(cb.abs((root.get("fslo").get("branchCode"))), criteria.getFsloCode())
                )
            );
        } else {
            if (criteria.getFsloCode() != null) {
                predicates.add(cb.equal(cb.abs(root.get("fslo").get("branchCode")), criteria.getFsloCode()));
            }
            if (criteria.getCircleCode() != null) {
                predicates.add(cb.equal(root.get("circle").get("circleCode"), criteria.getCircleCode()));

                if (criteria.getModuleCode() != null) {
                    predicates.add(cb.equal(root.get("module").get("moduleCode"), criteria.getModuleCode()));

                    if (criteria.getRegionCode() != null) {
                        predicates.add(cb.equal(root.get("region").get("regionCode"), criteria.getRegionCode()));
                    }
                }
            }
        }
        return predicates;
    }
}
