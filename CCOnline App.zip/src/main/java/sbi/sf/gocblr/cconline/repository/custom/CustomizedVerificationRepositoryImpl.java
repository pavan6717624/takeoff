package sbi.sf.gocblr.cconline.repository.custom;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Module;
import sbi.sf.gocblr.cconline.domain.Network;
import sbi.sf.gocblr.cconline.domain.Region;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationOfficer;
import sbi.sf.gocblr.cconline.domain.criteria.VerificationCriteria;
import sbi.sf.gocblr.cconline.domain.criteria.VerificationScrutinyCriteria;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;
import sbi.sf.gocblr.cconline.model.VerificationModel;
import sbi.sf.gocblr.cconline.model.VerificationsListFilters;
import sbi.sf.gocblr.cconline.model.ui.NzFilterMenu;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.RoleConstants;
import sbi.sf.gocblr.cconline.service.dto.ForComplianceVerificationListDto;
import sbi.sf.gocblr.cconline.service.dto.VerificationForListModel;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.ComplianceVerificationFilters;
import sbi.sf.gocblr.cconline.web.vm.ClosureListFilter;
import sbi.sf.gocblr.cconline.web.vm.VerificationClosureDto;

@Component
public class CustomizedVerificationRepositoryImpl implements CustomizedVerificationRepository {

    @PersistenceContext
    EntityManager em;

    @Override
    public Page<VerificationModel> verifications(VerificationCriteria criteria, Pageable pageable) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<VerificationModel> query = cb.createQuery(VerificationModel.class);

        Root<CurrencyChest> root = query.from(CurrencyChest.class);

        // join
        Join<CurrencyChest, Verification> verification = root.join("verifications", JoinType.LEFT);
        verification.on(
            cb.and(
                cb.equal(verification.get("type"), criteria.getType()),
                cb.equal(verification.get("blockFrom"), DateUtils.getLocalDate(criteria.getBlockFrom())),
                cb.equal(verification.get("blockTo"), DateUtils.getLocalDate(criteria.getBlockTo()))
            )
        );

        // projection
        query.select(
            cb.construct(
                VerificationModel.class,
                root.get("circle").get("circleName"),
                root.get("network").get("networkCode"),
                root.get("module").get("moduleCode"),
                root.get("module").get("moduleName"),
                root.get("region").get("regionCode"),
                root.get("branchCode"),
                root.get("branchName"),
                verification
            )
        );

        Join<Verification, VerificationOfficer> vo = verification.join("officer", JoinType.LEFT);

        Predicate[] spa = statusPredicates(cb, verification, vo, criteria);

        query.where(cb.and(combinePredicates(userLevelRestrictions(root, cb, criteria), filterPredicates(root, cb, criteria), spa)));

        query.orderBy(
            cb.asc(root.get("circle").get("circleName")),
            cb.asc(root.get("network")),
            cb.asc(root.get("module")),
            cb.asc(root.get("region")),
            cb.asc(root.get("branchCode"))
        );

        TypedQuery<VerificationModel> q = em
            .createQuery(query)
            .setFirstResult((int) pageable.getOffset())
            .setMaxResults(pageable.getPageSize());

        List<VerificationModel> result = q.getResultList();

        // Count query
        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);

        Root<CurrencyChest> rootCount = countQuery.from(CurrencyChest.class);

        Join<CurrencyChest, Verification> verification2 = rootCount.join("verifications", JoinType.LEFT);
        verification2.on(
            cb.and(
                cb.equal(verification.get("type"), criteria.getType()),
                cb.equal(verification.get("blockFrom"), DateUtils.getLocalDate(criteria.getBlockFrom())),
                cb.equal(verification.get("blockTo"), DateUtils.getLocalDate(criteria.getBlockTo()))
            )
        );
        Join<Verification, VerificationOfficer> vo2 = verification2.join("officer", JoinType.LEFT);

        countQuery
            .select(cb.count(rootCount))
            .where(
                cb.and(
                    combinePredicates(
                        userLevelRestrictions(rootCount, cb, criteria),
                        filterPredicates(rootCount, cb, criteria),
                        statusPredicates(cb, verification2, vo2, criteria)
                    )
                )
            );

        Long count = em.createQuery(countQuery).getSingleResult();

        return new PageImpl<>(result, pageable, count);
    }

    private Predicate[] statusPredicates(
        CriteriaBuilder cb,
        Join<CurrencyChest, Verification> verification,
        Join<Verification, VerificationOfficer> vo,
        VerificationCriteria criteria
    ) {
        // status filters
        Set<Predicate> sp = new HashSet<>();

        if (criteria.getVoPfId() != null) {
            sp.add(cb.equal(vo.get("pfId"), criteria.getVoPfId()));
        }

        if (criteria.getStatus() != null) {
            Expression<VerificationStatus> status = verification.get("status");

            switch (criteria.getStatus()) {
                case VO_NOT_ASSIGNED:
                    sp.add(cb.isNull(vo.get("pfId")));
                    break;
                case VER_NOT_STARTED:
                    sp.add(cb.and(cb.isNotNull(vo), cb.isNull(verification.get("status"))));
                    break;
                case IN_PROGRESS:
                    sp.add(cb.equal(verification.get("status"), VerificationStatus.IN_PROGRESS));
                    break;
                case REPORT_SUBMITTED:
                    sp.add(
                        cb.and(
                            cb.isNotNull(verification.get("status")),
                            cb.notEqual(verification.get("status"), VerificationStatus.IN_PROGRESS)
                        )
                    );
                    break;
                case PENDING_AT_BRANCH:
                    sp.add(
                        status.in(
                            Arrays.asList(
                                VerificationStatus.REPORT_SUBMITTED,
                                VerificationStatus.CMP_SUBMITTED_BY_BR_MAKER,
                                VerificationStatus.CMP_REJECTED_BY_BR_HEAD,
                                VerificationStatus.CMP_REJECTED_BY_SCRUTINIZER
                            )
                        )
                    );
                    break;
                case PENDING_AT_CONTROLLER:
                    sp.add(status.in(Arrays.asList(VerificationStatus.CMP_SUBMITTED_BY_BR_HEAD, VerificationStatus.CMP_REJECTED_BY_CA)));
                    break;
                case AWAITING_FOR_CLOSURE:
                    sp.add(
                        status.in(Arrays.asList(VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER, VerificationStatus.CMP_VERIFIED_BY_VO))
                    );
                    break;
                case CLOSED:
                    sp.add(cb.equal(verification.get("status"), VerificationStatus.CMP_CLOSED));
                    break;
                case ASSIGN_COMPL_VO:
                    sp.add(
                        status.in(
                            Arrays.asList(
                                VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER,
                                VerificationStatus.CMP_VERIFIED_BY_VO,
                                VerificationStatus.CMP_REJECTED_BY_CA,
                                VerificationStatus.CMP_CLOSED
                            )
                        )
                    );
                    break;
            }
        }

        return sp.toArray(new Predicate[sp.size()]);
    }

    @Override
    public VerificationsListFilters filters(VerificationCriteria criteria) {
        CriteriaBuilder cb = em.getCriteriaBuilder();

        VerificationsListFilters filters = new VerificationsListFilters();

        // circles
        CriteriaQuery<NzFilterMenu> circlesQuery = cb.createQuery(NzFilterMenu.class);
        Root<CurrencyChest> circlesRoot = circlesQuery.from(CurrencyChest.class);
        circlesQuery
            .select(
                cb.construct(
                    NzFilterMenu.class,
                    circlesRoot.get("circle").get("circleName"),
                    circlesRoot.get("circle").get("circleCode").as(String.class)
                )
            )
            .distinct(true)
            .where(cb.and(userLevelRestrictions(circlesRoot, cb, criteria)))
            .orderBy(cb.asc(circlesRoot.get("circle").get("circleName")));

        filters.setCircles(em.createQuery(circlesQuery).getResultList());

        // networks
        CriteriaQuery<NzFilterMenu> networksQuery = cb.createQuery(NzFilterMenu.class);
        Root<CurrencyChest> networksRoot = networksQuery.from(CurrencyChest.class);
        networksQuery
            .select(
                cb.construct(
                    NzFilterMenu.class,
                    networksRoot.get("network").get("networkCode").as(String.class),
                    networksRoot.get("network").get("networkCode").as(String.class)
                )
            )
            .distinct(true)
            .where(cb.and(userLevelRestrictions(networksRoot, cb, criteria)));

        filters.setNetworks(em.createQuery(networksQuery).getResultList());

        // modules
        CriteriaQuery<NzFilterMenu> modulesQuery = cb.createQuery(NzFilterMenu.class);
        Root<CurrencyChest> modulesRoot = modulesQuery.from(CurrencyChest.class);
        modulesQuery
            .select(
                cb.construct(
                    NzFilterMenu.class,
                    modulesRoot.get("module").get("moduleName"),
                    modulesRoot.get("module").get("moduleCode").as(String.class)
                )
            )
            .distinct(true)
            .where(cb.and(userLevelRestrictions(modulesRoot, cb, criteria)))
            .orderBy(cb.asc(modulesRoot.get("module").get("moduleName")));

        filters.setModules(em.createQuery(modulesQuery).getResultList());

        // regions
        CriteriaQuery<NzFilterMenu> regionsQuery = cb.createQuery(NzFilterMenu.class);
        Root<CurrencyChest> regionsRoot = regionsQuery.from(CurrencyChest.class);
        regionsQuery
            .select(
                cb.construct(
                    NzFilterMenu.class,
                    regionsRoot.get("region").get("regionCode").as(String.class),
                    regionsRoot.get("region").get("regionCode").as(String.class)
                )
            )
            .distinct(true)
            .where(cb.and(userLevelRestrictions(regionsRoot, cb, criteria)));

        filters.setRegions(em.createQuery(regionsQuery).getResultList());

        return filters;
    }

    private Predicate[] combinePredicates(Predicate[]... predicatesSet) {
        Set<Predicate> unique = new HashSet<>();

        for (Predicate[] predicate : predicatesSet) {
            Arrays.stream(predicate).forEach(p -> unique.add(p));
        }

        return unique.toArray(new Predicate[unique.size()]);
    }

    private Predicate[] filterPredicates(Root<CurrencyChest> root, CriteriaBuilder cb, VerificationCriteria criteria) {
        Set<Predicate> predicates = new HashSet<>();

        if (criteria.getCircle() != null) {
            predicates.add(cb.equal(root.get("circle").get("circleCode"), criteria.getCircle()));
        }

        if (criteria.getNetwork() != null) {
            predicates.add(cb.equal(root.get("network").get("networkCode"), criteria.getNetwork()));
        }

        if (criteria.getModule() != null) {
            predicates.add(cb.equal(root.get("module").get("moduleCode"), criteria.getModule()));
        }

        if (
            (criteria.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.RM_DGM_CONTROLLER_VISIT)) &&
            (SecurityUtils.isCurrentUserInRole(RoleConstants.DGM_BO))
        ) {
            predicates.add(cb.greaterThanOrEqualTo(root.get("region").get("regionCode"), 7));
        }

        if (criteria.getRegion() != null) {
            predicates.add(cb.equal(root.get("region").get("regionCode"), criteria.getRegion()));
        }

        if (criteria.getBranchCode() != null) {
            predicates.add(cb.equal(root.get("branchCode"), criteria.getBranchCode()));
        }

        // to filter based on open and closed dates
        predicates.add(
            cb.lessThanOrEqualTo(
                cb.coalesce(root.get("dateOfOpening"), DateUtils.getLocalDate(criteria.getBlockTo())),
                DateUtils.getLocalDate(criteria.getBlockTo())
            )
        );

        predicates.add(
            cb.greaterThan(
                cb.coalesce(root.get("closedDate"), DateUtils.getLocalDate(criteria.getBlockTo()).plusDays(1)),
                DateUtils.getLocalDate(criteria.getBlockTo())
            )
        );

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    private Predicate[] userLevelRestrictions(Root<CurrencyChest> root, CriteriaBuilder builder, VerificationCriteria criteria) {
        Set<Predicate> predicates = new HashSet<>();

        if (criteria.getUserCircleCode() != null) {
            predicates.add(builder.equal(root.get("circle").get("circleCode"), criteria.getUserCircleCode()));
            if (criteria.getUserNetworkCode() != null) {
                predicates.add(builder.equal(root.get("network").get("networkCode"), criteria.getUserNetworkCode()));
            }
            if (criteria.getUserModuleCode() != null) {
                predicates.add(builder.equal(root.get("module").get("moduleCode"), criteria.getUserModuleCode()));
                if (criteria.getUserRegionCode() != null) {
                    predicates.add(builder.equal(root.get("region").get("regionCode"), criteria.getUserRegionCode()));
                }
            }
        }
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    @Override
    public List<VerificationForListModel> verificationsForScrutiny(VerificationScrutinyCriteria criteria) {
        VerificationStatus[] statuses = VerificationStatus.values();

        int cstatus = criteria.getCstatus().intValue();
        int pending = criteria.getPending().intValue();

        CriteriaBuilder builder = em.getCriteriaBuilder();

        CriteriaQuery<VerificationForListModel> query = builder.createQuery(VerificationForListModel.class);

        Root<Verification> root = query.from(Verification.class);
        Join<Verification, CurrencyChest> cc = root.join("currencyChest");

        Set<Predicate> predicates = new HashSet<>();

        if (criteria.getCircleCode() != null) {
            predicates.add(builder.equal(cc.get("circle").get("circleCode"), criteria.getCircleCode()));

            if (criteria.getModuleCode() != null) {
                predicates.add(builder.equal(cc.get("module").get("moduleCode"), criteria.getModuleCode()));

                if (criteria.getRegionCode() != null) {
                    predicates.add(builder.equal(cc.get("region").get("regionCode"), criteria.getRegionCode()));
                }
            }
        }

        Expression<String> types = root.get("type").get("key");
        predicates.add(types.in(criteria.getTypes()));

        predicates.add(
            builder.notEqual(builder.coalesce(root.get("status"), VerificationStatus.IN_PROGRESS.code()), VerificationStatus.IN_PROGRESS)
        );

        if (cstatus != 0) predicates.add(
            builder.equal(builder.coalesce(root.get("status"), statuses[cstatus].code()), statuses[cstatus])
        ); else if (pending == 1) {
            predicates.add(
                builder.or(
                    builder.equal(builder.coalesce(root.get("status"), statuses[4].code()), statuses[4]),
                    builder.or(builder.equal(builder.coalesce(root.get("status"), statuses[8].code()), statuses[8]))
                )
            );
        }

        LocalDate fromDate = LocalDate.of(criteria.getYear().intValue(), 1, 1);
        LocalDate toDate = LocalDate.of(criteria.getYear().intValue(), 12, 31);
        predicates.add(
            builder.or(builder.between(root.get("blockFrom"), fromDate, toDate), builder.between(root.get("blockTo"), fromDate, toDate))
        );

        query.select(
            builder.construct(
                VerificationForListModel.class,
                root.get("id"),
                root.get("type").get("name"),
                root.get("blockFrom"),
                root.get("blockTo"),
                root.get("currencyChest").get("branchCode"),
                root.get("currencyChest").get("branchName"),
                root.get("status"),
                root.get("currencyChest").get("circle").get("circleName"),
                root.get("currencyChest").get("network").get("networkCode"),
                root.get("currencyChest").get("module").get("moduleName"),
                root.get("currencyChest").get("region").get("regionCode")
            )
        );

        query.where(builder.and(predicates.toArray(new Predicate[predicates.size()])));

        TypedQuery<VerificationForListModel> q = em.createQuery(query);

        return q.getResultList();
    }

    @Override
    public List<VerificationForListModel> compliance(VerificationScrutinyCriteria criteria) {
        VerificationStatus[] statuses = VerificationStatus.values();

        int cstatus = criteria.getCstatus().intValue();
        int pending = criteria.getPending().intValue();

        CriteriaBuilder builder = em.getCriteriaBuilder();

        CriteriaQuery<VerificationForListModel> query = builder.createQuery(VerificationForListModel.class);

        Root<Verification> root = query.from(Verification.class);
        Join<Verification, CurrencyChest> cc = root.join("currencyChest");

        Set<Predicate> predicates = new HashSet<>();

        if (criteria.getBranchCode() != null) {
            predicates.add(builder.equal(cc.get("branchCode"), criteria.getBranchCode()));
        }

        Expression<String> types = root.get("type").get("key");
        predicates.add(types.in(criteria.getTypes()));

        predicates.add(
            builder.notEqual(builder.coalesce(root.get("status"), VerificationStatus.IN_PROGRESS.code()), VerificationStatus.IN_PROGRESS)
        );

        if (cstatus != 0) {
            predicates.add(builder.equal(builder.coalesce(root.get("status"), statuses[cstatus].code()), statuses[cstatus]));
        } else if (pending == 1) {
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_HEAD)) {
                predicates.add(
                    builder.or(
                        builder.equal(builder.coalesce(root.get("status"), statuses[2].code()), statuses[2]),
                        builder.or(builder.equal(builder.coalesce(root.get("status"), statuses[5].code()), statuses[5]))
                    )
                );
            } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_USER)) {
                predicates.add(
                    builder.or(
                        builder.equal(builder.coalesce(root.get("status"), statuses[1].code()), statuses[1]),
                        builder.or(builder.equal(builder.coalesce(root.get("status"), statuses[3].code()), statuses[3]))
                    )
                );
            }
        }

        LocalDate fromDate = LocalDate.of(criteria.getYear().intValue(), 1, 1);
        LocalDate toDate = LocalDate.of(criteria.getYear().intValue(), 12, 31);
        predicates.add(
            builder.or(builder.between(root.get("blockFrom"), fromDate, toDate), builder.between(root.get("blockTo"), fromDate, toDate))
        );

        query.select(
            builder.construct(
                VerificationForListModel.class,
                root.get("id"),
                root.get("type").get("name"),
                root.get("blockFrom"),
                root.get("blockTo"),
                root.get("currencyChest").get("branchCode"),
                root.get("currencyChest").get("branchName"),
                root.get("status")
            )
        );

        query.where(builder.and(predicates.toArray(new Predicate[predicates.size()])));

        TypedQuery<VerificationForListModel> q = em.createQuery(query);

        return q.getResultList();
    }

    @Override
    public List<Circle> circles(VerificationCriteria criteria) {
        CriteriaBuilder cb = em.getCriteriaBuilder();

        // circles
        CriteriaQuery<Circle> query = cb.createQuery(Circle.class);

        Root<CurrencyChest> root = query.from(CurrencyChest.class);
        query
            .select(root.get("circle"))
            .distinct(true)
            .where(cb.and(combinePredicates(userLevelRestrictions(root, cb, criteria), filterPredicates(root, cb, criteria))))
            .orderBy(cb.asc(root.get("circle").get("circleName")));

        return em.createQuery(query).getResultList();
    }

    @Override
    public List<Network> networks(VerificationCriteria criteria) {
        CriteriaBuilder cb = em.getCriteriaBuilder();

        CriteriaQuery<Network> query = cb.createQuery(Network.class);

        Root<CurrencyChest> root = query.from(CurrencyChest.class);
        Join<CurrencyChest, Network> join = root.join("network");

        query
            .select(root.get("network"))
            .distinct(true)
            .where(cb.and(combinePredicates(userLevelRestrictions(root, cb, criteria), filterPredicates(root, cb, criteria))))
            .orderBy(cb.asc(join.get("networkCode")));

        return em.createQuery(query).getResultList();
    }

    @Override
    public List<Module> modules(VerificationCriteria criteria) {
        CriteriaBuilder cb = em.getCriteriaBuilder();

        CriteriaQuery<Module> query = cb.createQuery(Module.class);

        Root<CurrencyChest> root = query.from(CurrencyChest.class);
        Join<CurrencyChest, Module> join = root.join("module");
        query
            .select(root.get("module"))
            .distinct(true)
            .where(cb.and(combinePredicates(userLevelRestrictions(root, cb, criteria), filterPredicates(root, cb, criteria))))
            .orderBy(cb.asc(join.get("moduleCode")));

        return em.createQuery(query).getResultList();
    }

    @Override
    public List<Region> regions(VerificationCriteria criteria) {
        CriteriaBuilder cb = em.getCriteriaBuilder();

        CriteriaQuery<Region> query = cb.createQuery(Region.class);

        Root<CurrencyChest> root = query.from(CurrencyChest.class);
        Join<CurrencyChest, Region> join = root.join("region");
        query
            .select(root.get("region"))
            .distinct(true)
            .where(cb.and(combinePredicates(userLevelRestrictions(root, cb, criteria), filterPredicates(root, cb, criteria))))
            .orderBy(cb.asc(join.get("regionCode")));

        return em.createQuery(query).getResultList();
    }

    @Override
    public List<ForComplianceVerificationListDto> listForComplianceVerification(ComplianceVerificationFilters filter) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<ForComplianceVerificationListDto> query = cb.createQuery(ForComplianceVerificationListDto.class);

        Root<Verification> verification = query.from(Verification.class);
        Join<Verification, CurrencyChest> currencyChest = verification.join("currencyChest", JoinType.INNER);
        Join<Verification, VerificationOfficer> vOfficer = verification.join("officer", JoinType.LEFT);
        Join<Verification, VerificationOfficer> cvOfficer = verification.join("complianceVerificationOfficer", JoinType.LEFT);

        List<Predicate> predicates = new ArrayList<>();
        predicates.add(cb.equal(verification.get("type").get("key"), filter.getType()));
        predicates.add(
            cb.and(cb.isNotNull(verification.get("status")), cb.notEqual(verification.get("status"), VerificationStatus.IN_PROGRESS))
        );

        predicates.add(
            cb.or(
                cb.and(cb.equal(vOfficer.get("pfId"), filter.getPfId()), cb.isNull(cvOfficer)),
                cb.equal(cvOfficer.get("pfId"), filter.getPfId())
            )
        );

        if (Boolean.TRUE.equals(filter.getOnlyActionRequired())) {
            predicates.add(cb.equal(verification.get("status"), VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER));
        }

        query.select(
            cb.construct(
                ForComplianceVerificationListDto.class,
                verification.get("id"),
                verification.get("blockFrom"),
                verification.get("blockTo"),
                verification.get("status"),
                currencyChest.get("network").get("networkCode"),
                currencyChest.get("module").get("moduleCode"),
                currencyChest.get("module").get("moduleName"),
                currencyChest.get("region").get("regionCode"),
                currencyChest.get("branchCode"),
                currencyChest.get("branchName"),
                vOfficer.get("pfId"),
                vOfficer.get("name")
            )
        );

        query.where(predicates.toArray(new Predicate[predicates.size()]));

        query.orderBy(
            cb.asc(verification.get("currencyChest").get("network").get("networkCode")),
            cb.asc(verification.get("currencyChest").get("module").get("moduleCode")),
            cb.asc(verification.get("currencyChest").get("region").get("regionCode")),
            cb.asc(verification.get("currencyChest").get("branchCode"))
        );

        return em.createQuery(query).getResultList();
    }

    @Override
    public List<VerificationClosureDto> listForClosure(ClosureListFilter filter) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<VerificationClosureDto> query = cb.createQuery(VerificationClosureDto.class);

        Root<Verification> root = query.from(Verification.class);
        Join<Verification, CurrencyChest> cc = root.join("currencyChest", JoinType.INNER);

        List<Predicate> predicates = new ArrayList<>();

        if (filter.getType() != null) {
            predicates.add(cb.equal(root.get("type").get("key"), filter.getType()));
        }

        predicates.add(cb.and(cb.isNotNull(root.get("status")), cb.notEqual(root.get("status"), VerificationStatus.IN_PROGRESS)));

        if (filter.getCircleCode() != null) {
            predicates.add(cb.equal(cc.get("circle").get("circleCode"), filter.getCircleCode()));
        }

        if (filter.getNetworkCode() != null) {
            predicates.add(cb.equal(cc.get("network").get("networkCode"), filter.getNetworkCode()));
        }

        if (filter.getModuleCode() != null) {
            predicates.add(cb.equal(cc.get("module").get("moduleCode"), filter.getModuleCode()));
        }

        // for showing only direct control branches i.e., region code greater than equal to 7
        if (filter.isOnlyDirectControlBranches()) {
            predicates.add(cb.greaterThanOrEqualTo(cc.get("region").get("regionCode"), 7L));
        } else {
        	if (filter.getRegionCode() != null) {
        		predicates.add(cb.equal(cc.get("region").get("regionCode"), filter.getRegionCode()));
        	}
        }

        // for showing only branches under region i.e., region code less than 8 (changed from 7)
        if (filter.isOnlyBranchesUnderRegion()) {
            predicates.add(cb.lessThan(cc.get("region").get("regionCode"), 8L));
        }

        if (filter.isOnlyActionRequired()) {
            if (
                filter.getType().equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY) ||
                filter.getType().equalsIgnoreCase(VerificationTypeConstants.HALF_YEARLY)
            ) {
                predicates.add(cb.equal(root.get("status"), VerificationStatus.CMP_VERIFIED_BY_VO));
            } else {
                predicates.add(cb.equal(root.get("status"), VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER));
            }
        }

        if (filter.getStatus() != null) {
            predicates.add(cb.equal(root.get("status"), filter.getStatus()));
        }

        LocalDate startDate = filter.getYear().atDay(1);
        LocalDate endDate = filter.getYear().isLeap() ? filter.getYear().atDay(366) : filter.getYear().atDay(365);

        predicates.add(cb.or(cb.between(root.get("blockFrom"), startDate, endDate), cb.between(root.get("blockTo"), startDate, endDate)));

        query.select(
            cb.construct(
                VerificationClosureDto.class,
                root.get("id"),
                root.get("type").get("name"),
                root.get("blockFrom"),
                root.get("blockTo"),
                cc.get("branchCode"),
                cc.get("branchName"),
                root.get("status"),
                cc.get("circle").get("circleName"),
                cc.get("network").get("networkCode"),
                cc.get("module").get("moduleName"),
                cc.get("region").get("regionCode")
            )
        );

        query.orderBy(
            cb.asc(cc.get("circle").get("circleName")),
            cb.asc(cc.get("network")),
            cb.asc(cc.get("module")),
            cb.asc(cc.get("region")),
            cb.asc(cc.get("branchCode"))
        );

        query.where(predicates.toArray(new Predicate[predicates.size()]));

        return em.createQuery(query).getResultList();
    }
}
