package sbi.sf.gocblr.cconline.security;

import java.util.Optional;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;
import sbi.sf.gocblr.cconline.utils.TextUtils;

@Component
public class SpringSecurityAuditorAware implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        var currentUserId = SecurityUtils.getCurrentUserId();
        if (currentUserId.isPresent() && TextUtils.hasText(currentUserId.get())) {
            if (TextUtils.hasText(currentUserId.get()) && "anonymousUser".equalsIgnoreCase(currentUserId.get())) {
                return Optional.of("system");
            } else {
                return currentUserId;
            }
        } else {
            return Optional.of("system");
        }
    }
}
