package sbi.sf.gocblr.cconline.domain.converters;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.text.SimpleDateFormat;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.web.rest.vm.ChestProfileSaveVM;

@Converter(autoApply = true)
public class ChestProfileSaveVmConverter implements AttributeConverter<ChestProfileSaveVM, String> {

    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(ChestProfileSaveVM attribute) {
        try {
            mapper.setDateFormat(new SimpleDateFormat("dd-MM-yyyy"));
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            return mapper.writeValueAsString(attribute);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    @Override
    public ChestProfileSaveVM convertToEntityAttribute(String dbData) {
        try {
            mapper.setDateFormat(new SimpleDateFormat("dd-MM-yyyy"));
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            return mapper.readValue(dbData, ChestProfileSaveVM.class);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
