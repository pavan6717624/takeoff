package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Value statement option compliance type
 *
 * @author Kiran
 *
 */
public enum OptionCompliance {
    COMPLIED("C", "Complied"),
    NOT_COMPLIED("NC", "Not Complied"),
    NOT_APPLICABLE("NA", "Not Applicable");

    private final String code;
    private final String description;

    OptionCompliance(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static OptionCompliance fromCode(String code) {
        for (OptionCompliance n : OptionCompliance.values()) {
            if (n.code.equalsIgnoreCase(code)) {
                return n;
            }
        }
        return null;
    }
}
