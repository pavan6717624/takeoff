package sbi.sf.gocblr.cconline.exception;

import java.util.HashMap;

public class ReportGenerationFailedException extends ServiceException {

    private static final long serialVersionUID = 1L;

    public ReportGenerationFailedException(String msg) {
        super(msg);
    }

    public ReportGenerationFailedException(String msg, Throwable t) {
        super(msg, t);
    }

    ReportGenerationFailedException(String msg, HashMap<String, String[]> data) {
        super(msg, data);
    }
}
