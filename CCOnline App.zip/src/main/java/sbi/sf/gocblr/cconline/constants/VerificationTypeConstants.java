package sbi.sf.gocblr.cconline.constants;

public final class VerificationTypeConstants {

    private VerificationTypeConstants() {
        // static class not to be initialized
    }

    public static final String BI_MONTHLY = "bi-monthly";
    public static final String QUARTERLY = "quarterly";
    public static final String HALF_YEARLY = "half-yearly";
    public static final String DGM_CFO = "dgm-cfo";
    public static final String SECURITY_OFFICER = "security-officer";

    public static final String RM_DGM_CONTROLLER_VISIT = "rm-dgm-controller-visit";
    public static final String DGM_BO_MODULE_HEAD_VISIT = "dgm-bo-module-head-visit";
    public static final String GM_NETWORK_VISIT = "gm-network-visit";
    public static final String CGM_VISIT = "cgm-visit";
    public static final String DGM_CFO_VISIT = "dgm-cfo-visit";
}
