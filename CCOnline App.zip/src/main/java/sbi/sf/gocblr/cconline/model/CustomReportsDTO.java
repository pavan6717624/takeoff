package sbi.sf.gocblr.cconline.model;

public interface CustomReportsDTO {
    String getCsdate();
    String getCircle();
    Long getNet();
    String getZone();
    Long getRegion();
    Long getBrcode();
    String getBrname();
    Long getCccode();
    Long getFslocode();
    String getPopcode();
    String getState();
    String getFsloname();
    Long getCbl();
    Double getN1();
    Double getN2();
    Double getN5();
    Double getN10();
    Double getN20();
    Double getN50();
    Double getN100();
    Double getN200();
    Double getN500();
    Double getN1000();
    Double getN2000();
    Double getC1();
    Double getC2();
    Double getC5();
    Double getC10();
    Double getC20();
    Double getTotalpieces();
    Double getTotalvalue();
}
