package sbi.sf.gocblr.cconline.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.ComplianceVerificationOfficer;
import sbi.sf.gocblr.cconline.repository.ComplianceVerificationOfficerRepository;
import sbi.sf.gocblr.cconline.service.dto.DetailsForNotify;
import sbi.sf.gocblr.cconline.web.rest.vm.ComplianceVerificationOfficerInputModel;

@Slf4j
@Service
@RequiredArgsConstructor
public class ComplianceVerificationOfficerServiceNotify {

    private final ApplicationProperties app;
    private final ComplianceVerificationOfficerService service;
    private final SpringTemplateEngine templateEngine;
    private final MailSenderService emailService;
    private final SmsService smsService;

    private final ComplianceVerificationOfficerRepository repo;

    public ComplianceVerificationOfficer assign(String type, ComplianceVerificationOfficerInputModel input) {
        ComplianceVerificationOfficer assigned = service.assign(type, input);

        DetailsForNotify details = repo.detailsForNotification(assigned.getId());

        notifyByEmail(details);
        sendSmsNotification(details);

        log.debug("returning created entity");
        return assigned;
    }

    public ComplianceVerificationOfficer modify(String type, ComplianceVerificationOfficerInputModel input) {
        ComplianceVerificationOfficer modified = service.modify(type, input);

        DetailsForNotify details = repo.detailsForNotification(modified.getId());

        notifyByEmail(details);
        sendSmsNotification(details);

        log.debug("returning modified entity");
        return modified;
    }

    private void sendSmsNotification(DetailsForNotify details) {
        log.trace(">> SmsNotification()");

        smsService.sendSmsAsync(
            String.valueOf(details.getMobileNo()),
            String.format(app.getSmsComplianceVerificationAssigned(), details.getVerificationType().getName(), details.getBranchCode())
        );
    }

    private void notifyByEmail(DetailsForNotify details) {
        log.trace(">> notifyByEmail()");

        Context context = new Context();
        context.setVariable("verificationType", details.getVerificationType().getName());
        context.setVariable("branchName", details.getBranchName());
        context.setVariable("branchCode", details.getBranchCode());

        String htmlTemplate = templateEngine.process("email/complianceVerificationAssigned.html", context);

        // 2. send email
        emailService.sendEmailAsync(
            new String[] { details.getEmailId() },
            new String[0],
            String.format("%s verification assigned", details.getVerificationType().getName()),
            htmlTemplate,
            true
        );
    }
}
