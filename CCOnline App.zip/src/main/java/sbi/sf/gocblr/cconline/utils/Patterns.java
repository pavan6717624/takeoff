package sbi.sf.gocblr.cconline.utils;

/**
 * Common regexp patterns used
 *
 * @author Kiran Marturu
 *
 */
public final class Patterns {

    private Patterns() {
        // static class, not to be initialized
    }

    public static final String VERIFICATION_TYPE = "^[a-ZA-Z-]+$";
    public static final String ALPHA_NUMERIC = "[a-zA-Z0-9]+";
}
