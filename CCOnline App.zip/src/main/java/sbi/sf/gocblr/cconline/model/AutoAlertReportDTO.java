package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import java.util.List;

public interface AutoAlertReportDTO {
	
	Long getBranchCode();
	String getBranchName();
	Long getRegionCode();
	Long getModuleCode();
	String getModuleName();
	Long getNetworkCode();
	Long getCircleCode();
	String getCircleName();
	Double getClosingBalance();
	Double getCbl();
	String getLastUploadDate();	
	String getBranchManagerMobile();
	String getCashOfficerMobile();
	String getAccountantMobile();
	String getBranchEmail();
	String getRmMobile();
	String getCmMobile();
	String getRmEmail();
	String getCmEmail();
	String getDgmMobile();
	String getCmagmMobile();
	String getDgmEmail();
	String getCmAgmEmail();
	String getDgmMobileDirect();
	String getCmagmMobileDirect();
	String getDgmEmailDirect();
	String getCmagmEmailDirect();
	String getAgmfsloEmail();
	String getDgmcfoEmail();
	String getDgmabdEmail();
	String getAbdEmail();
	String getAgmCircleEmail();
	Long getFsloCode();
	Double getCashLimit();
	Double getExceededBy();
	Long getDaysExceededInMonth();
	LocalDate getReportDate();
	Long getMonthCount();
	Long getMonthConsecutiveCount();
		
}
