package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;

public interface IMisReport {
    String getCircle();
    Long getNetwork();
    Long getModule();
    String getModuleName();
    Long getRegion();
    Long getBrcode();
    String getBrname();
    Long getCccode();
    Long getFslocode();
    String getFsloName();
    Long getCbl();
    Double getTotal();
    LocalDate getLastUploadedDate();
}
