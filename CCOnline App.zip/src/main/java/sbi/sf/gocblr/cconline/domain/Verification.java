package sbi.sf.gocblr.cconline.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.NaturalId;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;

/**
 * Verification entity representing a verification tracking its assignment, status and closure status
 *
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Table(
    name = "verifications",
    uniqueConstraints = @UniqueConstraint(
        name = "uk_verifications_natural_id",
        columnNames = { "verification_type_id", "block_from", "block_to", "cc_branch_code" }
    )
)
public class Verification implements Serializable {

    private static final long serialVersionUID = -5720882805925960194L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @NaturalId
    @EqualsAndHashCode.Include
    @JoinColumn(name = "verification_type_id", foreignKey = @ForeignKey(name = "fk_verification_verification_type"))
    private VerificationType type;

    @NaturalId
    @Column(name = "block_from")
    @EqualsAndHashCode.Include
    private LocalDate blockFrom;

    @NaturalId
    @Column(name = "block_to")
    @EqualsAndHashCode.Include
    private LocalDate blockTo;

    @NaturalId
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_verification_currency_chest"))
    private CurrencyChest currencyChest;

    @OneToOne(mappedBy = "verification")
    private VerificationOfficer officer;

    @OneToOne(mappedBy = "verification")
    private ComplianceVerificationOfficer complianceVerificationOfficer;

    @Column(name = "to_be_completed_before")
    private LocalDate toBeCompletedBefore;

    private VerificationStatus status;

    // this is not a great way, but helps in reducing changes in old code
    @Transient // for preventing to be present in database
    @JsonProperty // for including in serialized
    private String statusDescription;

    // override to get status description
    public String getStatusDescription() {
        if (status != null) {
            return status.description();
        }
        return "N/A";
    }

    @OneToMany(mappedBy = "verification")
    private Set<VerificationSectionStatus> sectionsStatuses;

    @Column(name = "date_of_verification")
    private LocalDate dateOfVerification;

    @JsonIgnore
    @OneToOne(mappedBy = "verification", fetch = FetchType.LAZY)
    private BalanceVerification balanceVerification;

    @Column(name = "vo_comments", length = 1000)
    private String verificationOfficerComments;

    @Column(name = "report_submitted_by")
    private Long reportSubmittedBy;

    @Column(name = "report_submitted_on")
    private LocalDate reportSubmittedOn;

    @Column(name = "branch_head_comments", length = 400)
    private String branchHeadComments;

    @Column(name = "branch_head_pf_id")
    private Long branchHeadPfId;

    @Column(name = "branch_head_submitted_on")
    private LocalDateTime branchHeadSubmittedOn;

    @Column(name = "scrutinizer_comments", length = 400)
    private String scrutinizerComments;

    @Column(name = "scrutinizer_submitted_on")
    private LocalDateTime scrutinizerSubmittedOn;

    @Column(name = "scrutinizer_pf_id")
    private Long scrutinizerPfId;

    @Column(name = "vo_compl_comments", length = 400)
    private String verificationOfficerComplianceComments;

    @Column(name = "vo_compl_pf_id")
    private Long verificationOfficerCompliancePfId;

    @Column(name = "vo_compl_submitted_on")
    private LocalDateTime voComplianceSubmittedOn;

    @Column(name = "closure_by")
    private Long closureBy;

    @Column(name = "closure_on")
    private LocalDate closureOn;

    @Column(name = "closure_comments", length = 400)
    private String closureComments;
}
