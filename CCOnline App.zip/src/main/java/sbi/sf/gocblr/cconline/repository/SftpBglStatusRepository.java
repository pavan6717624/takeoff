package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import sbi.sf.gocblr.cconline.domain.SftpBglStatus;

public interface SftpBglStatusRepository extends JpaRepository<SftpBglStatus, Long> {
    @Query("select max(fileDate) from SftpBglStatus where status like 'Success'")
    LocalDate getLatestUploadDate();
}
