package sbi.sf.gocblr.cconline.security;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import sbi.sf.gocblr.cconline.domain.Role;

/**
 * User principal for spring security
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class AppUser implements UserDetails {

    private static final long serialVersionUID = -4521406757198942233L;

    @EqualsAndHashCode.Include
    private long id;

    private Long sessionId;

    private String title;
    private String name;

    // user hierarchy details

    private Long circleCode;
    private String circleName;

    private long networkCode;

    private long moduleCode;
    private String moduleName;

    private long regionCode;

    private long branchCode;
    private String branchName;

    private boolean isEnabled;

    private Set<Role> roles = new HashSet<>();

    private LocalDate lastLogin;

    public Long getBranchCode() {
        return Math.abs(branchCode);
    }

    @Override
    public String getUsername() {
        return id + "";
    }

    @Override
    public boolean isEnabled() {
        return isEnabled;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles;
    }

    // ===================================================
    //  Not applicable methods from UserDetails interface
    // ===================================================

    @Override
    public String getPassword() {
        // This method is N/A
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        // This method is N/A
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        // This method is N/A
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        // This method is N/A
        return false;
    }
}
