package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class AutoSmsResponse implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 6011904325090049680L;
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	 
	 private LocalDate smsDate;
	 
	 private String mobile;
	 
	 private String text;
	 
	 private String umid;
	 private int errorCode;
	 private String errorDescription;

}
