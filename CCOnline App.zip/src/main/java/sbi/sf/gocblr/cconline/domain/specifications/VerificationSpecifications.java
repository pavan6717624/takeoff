package sbi.sf.gocblr.cconline.domain.specifications;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;

public class VerificationSpecifications {

    private VerificationSpecifications() {
        // static class
    }

    public static Specification<Verification> assigned(long verificationId, long officerPfId) {
        return (root, query, builder) ->
            builder.and(builder.equal(root.get("id"), verificationId), builder.equal(root.get("officer").get("pfId"), officerPfId));
    }

    public static Specification<Verification> submitted(long verificationId) {
        return (root, query, builder) ->
            builder.and(
                builder.equal(root.get("id"), verificationId),
                root.get("status").isNotNull(),
                builder.notEqual(root.get("status"), VerificationStatus.IN_PROGRESS)
            );
    }

    public static Specification<Verification> notSubmitted(long verificationId) {
        return (root, query, builder) ->
            builder.and(
                builder.equal(root.get("id"), verificationId),
                builder.or(root.get("status").isNull(), builder.equal(root.get("status"), VerificationStatus.IN_PROGRESS))
            );
    }
    
    public static Specification<Verification> types(List<String> types)  {
    	return (root, query, builder) -> builder.in(root.get("type").get("key").in(types));
    }
    
    public static Specification<Verification> type(String types)  {
    	return (root, query, builder) -> builder.equal(root.get("type").get("key"), types);
    }
    
    public static Specification<Verification> verificationCompleted() {
    	return (root, query, builder) -> 
    		builder.and(
                root.get("status").isNotNull(),
                builder.notEqual(root.get("status"), VerificationStatus.IN_PROGRESS)
            );
    }
    
    public static Specification<Verification> complianceVerification(long pfId) {
    	return (root, query, builder) -> 
    		builder.or(
    				builder.and(
						builder.equal(root.get("officer").get("pfId"), pfId),
						builder.isNull(root.get("complianceVerificationOfficer"))
					),
					builder.equal(root.get("complianceVerificationOfficer").get("pfId"), pfId)
			);
    }
    
    public static Specification<Verification> doComplianceVerification() {
    	return (root, query, builder) ->
    		builder.equal(root.get("status"), VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER);
    }
    
    public static Specification<Verification> fetchCurrenc() {
    	return (root, query, builder) ->
    		builder.equal(root.get("status"), VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER);
    }
}
