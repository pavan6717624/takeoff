package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sbi.sf.gocblr.cconline.domain.AutoAlertsDetails;
import sbi.sf.gocblr.cconline.domain.AutoAlertsRecipients;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.model.AutoAlertsDTO;

public interface AutoAlertsRepository extends JpaRepository<AutoAlertsDetails, Long> {


	
	@Query("select "
			+ "r.receivers as role, r.receivers.id as roleId, a.pfid as pfid, a.branch.branchCode as brcode, "
			+ "a.name as name, a.mobile as mobile, a.email as email,a.designation as designation from "
			+ "AutoAlertsDetails  a  "
			+ "right join AutoAlertsRecipients r on a.forRole = r and a.branch.branchCode=(:branchCode) where r.forRole like (:forRole)")
	List<AutoAlertsDTO> findByBranchCode(@Param("branchCode") Long branchCode, @Param("forRole") String forRole);
	
	
	@Query("select "
			+ "r.receivers as role, r.receivers.id as roleId, a.pfid as pfid, a.branch.branchCode as brcode, "
			+ "a.name as name, a.mobile as mobile, a.email as email,a.designation as designation from "
			+ "AutoAlertsDetails  a  "
			+ "right join AutoAlertsRecipients r on a.forRole = r and a.branch.branchCode in (:branches)")
	List<AutoAlertsDTO> findByBranchList(@Param("branches") List<Long> branches);
	
	
	@Query("select a from AutoAlertsDetails a where "
			+ " (a.branch.branchCode=:#{#branch.branchCode} and a.forRole.receivers like :#{#forRole.receivers} and a.forRole.receivers like 'Branch Manager') or "
			+ " (a.branch.branchCode=:#{#branch.branchCode} and a.forRole.receivers like :#{#forRole.receivers} and a.forRole.receivers like 'Cash Officer') or "
			+ " (a.branch.branchCode=:#{#branch.branchCode} and a.forRole.receivers like :#{#forRole.receivers} and a.forRole.receivers like 'Accountant') or " 
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'Regional Manager') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'CM (C&O)') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'DGM (B&O)') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and a.branch.region.regionCode=:#{#branch.region.regionCode} and (:#{#branch.branchTypeCode})=22 and a.branch.branchTypeCode=22 and a.forRole.receivers like 'CM/AGM (GB)') or "
			
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and (:#{#branch.branchTypeCode})=17 and a.branch.branchTypeCode=17 and a.forRole.receivers like 'DGM (B&O)') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and a.branch.network.networkCode=:#{#branch.network.networkCode} and a.branch.module.moduleCode=:#{#branch.module.moduleCode} and (:#{#branch.branchTypeCode})=17 and a.branch.branchTypeCode=17 and a.forRole.receivers like 'CM/AGM (GB)') or "
			
			+ " (abs(a.branch.branchCode)=abs(:#{#branch.branchCode}) and a.branch.branchCode in (select distinct abs(branchCode) from Fslo) and a.forRole.receivers like :#{#forRole.receivers} and a.forRole.receivers like 'AGM FSLO') or "
			+ " (a.branch.circle.circleCode=:#{#branch.circle.circleCode} and a.forRole.receivers like :#{#forRole.receivers} and (:#{#branch.branchTypeCode})=18 and a.branch.branchTypeCode=18 and a.forRole.receivers like 'DGM & CFO') or "
			+ " (a.branch.branchCode=:#{#branch.branchCode} and  a.branch.branchCode=3999 and a.forRole.receivers like :#{#forRole.receivers} and a.forRole.receivers like 'DGM ABD')"
			)	
	
	Optional<AutoAlertsDetails> findByForRoleAndBranch(@Param("forRole") AutoAlertsRecipients forRole, @Param("branch") Branch branch);

}
