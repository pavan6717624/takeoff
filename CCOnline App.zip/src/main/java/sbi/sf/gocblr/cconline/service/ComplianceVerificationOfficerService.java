package sbi.sf.gocblr.cconline.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.ComplianceVerificationOfficer;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.NothingSpecificException;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.model.EmployeeDetailsModel;
import sbi.sf.gocblr.cconline.repository.ComplianceVerificationOfficerRepository;
import sbi.sf.gocblr.cconline.utils.TextUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.ComplianceVerificationOfficerInputModel;

@Service
@RequiredArgsConstructor
public class ComplianceVerificationOfficerService {

    private static final Pattern SCALE_PATTERN = Pattern.compile("^[osOS][3456789] *$");

    private final VerificationService verificationService;
    private final BranchMasterService branchMasterService;
    private final EmployeeDetailsService empDetailService;
    private final ComplianceVerificationOfficerRepository repo;

    @Transactional
    public ComplianceVerificationOfficer assign(String type, ComplianceVerificationOfficerInputModel input) {
        var emp = empDetailService.getEmployeeDetails(input.getOfficerPfId());

        checkEmployeeScale(type, emp);

        var branch = branchMasterService.getBranch(emp.getBranchCode());

        Verification verification = verificationService.submitted(input.getVerificationId());

        checkStatus(verification);

        ComplianceVerificationOfficer officer = new ComplianceVerificationOfficer();
        officer.setVerification(verification);
        officer.setPfId(emp.getPfId());
        officer.setTitle(emp.getTitle());
        officer.setName(emp.getName());
        officer.setDesignation(emp.getDesignation());
        officer.setMobileNo(emp.getMobileNo());
        officer.setEmailId(emp.getEmailId().toLowerCase());
        officer.setBranch(branch);

        return repo.save(officer);
    }

    private void checkStatus(Verification verification) {
        if (verification.getStatus() != VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER) {
            throw new InvalidOperationException(
                "Compliance verification officer can only be assigned after " +
                VerificationStatus.CMP_SUBMITTED_BY_SCRUTINIZER.description()
            );
        }
    }

    private void checkEmployeeScale(String type, EmployeeDetailsModel emp) {
        if (type.equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY)) {
            if (TextUtils.hasText(emp.getEmployeeSubGroup())) {
                Matcher m = SCALE_PATTERN.matcher(emp.getEmployeeSubGroup());
                if (!m.matches()) {
                    throw new ValidationException(
                        "Bi-Monthly compliance verification can only be assigned to Scale III and above officers."
                    );
                }
            } else {
                throw new NothingSpecificException("Employee Sub Group is not available. Kindly get it updated in HRMS");
            }
        }
    }

    @Transactional
    public ComplianceVerificationOfficer modify(String type, ComplianceVerificationOfficerInputModel input) {
        ComplianceVerificationOfficer officer = repo
            .findById(input.getVerificationId())
            .orElseThrow(() -> new ResourceNotFoundException("No compliance verification officer found for given verification."));

        if (officer.getPfId() == (long) input.getOfficerPfId()) {
            return officer;
        }

        var emp = empDetailService.getEmployeeDetails(input.getOfficerPfId());

        checkStatus(officer.getVerification());
        checkEmployeeScale(type, emp);

        var branch = branchMasterService.getBranch(emp.getBranchCode());

        officer.setPfId(emp.getPfId());
        officer.setTitle(emp.getTitle());
        officer.setName(emp.getName());
        officer.setDesignation(emp.getDesignation());
        officer.setMobileNo(emp.getMobileNo());
        officer.setEmailId(emp.getEmailId().toLowerCase());
        officer.setBranch(branch);

        return repo.save(officer);
    }

    @Transactional(readOnly = true)
    public boolean anyComplianceVerificationsAssigned(long pfId) {
        return !repo
            .findByPfIdAndVerificationTypeKeyIn(
                pfId,
                new String[] { VerificationTypeConstants.BI_MONTHLY, VerificationTypeConstants.HALF_YEARLY }
            )
            .isEmpty();
    }
}
