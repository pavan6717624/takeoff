package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.domain.criteria.VerificationCriteria;
import sbi.sf.gocblr.cconline.domain.criteria.VerificationScrutinyCriteria;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;
import sbi.sf.gocblr.cconline.domain.specifications.VerificationSpecifications;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.model.VerificationLetterModel;
import sbi.sf.gocblr.cconline.model.VerificationModel;
import sbi.sf.gocblr.cconline.model.VerificationsListFilters;
import sbi.sf.gocblr.cconline.repository.VerificationRepository;
import sbi.sf.gocblr.cconline.service.dto.ForComplianceVerificationListDto;
import sbi.sf.gocblr.cconline.service.dto.VerificationForListModel;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.ComplianceVerificationFilters;
import sbi.sf.gocblr.cconline.web.vm.ClosureListFilter;
import sbi.sf.gocblr.cconline.web.vm.VerificationClosureDto;

@Service
@Transactional
public class VerificationService {

    @Autowired
    private VerificationRepository repo;

    @Autowired
    private VerificationTypeService typeService;

    @Autowired
    private SpringTemplateEngine springTemplateEngine;

    @Lazy
    @Autowired
    private VerificationOfficerService voService;

    public Page<VerificationModel> verificationsList(VerificationCriteria criteria, Pageable pageable) {
        return repo.verifications(criteria, pageable);
    }

    public VerificationsListFilters filters(VerificationCriteria criteria) {
        return repo.filters(criteria);
    }

    public List<Verification> assignedVerifications(String verificationType, Long officerPfId) {
        VerificationType vt = typeService.getByKeyOrThrow(verificationType);
        return repo.findByTypeAndOfficerPfId(vt, officerPfId);
    }

    @Transactional(readOnly = true)
    public String verificationLetter(long verificationId) {
        Verification verification = repo
            .getById(verificationId)
            .orElseThrow(() -> new ResourceNotFoundException(String.format("Invalid verification id %d", verificationId)));

        VerificationLetterModel model = new VerificationLetterModel();
        model.setOfficerTitle(verification.getOfficer().getTitle());
        model.setOfficerName(verification.getOfficer().getName());
        model.setOfficerPfIndex(verification.getOfficer().getPfId());
        model.setOfficerDesignation(verification.getOfficer().getDesignation());
        model.setOfficerBranchCode(verification.getOfficer().getBranchCode());
        model.setOfficerBranchName(verification.getOfficer().getBranchName());

        model.setLetterDate(LocalDate.now().format(DateUtils.STANDARD_DATE_TIME_FROMAT));
        model.setVerificationType(verification.getType().getName());
        model.setVerificationBranchCode(verification.getCurrencyChest().getBranchCode());
        model.setVerificationBranchName(verification.getCurrencyChest().getBranchName());
        model.setVerificationToBeCompletedBefore(verification.getToBeCompletedBefore().format(DateUtils.STANDARD_DATE_TIME_FROMAT));

        model.setCircleName(verification.getCurrencyChest().getRegion().getModule().getNetwork().getCircle().getCircleName());

        // set percentage count
        model.setHalfYearly(verification.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.HALF_YEARLY));

        Context context = new Context();
        context.setVariable("model", model);

        return springTemplateEngine.process("verification", context);
    }

    public Verification getVerificationById(Long id) {
        return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("No verifiation found for %d", id)));
    }

    /**
     * Only checking for bimonthly and half yearly
     * @param verificationId
     * @param officerPfId
     * @return
     */
    @Transactional
    public Verification assigned(long verificationId, long officerPfId) {
        Verification v = getVerificationById(verificationId);

        if (isBiMonthlyOrHalfYearly(v.getType().getKey())) {
            if (v.getOfficer().getPfId() != officerPfId) {
                throw new InvalidOperationException(String.format("No assigned verification found for id: %d", verificationId));
            }
        }
        return v;
    }

    public Verification notSubmitted(long verificationId) {
        return repo
            .findOne(VerificationSpecifications.notSubmitted(verificationId))
            .orElseThrow(() -> new ResourceNotFoundException(String.format("No pending verification found for id: %d", verificationId)));
    }

    public Verification submitted(long id) {
        return repo
            .findOne(VerificationSpecifications.submitted(id))
            .orElseThrow(() -> new ResourceNotFoundException(String.format("No submitted verification found for id: %d", id)));
    }

    @Transactional
    public void markInProgress(Verification v) {
        var ve = repo.findById(v.getId());

        if (ve.isPresent() && ve.get().getStatus() == null) {
            ve.get().setStatus(VerificationStatus.IN_PROGRESS);
            repo.save(ve.get());
        }
    }

    @Transactional(readOnly = true)
    public Optional<Verification> findByCcAndTypeAndBlock(long branchCode, VerificationType vt, LocalDate blockStart, LocalDate blockEnd) {
        return repo.findByCurrencyChestBranchCodeAndTypeAndBlockFromAndBlockTo(branchCode, vt, blockStart, blockEnd);
    }

    public List<VerificationForListModel> scrutiny(VerificationScrutinyCriteria criteria) {
        return repo.verificationsForScrutiny(criteria);
    }

    @Transactional(readOnly = true)
    public List<Verification> closure(long circleCode, long networkCode, long moduleCode, String... types) {
        int[] verificationTypes = new int[types.length];
        for (int i = 0; i < types.length; i++) {
            verificationTypes[i] = typeService.getByKeyOrThrow(types[i]).getId();
        }
        return repo.closure(circleCode, networkCode, moduleCode, verificationTypes);
    }

    @Transactional(readOnly = true)
    public List<VerificationClosureDto> closureFiltersNew(ClosureListFilter filter) {
        return repo.listForClosure(filter);
    }

    @Transactional(readOnly = true)
    public List<Verification> closure(long circleCode, String... types) {
        int[] verificationTypes = new int[types.length];
        for (int i = 0; i < types.length; i++) {
            verificationTypes[i] = typeService.getByKeyOrThrow(types[i]).getId();
        }
        return repo.closure(circleCode, verificationTypes);
    }

    @Transactional(readOnly = true)
    public List<ForComplianceVerificationListDto> complianceVerification(ComplianceVerificationFilters filter) {
        return repo.listForComplianceVerification(filter);
    }

    public boolean isBiMonthlyOrHalfYearly(String key) {
        return (key.equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY) || key.equalsIgnoreCase(VerificationTypeConstants.HALF_YEARLY));
    }

    @Transactional(readOnly = true)
    public VerificationType getVerificationType(long verificationId) {
        return getVerificationById(verificationId).getType();
    }
}
