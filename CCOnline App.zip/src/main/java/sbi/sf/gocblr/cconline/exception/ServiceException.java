package sbi.sf.gocblr.cconline.exception;

import java.util.HashMap;
import lombok.Getter;

public abstract class ServiceException extends RuntimeException {

    private static final long serialVersionUID = 3750271086981947011L;

    @Getter
    private final HashMap<String, String[]> data;

    protected ServiceException(String msg) {
        super(msg);
        this.data = new HashMap<>();
    }

    ServiceException(String msg, Throwable t) {
        super(msg, t);
        this.data = new HashMap<>();
    }

    ServiceException(String msg, HashMap<String, String[]> data) {
        super(msg);
        this.data = data;
    }
}
