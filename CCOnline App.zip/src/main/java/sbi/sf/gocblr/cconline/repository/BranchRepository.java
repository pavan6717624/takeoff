package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.Module;
import sbi.sf.gocblr.cconline.domain.Network;
import sbi.sf.gocblr.cconline.domain.Region;

public interface BranchRepository extends JpaRepository<Branch, Long> {
    @EntityGraph(attributePaths = { "circle", "network", "module", "region" })
    Optional<Branch> findById(long branchCode);

    List<Branch> findByRegionModuleNetworkCircle(Circle circle);

    // ~ For MIS hierarchy filters
    //============================

    @Query(
        "SELECT DISTINCT cc.circle " +
        "  FROM CurrencyChest cc " +
        " WHERE :circleCode IS NULL OR cc.circle.circleCode = :circleCode " +
        " ORDER BY cc.circle.circleName"
    )
    List<Circle> circles(Long circleCode);

    @Query("SELECT DISTINCT cc.network " + "  FROM CurrencyChest cc " + " WHERE cc.circle.circleCode = :circle " + " ORDER BY cc.network")
    List<Network> networks(@Param("circle") long circleCode);

    @Query(
        "select distinct b.network.networkCode from Branch b where b.circle.circleCode in (select b1.circle.circleCode from Branch b1 where b1.branchCode=:branchCode) order by b.network.networkCode"
    )
    List<Long> networksByBranch(@Param("branchCode") Long branchCode);

    @Query(
        "SELECT DISTINCT cc.module " +
        "  FROM CurrencyChest cc " +
        " WHERE cc.circle.circleCode = :circle " +
        "   AND cc.network.networkCode = :network " +
        " ORDER BY cc.module"
    )
    List<Module> modules(@Param("circle") Long circleCode, @Param("network") Long networkCode);

    @Query(
        "SELECT DISTINCT cc.region " +
        "  FROM CurrencyChest cc " +
        " WHERE cc.circle.circleCode = :circle " +
        "  AND  cc.module.moduleCode = :module " +
        " ORDER BY cc.region"
    )
    List<Region> regions(@Param("circle") long circleCode, @Param("module") long moduleCode);
}
