package sbi.sf.gocblr.cconline.model;

import lombok.Value;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Verification;

@Value
public class CcAndVerification {

    Verification verification;
    CurrencyChest currencyChest;
}
