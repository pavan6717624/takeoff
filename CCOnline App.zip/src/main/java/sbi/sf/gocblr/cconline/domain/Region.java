package sbi.sf.gocblr.cconline.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Region entity
 * @author Kiran Marturu
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "regions")
@IdClass(RegionId.class)
public class Region implements Serializable {

    private static final long serialVersionUID = 6529153324309500179L;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns(
        value = {
            @JoinColumn(name = "circle_code", referencedColumnName = "circle_code"),
            @JoinColumn(name = "network_code", referencedColumnName = "network_code"),
            @JoinColumn(name = "module_code", referencedColumnName = "module_code"),
        },
        foreignKey = @ForeignKey(name = "fk_regions_module")
    )
    private Module module;

    @Id
    @Column(name = "region_code")
    private Long regionCode;

    @JsonIgnore
    @OneToMany(mappedBy = "region", fetch = FetchType.LAZY)
    @Builder.Default
    private Set<Branch> branches = new HashSet<>();

    // RM & CM (C&R) details
    @Column(name = "cm_cr_id")
    private Integer cmCrPfId;

    @Column(name = "cm_cr_name")
    private String cmCrName;

    @Column(name = "cm_cr_mobile_no")
    private Long cmCrMobileNo;

    @Column(name = "rm_id")
    private Integer rmPfId;

    @Column(name = "rm_name")
    private String rmName;

    @Column(name = "rm_mobile_no")
    private Long rmMobileNo;
}
