package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.repository.VerificationRepository;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.VerificationSubmitVM;

@Service
@RequiredArgsConstructor
public class VerificationSubmitService {

    private final ActivityLogService activityLog;

    private final VerificationService service;
    private final VerificationOfficerService voService;
    private final VerificationSectionService sectionService;
    private final VerificationRepository repo;

    /**
     * Submit verification
     * @param userPfId
     * @param model
     * @return
     */
    @Transactional
    public Verification submitVerification(long userPfId, VerificationSubmitVM model) {
        Verification v = service.notSubmitted(model.getVerificationId());

        if (v.getBlockFrom().isAfter(LocalDate.now())) {
            throw new ValidationException("Cannot submit for future verification, check the verification period.");
        }

        if (model.getVerificationDate().isBefore(v.getBlockFrom()) || model.getVerificationDate().isAfter(v.getBlockTo())) {
            throw new ValidationException(
                String.format(
                    "Date of verification should be between %s and %s",
                    DateUtils.format(v.getBlockFrom()),
                    DateUtils.format(v.getBlockTo())
                )
            );
        }

        if (model.getVerificationDate().isAfter(LocalDate.now())) {
            throw new ValidationException("Verification date cannot be a future date.");
        }

        if (service.isBiMonthlyOrHalfYearly(v.getType().getKey()) && v.getOfficer().getPfId() != userPfId) {
            throw new InvalidOperationException(String.format("%d verification is not assigned to you", v.getId()));
        }

        // check chest balances date should be within 6 previous days
        if (service.isBiMonthlyOrHalfYearly(v.getType().getKey())) {
            LocalDate ccBalancesDate = v.getBalanceVerification().getBalancesAsOn();
            LocalDate verificationDate = model.getVerificationDate();

            if (ccBalancesDate.isAfter(verificationDate) || ccBalancesDate.isEqual(verificationDate)) {
                throw new ValidationException("CC balance cannot be after verification date.");
            }

            if (ChronoUnit.DAYS.between(ccBalancesDate, verificationDate) > 6) {
                throw new ValidationException("CC balance date cannot be prior to 6 days from verification date.");
            }
        }

        // check all sections are saved
        List<VerificationSection> pendingSections = sectionService.pendingSections(model.getVerificationId());

        if (!pendingSections.isEmpty()) {
            throw new ValidationException(
                "Please save everything in below sections before submitting.",
                pendingSections.stream().map(VerificationSection::getName).collect(Collectors.toList())
            );
        }

        if (v.getOfficer().getPfId() != userPfId) {
            activityLog.logActivity(
                "ASSINGED_VO_DIFF_FROM_SUBMITTING",
                Map.of(
                    "verificationId",
                    String.valueOf(model.getVerificationId()),
                    "old",
                    String.valueOf(v.getOfficer().getPfId()),
                    "new",
                    String.valueOf(userPfId)
                )
            );
            voService.updateVerificationOfficerDetails(v.getId(), userPfId);
        }

        v.setVerificationOfficerComments(model.getVerificationOfficerComments());
        v.setStatus(VerificationStatus.REPORT_SUBMITTED);

        v.setDateOfVerification(model.getVerificationDate());

        v.setReportSubmittedBy(userPfId);
        v.setReportSubmittedOn(LocalDate.now());

        return repo.save(v);
    }
}
