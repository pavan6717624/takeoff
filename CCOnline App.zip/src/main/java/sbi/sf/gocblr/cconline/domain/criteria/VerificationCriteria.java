package sbi.sf.gocblr.cconline.domain.criteria;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.model.ui.VerificationStatusFilter;

@Data
public class VerificationCriteria implements Serializable {

    private static final long serialVersionUID = -7561965392159279093L;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date blockFrom;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date blockTo;

    // UI filters
    private Long circle;
    private Long network;
    private Long module;
    private Long region;
    private Long branchCode;

    private VerificationStatusFilter status;
    private Long voPfId;

    // User level restrictions
    @JsonIgnore
    private VerificationType type;

    @JsonIgnore
    private Long userCircleCode;

    @JsonIgnore
    private Long userNetworkCode;
    
    @JsonIgnore
    private Long userModuleCode;

    @JsonIgnore
    private Long userRegionCode;
}
