package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author Kiran Marturu
 *
 */
@Data
public class NetworkId implements Serializable {

    private static final long serialVersionUID = -5532974258002368194L;

    private Circle circle;
    private Long networkCode;
}
