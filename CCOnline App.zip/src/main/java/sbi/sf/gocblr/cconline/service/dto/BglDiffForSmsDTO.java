package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.time.LocalDate;

@JsonInclude(Include.NON_NULL)
public interface BglDiffForSmsDTO extends IBranchAndContactsDTO, IFsloDTO {
    LocalDate getChestSlipDate();
    Long getCymValue();
    Long getBglValue();
    Long getDifference();
    Boolean getSmsSent();
}
