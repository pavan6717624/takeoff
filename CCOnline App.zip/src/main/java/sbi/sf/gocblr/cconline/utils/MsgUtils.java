package sbi.sf.gocblr.cconline.utils;

import java.util.Locale;
import org.springframework.context.MessageSource;

public final class MsgUtils {

    private MsgUtils() {
        // utils class
    }

    public static String getMessage(MessageSource msgSource, String key) {
        return msgSource.getMessage(key, null, Locale.ENGLISH);
    }
}
