package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Address details of Currency Chest
 *
 * @author Kiran Marturu
 *
 */
@Embeddable
@Getter
@Setter
@ToString
public class CcEmployeeDetails implements Serializable {

    private static final long serialVersionUID = -5420858475651732104L;

    private Integer accountantId;
    private String accountantName;
    private LocalDate accountantDateOfTakingOver;
    private Long accountantMobileNo;
    private Integer coId;
    private String coName;
    private LocalDate coDateOfTakingOver;
    private Long coMobileNo;
    private Integer bmId;
    private String bmName;
    private LocalDate bmDateOfTakingOver;
    private Long bmMobileNo;
}
