package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class PenaltyReport {

    String headers[];
    String data[][];
}
