package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ValueStatement;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.model.verificationmis.VsMinimal;
import sbi.sf.gocblr.cconline.service.dto.ValueStatementComplianceDTO;
import sbi.sf.gocblr.cconline.service.dto.ValueStatementVerificationDTO;

@Repository
public interface ValueStatementRepository extends JpaRepository<ValueStatement, Long> {
    @Query(
        "SELECT vs as valueStatement, vsv.optionInput as optionInput, " +
        "       vsv.compliance as compliance, " +
        "       vsv.dateInput as dateInput, " +
        "       vsv.numberInput as numberInput, " +
        "       vsv.comments as comments, " +
        "       vsc.branchComments as branchComments, " +
        "       vsc.branchCompliance as branchCompliance " +
        "  FROM ValueStatement vs " +
        "       LEFT JOIN ValueStatementVerification vsv " +
        "              ON vsv.valueStatement = vs " +
        "             AND vsv.verification = :verification " +
        " LEFT JOIN ValueStatementCompliance vsc on vsc.vsVerification = vsv " +
        " WHERE vs.section = :verificationSection " +
        " ORDER BY COALESCE(vs.displayOrder, 1), vs.id"
    )
    List<ValueStatementVerificationDTO> valueStatementWithVerification(
        @Param("verification") Verification verification,
        @Param("verificationSection") VerificationSection verificationSection
    );

    Optional<ValueStatement> findByIdAndSectionId(long vsId, long sectionId);

    @Query(
        "SELECT SUM(CASE WHEN vsv.compliance IS NULL THEN 1 ELSE 0 END) " +
        "  FROM ValueStatement vs " +
        "       LEFT JOIN ValueStatementVerification vsv " +
        "              ON vsv.valueStatement = vs " +
        "             AND vsv.verification = :verification " +
        " WHERE vs.section = :verificationSection " +
        "   AND NVL(vs.isOnlyAsHeader, false) <> true " +
        " ORDER BY vs.displayOrder"
    )
    Integer pendingCount(
        @Param("verification") Verification verification,
        @Param("verificationSection") VerificationSection verificationSection
    );

    @Query(
        "SELECT vs as valueStatement," +
        "       vsv.optionInput as optionInput, " +
        "       vsv.compliance as compliance, " +
        "       vsv.dateInput as dateInput, " +
        "       vsv.numberInput as numberInput, " +
        "       vsv.comments as comments," +
        "       vsc.branchCompliance as branchCompliance," +
        "       vsc.branchComments as branchComments " +
        "  FROM ValueStatement vs " +
        "       LEFT JOIN ValueStatementVerification vsv " +
        "              ON vsv.valueStatement = vs " +
        "             AND vsv.verification = :verification " +
        "       LEFT JOIN ValueStatementCompliance vsc " +
        "              ON vsc.vsVerification = vsv " +
        " WHERE vs.section = :verificationSection " +
        " ORDER BY COALESCE(vs.displayOrder, 0), vs.id"
    )
    List<ValueStatementComplianceDTO> valueStatementWithCompliance(
        @Param("verification") Verification verification,
        @Param("verificationSection") VerificationSection verificationSection
    );

    @Query(
        "SELECT vs " +
        "  FROM ValueStatement vs " +
        "       JOIN FETCH vs.section " +
        " WHERE vs.section.verificationType.id = :type " +
        " ORDER BY vs.section.displayOrder, vs.displayOrder"
    )
    List<ValueStatement> valueStatements(@Param("type") int typeId);

    @Query(
        "SELECT vs.id as id, " +
        "       CONCAT( " +
        "                vs.section.displayNo, ': ',  " +
        "                NVL(ppvs.displayNumber, ''),   " +
        "                CASE WHEN ppvs.displayNumber IS NULL THEN '' ELSE '.'  END,   " +
        "                NVL(pvs.displayNumber, ''),   " +
        "                CASE WHEN pvs.displayNumber IS NULL THEN '' ELSE '.'  END,  " +
        "                vs.displayNumber " +
        "             ) as displayNo " +
        "  FROM ValueStatement vs " +
        "       LEFT JOIN ValueStatement pvs " +
        "              ON pvs = vs.parentValueStatement " +
        "       LEFT JOIN ValueStatement ppvs " +
        "              ON ppvs = pvs.parentValueStatement " +
        " WHERE vs.section.verificationType.id = :type " +
        "   AND NVL(vs.isOnlyAsHeader, 0) = 0 " +
        " ORDER BY vs.section.displayOrder, vs.displayOrder"
    )
    List<VsMinimal> valueStatementsWithoutHeaders(@Param("type") int typeId);
}
