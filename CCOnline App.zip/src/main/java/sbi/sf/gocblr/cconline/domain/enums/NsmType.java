package sbi.sf.gocblr.cconline.domain.enums;

/**
 * NSM Types
 * @author Kiran Marturu
 *
 */
public enum NsmType {
    ONE_PLUS_ONE(1, "1+1"),
    TWO_PLUS_ONE(2, "2+1"),
    THREE_PLUS_ONE(3, "3+1"),
    FOUR_PLUS_ONE(4, "4+1");

    private final int code;
    private final String description;

    NsmType(int code, String desc) {
        this.code = code;
        this.description = desc;
    }

    public int code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static NsmType fromCode(int code) {
        for (NsmType n : NsmType.values()) {
            if (n.code == code) {
                return n;
            }
        }
        throw new IllegalArgumentException("Invalid NsmType code: " + code);
    }
}
