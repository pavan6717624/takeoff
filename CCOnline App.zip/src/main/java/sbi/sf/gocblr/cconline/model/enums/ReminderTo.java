package sbi.sf.gocblr.cconline.model.enums;

public enum ReminderTo {
    FSLO,
    CFO,
}
