package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
public class AutoAlertsRecipients implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 4512847379234113714L;
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 Long id;
	 
	String forRole;
	 
	 String receivers;
	

}
