package sbi.sf.gocblr.cconline.constants;

public class SectionRouteConstants {

    private SectionRouteConstants() {
        // static constants class; not to be initialized
    }

    public static final String BRANCH_PROFILE = "branch-profile";
    public static final String BALANCE_VERIFICATION = "balance-verification";
    public static final String NOTES_VERIFICATION = "notes-verification";
    public static final String NOTES_ADJUDICATED = "notes-adjudicated";
}
