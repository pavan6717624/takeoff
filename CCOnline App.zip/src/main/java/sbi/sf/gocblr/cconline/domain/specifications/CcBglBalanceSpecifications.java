package sbi.sf.gocblr.cconline.domain.specifications;

import java.time.LocalDate;
import org.springframework.data.jpa.domain.Specification;
import sbi.sf.gocblr.cconline.domain.CcBglBalance;

public class CcBglBalanceSpecifications {

    public static Specification<CcBglBalance> branchCode(long branchCode) {
        return (root, query, builder) -> builder.equal(root.get("currencyChest").get("branchCode"), branchCode);
    }

    public static Specification<CcBglBalance> bgl98958() {
        return (root, query, builder) -> builder.like(root.get("checkClosingFields").get("fieldName"), "BGL98958Closing");
    }

    public static Specification<CcBglBalance> asOn(LocalDate asOn) {
        return (root, query, builder) -> builder.equal(root.get("date"), asOn);
    }
}
