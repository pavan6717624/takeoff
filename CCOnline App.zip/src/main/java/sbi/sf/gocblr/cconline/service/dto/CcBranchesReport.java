package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public interface CcBranchesReport {
    Integer getCircleCode();
    String getCircleName();
    Integer getNetworkCode();
    String getModuleName();
    Integer getRegionCode();
    Integer getBranchCode();
    String getBranchName();
    Integer getFsloCode();
    Integer getCcCode();
    String getState();
    String getDistrict();
    String getCenterName();
    String getCenterType();
    String getCcType();
    String getPopulationGroup();
    Long getStorageCapacity();
    Long getCashBalanceLimit();
}
