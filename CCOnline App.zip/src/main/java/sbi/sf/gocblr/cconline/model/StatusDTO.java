package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class StatusDTO {
	
	String message;
	Boolean status;

}
