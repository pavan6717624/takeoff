package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public interface VerificationSectionDTO {
    Long getId();
    Integer getDisplayOrder();
    String getDisplayNo();
    String getName();
    Boolean getIsHeader();
    Boolean getIsValueStatementSection();
    String getRoute();
    Boolean getIsSaved();
    Integer getPending();
    Integer getTotal();
}
