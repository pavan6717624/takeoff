package sbi.sf.gocblr.cconline.service.dto;

import lombok.Value;

@Value
public class MonthlyCertificateSubmissionSummaryImpl implements MonthlyCertificateSubmissionSummary {

    private Long notSubmitted;
    private Long submitted;
}
