package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;

@ToString
@Getter
@Setter
@Entity
@Table(name = "reject_and_submit_states")
public class RejectAndSubmitState {

    @Id
    private Long id;

    @ManyToOne
    @JoinColumn(name = "verification_type_id", foreignKey = @ForeignKey(name = "fk_reject_submit_states_verification_type"))
    @EqualsAndHashCode.Include
    private VerificationType verificationType;

    @ManyToOne
    @JoinColumn(name = "for_role", referencedColumnName = "name", foreignKey = @ForeignKey(name = "fk_reject_submit_states_for_role"))
    @EqualsAndHashCode.Include
    private Role forRole;

    @Column(name = "reject_state", length = 50)
    @EqualsAndHashCode.Include
    private VerificationStatus rejectState;

    @Column(name = "reject_state_label", length = 100)
    private String rejectStateActionLabel;

    @Column(name = "submit_state", length = 50)
    @EqualsAndHashCode.Include
    private VerificationStatus submitState;

    @Column(name = "submit_state_label", length = 100)
    private String submitStateActionLabel;
}
