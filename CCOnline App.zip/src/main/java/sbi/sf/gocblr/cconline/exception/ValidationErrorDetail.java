package sbi.sf.gocblr.cconline.exception;

import java.io.Serializable;
import lombok.Data;

@Data
public class ValidationErrorDetail implements Serializable {

    private static final long serialVersionUID = 1115236575501568063L;

    private final String name;
    private final String reason;
}
