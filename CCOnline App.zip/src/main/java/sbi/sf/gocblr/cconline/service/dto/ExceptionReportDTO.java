package sbi.sf.gocblr.cconline.service.dto;

import java.time.LocalDate;

public interface ExceptionReportDTO {
    Integer getCircleCode();
    String getCircleName();
    Integer getBranchCode();
    String getBranchName();
    LocalDate getReportDate();
    String getMessage();
}
