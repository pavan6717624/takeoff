package sbi.sf.gocblr.cconline.service;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.exception.NoDataException;
import sbi.sf.gocblr.cconline.repository.VerificationTypeRepository;

@Service
@RequiredArgsConstructor
public class VerificationTypeService {

    private final VerificationTypeRepository repo;

    public List<VerificationType> all() {
        return repo.findAll();
    }

    public boolean isValidVerificationType(String key) {
        Optional<VerificationType> vt = repo.findByKey(key);
        return vt.isPresent();
    }

    public Optional<VerificationType> findByKey(String key) {
        return repo.findByKey(key);
    }

    public VerificationType getByKeyOrThrow(String key) {
        return repo.findByKey(key.toLowerCase()).orElseThrow(() -> new NoDataException(key, VerificationType.class.getName()));
    }
}
