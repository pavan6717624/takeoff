package sbi.sf.gocblr.cconline.model.verificationmis;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.Circle;

@Data
@AllArgsConstructor
public class VsConsolidatedCircleWiseWrapper {

    private List<Circle> circles;
    private List<VsConsolidatedCircleWise> data;
}
