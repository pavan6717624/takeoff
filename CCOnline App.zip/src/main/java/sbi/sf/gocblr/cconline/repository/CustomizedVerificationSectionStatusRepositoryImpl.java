package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.model.VerificationSectionStatusDto;

@Service
public class CustomizedVerificationSectionStatusRepositoryImpl implements CustomizedVerificationSectionStatusRepository {

    @PersistenceContext
    private EntityManager em;

    @Override
    public List<VerificationSectionStatusDto> somethingSomething() {
        //		CriteriaBuilder builder = em.getCriteriaBuilder();
        //		CriteriaQuery<VerificationSectionStatusDto> criteria = builder.createQuery(VerificationSectionStatusDto.class);
        //
        //		Root<VerificationSection> section = criteria.from(VerificationSection.class);
        //		Join<VerificationSection, VerificationSectionStatus> sectionStatus = section.join("section");
        //		sectionStatus.on
        //
        //		Join<VerificationSection, VerificationSectionStatus> join = section.join(section);
        //		criteria.multiselect(builder.construct(VerificationSectionStatusDto.class, section, join.get("saved")));
        //
        //		return em.createQuery(criteria).getResultList();

        return null;
    }
}
