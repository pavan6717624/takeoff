package sbi.sf.gocblr.cconline.exception;

public class ParsingException extends RuntimeException {

    private static final long serialVersionUID = 7221137164235944947L;

    public ParsingException(String msg) {
        super(msg);
    }
}
