package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;

@Repository
public interface ParticularsRepository extends JpaRepository<ChestSlipParticular, Long> {
    @Query("SELECT keyword FROM ChestSlipParticular p where p.type=(:type)")
    List<String> allKeywordsByType(@Param("type") String type);

    @Query("SELECT particular FROM ChestSlipParticular p where p.type=(:type)")
    List<String> allParticularByType(@Param("type") String type);

    @Query("SELECT p FROM ChestSlipParticular p where p.type=(:type)")
    List<ChestSlipParticular> allParticularsByType(@Param("type") String type);

    @Query("SELECT addindex FROM ChestSlipParticular p where p.type=(:type)")
    List<Integer> allIndicesByType(@Param("type") String type);

    @Query("SELECT p FROM ChestSlipParticular p where keyword=(:keyword) and p.type=(:type)")
    ChestSlipParticular particularByKeyword(@Param("keyword") String keyword, @Param("type") String type);

    @Query("SELECT p FROM ChestSlipParticular p where p.keyword LIKE :keyword% and p.type=(:type)")
    ChestSlipParticular particularByPhrase(@Param("keyword") String keyword, @Param("type") String type);

    @Query("SELECT keyword FROM ChestSlipParticular p where addindex = 1")
    List<String> getNewLineParticulars();

    @Query("select pid from ChestSlipParticular p where p.keyword like :keyword%")
    List<Long> getPids(@Param("keyword") String keyword);

    @Query("select pid from ChestSlipParticular p where p.particular like :particular")
    List<Long> getPidsByParticular(@Param("particular") String particular);

    Optional<ChestSlipParticular> findByParticularAndType(@Param("particular") String particular, @Param("type") String type);
}
