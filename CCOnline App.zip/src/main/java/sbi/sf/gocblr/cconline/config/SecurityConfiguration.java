package sbi.sf.gocblr.cconline.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
import org.zalando.problem.spring.web.advice.security.SecurityProblemSupport;
import sbi.sf.gocblr.cconline.security.jwt.JwtConfigurer;
import sbi.sf.gocblr.cconline.security.jwt.TokenProvider;

@Import(SecurityProblemSupport.class)
@EnableWebSecurity
@RequiredArgsConstructor
@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true, jsr250Enabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    private final TokenProvider tokenProvider;
    private final SecurityProblemSupport securityProblemSupport;

    @Bean
    public PasswordEncoder passwordEncoder() {
        // Only for complying with Spring Security
        return new BCryptPasswordEncoder();
    }

    @Override
    public void configure(WebSecurity web) {
        web.ignoring().antMatchers("/h2-console/**").antMatchers("/test/**");
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        // @formatter:off
    	http
    		.cors()
    		.and()
    			.csrf()
    				.disable()
    		.exceptionHandling()
    			.authenticationEntryPoint(securityProblemSupport)
    			.accessDeniedHandler(securityProblemSupport)
			.and()
				.headers()
				.contentSecurityPolicy("default-src 'self'; frame-src 'self' data:; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://storage.googleapis.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:")
			.and()
				.referrerPolicy(ReferrerPolicyHeaderWriter.ReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN)
			.and()
				.featurePolicy("geolocation 'none'; midi 'none'; sync-xhr 'none'; microphone 'none'; camera 'none'; magnetometer 'none'; gyroscope 'none'; speaker 'none'; fullscreen 'self'; payment 'none'")
			.and()
				.frameOptions()
				.deny()
			.and()
				.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
			.and()
				.authorizeRequests()
				.antMatchers("/api/getVerificationAlerts").permitAll()
				.antMatchers("/api/sendAutoAlerts").permitAll()
				.antMatchers("/api/sendAutoAlertsHbb").permitAll()
				.antMatchers("/api/login").permitAll()
				.antMatchers("/api/logout").permitAll()
				.antMatchers("/api/logout/result").permitAll()
				.antMatchers("/api/account").permitAll()
				.antMatchers("/api/authenticate").permitAll()
				.antMatchers("/actuator").permitAll()
				.antMatchers("/api/employee/**").permitAll()
				.antMatchers("/api/verification/**/report").permitAll()
				.antMatchers("/api/sms/**").permitAll()
				.antMatchers("/api/mail/**").permitAll()
				.antMatchers("/api/**").authenticated()
				.antMatchers("/error/**").permitAll()
				.anyRequest().denyAll()
				
			.and()
				.httpBasic()
			.and()
				.apply(jwtConfigurerAdapter());
    	
        // @formatter:on
    }

    private JwtConfigurer jwtConfigurerAdapter() {
        return new JwtConfigurer(tokenProvider);
    }
}
