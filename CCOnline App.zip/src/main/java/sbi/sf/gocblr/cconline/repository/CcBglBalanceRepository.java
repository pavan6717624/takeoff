package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import sbi.sf.gocblr.cconline.domain.CcBglBalance;
import sbi.sf.gocblr.cconline.domain.ChestClosingFields;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;

@Repository
public interface CcBglBalanceRepository extends JpaRepository<CcBglBalance, Long>, JpaSpecificationExecutor<CcBglBalance> {
    @Query(
        "SELECT max(balanceId) FROM CcBglBalance c WHERE c.currencyChest=(:currencyChest) and c.checkClosingFields=(:checkClosingFields)"
    )
    Long getLatestBalanceId(
        @Param("currencyChest") CurrencyChest currencyChest,
        @Param("checkClosingFields") ChestClosingFields checkClosingFields
    );

    @Query(
        "SELECT c FROM CcBglBalance c WHERE c.currencyChest=(:currencyChest) and checkClosingFields=(:checkClosingFields) and date = (:date)"
    )
    List<CcBglBalance> getBalance(
        @Param("currencyChest") CurrencyChest currencyChest,
        @Param("checkClosingFields") ChestClosingFields checkClosingFields,
        @Param("date") LocalDate date
    );

    Optional<CcBglBalance> findTopByCurrencyChestBranchCodeOrderByDateDesc(Long branchCode);
}
