package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.PenaltyReason;
import sbi.sf.gocblr.cconline.domain.PenaltySubReason;

@Repository
public interface PenaltySubReasonRepository extends JpaRepository<PenaltySubReason, Long> {
    List<PenaltySubReason> findByReason(PenaltyReason penalty_reason);
}
