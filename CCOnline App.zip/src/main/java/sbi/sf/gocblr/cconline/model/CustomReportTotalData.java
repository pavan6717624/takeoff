package sbi.sf.gocblr.cconline.model;

public interface CustomReportTotalData {
    Double getTotalPieces();
    Double getTotalValue();
}
