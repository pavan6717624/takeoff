package sbi.sf.gocblr.cconline.service.dto;

import lombok.Data;

@Data
public class SmsResponse {

    private String errorCode;
    private String errorDescription;
    private String umid;
}
