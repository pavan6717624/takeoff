package sbi.sf.gocblr.cconline.security;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.User;

/**
 * Utils for common actions w.r.t Spring Security
 *
 * @author Kiran Marturu
 *
 */
@Slf4j
public final class SecurityUtils {

    private SecurityUtils() {}

    public static Optional<String> getCurrentUserId() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        return Optional.ofNullable(extractPrincipal(securityContext.getAuthentication()));
    }

    private static String extractPrincipal(Authentication authentication) {
        log.debug(">> extractPrincipal");

        if (authentication == null) {
            log.debug("authentication is null; returning null");
            return null;
        } else if (authentication.getPrincipal() instanceof UserDetails) {
            UserDetails springSecurityUser = (UserDetails) authentication.getPrincipal();
            return springSecurityUser.getUsername();
        } else if (authentication.getPrincipal() instanceof String) {
            log.debug("authentication is string; returning authentication.getPrincipal()");
            return (String) authentication.getPrincipal();
        }
        log.debug("authentication is not null/instance of UserDetails/String; returning null");
        return null;
    }

    /**
     * Get logged in user from the Security Context
     *
     * @return AppUser instance
     */
    public static AppUser getLoggedInUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof AppUser) {
            return (AppUser) principal;
        }
        log.debug("no AppUser instance found; returning null");
        return null;
    }

    /**
     * If the current user has a specific authority (security role).
     * <p>
     * The name of this method comes from the {@code isUserInRole()} method in the Servlet API.
     *
     * @param role the authority to check.
     * @return true if the current user has the authority, false otherwise.
     */
    public static boolean isCurrentUserInRole(String role) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && getAuthorities(authentication).anyMatch(role::equals);
    }

    public static boolean isCurrentUserInRole(String... roles) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null) {
            return false;
        }

        for (String role : roles) {
            for (var authority : authentication.getAuthorities()) {
                if (role.equalsIgnoreCase(authority.getAuthority())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check user has given roles (based on domain User instance)
     * @param user
     * @param roles
     * @return
     */
    public static boolean isUserOfType(User user, String... roles) {
        Set<Role> userRoles = user.getRoles();
        for (String r : roles) {
            if (userRoles.stream().anyMatch(userRole -> userRole.getName().equalsIgnoreCase(r))) {
                return true;
            }
        }
        return false;
    }

    public static boolean isUserOfType(AppUser user, String... roles) {
        Set<Role> userRoles = user.getRoles();
        for (String r : roles) {
            if (userRoles.stream().anyMatch(userRole -> userRole.getName().equalsIgnoreCase(r))) {
                return true;
            }
        }
        return false;
    }

    private static Stream<String> getAuthorities(Authentication authentication) {
        return authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority);
    }
}
