package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.CcClass;

/**
 * Attribute converter for @see sbi.sf.gocblr.cconline.domain.enums.CcClass
 * @author Kiran Marturu
 *
 */
@Converter(autoApply = true)
public class CcClassConverter implements AttributeConverter<CcClass, String> {

    @Override
    public String convertToDatabaseColumn(CcClass ccClass) {
        return ccClass.toString();
    }

    @Override
    public CcClass convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return CcClass.fromCode(code);
    }
}
