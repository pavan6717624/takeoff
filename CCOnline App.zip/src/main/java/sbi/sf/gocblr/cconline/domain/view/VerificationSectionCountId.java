package sbi.sf.gocblr.cconline.domain.view;

import java.io.Serializable;
import lombok.Data;

@Data
public class VerificationSectionCountId implements Serializable {

    private static final long serialVersionUID = 3167551844684589693L;

    private Long verificationId;
    private Long sectionId;
}
