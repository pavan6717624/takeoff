package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.CcBglBalance;
import sbi.sf.gocblr.cconline.domain.CcCloseRequests;
import sbi.sf.gocblr.cconline.service.dto.CyMClosingBalance;

public interface CcClosureRepository extends JpaRepository<CcCloseRequests, Long> {
    // Get chest slip closing balance for a branch
    @Query(
        "SELECT csud.currencyChest.branchCode as branchCode, " +
        "       csud.chestSlipDate as ccClosingBalanceDate, " +
        "       cb.cymValue as ccClosingBalance " +
        "  FROM ChestSlipUploadDetails csud " +
        "       JOIN CcClosingBalance cb " +
        "         ON cb.csUploadId = csud.id " +
        " WHERE id IN (SELECT max(id) FROM ChestSlipUploadDetails ud where ud.currencyChest.branchCode = (:branchCode) and ud.status='New')"
    )
    Optional<CyMClosingBalance> getCyMClosingBalance(@Param("branchCode") long branchCode);

    // Get BGL 98908 closing balance for a branch
    @Query(
        "SELECT c " +
        "  FROM CcBglBalance c " +
        "       JOIN ChestClosingFields cf " +
        "         ON c.checkClosingFields = cf " +
        "        AND cf.fieldName LIKE 'BGL98908Closing' " +
        " WHERE c.currencyChest.branchCode = :branchCode " +
        "   AND c.date IN (SELECT MAX(date) FROM CcBglBalance c2 WHERE c.currencyChest.branchCode = :branchCode)"
    )
    Optional<CcBglBalance> getBGL98908ClosingBalance(@Param("branchCode") long branchcode);

    // Get BGL 98958 closing balance for a branch
    @Query(
        "SELECT c " +
        "  FROM CcBglBalance c " +
        "       JOIN ChestClosingFields cf " +
        "          ON c.checkClosingFields = cf " +
        "         AND cf.fieldName LIKE 'BGL98958Closing' " +
        " WHERE c.currencyChest.branchCode = :branchCode " +
        "   AND c.date IN (SELECT MAX(date) FROM CcBglBalance c2 WHERE c.currencyChest.branchCode = :branchCode)"
    )
    Optional<CcBglBalance> getBGL98958ClosingBalance(@Param("branchCode") long branchcode);

    //CcClosureDataVM setClosureRequest(@Valid CcClosureModel submitData);

    Optional<CcCloseRequests> findByCcBranchCode(Long branchCode);
    //    // Get branch details
    //    @Query(
    //        "SELECT c.circle.circleCode as circleCode, " +
    //        "       c.circle.circleName as circleName, " +
    //        "       c.network.networkCode as networkCode, " +
    //        "       c.module.moduleCode as moduleCode, " +
    //        "       c.module.moduleName as moduleName, " +
    //        "       c.region.regionCode as regionCode, " +
    //        "       c.branchCode as branchCode, " +
    //        "       c.branchName as branchName " +
    //        "  FROM CurrencyChest c " +
    //        "  WHERE c.branchCode = :branchCode " +
    //        "  ORDER BY circleCode, networkCode, moduleCode, regionCode, branchCode "
    //    )
    //    List<CcClosureDataVM> getBranchHierarchyDetails(@Param("branchCode") long branchCode);
}
