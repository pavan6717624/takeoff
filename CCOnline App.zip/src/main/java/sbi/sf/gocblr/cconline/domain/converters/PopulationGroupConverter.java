package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.PopulationGroup;

@Converter(autoApply = true)
public class PopulationGroupConverter implements AttributeConverter<PopulationGroup, String> {

    @Override
    public String convertToDatabaseColumn(PopulationGroup populationGroup) {
        return populationGroup.code();
    }

    @Override
    public PopulationGroup convertToEntityAttribute(String code) {
        return PopulationGroup.fromCode(code);
    }
}
