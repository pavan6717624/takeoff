package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * POJO for representing contents of chest slip
 * @author Pavan Kumar
 *
 */
@Data
@NoArgsConstructor
public class ChestSlip {

    private LocalDate date;
    private Long ccCode;
    private String ccName;

    private PDFTable notesTable;
    private PDFTable coinsTable;

    private String status;
    private String message;
    private String uploadDate;
    private String fileName;

    private LocalDate uploadedDate;

    private Long brCode;

    private String printDetails;
}
