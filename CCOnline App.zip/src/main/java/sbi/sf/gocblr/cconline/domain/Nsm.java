package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.enums.NsmType;

/**
 * NSM's master
 * NOTE: May require to be changed based on the functionality to be implemented
 *
 * @author Kiran Marturu
 *
 */
@Data
@Entity
@Table(name = "nsms")
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Nsm implements Serializable {

    private static final long serialVersionUID = -4307029167028718304L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "type")
    private NsmType nsmType;

    @Column(length = 100)
    private String make;

    @Column(length = 100)
    private String model;
}
