package sbi.sf.gocblr.cconline.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * CORS config for allowing requests from angular
 *
 * @author Kiran Marturu
 *
 */
@Configuration
public class CorsConfig {

    private final ApplicationProperties applicationProperties;

    public CorsConfig(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry
                    .addMapping("/**")
                    .allowedMethods("GET", "HEAD", "POST", "PUT", "DELETE")
                    .allowedOrigins(
                        "https://fs.testsso.com",
                        "https://sso.sbi.co.in",
                        "https://uatcconline.bank.sbi",
                        applicationProperties.getFrontEndUrl()
                    );
            }
        };
    }
}
