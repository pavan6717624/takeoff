package sbi.sf.gocblr.cconline.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.RoleRepository;
import sbi.sf.gocblr.cconline.security.SecurityUtils;

@Service
@RequiredArgsConstructor
public class RoleService {

    private final RoleRepository repo;

    public Optional<Role> findByName(String name) {
        return repo.findByName(name);
    }

    public Role getByName(String name) {
        return repo.findByName(name).orElseThrow(() -> new ResourceNotFoundException("No role found for name " + name));
    }

    public List<Role> canAddRoles() {
        Set<Role> rolesCanAdd = new HashSet<>();
        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER, RoleConstants.DGM_ABD)) {
            ApplicationProperties.ROLES_ALLOWED_FOR_ABD.forEach(rs -> rolesCanAdd.add(getByName(rs)));
        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            ApplicationProperties.ROLES_ALLOWED_FOR_CIRCLE_ADMIN.forEach(rs -> rolesCanAdd.add(getByName(rs)));
        }
        return new ArrayList<>(rolesCanAdd);
    }
}
