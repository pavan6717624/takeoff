package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.VerificationType;

public interface VerificationTypeRepository extends JpaRepository<VerificationType, Integer> {
    Optional<VerificationType> findByKey(String key);
}
