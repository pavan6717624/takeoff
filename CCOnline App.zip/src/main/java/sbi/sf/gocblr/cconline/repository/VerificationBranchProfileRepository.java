package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationBranchProfile;

public interface VerificationBranchProfileRepository extends JpaRepository<VerificationBranchProfile, Long> {
    Optional<VerificationBranchProfile> findByVerificationId(Long verificationId);
    Optional<VerificationBranchProfile> findByVerification(Verification verification);
}
