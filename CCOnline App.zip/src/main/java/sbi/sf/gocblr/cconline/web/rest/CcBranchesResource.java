package sbi.sf.gocblr.cconline.web.rest;

import java.util.Date;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sbi.sf.gocblr.cconline.repository.CcBranchesRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.CcBranchesService;
import sbi.sf.gocblr.cconline.service.RoleConstants;
import sbi.sf.gocblr.cconline.service.dto.CcBranchesReport;
import sbi.sf.gocblr.cconline.service.dto.CcBranchesSummaryReport;
import sbi.sf.gocblr.cconline.service.dto.CcClosedBranchesReport;
import sbi.sf.gocblr.cconline.utils.DateUtils;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class CcBranchesResource {

    private final CcBranchesService service;
    private final CcBranchesRepository ccBranchesRepository;
    private static final String USER_NOT_HAVING_APPROPRIATE_ROLE = "User not having appropriate role for accessing this resource";
    private static final long DUMMY_FSLO_CODE = 0L;

    @GetMapping("/ccbranches/listreport")
    public List<CcBranchesReport> getCcBranchesReport(@NotNull @DateTimeFormat(pattern = "yyyy-MM-dd") Date asOn) {
        AppUser user = SecurityUtils.getLoggedInUser();

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER)) {
            return ccBranchesRepository.getCcBranchesReport(DateUtils.getLocalDate(asOn), null, null, null, null, null);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            return ccBranchesRepository.getCcBranchesReport(DateUtils.getLocalDate(asOn), user.getBranchCode(), null, null, null, null);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return ccBranchesRepository.getCcBranchesReport(DateUtils.getLocalDate(asOn), null, user.getCircleCode(), null, null, null);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER) || SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB)) {
            return ccBranchesRepository.getCcBranchesReport(
                DateUtils.getLocalDate(asOn),
                null,
                user.getCircleCode(),
                user.getNetworkCode(),
                user.getModuleCode(),
                null
            );
        } else if (
            SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM) ||
            SecurityUtils.isCurrentUserInRole(RoleConstants.RM) ||
            SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_DESK_OFFICER)
        ) {
            return ccBranchesRepository.getCcBranchesReport(
                DateUtils.getLocalDate(asOn),
                null,
                user.getCircleCode(),
                user.getNetworkCode(),
                user.getModuleCode(),
                user.getRegionCode()
            );
        } else {
            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        }
        //return service.getCcBranchesReport(DateUtils.getLocalDate(asOn));
    }

    @GetMapping("/ccbranches/summaryreport")
    public List<CcBranchesSummaryReport> getCcBranchesSummaryReport(@NotNull @DateTimeFormat(pattern = "yyyy-MM-dd") Date asOn) {
        //    	AppUser user = SecurityUtils.getLoggedInUser();
        //
        //    	if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER)) {
        //            return ccBranchesRepository.getCcBranchesSummaryReport(DateUtils.getLocalDate(asOn));
        //        } else if (
        //            SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
        //            return ccBranchesRepository.getCcBranchesSummaryReportFSLO(DateUtils.getLocalDate(asOn), user.getBranchCode());
        //        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
        //            return ccBranchesRepository.getCcBranchesSummaryReportCircleAdmin(DateUtils.getLocalDate(asOn), user.getCircleCode());
        //        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER) || SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB)) {
        //            return ccBranchesRepository.getCcBranchesSummaryReportAoUser(
        //            	DateUtils.getLocalDate(asOn),
        //                user.getCircleCode(),
        //                user.getNetworkCode(),
        //                user.getModuleCode()
        //            );
        //        } else if (
        //            SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM) ||
        //            SecurityUtils.isCurrentUserInRole(RoleConstants.RM) ||
        //            SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_DESK_OFFICER)
        //        ) {
        //            return ccBranchesRepository.getCcBranchesSummaryReportRBO(
        //            	DateUtils.getLocalDate(asOn),
        //                user.getCircleCode(),
        //                user.getNetworkCode(),
        //                user.getModuleCode(),
        //                user.getRegionCode()
        //            );
        //        } else {
        //            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        //        }
        //
        return service.getCcBranchesSummaryReport(DateUtils.getLocalDate(asOn));
        //return service.getDetails(DateUtils.getLocalDate(month), SecurityUtils.getLoggedInUser().getBranchCode());
    }

    @GetMapping("/ccbranches/closedlistreport")
    public List<CcClosedBranchesReport> getCcBranchesClosedReport(
        @NotNull @DateTimeFormat(pattern = "yyyy-MM-dd") Date fromDate,
        @NotNull @DateTimeFormat(pattern = "yyyy-MM-dd") Date toDate
    ) {
        log.trace("fromDate: {} ", fromDate);
        log.trace("toDate: {} ", toDate);
        return service.getCcBranchesClosedReport(DateUtils.getLocalDate(fromDate), DateUtils.getLocalDate(toDate));
        //return service.getDetails(DateUtils.getLocalDate(month), SecurityUtils.getLoggedInUser().getBranchCode());
    }
}
