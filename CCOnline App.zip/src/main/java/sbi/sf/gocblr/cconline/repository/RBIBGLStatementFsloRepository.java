package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.Fslo;
import sbi.sf.gocblr.cconline.domain.RBIBGLStatementFslo;
import sbi.sf.gocblr.cconline.domain.RBIBGLStatementUploadDetails;

@Repository
public interface RBIBGLStatementFsloRepository extends JpaRepository<RBIBGLStatementFslo, Long> {
    Optional<RBIBGLStatementFslo> findByFsloProfileAndBglStatementUploadDetails(
        @Param("fsloProfile") Fslo fsloProfile,
        @Param("bglStatementUploadDetails") RBIBGLStatementUploadDetails bglStatementUploadDetails
    );
}
