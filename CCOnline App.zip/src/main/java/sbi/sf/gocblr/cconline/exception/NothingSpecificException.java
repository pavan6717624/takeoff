package sbi.sf.gocblr.cconline.exception;

/**
 * Generic exception to be used in case of no specific exception cannot be created
 * @author Kiran Marturu
 *
 */
// TODO: For temporary usage till specific problem is created
public class NothingSpecificException extends ServiceException {

    private static final long serialVersionUID = 1535881522896651229L;

    public NothingSpecificException(String msg) {
        super(msg);
    }

    public NothingSpecificException(String msg, Throwable t) {
        super(msg, t);
    }
}
