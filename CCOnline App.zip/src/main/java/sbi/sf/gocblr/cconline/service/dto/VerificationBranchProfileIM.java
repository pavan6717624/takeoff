package sbi.sf.gocblr.cconline.service.dto;

import java.time.LocalDate;
import javax.validation.constraints.PastOrPresent;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import sbi.sf.gocblr.cconline.domain.enums.CcType;

@Data
public class VerificationBranchProfileIM {

    //@NotNull
    private Integer incumbency;

    //@NotNull
    @PastOrPresent
    @DateTimeFormat
    private LocalDate incumbencySince;

    //@NotNull
    private CcType ccType;

    private StaffPosition totalStaff;

    private StaffPosition cashDeptStaff;

    private Double ccBalanceReportedInCyM;

    private Double balanceOfSoiledNotesAvailableInCc;

    @PastOrPresent
    @DateTimeFormat
    private LocalDate lastBiMonthlyVerification;

    @PastOrPresent
    @DateTimeFormat
    private LocalDate lastQuarterlyVerification;

    @PastOrPresent
    @DateTimeFormat
    private LocalDate lastHalfYearlyVerification;

    //@NotNull
    @DateTimeFormat
    private LocalDate strongRoomFitnessCertExpiryDate;

    @DateTimeFormat
    @PastOrPresent
    private LocalDate lastSecurityOfficerVist;
}
