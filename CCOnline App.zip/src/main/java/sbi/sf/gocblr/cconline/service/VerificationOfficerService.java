package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationBlock;
import sbi.sf.gocblr.cconline.domain.VerificationOfficer;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.exception.InvalidCurrencyChestException;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.InvalidVerificationBlockException;
import sbi.sf.gocblr.cconline.exception.NothingSpecificException;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.model.EmployeeDetailsModel;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.VerificationBlockRepository;
import sbi.sf.gocblr.cconline.repository.VerificationOfficerRepository;
import sbi.sf.gocblr.cconline.repository.VerificationRepository;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.utils.TextUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.AssignVerificationOfficerVM;
import sbi.sf.gocblr.cconline.web.rest.vm.StartVerificationVM;

@Slf4j
@Service
public class VerificationOfficerService {

    private static final Pattern SCALE_PATTERN = Pattern.compile("^[osOS][23456789] *$");

    @Autowired
    private VerificationOfficerRepository repo;

    @Autowired
    private EmployeeDetailsService empService;

    @Autowired
    private VerificationRepository vRepo;

    @Autowired
    private VerificationBlockRepository vbRepo;

    @Autowired
    private CurrencyChestRepository ccRepo;

    @Autowired
    private VerificationTypeService verificationTypeService;

    @Autowired
    private VerificationService verificationService;

    @Autowired
    private CurrencyChestService ccService;

    @Autowired
    private ActivityLogService activityLog;

    @Autowired
    private VerificationBlockRepository blockRepo;

    @Transactional
    public Verification assign(String verificationType, AssignVerificationOfficerVM details) {
        log.trace(">> assign()");

        VerificationType vt = verificationTypeService.getByKeyOrThrow(verificationType);

        String[] blocks = details.getBlock().split("_");
        LocalDate blockStart = LocalDate.parse(blocks[0], DateUtils.BLOCK_DATE_INPUT);
        LocalDate blockEnd = LocalDate.parse(blocks[1], DateUtils.BLOCK_DATE_INPUT);

        if (blockEnd.isBefore(LocalDate.now())) {
            throw new ValidationException("Period end cannot be before today");
        }

        Optional<VerificationBlock> blk = vbRepo.findByTypeAndBlockFromAndBlockTo(vt, blockStart, blockEnd);

        if (blk.isEmpty()) {
            throw new InvalidVerificationBlockException("Invalid verification block");
        }

        log.trace("   fetching employee details");
        EmployeeDetailsModel empDetails = empService.getEmployeeDetails(details.getAssignedOfficerId());
        log.trace("   fetched employee details");

        if (vt.getKey().equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY)) {
            if (TextUtils.hasText(empDetails.getEmployeeSubGroup())) {
                Matcher m = SCALE_PATTERN.matcher(empDetails.getEmployeeSubGroup());
                if (!m.matches()) {
                    throw new ValidationException("Bi-monthly can be assigned to Scale II and above officers only.");
                }
            } else {
                throw new NothingSpecificException("Employee Sub Group is not available. Kindly get it updated in HRMS");
            }
        }

        CurrencyChest cc = ccRepo
            .findByBranchCode(details.getBranchCode())
            .orElseThrow(() -> new InvalidCurrencyChestException(String.format("Invalid currency chest %d", details.getBranchCode())));

        if (Boolean.TRUE.equals(cc.getIsClosed())) {
            throw new InvalidCurrencyChestException(String.format("Currency chest with branch code %d is closed", cc.getBranchCode()));
        }

        Optional<Verification> existing = vRepo.findExisting(vt, blockStart, blockEnd, cc);
        log.trace("existing: {}", existing.isPresent());
        if (existing.isPresent()) {
            log.trace("Existing officer: {}", existing.get().getOfficer() != null);
        }

        if (existing.isPresent() && existing.get().getStatus() != null) {
            throw new InvalidOperationException("Cannot assign/modify as status is " + existing.get().getStatus().description());
        }

        Verification returnVerification;
        if (existing.isPresent()) {
            log.debug("modifying existing verification");

            existing.get().setToBeCompletedBefore(details.getToBeCompletedBefore());

            VerificationOfficer vo;
            if (existing.get().getOfficer() == null) {
                vo = new VerificationOfficer();
            } else {
                vo = existing.get().getOfficer();
            }
            vo.setVerification(existing.get());

            setFields(details, empDetails, vo);

            existing.get().setOfficer(vo);

            returnVerification = repo.save(vo).getVerification();
        } else {
            log.debug("new verification");

            Verification v = new Verification();
            v.setCurrencyChest(cc);
            v.setType(vt);
            v.setBlockFrom(blockStart);
            v.setBlockTo(blockEnd);
            v.setToBeCompletedBefore(details.getToBeCompletedBefore());

            VerificationOfficer vo = new VerificationOfficer();
            vo.setVerification(v);

            setFields(details, empDetails, vo);

            v.setOfficer(vo);

            returnVerification = repo.save(vo).getVerification();
        }

        return returnVerification;
    }

    private void setFields(AssignVerificationOfficerVM details, EmployeeDetailsModel empDetails, VerificationOfficer vo) {
        vo.setTitle(empDetails.getTitle());
        vo.setPfId(empDetails.getPfId());
        vo.setName(empDetails.getName());
        vo.setDesignation(empDetails.getDesignation());

        vo.setMobileNo(empDetails.getMobileNo());
        vo.setEmailId(empDetails.getEmailId());

        vo.setBranchCode(empDetails.getBranchCode());
        vo.setBranchName(empDetails.getBranchName());
    }

    @Transactional
    public void withdrawVerificationOfficer(long verificationId) {
        VerificationOfficer verificationOfficer = repo
            .findById(verificationId)
            .orElseThrow(() -> new ResourceNotFoundException("No verification found for id " + verificationId));

        if (verificationOfficer.getVerification().getStatus() != null) {
            throw new InvalidOperationException(
                "Cannot withdraw as verification status is " + verificationOfficer.getVerification().getStatus().description()
            );
        }

        verificationOfficer.getVerification().setToBeCompletedBefore(null);
        verificationOfficer.getVerification().setOfficer(null);

        repo.delete(verificationOfficer);
    }

    @Transactional
    public Verification selfAssign(long userId, String verificationType, StartVerificationVM vm) {
        VerificationType vt = verificationTypeService.getByKeyOrThrow(verificationType);

        String[] blocks = vm.getBlock().split("_");
        LocalDate blockStart = LocalDate.parse(blocks[0], DateUtils.BLOCK_DATE_INPUT);
        LocalDate blockEnd = LocalDate.parse(blocks[1], DateUtils.BLOCK_DATE_INPUT);

        var block = blockRepo.findByTypeAndBlockFromAndBlockTo(vt, blockStart, blockEnd);
        if (block.isEmpty()) {
            throw new ValidationException(
                String.format("Invalid/Unknown period: %s - %s", DateUtils.format(blockStart), DateUtils.format(blockEnd))
            );
        }

        if (LocalDate.now().isAfter(blockEnd)) {
            // allow for last block for quarterly, security officer and dgm-cfo
            if (
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.QUARTERLY) ||
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.SECURITY_OFFICER) ||
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_CFO) ||
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.RM_DGM_CONTROLLER_VISIT) ||
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_BO_MODULE_HEAD_VISIT) ||
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_CFO_VISIT) ||
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.GM_NETWORK_VISIT) ||
                vt.getKey().equalsIgnoreCase(VerificationTypeConstants.CGM_VISIT)
            ) {
                if (blockRepo.isAllowedToStart(blockEnd, vt) > 1) {
                    throw new InvalidOperationException("Only current and previous block data is allowed for input");
                }
            } else {
                throw new InvalidOperationException("Cannot start verification for past block");
            }
        }

        var cc = ccService.getByBranchCode(vm.getBranchCode());

        var verification = verificationService.findByCcAndTypeAndBlock(vm.getBranchCode(), vt, blockStart, blockEnd);

        if (verification.isPresent()) {
            throw new InvalidOperationException("Cannot self-assign already assigned verification");
        } else {
            Verification v = new Verification();
            v.setCurrencyChest(cc);
            v.setType(vt);
            v.setBlockFrom(blockStart);
            v.setBlockTo(blockEnd);

            EmployeeDetailsModel empDetails = empService.getEmployeeDetails(Math.toIntExact(userId));

            VerificationOfficer vo = new VerificationOfficer();
            vo.setVerification(v);
            vo.setPfId(empDetails.getPfId());
            vo.setName(empDetails.getName());
            vo.setDesignation(empDetails.getDesignation());
            vo.setMobileNo(empDetails.getMobileNo());
            vo.setEmailId(empDetails.getEmailId());
            vo.setBranchCode(empDetails.getBranchCode());
            vo.setBranchName(empDetails.getBranchName());

            v.setOfficer(vo);

            return repo.save(vo).getVerification();
        }
    }

    public boolean anyVerificationsAssigned(long pfId) {
        return !repo
            .findByPfIdAndVerificationTypeKeyIn(
                pfId,
                new String[] { VerificationTypeConstants.BI_MONTHLY, VerificationTypeConstants.HALF_YEARLY }
            )
            .isEmpty();
    }

    @Transactional
    public void updateVerificationOfficerDetails(long verificationId, long userPfId) {
        Optional<VerificationOfficer> voOpt = repo.findById(verificationId);

        if (voOpt.isPresent() && voOpt.get().getPfId() != userPfId) {
            Map<String, String> logData = new HashMap<>();
            logData.put("verificationId", String.valueOf(verificationId));
            logData.put("oldUserId", String.valueOf(voOpt.get().getPfId()));
            logData.put("newUserId", String.valueOf(userPfId));

            EmployeeDetailsModel empDetails = empService.getEmployeeDetails(Math.toIntExact(userPfId));

            VerificationOfficer vo = voOpt.get();
            vo.setPfId(empDetails.getPfId());
            vo.setName(empDetails.getName());
            vo.setDesignation(empDetails.getDesignation());
            vo.setMobileNo(empDetails.getMobileNo());
            vo.setEmailId(empDetails.getEmailId());
            vo.setBranchCode(empDetails.getBranchCode());
            vo.setBranchName(empDetails.getBranchName());

            repo.save(vo);

            activityLog.logActivity("UPDATE_VERIFICATION_OFFICER_DETAILS", logData);
        }
    }
}
