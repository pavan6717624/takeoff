package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public interface MonthlyCertificateDetailedReport {
    Integer getCircleCode();
    String getCircleName();
    Integer getNetworkCode();
    Integer getModuleCode();
    String getModuleName();
    Integer getRegionCode();
    Integer getBranchCode();
    String getBranchName();
    String getSubmitted();
}
