package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
@Entity
@Table(name = "chest_slip_particular_totals")
public class TotalsTable implements Serializable {

    private static final long serialVersionUID = -3813846293509706795L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "total_pieces", columnDefinition = "NUMBER(15)")
    private Double totalPieces;

    @Column(name = "total_value", columnDefinition = "NUMBER(20,2)")
    private Double totalValue;

    @ManyToOne
    @JoinColumn(name = "cs_particular_id", foreignKey = @ForeignKey(name = "fk_cs_particular_totals_particular"))
    private ChestSlipParticular particular;

    @ManyToOne
    @JoinColumn(name = "cs_upload_id", foreignKey = @ForeignKey(name = "fk_cs_particular_totals_cs_upload_details"))
    private ChestSlipUploadDetails checkSlipUploadDetails;
}
