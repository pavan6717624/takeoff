package sbi.sf.gocblr.cconline.tasks;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.VerificationBlock;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.service.VerificationBlockService;
import sbi.sf.gocblr.cconline.service.VerificationTypeService;
import sbi.sf.gocblr.cconline.utils.Block;
import sbi.sf.gocblr.cconline.utils.BlockUtils;
import sbi.sf.gocblr.cconline.utils.JsonUtils;

@Slf4j
@Component
@RequiredArgsConstructor
public class UpdateVerificationBlocks {

    private final VerificationBlockService blockService;
    private final VerificationTypeService typeService;

    @Scheduled(cron = "0 0 23 25,26 * *")
    @Transactional
    public void updateVerificationPeriods() {
        log.trace(">> updateVerificationPeriods()");
        List<VerificationType> verificationTypes = typeService.all();
        for (VerificationType verificationType : verificationTypes) {
            updateNewVerificationBlocks(verificationType);
        }
    }

    public void updateNewVerificationBlocks(VerificationType verificationType) {
        log.debug("Updating verification blocks");
        Optional<VerificationBlock> lastBlock = blockService.findLastOneFor(verificationType);

        LocalDate startFrom = startDate(lastBlock);
        LocalDate thruTill = thruTill();

        log.trace("start: {} | thru: {}", startFrom, thruTill);

        if (!startFrom.isAfter(thruTill)) {
            List<Block> generatedBlocks = BlockUtils.getBlocks(startFrom, thruTill, verificationType.getKey());
            log.trace("generatedBlocks: {}", JsonUtils.toString(generatedBlocks));

            List<VerificationBlock> allBlocks = blockService.blocksFor(verificationType);

            List<VerificationBlock> blocksToBeAdded = new ArrayList<>();

            for (Block block : generatedBlocks) {
                VerificationBlock newBlock = VerificationBlock
                    .builder()
                    .type(verificationType)
                    .blockFrom(block.getBlockFrom())
                    .blockTo(block.getBlockTo())
                    .build();
                if (!allBlocks.contains(newBlock)) {
                    blocksToBeAdded.add(newBlock);
                }
            }
            blockService.addBlocks(blocksToBeAdded);
            log.debug("{} blocks added", blocksToBeAdded.size());
        }
    }

    private LocalDate thruTill() {
        LocalDate thruTill;
        if (LocalDate.now().getDayOfMonth() >= 25) {
            thruTill = LocalDate.now().plusMonths(1); // consider blocks till next month
        } else {
            thruTill = LocalDate.now().plusDays(1); // consider blocks till next month
        }
        return thruTill;
    }

    private LocalDate startDate(Optional<VerificationBlock> lastBlock) {
        return lastBlock.isPresent() ? lastBlock.get().getBlockTo() : LocalDate.now();
    }
}
