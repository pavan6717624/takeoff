package sbi.sf.gocblr.cconline.service;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.exception.ParsingException;
import sbi.sf.gocblr.cconline.model.ChestSlip;
import sbi.sf.gocblr.cconline.model.PDFTable;
import sbi.sf.gocblr.cconline.repository.ChestSlipUploadDetailsRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.ParticularsRepository;
import sbi.sf.gocblr.cconline.repository.TotalsTableRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class PdfParsingService {

    private static final String CHEST_SLIP_HEADING_TEXT = "Chest Slip - Daily Transaction Summary";
    private static final DateTimeFormatter CS_DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final ParticularsRepository particularsRepository;
    private final TotalsTableRepository totalsTableRepository;
    private final ChestSlipUploadDetailsRepository checkSlipUploadDetailsRepository;
    private final CurrencyChestRepository currencyChestRepository;

    public ChestSlip parsePdf(String location, LocalDate uploadingForDate, Long branchCode) throws IOException {
        List<String> lines = splitIntoLines(location);

        List<String> fields1 = particularsRepository.allKeywordsByType("Notes");
        List<String> particularFields1 = particularsRepository.allParticularByType("Notes");

        PDFTable notesTable = new PDFTable();

        String dat = lines.get(lines.indexOf(CHEST_SLIP_HEADING_TEXT) + 1).trim();

        String printDate = lines.get(lines.indexOf("Print Date") + 2).trim();
        String printTime = lines.get(lines.indexOf("Print Date") + 3).trim();

        //  System.out.println(printDate+" "+printTime);

        ChestSlip pdfDocument = new ChestSlip();

        pdfDocument.setDate(LocalDate.parse(dat, CS_DATE_FORMATTER));

        pdfDocument.setPrintDetails(printDate + " " + printTime);

        pdfDocument.setCcCode(Long.valueOf(lines.get(lines.indexOf("CC Code") + 2).trim().split(" ")[0].trim()));
        notesTable.setDenominations(lines.get(lines.indexOf("Denomination") + 2).split(" "));
        notesTable.setSize(lines.get(lines.indexOf("Denomination") + 2).split(" ").length + 3);
        notesTable.setParticulars(fields1);

        int notesTill = lines.lastIndexOf("Opening Balance") - 4;

        String[][] data = new String[fields1.size()][notesTable.getSize()];

        for (int i = 0; i < fields1.size(); i++) {
            if (lines.indexOf(fields1.get(i) + "") != -1 && lines.indexOf(fields1.get(i) + "") < notesTill) {
                data[i][0] = particularFields1.get(i) + "";
                int tablesize = notesTable.getSize() - 1;
                for (int j = 1; j <= tablesize; j++) {
                    data[i][j] = lines.get(lines.indexOf(fields1.get(i) + "") - 1).trim().split(" ")[j - 1];
                }
            } else {
                data[i][0] = fields1.get(i) + "";
                int tablesize = notesTable.getSize() - 1;
                for (int j = 1; j <= tablesize; j++) data[i][j] = "NA";
            }
        }
        notesTable.setData(data);
        pdfDocument.setNotesTable(notesTable);

        List<String> table2 = (lines.subList(lines.lastIndexOf("Opening Balance") - 4, lines.size()));
        List<String> fields2 = particularsRepository.allKeywordsByType("Coins");
        List<String> particularFields2 = particularsRepository.allParticularByType("Coins");

        PDFTable coinsTable = new PDFTable();
        coinsTable.setDenominations(table2.get(table2.indexOf("Denomination") + 2).split(" "));
        coinsTable.setSize(table2.get(table2.indexOf("Denomination") + 2).split(" ").length + 3);
        coinsTable.setParticulars(fields2);

        data = new String[fields2.size()][coinsTable.getSize()];

        for (int i = 0; i < fields2.size(); i++) {
            if (table2.indexOf(fields2.get(i) + "") != -1) {
                data[i][0] = particularFields2.get(i) + "";
                int tablesize = coinsTable.getSize() - 1;
                for (int j = 1; j <= tablesize; j++) data[i][j] =
                    table2.get(table2.indexOf(fields2.get(i) + "") - 1).trim().split(" ")[j - 1];
            } else {
                data[i][0] = fields2.get(i) + "";
                int tablesize = coinsTable.getSize() - 1;
                for (int j = 1; j <= tablesize; j++) data[i][j] = "NA";
            }
        }

        coinsTable.setData(data);
        pdfDocument.setCoinsTable(coinsTable);

        log.debug("CC Code: {}", pdfDocument.getCcCode());
        CurrencyChest cc = currencyChestRepository.findByCcCode(pdfDocument.getCcCode()).orElseThrow();
        CurrencyChest ccByBranchCode = currencyChestRepository.findByBranchCode(branchCode).orElseThrow();

        Optional<ChestSlipUploadDetails> csUploaDetails = checkSlipUploadDetailsRepository.findByCurrencyChestAndChestSlipDate(
            cc,
            pdfDocument.getDate()
        );

        if (!uploadingForDate.equals(pdfDocument.getDate())) {
            throw new ParsingException("Dates Mismatch. Please select Appropriate Date");
        } else if (Long.compare(ccByBranchCode.getCcCode(), pdfDocument.getCcCode()) != 0) {
            throw new ParsingException(
                "Your are mapped to " + ccByBranchCode.getCcCode() + ". You could not upload files of cccode - " + pdfDocument.getCcCode()
            );
        } else if (csUploaDetails.isPresent()) {
            Long maxUploadId = checkSlipUploadDetailsRepository.getMaxUploadId(cc);

            if (csUploaDetails.get().getId().equals(maxUploadId)) {
                pdfDocument.setFileName(location.split("/")[location.split("/").length - 1]);
                pdfDocument.setStatus("Warning");
                pdfDocument.setMessage(
                    "You have already Uploaded the File for the Selected Date. If you want to overwrite the uploaded file (" +
                    csUploaDetails.get().getUploadFile().split("/")[csUploaDetails.get().getUploadFile().split("/").length - 1] +
                    ") with current file (" +
                    pdfDocument.getFileName() +
                    "), Click on Confirm and Continue"
                );
            } else {
                throw new ParsingException("You have already Uploaded the File for the Selected Date");
            }
        } else {
            pdfDocument.setStatus("Success");
            pdfDocument.setMessage("File Selected :: " + location.split("/")[location.split("/").length - 1]);
            pdfDocument.setFileName(location.split("/")[location.split("/").length - 1]);
        }

        Long id = checkSlipUploadDetailsRepository.getMaxUploadIdIgnoreDate(cc, pdfDocument.getDate());

        if (id != null) {
            ChestSlipParticular notesParticular = particularsRepository.particularByPhrase("Closing Balance", "Notes");
            ChestSlipParticular coinsParticular = particularsRepository.particularByPhrase("Closing Balance", "Coins");

            double notesClosing = 0;
            double coinsClosing = 0;
            double notesOpening = 0;
            double coinsOpening = 0;

            Optional<ChestSlipUploadDetails> optCheckSlipUploadDetails = checkSlipUploadDetailsRepository.findById(id);
            if (optCheckSlipUploadDetails.isPresent()) {
                notesClosing = totalsTableRepository.findTotalValues(notesParticular, optCheckSlipUploadDetails.get());
                coinsClosing = totalsTableRepository.findTotalValues(coinsParticular, optCheckSlipUploadDetails.get());
            }

            notesOpening = Double.parseDouble(notesTable.getData()[0][notesTable.getData()[0].length - 1].replace(",", ""));
            coinsOpening = Double.parseDouble(coinsTable.getData()[0][coinsTable.getData()[0].length - 1].replace(",", ""));

            if (notesClosing != notesOpening) {
                throw new ParsingException(
                    "Notes Closing Balance of Last Uploaded (" +
                    CS_DATE_FORMATTER.format(optCheckSlipUploadDetails.get().getChestSlipDate()) +
                    ") File is NOT EQUAL TO Notes Opening Balance of Currently Uploading (" +
                    CS_DATE_FORMATTER.format(uploadingForDate) +
                    ") File. Please regenerate the latest Chest Slip for (" +
                    CS_DATE_FORMATTER.format(optCheckSlipUploadDetails.get().getChestSlipDate()) +
                    ") from e-Kuber and Upload it Again, then try for current date (" +
                    CS_DATE_FORMATTER.format(uploadingForDate) +
                    ")"
                );
            } else if (coinsClosing != coinsOpening) {
                throw new ParsingException(
                    "Coins Closing Balance of Last Uploaded (" +
                    CS_DATE_FORMATTER.format(optCheckSlipUploadDetails.get().getChestSlipDate()) +
                    ") File is NOT EQUAL TO Coins Opening Balance of Currently Uploading (" +
                    CS_DATE_FORMATTER.format(uploadingForDate) +
                    ") File. Please regenerate the latest Chest Slip for (" +
                    CS_DATE_FORMATTER.format(optCheckSlipUploadDetails.get().getChestSlipDate()) +
                    ") from e-Kuber and Upload it Again, then try for current date (" +
                    CS_DATE_FORMATTER.format(uploadingForDate) +
                    ")"
                );
            }
        }
        // sys
        return pdfDocument;
    }

    
    public String splitIntoLinesAdmin(String location) throws IOException {
        
        String text = "";

        File myFile = new File(location);

        try (PDDocument doc = PDDocument.load(myFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            text = stripper.getText(doc);
        }
        
        System.out.println(text);
        return text;
    }
    
    /**
     * Split the Chest Slip PDF file into lines for further processing
     * @param location
     * @return
     * @throws IOException
     */
    public List<String> splitIntoLines(String location) throws IOException {
        List<String> particulars = particularsRepository.getNewLineParticulars();

        String text = "";

        File myFile = new File(location);

        try (PDDocument doc = PDDocument.load(myFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            text = stripper.getText(doc);
        }
        
        System.out.println(text);

        if (text.indexOf("Chest Slip - Daily Transaction Summary") == -1) throw new ParsingException(
            "Please Select Proper Chest Slip PDF File."
        );
        
       

        for (int i = 0; i < particulars.size(); i++) text = text.replace(particulars.get(i) + "", "\n" + particulars.get(i));

        text = text.replace("\nCoins\n", "\n").replace("\nNotes\n", "\n").replace("Coins\n", "\n").replace("Notes\n", "\n");

        //Please dont delete this code
//        text =
//            text
//                .replace("\r\nCoins\r\n", "\r\n")
//                .replace("\r\nNotes\r\n", "\r\n")
//                .replace("Coins\r\n", "\r\n")
//                .replace("Notes\r\n", "\r\n")
//                .replace("\r", "");

        text = text.replace("Chest Slip - Daily Transaction Summary", "Chest Slip - Daily Transaction Summary\n");

        if (text.indexOf("Coins ") != -1) {
            text = text.replace("Coins ", "\n");
        }

        
        
        return Arrays.asList(text.split("\n"));
    }
}
