package sbi.sf.gocblr.cconline.model;

public class AutoAlertsData {

	
	public Long getPfid() {
		return pfid;
	}
	public void setPfid(Long pfid) {
		this.pfid = pfid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Long getBrcode() {
		return brcode;
	}
	public void setBrcode(Long brcode) {
		this.brcode = brcode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	Long pfid;
	String role;
	
	Long brcode;
	String name;
	
	Long mobile;
	String email;
	
	Long roleId;
	String designation;
	
	Long checkSum;

	public Long getCheckSum() {
		return checkSum;
	}
	public void setCheckSum(Long checkSum) {
		this.checkSum = checkSum;
	}
	
	
}
