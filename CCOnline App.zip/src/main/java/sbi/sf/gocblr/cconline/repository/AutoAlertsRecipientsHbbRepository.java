package sbi.sf.gocblr.cconline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import sbi.sf.gocblr.cconline.domain.AutoAlertsRecipientsHbb;
import sbi.sf.gocblr.cconline.domain.HandBalanceBranch;

public interface AutoAlertsRecipientsHbbRepository extends JpaRepository<AutoAlertsRecipientsHbb, Long> 
{

	
	
}
