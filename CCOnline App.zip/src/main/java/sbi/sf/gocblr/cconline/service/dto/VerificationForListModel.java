package sbi.sf.gocblr.cconline.service.dto;

import java.time.LocalDate;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;
import sbi.sf.gocblr.cconline.utils.BlockUtils;

@Data
public class VerificationForListModel {

    private Long id;
    private String type;
    private String period;

    private Long branchCode;
    private String branchName;

    private String circleName;
    private Long networkCode;
    private String moduleName;
    private Long regionCode;

    private String status;
    private String statusDescription;

    private boolean reportSubmitted;

    public VerificationForListModel(
        Long id,
        String type,
        LocalDate blockFrom,
        LocalDate blockTo,
        Long branchCode,
        String branchName,
        VerificationStatus status,
        String circleName,
        Long networkCode,
        String moduleName,
        Long regionCode
    ) {
        this.id = id;
        this.type = type;
        this.period = BlockUtils.formatBlockDescription(blockFrom, blockTo);
        this.branchCode = branchCode;
        this.branchName = branchName;
        this.status = status == null ? "" : status.description();
        this.circleName = circleName;
        this.networkCode = networkCode;
        this.moduleName = moduleName;
        this.regionCode = regionCode;
    }

    public VerificationForListModel(
        Long id,
        String type,
        LocalDate blockFrom,
        LocalDate blockTo,
        Long branchCode,
        String branchName,
        VerificationStatus status
    ) {
        this.id = id;
        this.type = type;
        this.period = BlockUtils.formatBlockDescription(blockFrom, blockTo);
        this.branchCode = branchCode;
        this.branchName = branchName;
        this.status = status == null ? "" : status.description();
        this.statusDescription = status == null ? "" : status.description();
        if (status != null && status != VerificationStatus.IN_PROGRESS) {
            this.reportSubmitted = true;
        }
    }
}
