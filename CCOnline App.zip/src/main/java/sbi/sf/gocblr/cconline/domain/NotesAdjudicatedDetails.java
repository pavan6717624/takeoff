package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.NaturalId;

/**
 *
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(
    name = "notes_adjudicated_details",
    uniqueConstraints = {
        @UniqueConstraint(columnNames = { "notes_adjudicated_id", "denomination_id" }, name = "uk_notes_adjudicated_denomination"),
    }
)
public class NotesAdjudicatedDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "notes_adjudicated_id", foreignKey = @ForeignKey(name = "fk_notes_adjudicated_details_notes_adjudicated"))
    @EqualsAndHashCode.Include
    private NotesAdjudicated notesAdjudicated;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "denomination_id", foreignKey = @ForeignKey(name = "fk_notes_adjudicated_details_denomination"))
    @EqualsAndHashCode.Include
    private Denomination denomination;

    @Column(name = "full_value_pieces")
    private Integer fullValuePieces;

    @Column(name = "half_value_pieces")
    private Integer halfValuePieces;

    @Column(name = "rejected_pieces")
    private Integer rejectedPieces;
}
