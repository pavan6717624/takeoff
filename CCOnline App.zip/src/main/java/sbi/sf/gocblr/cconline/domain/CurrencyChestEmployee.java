package sbi.sf.gocblr.cconline.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import sbi.sf.gocblr.cconline.domain.enums.CurrencyChestEmployeeType;

/**
 * Currency chest employee details
 * @author Kiran Marturu
 *
 */
@Entity
@Table(name = "cc_employees")
@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CurrencyChestEmployee implements Serializable {

    private static final long serialVersionUID = 4850267349211500702L;

    @Id
    @EqualsAndHashCode.Include
    private long id;

    @Column(name = "cc_employee_type", length = 20)
    private CurrencyChestEmployeeType type;

    @Column(name = "date_of_taking_over")
    private LocalDate dataOfTakingOver;

    @Column(name = "mobile_no")
    private Long mobileNumber;

    @Column(name = "name")
    private String name;

    @Column(name = "designation")
    private String designation;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "cc_branch_code", foreignKey = @ForeignKey(name = "fk_cc_employees_cc_branch_code"))
    private CurrencyChest currencyChest;
}
