package sbi.sf.gocblr.cconline.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "verification_officers")
public class VerificationOfficer implements Serializable {

    private static final long serialVersionUID = -4497205257021402421L;

    @Id
    @EqualsAndHashCode.Include
    private Long id;

    @JsonIgnore
    @MapsId
    @OneToOne
    @JoinColumn(name = "id", foreignKey = @ForeignKey(name = "fk_verification_officer_verificaton"))
    private Verification verification;

    @Column(name = "pf_id")
    private Long pfId;

    @Column(length = 10)
    private String title;

    @Column(length = 100)
    private String name;

    @Column(length = 100)
    private String designation;

    @Column(name = "mobile_no")
    private Long mobileNo;

    @Column(name = "email_id", length = 300)
    private String emailId;

    @Column(name = "branch_code")
    private Long branchCode;

    @Column(name = "branch_name", length = 100)
    private String branchName;
}
