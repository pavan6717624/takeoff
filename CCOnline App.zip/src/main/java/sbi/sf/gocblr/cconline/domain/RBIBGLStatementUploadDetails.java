package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "rbi_bgl_statement_upload_details")
public class RBIBGLStatementUploadDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    LocalDate uploadDate;
    LocalDate fileDate;

    @Column(columnDefinition = "NUMBER(20,2)")
    double openingBalance;

    @Column(columnDefinition = "NUMBER(20,2)")
    double closingBalance;

    String uploadFile;
    String ipAddress;

    Long pfid;
}
