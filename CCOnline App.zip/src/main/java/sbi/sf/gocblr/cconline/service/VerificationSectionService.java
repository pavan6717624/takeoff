package sbi.sf.gocblr.cconline.service;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationSection;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.domain.view.VerificationSectionCount;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.model.VerificationSectionStatusDto;
import sbi.sf.gocblr.cconline.repository.EditableRepository;
import sbi.sf.gocblr.cconline.repository.RejectAndSubmitStateRepository;
import sbi.sf.gocblr.cconline.repository.RoleComplianceRoleRepository;
import sbi.sf.gocblr.cconline.repository.VerificationSectionCountRepository;
import sbi.sf.gocblr.cconline.repository.VerificationSectionRepository;
import sbi.sf.gocblr.cconline.repository.VerificationSectionStatusRepository;
import sbi.sf.gocblr.cconline.service.dto.Action;
import sbi.sf.gocblr.cconline.service.dto.VerificationSectionDTO;
import sbi.sf.gocblr.cconline.service.dto.VerificationSectionsViewModel;
import sbi.sf.gocblr.cconline.utils.BlockUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class VerificationSectionService {

    private final VerificationSectionRepository repo;
    private final VerificationService verificationService;
    private final VerificationSectionStatusRepository statusRepo;
    private final VerificationSectionCountRepository sectionCountRepo;
    private final EditableRepository editableRepo;
    private final RejectAndSubmitStateRepository rejectAndSubmitStateRepo;
    private final RoleComplianceRoleRepository roleComplianceRepo;

    @Transactional(readOnly = true)
    public List<VerificationSectionDTO> sectionsWithStatus(Long verificationId) {
        Verification v = verificationService.getVerificationById(verificationId);
        return repo.sectionsWithStatus(v, v.getType());
    }

    @Transactional(readOnly = true)
    public VerificationSectionsViewModel sectionsViewModel(long verificationId) {
        Verification v = verificationService.getVerificationById(verificationId);
        List<VerificationSectionDTO> sections = repo.sectionsWithStatus(v, v.getType());

        VerificationSectionsViewModel vm = new VerificationSectionsViewModel();
        vm.setVerificationType(v.getType().getName());
        vm.setBranchCode(v.getCurrencyChest().getBranchCode());
        vm.setBranchName(v.getCurrencyChest().getBranchName());
        vm.setBlock(BlockUtils.formatBlockDescription(v.getBlockFrom(), v.getBlockTo()));
        vm.setBlockFrom(v.getBlockFrom());
        vm.setBlockTo(v.getBlockTo());

        vm.setSections(sections);
        vm.setCertificateText(v.getType().getCertificateText());

        return vm;
    }

    @Transactional(readOnly = true)
    public VerificationSectionsViewModel sectionsViewComplianceStatus(long verificationId, String role) {
        Verification v = verificationService.getVerificationById(verificationId);
        List<VerificationSectionDTO> sections = repo.sectionsWithComplianceStatus(v, v.getType());

        VerificationSectionsViewModel vm = new VerificationSectionsViewModel();
        vm.setVerificationType(v.getType().getName());
        vm.setBranchCode(v.getCurrencyChest().getBranchCode());
        vm.setBranchName(v.getCurrencyChest().getBranchName());

        vm.setBlock(BlockUtils.formatBlockDescription(v.getBlockFrom(), v.getBlockTo()));

        vm.setSections(sections);

        log.debug("type: {} | role: {} | status: {}", v.getType(), role, v.getStatus());

        var editable = editableRepo.findByVerificationTypeAndForRoleNameAndStatus(v.getType(), role, v.getStatus());

        if (editable.isPresent() && editable.get().getIsEditable().booleanValue()) {
            vm.setIsEditable(true);
        } else {
            vm.setIsEditable(false);
        }

        var rejectAndSubmit = rejectAndSubmitStateRepo.findByVerificationTypeAndForRoleName(v.getType(), role);

        if (rejectAndSubmit.isPresent()) {
            if (rejectAndSubmit.get().getRejectState() != null) {
                vm.setRejectAction(new Action(rejectAndSubmit.get().getRejectStateActionLabel(), false));
            }
            if (rejectAndSubmit.get().getSubmitState() != null) {
                vm.setSubmitAction(new Action(rejectAndSubmit.get().getSubmitStateActionLabel(), false));
            }
        }

        var rcr = roleComplianceRepo.findByVerificationTypeAndForRoleName(v.getType(), role);
        if (rcr.isPresent()) {
            vm.setUserRole(rcr.get().getComplianceRole());
        }
        vm.setVerificationOfficerComments(v.getVerificationOfficerComments());
        vm.setBranchHeadComments(v.getBranchHeadComments());
        vm.setScrutinizerComments(v.getScrutinizerComments());
        vm.setVerificationOfficerComplianceComments(v.getVerificationOfficerComplianceComments());
        vm.setClosureComments(v.getClosureComments());
        vm.setStatus(v.getStatus());
        return vm;
    }

    public List<VerificationSectionStatusDto> sectionsWithStatusOld(long verificationId) {
        Verification v = verificationService.getVerificationById(verificationId);
        return statusRepo.sectionsWithStatus(v, v.getType(), PageRequest.of(0, 100, Sort.by("displayOrder")));
    }

    @Transactional(readOnly = true)
    public VerificationSection getById(long sectionId) {
        return repo.findById(sectionId).orElseThrow(() -> new ResourceNotFoundException("Invalid section id " + sectionId));
    }

    public VerificationSection getByTypeAndRoute(VerificationType type, String route) {
        return repo
            .findByVerificationTypeAndRoute(type, route)
            .orElseThrow(() -> new ResourceNotFoundException(String.format("No %s section found for %s", route, type.getName())));
    }

    public List<VerificationSectionCount> sectionCompCount(long verificationId, long sectionId) {
        return sectionCountRepo.findByVerificationId(verificationId);
    }

    public List<VerificationSection> pendingSections(long verificationId) {
        Verification v = verificationService.getVerificationById(verificationId);
        return repo.pendingSections(v, v.getType());
    }
}
