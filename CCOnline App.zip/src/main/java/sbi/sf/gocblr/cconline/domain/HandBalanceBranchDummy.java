package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
@Data
@Entity
public class HandBalanceBranchDummy implements Serializable {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = -8356165785689886898L;

	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    Long id;
	 
	 Long circleCode;
	 String circleName;
	 Long networkCode;
	 Long moduleCode;
	 String moduleName;
	 Long regionCode;
	 Long branchCode;
	 String branchName;
	 String liveFlag;
	 Long branchTypeCode;
	 String branchType;
	 String branchEmailId;
	 Long brachManagerMobileNumber;
	 Long rboBranchCode;

}
