package sbi.sf.gocblr.cconline.service;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlips;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.NoPenaltyDataFoundDates;
import sbi.sf.gocblr.cconline.domain.PenaltyData;
import sbi.sf.gocblr.cconline.domain.PenaltyDebitType;
import sbi.sf.gocblr.cconline.domain.PenaltyDisposal;
import sbi.sf.gocblr.cconline.domain.PenaltyReason;
import sbi.sf.gocblr.cconline.domain.PenaltySubReason;
import sbi.sf.gocblr.cconline.domain.PenaltyUpdation;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.TotalsTable;
import sbi.sf.gocblr.cconline.model.CustomReport;
import sbi.sf.gocblr.cconline.model.CustomReportsDTO;
import sbi.sf.gocblr.cconline.model.PenaltyReport;
import sbi.sf.gocblr.cconline.model.PenaltyUpdationModel;
import sbi.sf.gocblr.cconline.repository.ChestSlipUploadDetailsRepository;
import sbi.sf.gocblr.cconline.repository.CircleRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.DenominationRepository;
import sbi.sf.gocblr.cconline.repository.FsloRepository;
import sbi.sf.gocblr.cconline.repository.ModuleRepository;
import sbi.sf.gocblr.cconline.repository.NoPenaltyDataFoundDatesRepository;
import sbi.sf.gocblr.cconline.repository.ParticularsRepository;
import sbi.sf.gocblr.cconline.repository.PenaltyDataRepository;
import sbi.sf.gocblr.cconline.repository.PenaltyDebitTypeRepository;
import sbi.sf.gocblr.cconline.repository.PenaltyDisposalRepository;
import sbi.sf.gocblr.cconline.repository.PenaltyReasonRepository;
import sbi.sf.gocblr.cconline.repository.PenaltySubReasonRepository;
import sbi.sf.gocblr.cconline.repository.PenaltyUpdationRepository;
import sbi.sf.gocblr.cconline.repository.RoleRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class PenaltyDataService {

    private final PenaltyDataRepository penaltyDataRepository;
    private final PenaltyDebitTypeRepository penaltyDebitTypeRepository;
    private final PenaltyReasonRepository penaltyReasonRepository;
    private final PenaltySubReasonRepository penaltySubReasonRepository;
    private final CurrencyChestRepository currencyChestRepository;
    private final PenaltyUpdationRepository penaltyUpdationRepository;
    private final PenaltyDisposalRepository penaltyDisposalRepository;
    private final ChestSlipUploadDetailsRepository chestSlipUploadDetailsRepository;
    private final DenominationRepository denominationsRepository;
    private final ParticularsRepository particularRepository;
    private final RoleRepository roleRepository;
    private final FsloRepository fsloRepository;
    private final CircleRepository circleRepository;
    private final ModuleRepository moduleRepository;
    private final NoPenaltyDataFoundDatesRepository noPenaltyDataFoundDatesRepository;

    public String checkPenaltyData(LocalDate reportDate) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        List<PenaltyData> penaltyCheckData = penaltyDataRepository.findByReportDateAndStatus(reportDate, "New");
        if (penaltyCheckData != null && penaltyCheckData.size() > 0) {
            return "You have already Uploaded RBI Penalty for Date : " + dateFormatter.format(reportDate) + ".";
        } else return "";
    }

    @Transactional
    public String saveRBIPenaltyData(PenaltyData[] penaltyData, String ipaddress) {
        List<PenaltyData> penaltyCheckData = penaltyDataRepository.findByReportDateAndStatus(penaltyData[0].getReportDate(), "New");

        String message = "{\"message\":\"Penalty Data Submitted.\"}";

        /*if (penaltyCheckData!= null && penaltyCheckData.size() > 0) {
        	 
        	 for(int i=0;i<penaltyCheckData.size();i++)
        	 {
        		 penaltyCheckData.get(i).setStatus("Deleted");
        		 penaltyDataRepository.save(penaltyCheckData.get(i));
        	 }
        	 message = "{\"message\":\"Penalty Data OverWritten.\"}";
         }*/

        for (int i = 0; i < penaltyData.length; i++) {
            penaltyData[i].setStatus("New");
            penaltyData[i].setPfid(SecurityUtils.getLoggedInUser().getId());
            penaltyData[i].setIpaddress(ipaddress);
            penaltyDataRepository.save(penaltyData[i]);
        }

        return message;
    }

    public List<PenaltyData> getPenaltyDataOnDate(LocalDate date) {
        AppUser user = SecurityUtils.getLoggedInUser();
        Long fsloCode = user.getBranchCode();
        return penaltyDataRepository.findByReportDateAndStatusAndFsloCode(date.getMonth().getValue(), date.getYear(), "New", fsloCode);
    }

    public List<PenaltyDebitType> getPenaltyDebitType() {
        return penaltyDebitTypeRepository.findAll();
    }

    public List<PenaltyDisposal> getDisposalData() {
        return penaltyDisposalRepository.findAll();
    }

    public List<PenaltyData> getPenaltyDisposal(LocalDate date) {
        AppUser user = SecurityUtils.getLoggedInUser();
        Long fsloCode = user.getBranchCode();
        return penaltyDataRepository.findByMonthAndYearAndStatusAndBranchCode(date.getMonth().getValue(), date.getYear(), "New", fsloCode);
    }

    public List<PenaltyReason> getPenaltyReasons(PenaltyDebitType penalty_debit_type) {
        // TODO Auto-generated method stub
        return penaltyReasonRepository.findByTypeOrderByIdAsc(penalty_debit_type);
    }

    public List<PenaltySubReason> getPenaltySubReasons(PenaltyReason penalty_reason) {
        // TODO Auto-generated method stub
        return penaltySubReasonRepository.findByReason(penalty_reason);
    }

    @Transactional
    public String savePenaltyDisposal(PenaltyUpdationModel penaltyUpdationModel, String ipaddress) {
        PenaltyUpdation penaltyUpdation = new PenaltyUpdation();
        penaltyUpdation.setId(penaltyUpdationModel.getId());
        penaltyUpdation.setAmount(penaltyUpdationModel.getAmount());
        penaltyUpdation.setNarration(penaltyUpdationModel.getNarration());
        penaltyUpdation.setReason(penaltyUpdationModel.getReason());
        penaltyUpdation.setSubReason(penaltyUpdationModel.getSubReason());
        penaltyUpdation.setCurrencyChest(currencyChestRepository.findByBranchCode(penaltyUpdationModel.getBranchCode()).get());
        penaltyUpdation.setStatus(penaltyUpdationModel.getStatus());
        penaltyUpdation.setUpdatedByPfid(penaltyUpdationModel.getUpdatedByPfid());
        penaltyUpdation.setUpdatedOnIp(penaltyUpdationModel.getUpdatedOnIp());
        penaltyUpdation.setDisposal(penaltyUpdationModel.getDisposal());
        penaltyUpdation.setDisposedByPfid(SecurityUtils.getLoggedInUser().getId());
        penaltyUpdation.setDisposedOnIp(ipaddress);
        penaltyUpdation.setUpdatedDate(penaltyUpdationModel.getUpdatedDate());
        penaltyUpdation.setDisposedDate(LocalDate.now());

        penaltyUpdationRepository.save(penaltyUpdation);
        
//        System.out.println("In chnage of disposal");
        
        
        Long notSubmitted = penaltyUpdationRepository.notSubmittedDisposal(penaltyUpdationModel.getNarration());
        
        if(notSubmitted == 0l)
        {
        	penaltyUpdation.getNarration().setDisposalStatus("Disposed");
        	penaltyDataRepository.save(penaltyUpdation.getNarration());
        	        	
        }

        return "{\"status\":\"success\",\"message\":\"Penalty Disposal Saved Successfully\"}";
    }

    @Transactional
    public String savePenaltyData(PenaltyUpdationModel[] penaltyUpdationModel, String ipaddress) {
        List<PenaltyUpdation> penalUpdationPresent = penaltyUpdationRepository.findByNarrationAndStatus(
            penaltyUpdationModel[0].getNarration(),
            "Submitted"
        );

        if (penalUpdationPresent != null && penalUpdationPresent.size() > 0) {
            return "{\"status\":\"error\",\"message\":\"Penalty Data already Submitted. Cannot Save Now.\"}";
        }

        penalUpdationPresent = penaltyUpdationRepository.findByNarrationAndStatus(penaltyUpdationModel[0].getNarration(), "Saved");

        if (penalUpdationPresent != null && penalUpdationPresent.size() > 0) {
            for (int i = 0; i < penalUpdationPresent.size(); i++) {
                penalUpdationPresent.get(i).setStatus("Deleted");
                penalUpdationPresent.get(i).setUpdatedByPfid(SecurityUtils.getLoggedInUser().getId());
                penalUpdationPresent.get(i).setUpdatedOnIp(ipaddress);
                penalUpdationPresent.get(i).setUpdatedDate(LocalDate.now());
                penaltyUpdationRepository.save(penalUpdationPresent.get(i));
            }
        }

        for (int i = 0; i < penaltyUpdationModel.length; i++) {
            PenaltyUpdation penaltyUpdation = new PenaltyUpdation();
            penaltyUpdation.setAmount(penaltyUpdationModel[i].getAmount());
            penaltyUpdation.setNarration(penaltyUpdationModel[i].getNarration());
            penaltyUpdation.setReason(penaltyUpdationModel[i].getReason());
            penaltyUpdation.setSubReason(penaltyUpdationModel[i].getSubReason());
            penaltyUpdation.setCurrencyChest(currencyChestRepository.findByBranchCode(penaltyUpdationModel[i].getBranchCode()).get());
            penaltyUpdation.setStatus("Saved");
            penaltyUpdation.setUpdatedDate(LocalDate.now());
            penaltyUpdation.setUpdatedByPfid(SecurityUtils.getLoggedInUser().getId());
            penaltyUpdation.setUpdatedOnIp(ipaddress);

            penaltyUpdationRepository.save(penaltyUpdation);
        }
        return "{\"status\":\"success\",\"message\":\"Penalty Data Saved Successfully\"}";
    }

    public String saveWithNoItems(PenaltyUpdationModel[] penaltyUpdationModel, String ipaddress) {
        List<PenaltyUpdation> penalUpdationPresent = penaltyUpdationRepository.findByNarrationAndStatus(
            penaltyUpdationModel[0].getNarration(),
            "Submitted"
        );

        if (penalUpdationPresent != null && penalUpdationPresent.size() > 0) {
            return "{\"status\":\"error\",\"message\":\"Penalty Data already Submitted. Cannot Save Now.\"}";
        }

        penalUpdationPresent = penaltyUpdationRepository.findByNarrationAndStatus(penaltyUpdationModel[0].getNarration(), "Saved");

        if (penalUpdationPresent != null && penalUpdationPresent.size() > 0) {
            for (int i = 0; i < penalUpdationPresent.size(); i++) {
                penalUpdationPresent.get(i).setStatus("Deleted");
                penalUpdationPresent.get(i).setUpdatedDate(LocalDate.now());
                penalUpdationPresent.get(i).setUpdatedByPfid(SecurityUtils.getLoggedInUser().getId());
                penalUpdationPresent.get(i).setUpdatedOnIp(ipaddress);
                penaltyUpdationRepository.save(penalUpdationPresent.get(i));
            }
        }

        return "{\"status\":\"success\",\"message\":\"Saved with No Items\"}";
    }

    @Transactional
    public String submitPenaltyData(PenaltyUpdationModel[] penaltyUpdationModel, String ipaddress) {
        List<PenaltyUpdation> penalUpdationPresent = penaltyUpdationRepository.findByNarrationAndStatus(
            penaltyUpdationModel[0].getNarration(),
            "Submitted"
        );

        if (penalUpdationPresent != null && penalUpdationPresent.size() > 0) {
            return "{\"status\":\"error\",\"message\":\"Penalty Data already Submitted.\"}";
        }
        penalUpdationPresent = penaltyUpdationRepository.findByNarrationAndStatus(penaltyUpdationModel[0].getNarration(), "Saved");

        if (penalUpdationPresent != null && penalUpdationPresent.size() > 0) {
            for (int i = 0; i < penalUpdationPresent.size(); i++) {
                penalUpdationPresent.get(i).setStatus("Deleted");
                penalUpdationPresent.get(i).setUpdatedDate(LocalDate.now());
                penalUpdationPresent.get(i).setUpdatedByPfid(SecurityUtils.getLoggedInUser().getId());
                penalUpdationPresent.get(i).setUpdatedOnIp(ipaddress);
                penaltyUpdationRepository.save(penalUpdationPresent.get(i));
            }
        }

        for (int i = 0; i < penaltyUpdationModel.length; i++) {
            PenaltyUpdation penaltyUpdation = new PenaltyUpdation();
            penaltyUpdation.setAmount(penaltyUpdationModel[i].getAmount());
            penaltyUpdation.setNarration(penaltyUpdationModel[i].getNarration());
            penaltyUpdation.setReason(penaltyUpdationModel[i].getReason());
            penaltyUpdation.setSubReason(penaltyUpdationModel[i].getSubReason());
            penaltyUpdation.setCurrencyChest(currencyChestRepository.findByBranchCode(penaltyUpdationModel[i].getBranchCode()).get());
            penaltyUpdation.setUpdatedByPfid(SecurityUtils.getLoggedInUser().getId());
            penaltyUpdation.setUpdatedOnIp(ipaddress);
            penaltyUpdation.setUpdatedDate(LocalDate.now());
            penaltyUpdation.setStatus("Submitted");
            penaltyUpdationRepository.save(penaltyUpdation);
        }

        PenaltyData penaltyData = penaltyDataRepository.findById(penaltyUpdationModel[0].getNarration().getId()).get();
        penaltyData.setPostedStatus("Submitted");
        penaltyDataRepository.save(penaltyData);

        return "{\"status\":\"success\",\"message\":\"Penalty Data Submitted Successfully\"}";
    }

    public List<PenaltyUpdation> getPenaltyProvidedData(PenaltyData narration) {
        return penaltyUpdationRepository.findByNarrationLatest(narration);
    }

    public String deleteRBIPenaltyData(PenaltyData penaltyData, String ipaddress) {
        penaltyData.setStatus("Deleted");
        penaltyData.setPfid(SecurityUtils.getLoggedInUser().getId());
        penaltyData.setIpaddress(ipaddress);
        penaltyDataRepository.save(penaltyData);
        return "{\"status\":\"success\",\"message\":\"Selected Penalty Row Deleted Successfully\"}";
    }

    @Transactional
    public CustomReport[] getCustomReports(LocalDate fromdate, LocalDate todate, String report) {
        int totalDenominations = 11;

        Optional<ChestSlipParticular> checkInCoins = particularRepository.findByParticularAndType(report, "Coins");

        AppUser user = SecurityUtils.getLoggedInUser();

        Set<Role> roles = user.getRoles();

        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        Role RBO_DESK_OFFICER = roleRepository.findByName(RoleConstants.RBO_DESK_OFFICER).get();
        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        if (checkInCoins.isPresent()) totalDenominations = 16;

        int dataSize = totalDenominations + 2;

        List<TotalsTable> chestSlipTotalsDetails = chestSlipUploadDetailsRepository.getTotalsReport(fromdate, todate, report);
        List<ChestSlips> chestSlipUploadDetails = chestSlipUploadDetailsRepository.getReports(fromdate, todate, report);

        CustomReport[] customReport = null;

        if (chestSlipUploadDetails.size() != 0) {
            customReport = new CustomReport[(chestSlipUploadDetails.size() / totalDenominations) + 1];
        }

        Double[] total = new Double[dataSize];
        for (int i = 0; i < dataSize; i++) total[i] = 0d;

        for (int i = 0; i < chestSlipUploadDetails.size(); i += totalDenominations) {
            customReport[i / totalDenominations] = new CustomReport();
            customReport[i / totalDenominations].setDate(chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getChestSlipDate());
            customReport[i / totalDenominations].setBrname(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getBranchName()
                );
            customReport[i / totalDenominations].setCccode(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getBranchCode()
                );
            customReport[i / totalDenominations].setCircle(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getCircle().getCircleName()
                );
            customReport[i / totalDenominations].setFslocode(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getFslo().getBranchCode()
                );
            customReport[i / totalDenominations].setNetwork(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getNetwork().getNetworkCode()
                );
            customReport[i / totalDenominations].setRegion(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getRegion().getRegionCode()
                );

            customReport[i / totalDenominations].setModule(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getModule().getModuleCode()
                );

            customReport[i / totalDenominations].setPopcd(
                    chestSlipUploadDetails
                        .get(i)
                        .getCheckSlipUploadDetails()
                        .getCurrencyChest()
                        .getAddress()
                        .getPopulationGroup()
                        .description()
                );
            customReport[i / totalDenominations].setState(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getAddress().getState().getName()
                );
            customReport[i / totalDenominations].setZone(
                    chestSlipUploadDetails.get(i).getCheckSlipUploadDetails().getCurrencyChest().getModule().getModuleName()
                );

            Double[] data = new Double[dataSize];

            for (int j = i; j < i + totalDenominations; j++) {
                data[j % totalDenominations] = chestSlipUploadDetails.get(j).getValue();
                total[j % totalDenominations] += data[j % totalDenominations];
            }

            if (totalDenominations == 11) {
                data[totalDenominations] = (chestSlipTotalsDetails.get(i / totalDenominations).getTotalPieces());
                data[totalDenominations + 1] = (chestSlipTotalsDetails.get(i / totalDenominations).getTotalValue());
            } else if (totalDenominations == 16) {
                data[totalDenominations] =
                    (
                        chestSlipTotalsDetails.get((i / totalDenominations) * 2).getTotalPieces() +
                        chestSlipTotalsDetails.get(((i / totalDenominations) * 2) + 1).getTotalPieces()
                    );
                data[totalDenominations + 1] =
                    (
                        chestSlipTotalsDetails.get((i / totalDenominations) * 2).getTotalValue() +
                        chestSlipTotalsDetails.get(((i / totalDenominations) * 2) + 1).getTotalValue()
                    );
            }
            total[totalDenominations] += data[totalDenominations];
            total[totalDenominations + 1] += data[totalDenominations + 1];

            customReport[i / totalDenominations].setData(data);
        }

        if (customReport != null && customReport.length > 0) {
            customReport[chestSlipUploadDetails.size() / totalDenominations] = new CustomReport();
            customReport[chestSlipUploadDetails.size() / totalDenominations].setData(total);
            customReport[chestSlipUploadDetails.size() / totalDenominations].setState("TOTAL");
        }

        if (customReport == null) return customReport;

        /*   Arrays.sort(
            customReport,
            new Comparator<CustomReport>() {
                @Override
                public int compare(CustomReport o1, CustomReport o2) {
                    if (o1 != null && o2 != null && o1.getDate() != null && o2.getDate() != null) return o1
                        .getDate()
                        .compareTo(o2.getDate()); else return 0; // or whatever property you want to sort
                }
            }
        );*/

        if (roles.contains(FSLO_USER)) {
            Long fsloCode = user.getBranchCode();
            customReport =
                Arrays
                    .stream(customReport)
                    .filter(
                        x -> {
                            if (
                                (x.getState() != null && x.getState().equals("TOTAL")) ||
                                (x.getFslocode() != null && (x.getFslocode() - fsloCode == 0))
                            ) return true; else return false;
                        }
                    )
                    .toArray(CustomReport[]::new);
        }

        if (roles.contains(CIRCLE_ADMIN)) {
            String circle = circleRepository.findByCircleCode(user.getCircleCode()).get().getCircleName();

            customReport =
                Arrays
                    .stream(customReport)
                    .filter(
                        x -> {
                            if (
                                (x.getState() != null && x.getState().equals("TOTAL")) ||
                                (x.getCircle() != null && (x.getCircle().toLowerCase().equals(circle.toLowerCase())))
                            ) return true; else return false;
                        }
                    )
                    .toArray(CustomReport[]::new);
        }

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        Arrays.sort(
            customReport,
            new Comparator<CustomReport>() {
                @Override
                public int compare(CustomReport o1, CustomReport o2) {
                    if (o1.getDate() == null || o2.getDate() == null) return 0;
                    String date1 = dateFormatter.format(o1.getDate());
                    String circle1 = o1.getCircle() + "";
                    String network1 = o1.getNetwork() + "";
                    String module1 = o1.getModule() + "";
                    String region1 = o1.getRegion() + "";
                    String brcode1 = o1.getCccode() + "";

                    String date2 = dateFormatter.format(o2.getDate());
                    String circle2 = o2.getCircle() + "";
                    String network2 = o2.getNetwork() + "";
                    String module2 = o2.getModule() + "";
                    String region2 = o2.getRegion() + "";
                    String brcode2 = o2.getCccode() + "";

                    String compare1 = date1 + "" + circle1 + "" + network1 + "" + module1 + "" + region1 + "" + brcode1;
                    String compare2 = date2 + "" + circle2 + "" + network2 + "" + module2 + "" + region2 + "" + brcode2;

                    return compare1.compareTo(compare2);
                }
            }
        );

        return customReport;
    }

    @Transactional
    public List<CustomReportsDTO> getCustomReportsFsloSummary(
        LocalDate fromdate,
        LocalDate todate,
        String report,
        String circle,
        String network,
        String module,
        String region
    ) {
        Long[] did = denominationsRepository.getIndices().toArray(new Long[0]);

        List<CustomReportsDTO> reportDto = chestSlipUploadDetailsRepository.getCustomReportsFsloSummary(
            fromdate,
            todate,
            did[0],
            did[1],
            did[2],
            did[3],
            did[4],
            did[5],
            did[6],
            did[7],
            did[8],
            did[9],
            did[10],
            did[11],
            did[12],
            did[13],
            did[14],
            did[15],
            particularRepository.getPidsByParticular(report)
        );

        reportDto.add(
            chestSlipUploadDetailsRepository.getSumCustomReportsFsloSummary(
                fromdate,
                todate,
                did[0],
                did[1],
                did[2],
                did[3],
                did[4],
                did[5],
                did[6],
                did[7],
                did[8],
                did[9],
                did[10],
                did[11],
                did[12],
                did[13],
                did[14],
                did[15],
                particularRepository.getPidsByParticular(report)
            )
        );

        return reportDto;
    }

    @Transactional
    public List<CustomReportsDTO> getCustomReportsCircleSummary(
        LocalDate fromdate,
        LocalDate todate,
        String report,
        String circle,
        String network,
        String module,
        String region
    ) {
        Long[] did = denominationsRepository.getIndices().toArray(new Long[0]);

        List<CustomReportsDTO> reportDto = chestSlipUploadDetailsRepository.getCustomReportsCircleSummary(
            fromdate,
            todate,
            did[0],
            did[1],
            did[2],
            did[3],
            did[4],
            did[5],
            did[6],
            did[7],
            did[8],
            did[9],
            did[10],
            did[11],
            did[12],
            did[13],
            did[14],
            did[15],
            particularRepository.getPidsByParticular(report)
        );

        reportDto.add(
            chestSlipUploadDetailsRepository.getSumCustomReportsCircleSummary(
                fromdate,
                todate,
                did[0],
                did[1],
                did[2],
                did[3],
                did[4],
                did[5],
                did[6],
                did[7],
                did[8],
                did[9],
                did[10],
                did[11],
                did[12],
                did[13],
                did[14],
                did[15],
                particularRepository.getPidsByParticular(report)
            )
        );

        return reportDto;
    }

    @Transactional
    public List<CustomReportsDTO> getCustomReportsCircleStateSummary(
        LocalDate fromdate,
        LocalDate todate,
        String report,
        String circle,
        String network,
        String module,
        String region
    ) {
        Long[] did = denominationsRepository.getIndices().toArray(new Long[0]);

        List<CustomReportsDTO> reportDto = chestSlipUploadDetailsRepository.getCustomReportsCircleStateSummary(
            fromdate,
            todate,
            did[0],
            did[1],
            did[2],
            did[3],
            did[4],
            did[5],
            did[6],
            did[7],
            did[8],
            did[9],
            did[10],
            did[11],
            did[12],
            did[13],
            did[14],
            did[15],
            particularRepository.getPidsByParticular(report)
        );

        reportDto.add(
            chestSlipUploadDetailsRepository.getSumCustomReportsCircleStateSummary(
                fromdate,
                todate,
                did[0],
                did[1],
                did[2],
                did[3],
                did[4],
                did[5],
                did[6],
                did[7],
                did[8],
                did[9],
                did[10],
                did[11],
                did[12],
                did[13],
                did[14],
                did[15],
                particularRepository.getPidsByParticular(report)
            )
        );

        return reportDto;
    }

    @Transactional
    public List<CustomReportsDTO> getCustomReportsNew(
        LocalDate fromdate,
        LocalDate todate,
        String report,
        String circle,
        String network,
        String module,
        String region
    ) {
        log.debug(new java.util.Date() + "Received call.");

        /*	Optional<ChestSlipParticular> checkInCoins = particularRepository.findByParticularAndType(report, "Coins");
        int totalDenominations = checkInCoins.isPresent() ? 16 : 11;

        AppUser user = SecurityUtils.getLoggedInUser();
        log.debug("roles: {}", user.getRoles());

        List<CustomReportTotalData> chestSlipTotalsDetails;
        List<CustomReportChestSlipData> chestSlipUploadDetails;

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER, RoleConstants.DGM_ABD)) {
            chestSlipTotalsDetails = chestSlipUploadDetailsRepository.getTotalsReportNew(fromdate, todate, report, null, null, null, null,null);
            chestSlipUploadDetails = chestSlipUploadDetailsRepository.getReportsNew(fromdate, todate, report, null, null, null, null,null);
        } else if (
            SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER) && SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)
        ) {
            chestSlipTotalsDetails =
                chestSlipUploadDetailsRepository.getTotalsReportNew(
                    fromdate,
                    todate,
                    report,
                    user.getBranchCode(),
                    user.getCircleCode(),
                    null,
                    null,
                    null
                );
            chestSlipUploadDetails =
                chestSlipUploadDetailsRepository.getReportsNew(
                    fromdate,
                    todate,
                    report,
                    user.getBranchCode(),
                    user.getCircleCode(),
                    null,
                    null,
                    null
                );
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            chestSlipTotalsDetails =
                chestSlipUploadDetailsRepository.getTotalsReportNew(fromdate, todate, report, user.getBranchCode(), 999L, null, null,null);
            chestSlipUploadDetails =
                chestSlipUploadDetailsRepository.getReportsNew(fromdate, todate, report, user.getBranchCode(), 999L, null, null,null);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            chestSlipTotalsDetails =
                chestSlipUploadDetailsRepository.getTotalsReportNew(fromdate, todate, report, 0L, user.getCircleCode(), null, null,null);
            chestSlipUploadDetails =
                chestSlipUploadDetailsRepository.getReportsNew(fromdate, todate, report, 0L, user.getCircleCode(), null, null,null);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER) || SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB)) {
            chestSlipTotalsDetails =
                chestSlipUploadDetailsRepository.getTotalsReportNew(
                    fromdate,
                    todate,
                    report,
                    0L,
                    user.getCircleCode(),
                    user.getModuleCode(),
                    null,
                    null
                );
            chestSlipUploadDetails =
                chestSlipUploadDetailsRepository.getReportsNew(
                    fromdate,
                    todate,
                    report,
                    0L,
                    user.getCircleCode(),
                    user.getModuleCode(),
                    null,
                    null
                );
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM) || SecurityUtils.isCurrentUserInRole(RoleConstants.RM)) {
            chestSlipTotalsDetails =
                chestSlipUploadDetailsRepository.getTotalsReportNew(
                    fromdate,
                    todate,
                    report,
                    0L,
                    user.getCircleCode(),
                    user.getModuleCode(),
                    user.getRegionCode(),
                    null
                );
            chestSlipUploadDetails =
                chestSlipUploadDetailsRepository.getReportsNew(
                    fromdate,
                    todate,
                    report,
                    0L,
                    user.getCircleCode(),
                    user.getModuleCode(),
                    user.getRegionCode(),
                    null
                );
        } 
        
        
        else if (SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_HEAD) || SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_USER)) {
            chestSlipTotalsDetails =
                chestSlipUploadDetailsRepository.getTotalsReportNew(
                    fromdate,
                    todate,
                    report,
                    0L,
                    user.getCircleCode(),
                    user.getModuleCode(),
                    user.getRegionCode(),
                    user.getBranchCode()
                );
            chestSlipUploadDetails =
                chestSlipUploadDetailsRepository.getReportsNew(
                    fromdate,
                    todate,
                    report,
                    0L,
                    user.getCircleCode(),
                    user.getModuleCode(),
                    user.getRegionCode(),
                    user.getBranchCode()
                );
        }
        
        
        
        else {
            throw new InsufficientAuthenticationException("User role is not authorized for accessing this resource");
        }

        int dataSize = totalDenominations + 2;

        CustomReport[] customReport = null;

        if (chestSlipUploadDetails.size() != 0) {
            customReport = new CustomReport[(chestSlipUploadDetails.size() / totalDenominations) + 1];
        }

        Double[] total = new Double[dataSize];
        for (int i = 0; i < dataSize; i++) total[i] = 0d;

        for (int i = 0; i < chestSlipUploadDetails.size(); i += totalDenominations) {
            String circleName = chestSlipUploadDetails.get(i).getCircleName();
            Long networkCode = chestSlipUploadDetails.get(i).getNetworkCode();
            Long regionCode = chestSlipUploadDetails.get(i).getRegionCode();
            String moduleName = chestSlipUploadDetails.get(i).getModuleName();

            if (!circle.equals("%") && !circleName.equals(circle)) {
                continue;
            }

            if (!network.equals("%") && !networkCode.toString().equals(network)) {
                continue;
            }

            if (!module.equals("%") && !moduleName.equals(module)) {
                continue;
            }

            if (!region.equals("%") && !regionCode.toString().equals(region)) {
                continue;
            }

            customReport[i / totalDenominations] = new CustomReport();
            customReport[i / totalDenominations].setDate(chestSlipUploadDetails.get(i).getChestSlipDate());
            customReport[i / totalDenominations].setBrname(chestSlipUploadDetails.get(i).getBranchName());
            customReport[i / totalDenominations].setCccode(chestSlipUploadDetails.get(i).getBranchCode());
            customReport[i / totalDenominations].setCircle(chestSlipUploadDetails.get(i).getCircleName());
            customReport[i / totalDenominations].setFslocode(chestSlipUploadDetails.get(i).getFsloBranchCode());
            customReport[i / totalDenominations].setNetwork(chestSlipUploadDetails.get(i).getNetworkCode());
            customReport[i / totalDenominations].setRegion(chestSlipUploadDetails.get(i).getRegionCode());
            customReport[i / totalDenominations].setCbl(chestSlipUploadDetails.get(i).getCashBalanceLimit());

            customReport[i / totalDenominations].setModule(chestSlipUploadDetails.get(i).getModuleCode());

            customReport[i / totalDenominations].setPopcd(chestSlipUploadDetails.get(i).getPopulationGroup().description());
            customReport[i / totalDenominations].setState(chestSlipUploadDetails.get(i).getStateName());
            customReport[i / totalDenominations].setZone(chestSlipUploadDetails.get(i).getModuleName());

            Double[] data = new Double[dataSize];

            for (int j = i; j < i + totalDenominations; j++) {
                data[j % totalDenominations] = chestSlipUploadDetails.get(j).getValue();
                total[j % totalDenominations] += data[j % totalDenominations];
            }

            if (totalDenominations == 11) {
                data[totalDenominations] = (chestSlipTotalsDetails.get(i / totalDenominations).getTotalPieces());
                data[totalDenominations + 1] = (chestSlipTotalsDetails.get(i / totalDenominations).getTotalValue());
            } else if (totalDenominations == 16) {
                data[totalDenominations] =
                    (
                        chestSlipTotalsDetails.get((i / totalDenominations) * 2).getTotalPieces() +
                        chestSlipTotalsDetails.get(((i / totalDenominations) * 2) + 1).getTotalPieces()
                    );
                data[totalDenominations + 1] =
                    (
                        chestSlipTotalsDetails.get((i / totalDenominations) * 2).getTotalValue() +
                        chestSlipTotalsDetails.get(((i / totalDenominations) * 2) + 1).getTotalValue()
                    );
            }
            total[totalDenominations] += data[totalDenominations];
            total[totalDenominations + 1] += data[totalDenominations + 1];

            customReport[i / totalDenominations].setData(data);
        }

        if (customReport != null && customReport.length > 0) {
            customReport[chestSlipUploadDetails.size() / totalDenominations] = new CustomReport();
            customReport[chestSlipUploadDetails.size() / totalDenominations].setData(total);
            customReport[chestSlipUploadDetails.size() / totalDenominations].setState("TOTAL");
        }

        if (customReport == null) return customReport;

        customReport = Arrays.stream(customReport).filter(x -> x != null).toArray(CustomReport[]::new);

        //        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        //        Arrays.sort(
        //            customReport,
        //            new Comparator<CustomReport>() {
        //                @Override
        //                public int compare(CustomReport o1, CustomReport o2) {
        //                    if (o1.getDate() == null || o2.getDate() == null) return 0;
        //                    String date1 = dateFormatter.format(o1.getDate());
        //                    String circle1 = o1.getCircle() + "";
        //                    String network1 = o1.getNetwork() + "";
        //                    String module1 = o1.getModule() + "";
        //                    String region1 = o1.getRegion() + "";
        //                    String brcode1 = o1.getCccode() + "";
        //
        //                    String date2 = dateFormatter.format(o2.getDate());
        //                    String circle2 = o2.getCircle() + "";
        //                    String network2 = o2.getNetwork() + "";
        //                    String module2 = o2.getModule() + "";
        //                    String region2 = o2.getRegion() + "";
        //                    String brcode2 = o2.getCccode() + "";
        //
        //                    String compare1 = date1 + "" + circle1 + "" + network1 + "" + module1 + "" + region1 + "" + brcode1;
        //                    String compare2 = date2 + "" + circle2 + "" + network2 + "" + module2 + "" + region2 + "" + brcode2;
        //
        //                    return compare1.compareTo(compare2);
        //                }
        //            }
        //        );

        return customReport;*/

        AppUser user = SecurityUtils.getLoggedInUser();
        log.debug("roles: {}", user.getRoles());

        Long userCircleCode = user.getCircleCode();
        Long userNetworkCode = user.getNetworkCode();
        Long userModuleCode = user.getModuleCode();
        Long userRegionCode = user.getRegionCode();
        Long userBranchCode = user.getBranchCode();

        String queryCircle = "%", queryNetwork = "%", queryModule = "%", queryRegion = "%", queryBranch = "%", queryFslo = "fslo";

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.ABD_USER, RoleConstants.DGM_ABD)) {
            if (!circle.equals("%")) queryCircle = circleRepository.findByCircleName(circle).get().getCircleCode() + ""; else queryCircle =
                circle;

            queryNetwork = network;
//            if (!module.equals("%")) queryModule =
//                moduleRepository.getModuleCode(
//                    circleRepository.findByCircleName(circle).get().getCircleCode(),
//                    Long.valueOf(network),
//                    module
//                ) +
//                ""; else 
            queryModule = module;
            queryRegion = region;
        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            if (queryCircle.equals("%")) queryCircle = userCircleCode + "";
            queryFslo = userBranchCode + "";
        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            queryCircle = userCircleCode + "";
            queryNetwork = network;
//            if (!module.equals("%")) queryModule =
//                moduleRepository.getModuleCode(
//                    circleRepository.findByCircleName(circle).get().getCircleCode(),
//                    Long.valueOf(network),
//                    module
//                ) +
//                ""; else
            queryModule = module;
            queryRegion = region;
        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER) || SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB)) {
            queryCircle = userCircleCode + "";
            queryNetwork = userNetworkCode + "";
//            if (!module.equals("%")) queryModule =
//                moduleRepository.getModuleCode(
//                    circleRepository.findByCircleName(circle).get().getCircleCode(),
//                    Long.valueOf(network),
//                    module
//                ) +
//                ""; else 
            queryModule = module;
            queryRegion = region;
        }

        if (
            SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM) ||
            SecurityUtils.isCurrentUserInRole(RoleConstants.RM) ||
            SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_DESK_OFFICER)
        ) {
            queryCircle = userCircleCode + "";
            queryNetwork = userNetworkCode + "";
            queryModule = userModuleCode + "";
            queryRegion = region;
        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_HEAD) || SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_USER)) {
            queryCircle = userCircleCode + "";
            queryNetwork = userNetworkCode + "";
            queryModule = userModuleCode + "";
            queryRegion = userRegionCode + "";
            queryBranch = userBranchCode + "";
        }

        Long[] did = denominationsRepository.getIndices().toArray(new Long[0]);

       // System.out.println(queryCircle + " " + queryNetwork + " " + queryModule + " " + queryRegion + " " + queryBranch + " " + queryFslo);
        List<CustomReportsDTO> reportsDTO = chestSlipUploadDetailsRepository.getCustomReports(
            fromdate,
            todate,
            queryCircle,
            queryNetwork,
            queryModule,
            queryRegion,
            queryBranch,
            queryFslo,
            did[0],
            did[1],
            did[2],
            did[3],
            did[4],
            did[5],
            did[6],
            did[7],
            did[8],
            did[9],
            did[10],
            did[11],
            did[12],
            did[13],
            did[14],
            did[15],
            particularRepository.getPidsByParticular(report)
        );

        CustomReportsDTO reportsSumDTO = chestSlipUploadDetailsRepository.getSumCustomReports(
            fromdate,
            todate,
            queryCircle,
            queryNetwork,
            queryModule,
            queryRegion,
            queryBranch,
            queryFslo,
            did[0],
            did[1],
            did[2],
            did[3],
            did[4],
            did[5],
            did[6],
            did[7],
            did[8],
            did[9],
            did[10],
            did[11],
            did[12],
            did[13],
            did[14],
            did[15],
            particularRepository.getPidsByParticular(report)
        );

        reportsDTO.add(reportsSumDTO);

        log.debug(new java.util.Date() + "Received Data.");

        return reportsDTO;
    }

    public PenaltyReport getCircleWiseSummaryOfPenalties(LocalDate fromdate, LocalDate todate) {
        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatus("Submitted", fromdate, todate, 0l);

        PenaltyReport penaltyReport = new PenaltyReport();

        String headers[] = {
            "Circle",
            "Count",
            "Penalty",
            "Disposed Count",
            "Disposed Penal Amount",
            "Reversed By RBI",
            "Waived By RBI",
            "Non-Recoverable",
            "Recovered from Staff",
            "Recovered from the Outsourcing Agency",
        };

        Map<String, List<PenaltyUpdation>> grouping = new TreeMap<>(
            allData.stream().collect(Collectors.groupingBy(w -> w.getCurrencyChest().getCircle().getCircleName()))
        );

        List<String> all_circles = circleRepository.findAllCirlces();

        String data[][] = new String[all_circles.size() + 1][headers.length];

        Double sums[] = new Double[9];

        for (int i = 0; i < 9; i++) sums[i] = 0d;

        int i = 0;
        for (i = 0; i < grouping.size(); i++) {
            Double amount = grouping.get(grouping.keySet().toArray()[i]).stream().mapToDouble(o -> o.getAmount()).sum();
            Long sum = grouping.get(grouping.keySet().toArray()[i]).stream().filter(o -> o.getDisposal() != null).count();
            Double sum1 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null)
                .mapToDouble(o -> o.getAmount())
                .sum();

            Double sum2 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since reversed by RBI"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum3 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since waived by RBI"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum4 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Non-Recoverable declared by CMC"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum5 = grouping
                    .get(grouping.keySet().toArray()[i])
                    .stream()
                    .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from Staff"))
                    .mapToDouble(o -> o.getAmount())
                    .sum();

            Double sum6 = grouping
                    .get(grouping.keySet().toArray()[i])
                    .stream()
                    .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from the Outsourcing Agency"))
                    .mapToDouble(o -> o.getAmount())
                    .sum();

            
            data[i][0] = grouping.keySet().toArray()[i] + "";

            data[i][1] = grouping.get(grouping.keySet().toArray()[i]).size() + "";
            sums[0] += grouping.get(grouping.keySet().toArray()[i]).size();

            data[i][2] = amount + "";
            sums[1] += amount;

            data[i][3] = sum + "";
            sums[2] += sum;

            data[i][4] = sum1 + "";
            sums[3] += sum1;

            data[i][5] = sum2 + "";
            sums[4] += sum2;

            data[i][6] = sum3 + "";
            sums[5] += sum3;

            data[i][7] = sum4 + "";
            sums[6] += sum4;

            data[i][8] = sum5 + "";
            sums[7] += sum5;
            
            data[i][9] = sum6 + "";
            sums[8] += sum6;
        }

        List<String> circles = new ArrayList<>();
        circles.addAll(grouping.keySet());

        all_circles.removeAll(circles);
        int k = 0;
        for (k = 0; k < all_circles.size(); k++) {
            data[grouping.size() + k][0] = all_circles.get(k);
            data[grouping.size() + k][1] = "0";
            data[grouping.size() + k][2] = "0";
            data[grouping.size() + k][3] = "0";
            data[grouping.size() + k][4] = "0";
            data[grouping.size() + k][5] = "0";
            data[grouping.size() + k][6] = "0";
            data[grouping.size() + k][7] = "0";
            data[grouping.size() + k][8] = "0";
            data[grouping.size() + k][9] = "0";
        }

        data[i + k][0] = "Total";
        for (int j = 0; j < 9; j++) data[i + k][j + 1] = sums[j] + "";
        
        
        java.util.Arrays.sort(data, new java.util.Comparator<String[]>() {
            public int compare(String[] a, String[] b) {
                return a[0].compareTo(b[0]);
            }
        });
        
        penaltyReport.setData(data);
        penaltyReport.setHeaders(headers);
        

        return penaltyReport;
    }

//    public PenaltyReport getHeadWiseSummaryOfPenalties(LocalDate fromdate, LocalDate todate) {
//        AppUser user = SecurityUtils.getLoggedInUser();
//        Long fsloCode = user.getBranchCode();
//
//        Set<Role> roles = user.getRoles();
//
//        Role ABD = roleRepository.findByName(RoleConstants.ABD_USER).get();
//        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
//
//        if (roles.contains(ABD) || roles.contains(CIRCLE_ADMIN)) {
//            fsloCode = 0l;
//        }
//
//        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatus("Submitted", fromdate, todate, fsloCode);
//
//        PenaltyReport penaltyReport = new PenaltyReport();
//
//        String headers[] = {
//            "Reason",
//            "Sub Reason",
//            "Count",
//            "Penalty",
//            "Disposed Count",
//            "Disposed Penal Amount",
//            "Reversed By RBI",
//            "Waived By RBI",
//            "Non-Recoverable",
//            "Recovered from Staff",
//            "Recovered from the Outsourcing Agency",
//        };
//
//        Map<String, List<PenaltyUpdation>> grouping = new TreeMap<>(
//            allData
//                .stream()
//                .collect(
//                    Collectors.groupingBy(
//                        w -> {
//                            String group = w.getReason().getReason() + "# ";
//                            if (w.getSubReason() != null) group += w.getSubReason().getSubReason();
//                            return group;
//                        }
//                    )
//                )
//        );
//
//        String data[][] = new String[grouping.size() + 1][headers.length];
//
//        Double sums[] = new Double[9];
//
//        for (int i = 0; i < 9; i++) sums[i] = 0d;
//
//        int i = 0;
//        for (i = 0; i < grouping.size(); i++) {
//            Double amount = grouping.get(grouping.keySet().toArray()[i]).stream().mapToDouble(o -> o.getAmount()).sum();
//            Long sum = grouping.get(grouping.keySet().toArray()[i]).stream().filter(o -> o.getDisposal() != null).count();
//            Double sum1 = grouping
//                .get(grouping.keySet().toArray()[i])
//                .stream()
//                .filter(o -> o.getDisposal() != null)
//                .mapToDouble(o -> o.getAmount())
//                .sum();
//
//            Double sum2 = grouping
//                .get(grouping.keySet().toArray()[i])
//                .stream()
//                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since reversed by RBI"))
//                .mapToDouble(o -> o.getAmount())
//                .sum();
//            Double sum3 = grouping
//                .get(grouping.keySet().toArray()[i])
//                .stream()
//                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since waived by RBI"))
//                .mapToDouble(o -> o.getAmount())
//                .sum();
//            Double sum4 = grouping
//                .get(grouping.keySet().toArray()[i])
//                .stream()
//                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Non-Recoverable declared by CMC"))
//                .mapToDouble(o -> o.getAmount())
//                .sum();
//            Double sum5 = grouping
//                .get(grouping.keySet().toArray()[i])
//                .stream()
//                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from Staff"))
//                .mapToDouble(o -> o.getAmount())
//                .sum();
//            
//            Double sum6 = grouping
//                    .get(grouping.keySet().toArray()[i])
//                    .stream()
//                    .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from the Outsourcing Agency"))
//                    .mapToDouble(o -> o.getAmount())
//                    .sum();
//
//            data[i][0] = grouping.keySet().toArray()[i].toString().split("#")[0].trim();
//            data[i][1] = grouping.keySet().toArray()[i].toString().split("#")[1].trim();
//
//            data[i][2] = grouping.get(grouping.keySet().toArray()[i]).size() + "";
//            sums[0] += grouping.get(grouping.keySet().toArray()[i]).size();
//
//            data[i][3] = amount + "";
//            sums[1] += amount;
//
//            data[i][4] = sum + "";
//            sums[2] += sum;
//
//            data[i][5] = sum1 + "";
//            sums[3] += sum1;
//
//            data[i][6] = sum2 + "";
//            sums[4] += sum2;
//
//            data[i][7] = sum3 + "";
//            sums[5] += sum3;
//
//            data[i][8] = sum4 + "";
//            sums[6] += sum4;
//
//            data[i][9] = sum5 + "";
//            sums[7] += sum5;
//            
//            data[i][10] = sum6 + "";
//            sums[8] += sum6;
//        }
//
//        if (i > 0) {
//            data[i][0] = "";
//            data[i][1] = "Total";
//            for (int j = 0; j < 9; j++) data[i][j + 2] = sums[j] + "";
//
//            penaltyReport.setData(data);
//            penaltyReport.setHeaders(headers);
//        }
//        return penaltyReport;
//    }
//    
    public PenaltyReport getHeadWiseSummaryOfPenalties(LocalDate fromdate, LocalDate todate, String circle,String fslo) {
      
    	List<Long> fslos=getFslos(circle).stream().map(Long::valueOf).collect(Collectors.toList());
        
        if(!fslo.equals("ALL"))
        fslos = fslos.stream().filter(o -> o.equals(Long.valueOf(fslo))).collect(Collectors.toList());
        
        
        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatus("Submitted", fromdate, todate, fslos);

        PenaltyReport penaltyReport = new PenaltyReport();

        String headers[] = {
            "Reason",
            "Sub Reason",
            "Count",
            "Penalty",
            "Disposed Count",
            "Disposed Penal Amount",
            "Reversed By RBI",
            "Waived By RBI",
            "Non-Recoverable",
            "Recovered from Staff",
            "Recovered from the Outsourcing Agency"
        };

        Map<String, List<PenaltyUpdation>> grouping = new TreeMap<>(
            allData
                .stream()
                .collect(
                    Collectors.groupingBy(
                        w -> {
                            String group = w.getReason().getReason() + "# ";
                            if (w.getSubReason() != null) group += w.getSubReason().getSubReason();
                            return group;
                        }
                    )
                )
        );

        String data[][] = new String[grouping.size() + 1][headers.length];

        Double sums[] = new Double[9];

        for (int i = 0; i < 9; i++) sums[i] = 0d;

        int i = 0;
        for (i = 0; i < grouping.size(); i++) {
            Double amount = grouping.get(grouping.keySet().toArray()[i]).stream().mapToDouble(o -> o.getAmount()).sum();
            Long sum = grouping.get(grouping.keySet().toArray()[i]).stream().filter(o -> o.getDisposal() != null).count();
            Double sum1 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null)
                .mapToDouble(o -> o.getAmount())
                .sum();

            Double sum2 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since reversed by RBI"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum3 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since waived by RBI"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum4 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Non-Recoverable declared by CMC"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum5 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from Staff"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            
            Double sum6 = grouping
                    .get(grouping.keySet().toArray()[i])
                    .stream()
                    .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from the Outsourcing Agency"))
                    .mapToDouble(o -> o.getAmount())
                    .sum();

            data[i][0] = grouping.keySet().toArray()[i].toString().split("#")[0].trim();
            data[i][1] = grouping.keySet().toArray()[i].toString().split("#")[1].trim();

            data[i][2] = grouping.get(grouping.keySet().toArray()[i]).size() + "";
            sums[0] += grouping.get(grouping.keySet().toArray()[i]).size();

            data[i][3] = amount + "";
            sums[1] += amount;

            data[i][4] = sum + "";
            sums[2] += sum;

            data[i][5] = sum1 + "";
            sums[3] += sum1;

            data[i][6] = sum2 + "";
            sums[4] += sum2;

            data[i][7] = sum3 + "";
            sums[5] += sum3;

            data[i][8] = sum4 + "";
            sums[6] += sum4;

            data[i][9] = sum5 + "";
            sums[7] += sum5;
            
            data[i][10] = sum6 + "";
            sums[8] += sum6;
        }

        if (i > 0) {
            data[i][0] = "";
            data[i][1] = "Total";
            for (int j = 0; j < 9; j++) data[i][j + 2] = sums[j] + "";

            penaltyReport.setData(data);
            penaltyReport.setHeaders(headers);
        }
        return penaltyReport;
    }

    public PenaltyReport getCircleWiseHeadWiseSummaryOfPenalties(LocalDate fromdate, LocalDate todate) {
        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatus("Submitted", fromdate, todate, 0l);

        PenaltyReport penaltyReport = new PenaltyReport();

        String headers[] = {
            "Circle",
            "Reason",
            "Sub Reason",
            "Count",
            "Penalty",
            "Disposed Count",
            "Disposed Penal Amount",
            "Reversed By RBI",
            "Waived By RBI",
            "Non-Recoverable",
            "Recovered from Staff",
            "Recovered from the Outsourcing Agency"
        };

        Map<String, List<PenaltyUpdation>> grouping = new TreeMap<>(
            allData
                .stream()
                .collect(
                    Collectors.groupingBy(
                        w -> {
                            String group = w.getCurrencyChest().getCircle().getCircleName() + "#" + w.getReason().getReason() + "# ";
                            if (w.getSubReason() != null) group += w.getSubReason().getSubReason();
                            return group;
                        }
                    )
                )
        );

        String data[][] = new String[grouping.size() + 1][headers.length];

        Double sums[] = new Double[9];

        for (int i = 0; i < 9; i++) sums[i] = 0d;

        int i = 0;
        for (i = 0; i < grouping.size(); i++) {
            Double amount = grouping.get(grouping.keySet().toArray()[i]).stream().mapToDouble(o -> o.getAmount()).sum();
            Long sum = grouping.get(grouping.keySet().toArray()[i]).stream().filter(o -> o.getDisposal() != null).count();
            Double sum1 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null)
                .mapToDouble(o -> o.getAmount())
                .sum();

            Double sum2 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since reversed by RBI"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum3 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Since waived by RBI"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum4 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Non-Recoverable declared by CMC"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            Double sum5 = grouping
                .get(grouping.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from Staff"))
                .mapToDouble(o -> o.getAmount())
                .sum();
            
            Double sum6 = grouping
                    .get(grouping.keySet().toArray()[i])
                    .stream()
                    .filter(o -> o.getDisposal() != null && o.getDisposal().getDisposal().equals("Recovered from the Outsourcing Agency"))
                    .mapToDouble(o -> o.getAmount())
                    .sum();

            data[i][0] = grouping.keySet().toArray()[i].toString().split("#")[0].trim();
            data[i][1] = grouping.keySet().toArray()[i].toString().split("#")[1].trim();
            data[i][2] = grouping.keySet().toArray()[i].toString().split("#")[2].trim();

            data[i][3] = grouping.get(grouping.keySet().toArray()[i]).size() + "";
            sums[0] += grouping.get(grouping.keySet().toArray()[i]).size();

            data[i][4] = amount + "";
            sums[1] += amount;

            data[i][5] = sum + "";
            sums[2] += sum;

            data[i][6] = sum1 + "";
            sums[3] += sum1;

            data[i][7] = sum2 + "";
            sums[4] += sum2;

            data[i][8] = sum3 + "";
            sums[5] += sum3;

            data[i][9] = sum4 + "";
            sums[6] += sum4;

            data[i][10] = sum5 + "";
            sums[7] += sum5;
            
            data[i][11] = sum6 + "";
            sums[8] += sum6;
        }
        if (i > 0) {
            data[i][0] = "";
            data[i][1] = "";
            data[i][2] = "Total";
            for (int j = 0; j < 9; j++) data[i][j + 3] = sums[j] + "";
            penaltyReport.setData(data);
            penaltyReport.setHeaders(headers);
        }
        return penaltyReport;
    }

    public PenaltyReport getPenaltyUpdationStatus(LocalDate fromdate, LocalDate todate) {
        List<PenaltyData> allData = penaltyDataRepository.findByStatusOrderByFsloFsloBranchCodeAsc("New", fromdate, todate);

        List<Long> allFslos = fsloRepository.findAllFslos();

        PenaltyReport penaltyReport = new PenaltyReport();

        String headers[] = { "FSLO", "Branch", "Count", "Total", "Count", "Posted", "Count", "Not Posted" };

        Map<Long, List<PenaltyData>> allDataGroup = new TreeMap<>(
            allData
                .stream()
                .collect(
                    Collectors.groupingBy(
                        w -> {
                            Long fslo = w.getFslo().getFslo().getBranchCode();
                            return fslo;
                        }
                    )
                )
        );

        String data[][] = new String[allFslos.size() + 1][headers.length];

        Double sums[] = new Double[6];

        for (int i = 0; i < 6; i++) sums[i] = 0d;

        int i = 0;

        for (i = 0; i < allDataGroup.size(); i++) {
            Double amount = allDataGroup.get(allDataGroup.keySet().toArray()[i]).stream().mapToDouble(o -> o.getDebit()).sum();
            Long count = allDataGroup.get(allDataGroup.keySet().toArray()[i]).stream().count();

            Double amount1 = allDataGroup
                .get(allDataGroup.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getPostedStatus() != null && o.getPostedStatus().equals("Submitted"))
                .mapToDouble(o -> o.getDebit())
                .sum();
            Long count1 = allDataGroup
                .get(allDataGroup.keySet().toArray()[i])
                .stream()
                .filter(o -> o.getPostedStatus() != null && o.getPostedStatus().equals("Submitted"))
                .count();

            data[i][0] = allDataGroup.keySet().toArray()[i].toString();
            data[i][1] = fsloRepository.findByBranchCode(Long.valueOf(allDataGroup.keySet().toArray()[i].toString())).get().getBranchName();

            data[i][2] = count + "";
            sums[0] += count;

            data[i][3] = amount + "";
            sums[1] += amount;

            data[i][4] = count1 + "";
            sums[2] += count1;

            data[i][5] = amount1 + "";
            sums[3] += amount1;

            data[i][6] = (count - count1) + "";
            sums[4] += (count - count1);

            data[i][7] = (amount - amount1) + "";
            sums[5] += (amount - amount1);
        }

        DecimalFormat df = new DecimalFormat("0.00");

        List<Long> fslos = new ArrayList<>();
        fslos.addAll(allDataGroup.keySet());
        allFslos.removeAll(fslos);

        //System.out.println(fslos + " " + allFslos);

        int k = 0;
        for (k = 0; k < allFslos.size(); k++) {
            data[i + k][0] = allFslos.get(k) + "";
            data[i + k][1] = fsloRepository.findByBranchCode(allFslos.get(k)).get().getBranchName();
            data[i + k][2] = "0";
            data[i + k][3] = "0";
            data[i + k][4] = "0";
            data[i + k][5] = "0";
            data[i + k][6] = "0";
            data[i + k][7] = "0";
        }

        data[i + k][0] = "";
        data[i + k][1] = "Total";
        for (int j = 0; j < 6; j++) data[i + k][j + 2] = df.format(sums[j]);

        penaltyReport.setData(data);
        penaltyReport.setHeaders(headers);

        return penaltyReport;
    }

    public PenaltyReport getRBIPenaltyOrPenaltyInterestReport(LocalDate fromdate, LocalDate todate) {
        AppUser user = SecurityUtils.getLoggedInUser();
        Long fsloCode = user.getBranchCode();

        Set<Role> roles = user.getRoles();

        Role ABD = roleRepository.findByName(RoleConstants.ABD_USER).get();
        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();

        if (roles.contains(ABD) || roles.contains(CIRCLE_ADMIN)) {
            fsloCode = 0l;
        }

        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatusOrderByNarrationFsloFsloBranchCodeAsc(
            "Submitted",
            fromdate,
            todate,
            fsloCode
        );

        PenaltyReport penaltyReport = new PenaltyReport();

        String[] headers = {
            "Circle",
            "Type",
            "Report Date",
            "Br. Code",
            "Br.Name",
            "FSLO",
            "Penalty Reason",
            "Penalty Sub Reason",
            "Amount",
            "Disposal of Penalty",
        };

        String[][] data = new String[allData.size()][headers.length];

        for (int i = 0; i < allData.size(); i++) {
            PenaltyUpdation penalty = allData.get(i);
            data[i][0] = penalty.getNarration().getFslo().getFslo().getCircle().getCircleName();
            data[i][1] = penalty.getReason().getType().getType();
            data[i][2] = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(penalty.getNarration().getReportDate()) + "";
            data[i][3] = penalty.getCurrencyChest().getBranchCode() + "";
            data[i][4] = penalty.getCurrencyChest().getBranchName();
            data[i][5] = penalty.getNarration().getFslo().getFslo().getBranchCode() + "";
            data[i][6] = penalty.getReason().getReason();
            if (penalty.getSubReason() != null) data[i][7] = penalty.getSubReason().getSubReason(); else data[i][7] = "";
            data[i][8] = penalty.getAmount() + "";
            if (penalty.getDisposal() != null) data[i][9] = penalty.getDisposal().getDisposal(); else data[i][9] = "0.0";
        }
        penaltyReport.setData(data);

        penaltyReport.setHeaders(headers);
        return penaltyReport;
    }
    
    
    public PenaltyReport getRBIPenaltyOrPenaltyInterestReport(LocalDate fromdate, LocalDate todate,String circle, String fslo) {
       
	List<Long> fslos=getFslos(circle).stream().map(Long::valueOf).collect(Collectors.toList());
        
        if(!fslo.equals("ALL"))
        fslos = fslos.stream().filter(o -> o.equals(Long.valueOf(fslo))).collect(Collectors.toList());
        
        
    	
    	
        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatusOrderByNarrationFsloFsloBranchCodeAsc(
            "Submitted",
            fromdate,
            todate,
            fslos
        );

        PenaltyReport penaltyReport = new PenaltyReport();

        String[] headers = {
            "Circle",
            "Type",
            "Report Date",
            "Br. Code",
            "Br.Name",
            "FSLO",
            "Penalty Reason",
            "Penalty Sub Reason",
            "Amount",
            "Disposal of Penalty",
        };

        String[][] data = new String[allData.size()][headers.length];

        for (int i = 0; i < allData.size(); i++) {
            PenaltyUpdation penalty = allData.get(i);
            data[i][0] = penalty.getNarration().getFslo().getFslo().getCircle().getCircleName();
            data[i][1] = penalty.getReason().getType().getType();
            data[i][2] = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(penalty.getNarration().getReportDate()) + "";
            data[i][3] = penalty.getCurrencyChest().getBranchCode() + "";
            data[i][4] = penalty.getCurrencyChest().getBranchName();
            data[i][5] = penalty.getNarration().getFslo().getFslo().getBranchCode() + "";
            data[i][6] = penalty.getReason().getReason();
            if (penalty.getSubReason() != null) data[i][7] = penalty.getSubReason().getSubReason(); else data[i][7] = "";
            data[i][8] = penalty.getAmount() + "";
            if (penalty.getDisposal() != null) data[i][9] = penalty.getDisposal().getDisposal(); else data[i][9] = "0.0";
        }
        penaltyReport.setData(data);

        penaltyReport.setHeaders(headers);
        return penaltyReport;
    }

//    public PenaltyReport getFullSummaryOfPenalties(LocalDate fromdate, LocalDate todate) {
//        AppUser user = SecurityUtils.getLoggedInUser();
//        Long fsloCode = user.getBranchCode();
//
//        Set<Role> roles = user.getRoles();
//
//        Role ABD = roleRepository.findByName(RoleConstants.ABD_USER).get();
//        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
//
//        if (roles.contains(ABD) || roles.contains(CIRCLE_ADMIN)) {
//            fsloCode = 0l;
//        }
//
//        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatusOrderByNarrationFsloFsloBranchCodeAsc(
//            "Submitted",
//            fromdate,
//            todate,
//            fsloCode
//        );
//
//        PenaltyReport penaltyReport = new PenaltyReport();
//
//        String[] headers = {
//            "Report Date",
//            "Circle",
//            "NW",
//            "Zone",
//            "Region",
//            "FSLO",
//            "Br. Code",
//            "Br.Name",
//            "Penalty Reason",
//            "Penalty Sub Reason",
//            "Penalty Amount",
//            "Disposed Penal Amount",
//            "Reversed By RBI",
//            "Waived By RBI",
//            "Non-Recoverable",
//            "Recovered from Staff",
//            "Recovered from the Outsourcing Agency"
//        };
//
//        String[][] data = new String[allData.size()][headers.length];
//
//        for (int i = 0; i < allData.size(); i++) {
//            PenaltyUpdation penalty = allData.get(i);
//            data[i][0] = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(penalty.getNarration().getReportDate()) + "";
//            data[i][1] = penalty.getCurrencyChest().getCircle().getCircleName();
//            data[i][2] = penalty.getCurrencyChest().getNetwork().getNetworkCode() + "";
//            data[i][3] = penalty.getCurrencyChest().getModule().getModuleName();
//            data[i][4] = penalty.getCurrencyChest().getRegion().getRegionCode() + "";
//            data[i][5] = penalty.getNarration().getFslo().getFslo().getBranchCode() + "";
//            data[i][6] = penalty.getCurrencyChest().getBranchCode() + "";
//            data[i][7] = penalty.getCurrencyChest().getBranchName();
//            data[i][8] = penalty.getReason().getReason();
//            if (penalty.getSubReason() != null) data[i][9] = penalty.getSubReason().getSubReason(); else data[i][9] = "";
//            data[i][10] = penalty.getAmount() + "";
//
//            if (penalty.getDisposal() != null) {
//                String disposal = penalty.getDisposal().getDisposal();
//                data[i][11] = penalty.getAmount() + "";
//                if (disposal.equals("Since reversed by RBI")) data[i][12] = penalty.getAmount() + ""; else data[i][12] = "0.0";
//                if (disposal.equals("Since waived by RBI")) data[i][13] = penalty.getAmount() + ""; else data[i][13] = "0.0";
//                if (disposal.equals("Non-Recoverable declared by CMC")) data[i][14] = penalty.getAmount() + ""; else data[i][14] = "0.0";
//                if (disposal.equals("Recovered from Staff")) data[i][15] = penalty.getAmount() + ""; else data[i][15] = "0.0";
//                if (disposal.equals("Recovered from the Outsourcing Agency")) data[i][16] = penalty.getAmount() + ""; else data[i][16] = "0.0";
//            } else {
//                data[i][11] = "0.0";
//                data[i][12] = "0.0";
//                data[i][13] = "0.0";
//                data[i][14] = "0.0";
//                data[i][15] = "0.0";
//                data[i][16] = "0.0";
//            }
//        }
//        penaltyReport.setData(data);
//        penaltyReport.setHeaders(headers);
//        return penaltyReport;
//    }
//    
    public PenaltyReport getFullSummaryOfPenalties(LocalDate fromdate, LocalDate todate, String circle, String fslo) {
    	List<Long> fslos=getFslos(circle).stream().map(Long::valueOf).collect(Collectors.toList());
        
        if(!fslo.equals("ALL"))
        fslos = fslos.stream().filter(o -> o.equals(Long.valueOf(fslo))).collect(Collectors.toList());
        

        List<PenaltyUpdation> allData = penaltyUpdationRepository.findByStatusOrderByNarrationFsloFsloBranchCodeAsc(
            "Submitted",
            fromdate,
            todate,
            fslos
        );

        PenaltyReport penaltyReport = new PenaltyReport();

        String[] headers = {
            "Report Date",
            "Circle",
            "NW",
            "Zone",
            "Region",
            "FSLO",
            "Br. Code",
            "Br.Name",
            "Penalty Reason",
            "Penalty Sub Reason",
            "Penalty Amount",
            "Disposed Penal Amount",
            "Reversed By RBI",
            "Waived By RBI",
            "Non-Recoverable",
            "Recovered from Staff",
            "Recovered from the Outsourcing Agency"
        };

        String[][] data = new String[allData.size()][headers.length];

        for (int i = 0; i < allData.size(); i++) {
            PenaltyUpdation penalty = allData.get(i);
            data[i][0] = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(penalty.getNarration().getReportDate()) + "";
            data[i][1] = penalty.getCurrencyChest().getCircle().getCircleName();
            data[i][2] = penalty.getCurrencyChest().getNetwork().getNetworkCode() + "";
            data[i][3] = penalty.getCurrencyChest().getModule().getModuleName();
            data[i][4] = penalty.getCurrencyChest().getRegion().getRegionCode() + "";
            data[i][5] = penalty.getNarration().getFslo().getFslo().getBranchCode() + "";
            data[i][6] = penalty.getCurrencyChest().getBranchCode() + "";
            data[i][7] = penalty.getCurrencyChest().getBranchName();
            data[i][8] = penalty.getReason().getReason();
            if (penalty.getSubReason() != null) data[i][9] = penalty.getSubReason().getSubReason(); else data[i][9] = "";
            data[i][10] = penalty.getAmount() + "";

            if (penalty.getDisposal() != null) {
                String disposal = penalty.getDisposal().getDisposal();
                data[i][11] = penalty.getAmount() + "";
                if (disposal.equals("Since reversed by RBI")) data[i][12] = penalty.getAmount() + ""; else data[i][12] = "0.0";
                if (disposal.equals("Since waived by RBI")) data[i][13] = penalty.getAmount() + ""; else data[i][13] = "0.0";
                if (disposal.equals("Non-Recoverable declared by CMC")) data[i][14] = penalty.getAmount() + ""; else data[i][14] = "0.0";
                if (disposal.equals("Recovered from Staff")) data[i][15] = penalty.getAmount() + ""; else data[i][15] = "0.0";
                if (disposal.equals("Recovered from the Outsourcing Agency")) data[i][16] = penalty.getAmount() + ""; else data[i][16] = "0.0";
            } else {
                data[i][11] = "0.0";
                data[i][12] = "0.0";
                data[i][13] = "0.0";
                data[i][14] = "0.0";
                data[i][15] = "0.0";
                data[i][16] = "0.0";
            }
        }
        penaltyReport.setData(data);
        penaltyReport.setHeaders(headers);
        return penaltyReport;
    }
    
    

//    @Transactional
//    public PenaltyReport getPenaltyReports(LocalDate fromdate, LocalDate todate, String report) {
//        if (report.equals("CIRCLEWISE SUMMARY OF PENALTIES")) return getCircleWiseSummaryOfPenalties(fromdate, todate); else if (
//            report.equals("CIRCLE WISE HEAD WISE SUMMARY OF PENALTIES")
//        ) return getCircleWiseHeadWiseSummaryOfPenalties(fromdate, todate); else if (
//            report.equals("HEAD WISE SUMMARY OF PENALTIES")
//        ) return getHeadWiseSummaryOfPenalties(fromdate, todate); else if (
//            report.equals("PENALTY UPDATION STATUS")
//        ) return getPenaltyUpdationStatus(fromdate, todate); else if (
//            report.equals("REPORT OF RBI PENALTY OR PENAL INTEREST")
//        ) return getRBIPenaltyOrPenaltyInterestReport(fromdate, todate); else if (
//            report.equals("FULL SUMMARY OF PENALTIES")
//        ) return getFullSummaryOfPenalties(fromdate, todate); else return null;
//    }
    
    @Transactional
    public PenaltyReport getPenaltyReports(LocalDate fromdate, LocalDate todate, String report, String circle,String fslo) {
        if (report.equals("CIRCLEWISE SUMMARY OF PENALTIES")) return getCircleWiseSummaryOfPenalties(fromdate, todate); else if (
            report.equals("CIRCLE WISE HEAD WISE SUMMARY OF PENALTIES")
        ) return getCircleWiseHeadWiseSummaryOfPenalties(fromdate, todate); else if (
            report.equals("HEAD WISE SUMMARY OF PENALTIES")
        ) return getHeadWiseSummaryOfPenalties(fromdate, todate,circle,fslo); else if (
            report.equals("PENALTY UPDATION STATUS")
        ) return getPenaltyUpdationStatus(fromdate, todate); else if (
            report.equals("REPORT OF RBI PENALTY OR PENAL INTEREST")
        ) return getRBIPenaltyOrPenaltyInterestReport(fromdate, todate,circle,fslo); else if (
            report.equals("FULL SUMMARY OF PENALTIES")
        ) return getFullSummaryOfPenalties(fromdate, todate,circle,fslo); else return null;
    }

    public LocalDate rbiPenaltyLatestUploadedDate() {
        // TODO Auto-generated method stub
        return penaltyDataRepository.findByLatestUploadedDate();
    }

    public void saveWithPenaltyWithNoData(LocalDate date, String ipaddress) {
        NoPenaltyDataFoundDates noPenaltyDataFoundDates = new NoPenaltyDataFoundDates();
        noPenaltyDataFoundDates.setPfid(SecurityUtils.getLoggedInUser().getId());
        noPenaltyDataFoundDates.setIpaddress(ipaddress);
        noPenaltyDataFoundDates.setReportDate(date);
        noPenaltyDataFoundDatesRepository.save(noPenaltyDataFoundDates);
    }

    public List<String> getCircles() {
        return chestSlipUploadDetailsRepository.getCircles();
    }

    public List<String> getNetworks(String circle) {
        return chestSlipUploadDetailsRepository.getNetworks(circle);
    }

    public List<String> getModules(String circle, String network) {
        return chestSlipUploadDetailsRepository.getModules(circle, network);
    }

    public List<String> getRegions(String circle, String network, String module) {
        return chestSlipUploadDetailsRepository.getRegions(circle, network, module);
    }

	public List<String> getFslos(String circle) {
		
		Long circleCode=0l;
		Optional<Circle> circleDetails = circleRepository.findByCircleName(circle);
		
		if(circleDetails.isPresent())
		{
			circleCode=circleDetails.get().getCircleCode();
		}
		
		 return chestSlipUploadDetailsRepository.getFslos(circleCode);
		
	}

	@Transactional
	public Boolean splitPenaltyAmount(String id, String amount) {
		
		Optional<PenaltyUpdation> penaltyUpdation = penaltyUpdationRepository.findById(Long.valueOf(id));
		
		try
		{
		if(penaltyUpdation.get().getAmount()-Double.parseDouble(amount) <= 0)
			return false;
		
		if(penaltyUpdation.isPresent())
		{
			penaltyUpdation.get().setAmount(penaltyUpdation.get().getAmount()-Double.parseDouble(amount));
			penaltyUpdationRepository.save(penaltyUpdation.get());
			PenaltyUpdation pData1=new PenaltyUpdation(penaltyUpdation.get(),Double.parseDouble(amount));
			penaltyUpdationRepository.save(pData1);
			return true;
			
		}
		}
		catch(NumberFormatException ex)
		{
		return false;	
		}
	return false;
	}
}
