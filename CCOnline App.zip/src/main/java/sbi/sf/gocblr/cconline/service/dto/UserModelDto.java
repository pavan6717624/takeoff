package sbi.sf.gocblr.cconline.service.dto;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.User;
import sbi.sf.gocblr.cconline.domain.UserSession;

/**
 * User DTO only containing what is required at front-end
 *
 * @author Kiran Marturu
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class UserModelDto {

    private Long id;
    private String title;
    private String name;
    private String designation;
    private Long branchCode;
    private String branchName;
    private Long mobileNo;
    private String emailId;
    private Set<Role> roles = new HashSet<>();
    private LocalDateTime lastLogin;
    private boolean deleted;
    private boolean approved = false;
    private Long networkCode;

    private Boolean present;

    public UserModelDto(User user) {
        this.id = user.getId();
        this.title = user.getTitle();
        this.name = user.getName();
        this.designation = user.getDesignation();
        this.branchCode = user.getBranch().getBranchCode();
        this.branchName = user.getBranch().getBranchName();
        this.mobileNo = user.getMobileNo();
        this.emailId = user.getEmailId();
        this.roles = user.getRoles();
        this.lastLogin = user.getLastLogin();
        this.deleted = Boolean.TRUE.equals(user.getIsDeleted());
        this.approved = Boolean.TRUE.equals(user.isApproved());

        if (user.getNetwork() != null) {
            this.networkCode = user.getNetwork().getNetworkCode();
        }
    }

    public UserModelDto(UserSession user) {
        this.id = user.getPfId();
        this.title = user.getTitle();
        this.name = user.getName();
        this.branchCode = user.getBranchCode();
        this.branchName = user.getBranchName();
        this.roles = user.getRoles();

        if (user.getNetworkCode() != null) {
            this.networkCode = user.getNetworkCode();
        }
    }
}
