package sbi.sf.gocblr.cconline.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.SmsStatus;

public interface SmsStatusRepository extends JpaRepository<SmsStatus, Long> {}
