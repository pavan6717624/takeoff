package sbi.sf.gocblr.cconline.web;

import com.auth10.federation.Claim;
import com.auth10.federation.FederatedLoginManager;
import com.auth10.federation.FederatedPrincipal;
import com.auth10.federation.FederationException;
import com.pspl.adfs.sso.SamlAttributeName;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.UserSession;
import sbi.sf.gocblr.cconline.model.SsoClaimsModel;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.AppUserDetailsService;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.security.jwt.TokenProvider;
import sbi.sf.gocblr.cconline.service.ActivityLogService;
import sbi.sf.gocblr.cconline.service.UserSessionService;
import sbi.sf.gocblr.cconline.utils.JsonUtils;
import sbi.sf.gocblr.cconline.utils.NumberUtils;
import sbi.sf.gocblr.cconline.utils.TextUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.JustResponseMessage;
import sbi.sf.gocblr.cconline.web.vm.LoginResponseViewModel;

/**
 * Handle login related flows
 *
 * @author Kiran Marturu
 *
 */
@Profile("sso")
@Slf4j
@Controller
@RequestMapping("/api")
@RequiredArgsConstructor
@PropertySource("classpath:federation.properties")
public class LoginSsoController {

    private static final String LOGIN_RESPONSE = "_loginResponse";

    private final ApplicationProperties applicationProperties;
    private final TokenProvider tokenProvider;
    private final AppUserDetailsService appUserDetailsService;
    private final UserSessionService userSessionService;
    private final ActivityLogService activity;

    @Value("${federation.reply}")
    private String adfsWctx;

    @Value("${federation.realm}")
    private String federationRealm;

    @GetMapping("/login")
    public void login(HttpServletRequest request, HttpServletResponse response) {
        String redirect = FederatedLoginManager.getFederatedLoginUrl(adfsWctx);
        response.setHeader("Location", redirect);
        response.setStatus(302);
    }

    @PostMapping("/login")
    public String ssoLogin(HttpServletRequest request, HttpServletResponse response, Model model) {
        log.debug(">> ssoLogin()");

        boolean isLoginSuccessful = false;
        String token = "";
        String message = "";

        String wresult = request.getParameter("wresult");

        if (wresult != null) {
            try {
                FederatedLoginManager loginManager = FederatedLoginManager.fromRequest(request);
                FederatedPrincipal principal = loginManager.authenticate(wresult);

                List<Claim> claimsSSO = principal.getClaims();
                log.warn("SSO Claims: {}", JsonUtils.toString(claimsSSO));

                SsoClaimsModel ssoClaimModel = mapSsoClaimsToSsoClaimsModel(claimsSSO);

                String serializedSsoClaimModel = JsonUtils.toString(ssoClaimModel);
                AppUser appUser = appUserDetailsService.loadUserByUsername(serializedSsoClaimModel);
                Set<Role> roles = appUser.getRoles();
                roles.stream().forEach(r -> log.debug(r.getName()));

                UserSession session = userSessionService.createSession(appUser);

                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                    appUser,
                    null,
                    appUser.getAuthorities()
                );

                SecurityContextHolder.getContext().setAuthentication(authentication);

                activity.logActivity(
                    "LOGIN",
                    Map.of("roles", String.join(",", session.getRoles().stream().map(Role::getAuthority).collect(Collectors.toList())))
                );

                isLoginSuccessful = true;
                token = tokenProvider.createToken(authentication, session.getId());
            } catch (AuthenticationException ex) {
                log.warn(ex.getMessage(), ex.getMessage());
                message = ex.getMessage();
            } catch (NumberFormatException | FederationException ex) {
                log.error(ex.getMessage(), ex);
                message = "There is an issue in data recieved from SSO";
            }
        } else {
            message = "No data recieved from SSO, Please try after sometime.";
        }

        model.addAttribute(LOGIN_RESPONSE, JsonUtils.toString(new LoginResponseViewModel(isLoginSuccessful, message, token)));
        model.addAttribute("_feCallBackUrl", applicationProperties.getFrontEndLoginCallBackUrl());

        model.addAttribute("isLoginSuccessful", isLoginSuccessful);
        model.addAttribute("message", message);
        model.addAttribute("token", token);
        model.addAttribute("fe", applicationProperties.getFrontEndLoginCallBackUrl());

        return "redirectToSpa";
    }

    private SsoClaimsModel mapSsoClaimsToSsoClaimsModel(List<Claim> claimsSSO) {
        SsoClaimsModel ssoClaimModel = new SsoClaimsModel();
        String pfId = TextUtils.trim(claimsSSO.get(SamlAttributeName.PF_INDEX).getClaimValue());
        ssoClaimModel.setPfId(Long.parseLong(pfId));
        ssoClaimModel.setTitle(claimsSSO.get(SamlAttributeName.TITLE).getClaimValue());
        ssoClaimModel.setName(claimsSSO.get(SamlAttributeName.EMP_NAME).getClaimValue());
        ssoClaimModel.setEmployeeGroupCode(claimsSSO.get(SamlAttributeName.EG).getClaimValue());

        ssoClaimModel.setEmployeeSubGroupCode(claimsSSO.get(SamlAttributeName.ESG).getClaimValue());

        ssoClaimModel.setDesignation(claimsSSO.get(SamlAttributeName.EMPLOYEE_SUB_GROUP).getClaimValue());

        ssoClaimModel.setPosition(claimsSSO.get(SamlAttributeName.POSITION).getClaimValue());
        ssoClaimModel.setEmailId(claimsSSO.get(SamlAttributeName.OFF_MAIL_ID).getClaimValue());
        ssoClaimModel.setMobileNo(claimsSSO.get(SamlAttributeName.MOB_NO).getClaimValue());

        String psa = TextUtils.trim(claimsSSO.get(SamlAttributeName.PSA).getClaimValue());
        if (NumberUtils.isValidInt(psa)) {
            ssoClaimModel.setBranchCode(Long.parseLong(psa));
        } else {
            log.warn("PSA is null for {}", claimsSSO.get(SamlAttributeName.PF_INDEX).getClaimValue());
            ssoClaimModel.setBranchCode(0L);
        }

        ssoClaimModel.setBranchName(claimsSSO.get(SamlAttributeName.PERSONNEL_SUB_A).getClaimValue());
        return ssoClaimModel;
    }

    @PostMapping("/logout")
    public ResponseEntity<JustResponseMessage> logoutSession() {
        AppUser loggedInUser = SecurityUtils.getLoggedInUser();
        if (loggedInUser != null) {
            userSessionService.blackListUserSession(loggedInUser.getId(), loggedInUser.getSessionId(), "logged out");
        }
        return ResponseEntity.ok(new JustResponseMessage("Logged out"));
    }

    @GetMapping("/logout")
    public void logout(HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirect) throws IOException {
        log.debug(">> logout");
        String appUrl = federationRealm + "api/logout/result";
        response.sendRedirect(String.format("%s%s", applicationProperties.getSsoLogoutUrl(), URLEncoder.encode(appUrl, "UTF-8")));
    }

    @GetMapping("/logout/result")
    public String logoutResult() {
        return "redirect:" + applicationProperties.getFrontEndUrl();
    }
}
