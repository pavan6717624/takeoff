package sbi.sf.gocblr.cconline.domain.enums;

/**
 * Currency chest class types
 * @author Kiran
 *
 */
public enum CcClass {
    A,
    B,
    C,
    D;

    public static CcClass fromCode(String code) {
        for (CcClass c : CcClass.values()) {
            if (c.toString().equalsIgnoreCase(code)) {
                return c;
            }
        }
        return null;
    }
}
