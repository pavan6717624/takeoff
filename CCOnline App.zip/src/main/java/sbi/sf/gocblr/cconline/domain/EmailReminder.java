package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.Data;
import sbi.sf.gocblr.cconline.model.enums.ReminderTo;

@Data
@Entity
@Table(
    name = "email_reminders",
    uniqueConstraints = @UniqueConstraint(name = "uk_email_reminders", columnNames = { "reminder_for", "to_be_sent_to", "for_date" })
)
public class EmailReminder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "reminder_for", length = 1000)
    private String reminderFor;

    @Column(name = "to_be_sent_to")
    @Enumerated(EnumType.STRING)
    private ReminderTo toBeSentTo;

    @Column(name = "pendency_for")
    private Integer pendencyFor;

    @Column(name = "for_date")
    private LocalDate forDate;

    @Column(name = "triggered_by")
    private Long triggeredBy;

    @Column(name = "triggered_on")
    private LocalDateTime triggeredOn;
}
