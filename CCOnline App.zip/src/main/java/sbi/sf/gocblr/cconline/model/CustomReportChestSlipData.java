package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import sbi.sf.gocblr.cconline.domain.enums.PopulationGroup;

public interface CustomReportChestSlipData {
    LocalDate getChestSlipDate();
    Long getBranchCode();
    String getBranchName();
    Long getFsloBranchCode();
    String getCircleName();
    Long getNetworkCode();
    Long getModuleCode();
    String getModuleName();
    Long getRegionCode();
    PopulationGroup getPopulationGroup();
    String getStateName();
    Long getCashBalanceLimit();

    Double getValue();
}
