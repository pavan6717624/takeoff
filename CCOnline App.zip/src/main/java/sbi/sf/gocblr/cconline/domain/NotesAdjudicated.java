package sbi.sf.gocblr.cconline.domain;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "notes_adjudicated")
public class NotesAdjudicated {

    @Id
    private Long id;

    @MapsId
    @EqualsAndHashCode.Include
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id", foreignKey = @ForeignKey(name = "fk_notes_adjudicated_verification"))
    private Verification verification;

    @OneToMany(mappedBy = "notesAdjudicated", cascade = CascadeType.ALL)
    private Set<NotesAdjudicatedDetails> details = new HashSet<>();

    public void addDetails(NotesAdjudicatedDetails data) {
        this.details.add(data);
        data.setNotesAdjudicated(this);
    }
}
