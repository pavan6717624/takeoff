package sbi.sf.gocblr.cconline.domain.enums;

public enum CcCloseStatus {
    PENDING("P", "Pending for Approval"),
    APPROVED("A", "Approved"),
    REJECTED("R", "Rejected");

    private final String code;
    private final String description;

    CcCloseStatus(String code, String desc) {
        this.code = code;
        this.description = desc;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static CcCloseStatus fromCode(String code) {
        for (CcCloseStatus j : CcCloseStatus.values()) {
            if (j.code.equalsIgnoreCase(code)) {
                return j;
            }
        }

        return null;
    }
}
