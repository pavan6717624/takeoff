package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.RBIFSLOMapping;

public interface RBIFSLOMappingRepository extends JpaRepository<RBIFSLOMapping, Long> {
    Optional<RBIFSLOMapping> findByRbiRegionCode(@Param("rbiRegionCode") Integer rbiRegionCode);
}
