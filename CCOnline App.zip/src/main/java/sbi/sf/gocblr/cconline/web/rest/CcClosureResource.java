package sbi.sf.gocblr.cconline.web.rest;

import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import sbi.sf.gocblr.cconline.service.CcClosureService;
import sbi.sf.gocblr.cconline.web.rest.vm.CcClosureDataVM;
import sbi.sf.gocblr.cconline.web.rest.vm.CcClosureModel;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class CcClosureResource {

    private final CcClosureService service;

    @ResponseBody
    @PostMapping("/ccclosure/fetch")
    public CcClosureDataVM fetchCcClosure(@RequestBody @Valid CcClosureModel submitData) {
        return service.fetchCcClosure(submitData);
    }

    @ResponseBody
    @PostMapping("/ccclosure/submit")
    public ResponseEntity<Object> submitCcClosure(@RequestBody @Valid CcClosureModel submitData) {
        service.submitCcClosure(submitData);
        return ResponseEntity.ok().build();
    }
}
