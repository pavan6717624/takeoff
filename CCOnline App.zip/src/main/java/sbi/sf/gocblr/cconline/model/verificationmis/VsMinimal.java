package sbi.sf.gocblr.cconline.model.verificationmis;

public interface VsMinimal {
    long getId();
    String getDisplayNo();
}
