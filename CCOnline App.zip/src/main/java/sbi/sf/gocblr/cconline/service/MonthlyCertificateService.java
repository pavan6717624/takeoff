package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateData;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateStatus;
import sbi.sf.gocblr.cconline.domain.MonthlyCertificateStmts;
import sbi.sf.gocblr.cconline.domain.criteria.MonthlyCertificateCriteria;
import sbi.sf.gocblr.cconline.domain.enums.InputType;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.MonthlyCertificateDataRepository;
import sbi.sf.gocblr.cconline.repository.MonthlyCertificateRepository;
import sbi.sf.gocblr.cconline.repository.MonthlyCertificateStatusRepository;
import sbi.sf.gocblr.cconline.repository.RoleRepository;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateDetailedReport;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateSubmissionSummary;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateVsSummary;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateVsYesList;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.utils.TextUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.ChestProfileSaveVM;
import sbi.sf.gocblr.cconline.web.rest.vm.MonthlyCertificateVM;

@Slf4j
@Service
@RequiredArgsConstructor
public class MonthlyCertificateService {

    private static final String INVALID_OPTION = "Invalid option '%s' for %d, should be '%s'";

    private static final Pattern YES_NO_MATCHER = Pattern.compile("((YES)|(NO))");

    private final MonthlyCertificateRepository stmtRepo;
    private final MonthlyCertificateDataRepository dataRepo;
    private final MonthlyCertificateStatusRepository statusRepo;
    private final CurrencyChestService ccService;
    private final CurrencyChestRepository currencyChestRepository;
    private final RoleRepository roleRepository;
    private static final String USER_NOT_HAVING_APPROPRIATE_ROLE = "User not having appropriate role for accessing this resource";

    @Transactional(readOnly = true)
    public MonthlyCertificateDataAndStatusDTO getData(long branchCode, LocalDate month) {
        var data = dataRepo.dataForMonth(branchCode, month);

        MonthlyCertificateDataAndStatusDTO dto = new MonthlyCertificateDataAndStatusDTO();
        dto.setMonthlyCertificateStmts(data);
        dto.setSaved(statusRepo.findByMonthAndCcBranchCode(month, branchCode).isPresent());

        return dto;
    }

    @Transactional
    public List<MonthlyCertificateStmts> getMonthlyCertificateStmtsList() {
        return stmtRepo.findAll();
    }

    @Transactional
    public void submitMonthlyCertificate(Long branchCode, ChestProfileSaveVM submitData) {
        CurrencyChest cc = currencyChestRepository.findByBranchCode(branchCode).orElse(null);

        if (cc == null) {
            throw new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode));
        } else {}
    }

    public MonthlyCertificateStmts getStatement(int id) {
        return stmtRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("No monthly statement found with id: " + id));
    }

    @Transactional
    public void save(long branchCode, MonthlyCertificateVM im) {
        for (Map.Entry<Integer, String> entry : im.getData().entrySet()) {
            log.trace("entry: {} | {}", entry.getKey(), entry.getValue());

            MonthlyCertificateStmts stmt = getStatement(entry.getKey());

            if (isValidSelectedOption(entry.getValue(), stmt.getInputType())) {
                Optional<MonthlyCertificateData> e = dataRepo.findByMonthAndCcBranchCodeAndStatementId(
                    im.getMonth(),
                    branchCode,
                    entry.getKey()
                );

                MonthlyCertificateData toSave;

                // 1. if already saved
                if (e.isPresent()) {
                    toSave = e.get();

                    if (stmt.getInputType() == InputType.YES_NO) {
                        toSave.setOptionInput(entry.getValue());
                    } else if (stmt.getInputType() == InputType.DATE) {
                        toSave.setDateInput(DateUtils.parseIsoDate(entry.getValue()));
                    } else {
                        throw new ValidationException(
                            String.format(INVALID_OPTION, stmt.getInputType(), entry.getKey(), stmt.getInputType())
                        );
                    }
                }
                // 2. saving for first time
                else {
                    toSave = new MonthlyCertificateData();
                    toSave.setCc(ccService.getByBranchCode(branchCode));
                    toSave.setStatement(stmt);
                    toSave.setMonth(im.getMonth());

                    if (stmt.getInputType() == InputType.YES_NO) {
                        toSave.setOptionInput(entry.getValue());
                    } else if (stmt.getInputType() == InputType.DATE) {
                        toSave.setDateInput(DateUtils.parseIsoDate(entry.getValue()));
                    } else {
                        throw new ValidationException(
                            String.format(INVALID_OPTION, stmt.getInputType(), entry.getKey(), stmt.getInputType())
                        );
                    }
                }
                dataRepo.save(toSave);
            } else {
                throw new ValidationException(String.format(INVALID_OPTION, stmt.getInputType(), entry.getKey(), stmt.getInputType()));
            }
        }

        MonthlyCertificateStatus toSaveStatus;
        /* Update status in MonthlyCertificateStatus table on save */
        toSaveStatus = new MonthlyCertificateStatus();
        toSaveStatus.setCc(ccService.getByBranchCode(branchCode));
        toSaveStatus.setMonth(im.getMonth());
        toSaveStatus.setIsSubmitted(true);
        toSaveStatus.setSubmittedOn(LocalDate.now());
        toSaveStatus.setSubmittedBy(SecurityUtils.getLoggedInUser().getId());
        statusRepo.save(toSaveStatus);
    }

    private boolean isValidSelectedOption(String selectedOption, InputType inputType) {
        log.trace("selectedOption: {} | inputType: {}", selectedOption, inputType);

        String so = TextUtils.toUpperCase(selectedOption, true);

        switch (inputType) {
            case YES_NO:
                Matcher m = YES_NO_MATCHER.matcher(so);
                return m.matches();
            case DATE:
                try {
                    DateUtils.parseIsoDate(so);
                    return true;
                } catch (DateTimeParseException e) {
                    log.trace("cannot parse {}", so);
                    log.trace(e.getMessage(), e);
                    return false;
                }
            default:
                return false;
        }
    }

    public MonthlyCertificateSubmissionSummary getSummary(MonthlyCertificateCriteria criteria) {
        return stmtRepo.submissionSummary(criteria);
    }

    //    public List<MonthlyCertificateDetailedReport> getDetails(@NotNull LocalDate month, Long branchCode) {
    //        // TODO Auto-generated method stub
    //        log.debug("Fslo Code: {} | Month: {} ", branchCode, month);
    //        return stmtRepo.monthlyCertificateReport(month, branchCode);
    //    }

    public List<MonthlyCertificateDetailedReport> getDetails(@NotNull LocalDate month) {
        // TODO Auto-generated method stub
        log.trace("Month: {} ", month);
        //return stmtRepo.monthlyCertificateReport(month, branchCode);

        //        AppUser user = SecurityUtils.getLoggedInUser();
        //        Set<Role> roles = user.getRoles();

        //        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        //        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        //        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        //        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        //        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        //        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        //        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        //        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        //        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        Long circleCode = SecurityUtils.getLoggedInUser().getCircleCode();
        Long networkCode = SecurityUtils.getLoggedInUser().getNetworkCode();
        Long moduleCode = SecurityUtils.getLoggedInUser().getModuleCode();
        Long regionCode = SecurityUtils.getLoggedInUser().getRegionCode();
        Long branchCode = SecurityUtils.getLoggedInUser().getBranchCode();

        //        if (roles.contains(FSLO_USER)) {
        //            return stmtRepo.monthlyCertificateReport(month, branchCode);
        //        } else if (roles.contains(CIRCLE_ADMIN)) {
        //            return stmtRepo.monthlyCertificateReportCircleAdmin(month, circleCode);
        //        } else if (roles.contains(AO_USER) || roles.contains(AGM_GB)) {
        //            return stmtRepo.monthlyCertificateReportAoUser(month, circleCode, networkCode, moduleCode);
        //        } else if (roles.contains(RM) || (roles.contains(RBO_CM))) {
        //            return stmtRepo.monthlyCertificateReportRBO(month, circleCode, networkCode, moduleCode, regionCode);
        //        } else {
        //            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        //        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            return stmtRepo.monthlyCertificateReport(month, branchCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return stmtRepo.monthlyCertificateReportCircleAdmin(month, circleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER, RoleConstants.AGM_GB)) {
            return stmtRepo.monthlyCertificateReportAoUser(month, circleCode, networkCode, moduleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM, RoleConstants.RM, RoleConstants.RBO_DESK_OFFICER)) {
            return stmtRepo.monthlyCertificateReportRBO(month, circleCode, networkCode, moduleCode, regionCode);
        } else {
            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        }
    }

    //    public List<MonthlyCertificateVsSummary> getVsSummary(@NotNull LocalDate month, Long branchCode) {
    //        // TODO Auto-generated method stub
    //        log.debug("Fslo Code: {} | Month: {} ", branchCode, month);
    //        return stmtRepo.monthlyCertificateVsSummary(month, branchCode);
    //    }

    public List<MonthlyCertificateVsSummary> getVsSummary(@NotNull LocalDate month) {
        // TODO Auto-generated method stub
        log.trace("Month: {} ", month);

        //        AppUser user = SecurityUtils.getLoggedInUser();
        //        Set<Role> roles = user.getRoles();
        //
        //        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        //        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        //        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        //        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        //        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        //        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        //        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        //        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        //        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        Long circleCode = SecurityUtils.getLoggedInUser().getCircleCode();
        Long networkCode = SecurityUtils.getLoggedInUser().getNetworkCode();
        Long moduleCode = SecurityUtils.getLoggedInUser().getModuleCode();
        Long regionCode = SecurityUtils.getLoggedInUser().getRegionCode();
        Long branchCode = SecurityUtils.getLoggedInUser().getBranchCode();

        //        if (roles.contains(FSLO_USER)) {
        //            return stmtRepo.monthlyCertificateVsSummary(month, branchCode);
        //        } else if (roles.contains(CIRCLE_ADMIN)) {
        //            return stmtRepo.monthlyCertificateVsSummaryCircleAdmin(month, circleCode);
        //        } else if (roles.contains(AO_USER) || roles.contains(AGM_GB)) {
        //            return stmtRepo.monthlyCertificateVsSummaryAoUser(month, circleCode, networkCode, moduleCode);
        //        } else if (roles.contains(RM) || (roles.contains(RBO_CM))) {
        //            return stmtRepo.monthlyCertificateVsSummaryRBO(month, circleCode, networkCode, moduleCode, regionCode);
        //        } else {
        //            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        //        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            return stmtRepo.monthlyCertificateVsSummary(month, branchCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return stmtRepo.monthlyCertificateVsSummaryCircleAdmin(month, circleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER, RoleConstants.AGM_GB)) {
            return stmtRepo.monthlyCertificateVsSummaryAoUser(month, circleCode, networkCode, moduleCode);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM, RoleConstants.RM, RoleConstants.RBO_DESK_OFFICER)) {
            return stmtRepo.monthlyCertificateVsSummaryRBO(month, circleCode, networkCode, moduleCode, regionCode);
        } else {
            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        }
    }

    //    public List<MonthlyCertificateVsYesList> getVsListYes(@NotNull LocalDate month, Long branchCode, Integer displayOrder, Boolean yes) {
    //        // TODO Auto-generated method stub
    //        log.debug("Fslo Code: {} | Month: {} | displayNo: {} | Option: {}", branchCode, month, displayOrder, yes);
    //        String option = Boolean.TRUE.equals(yes) ? "YES" : "NO";
    //
    //        log.debug(" Option: {}", option);
    //        return stmtRepo.getVsListYes(month, branchCode, displayOrder, option);
    //    }

    public List<MonthlyCertificateVsYesList> getVsListYes(@NotNull LocalDate month, Integer displayOrder, Boolean yes) {
        // TODO Auto-generated method stub
        log.trace("Month: {} | displayNo: {} | Option: {}", month, displayOrder, yes);
        String option = Boolean.TRUE.equals(yes) ? "YES" : "NO";

        //        AppUser user = SecurityUtils.getLoggedInUser();
        //        Set<Role> roles = user.getRoles();
        //
        //        Role BRANCH_USER = roleRepository.findByName(RoleConstants.BRANCH_USER).get();
        //        Role BRANCH_HEAD = roleRepository.findByName(RoleConstants.BRANCH_HEAD).get();
        //        Role RBO_CM = roleRepository.findByName(RoleConstants.RBO_CM).get();
        //        Role RM = roleRepository.findByName(RoleConstants.RM).get();
        //        Role AO_USER = roleRepository.findByName(RoleConstants.AO_USER).get();
        //        Role AGM_GB = roleRepository.findByName(RoleConstants.AGM_GB).get();
        //        Role CIRCLE_ADMIN = roleRepository.findByName(RoleConstants.CIRCLE_ADMIN).get();
        //        Role FSLO_USER = roleRepository.findByName(RoleConstants.FSLO_USER).get();
        //        Role DGM_CFO = roleRepository.findByName(RoleConstants.DGM_CFO).get();

        Long circleCode = SecurityUtils.getLoggedInUser().getCircleCode();
        Long networkCode = SecurityUtils.getLoggedInUser().getNetworkCode();
        Long moduleCode = SecurityUtils.getLoggedInUser().getModuleCode();
        Long regionCode = SecurityUtils.getLoggedInUser().getRegionCode();
        Long branchCode = SecurityUtils.getLoggedInUser().getBranchCode();

        //        if (roles.contains(FSLO_USER)) {
        //            return stmtRepo.getVsListYes(month, branchCode, displayOrder, option);
        //        } else if (roles.contains(CIRCLE_ADMIN)) {
        //            return stmtRepo.getVsListYesCircleAdmin(month, circleCode, displayOrder, option);
        //        } else if (roles.contains(AO_USER) || roles.contains(AGM_GB)) {
        //            return stmtRepo.getVsListYesAoUser(month, circleCode, networkCode, moduleCode, displayOrder, option);
        //        } else if (roles.contains(RM) || (roles.contains(RBO_CM))) {
        //            return stmtRepo.getVsListYesRBO(month, circleCode, networkCode, moduleCode, regionCode, displayOrder, option);
        //        } else {
        //            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        //        }

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.FSLO_USER)) {
            return stmtRepo.getVsListYes(month, branchCode, displayOrder, option);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            return stmtRepo.getVsListYesCircleAdmin(month, circleCode, displayOrder, option);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER, RoleConstants.AGM_GB)) {
            return stmtRepo.getVsListYesAoUser(month, circleCode, networkCode, moduleCode, displayOrder, option);
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM, RoleConstants.RM, RoleConstants.RBO_DESK_OFFICER)) {
            return stmtRepo.getVsListYesRBO(month, circleCode, networkCode, moduleCode, regionCode, displayOrder, option);
        } else {
            throw new InsufficientAuthenticationException(USER_NOT_HAVING_APPROPRIATE_ROLE);
        }
    }
}
