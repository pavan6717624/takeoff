package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.PenaltyData;
import sbi.sf.gocblr.cconline.domain.PenaltyDisposal;
import sbi.sf.gocblr.cconline.domain.PenaltyReason;
import sbi.sf.gocblr.cconline.domain.PenaltySubReason;

@Data
public class PenaltyUpdationModel {

    PenaltyReason reason;
    PenaltySubReason subReason;
    PenaltyData narration;
    Double amount;
    Long branchCode;
    String status;
    PenaltyDisposal disposal;
    Long id;
    Long updatedByPfid;
    String updatedOnIp;
    Long disposedByPfid;
    String disposedOnIp;
    LocalDate disposedDate;
    LocalDate updatedDate;
}
