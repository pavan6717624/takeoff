package sbi.sf.gocblr.cconline.constants;

public class NotificationTypeConstants {

    private NotificationTypeConstants() {
        /* static class */
    }

    public static final String REMINDER_MAIL = "REMINDER_MAIL";
    public static final String DIFF_BGL_98908 = "DIFF_BGL_98908";
    public static final String DIFF_BGL_98958 = "DIFF_BGL_98958";
    public static final String CS_NOT_UPLOADED = "CS_NOT_UPLOADED";
    public static final String VERIFICATION_ASSIGNED = "VERIFICATION_ASSIGNED";
}
