package sbi.sf.gocblr.cconline.domain;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "no_penalty_found_dates")
public class NoPenaltyDataFoundDates {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    LocalDate reportDate;
    Long pfid;
    String ipaddress;
}
