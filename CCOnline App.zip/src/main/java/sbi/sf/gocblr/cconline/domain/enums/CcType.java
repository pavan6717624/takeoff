package sbi.sf.gocblr.cconline.domain.enums;

import java.util.ArrayList;
import java.util.List;
import sbi.sf.gocblr.cconline.web.rest.vm.IdNameDesc;

/**
 * Currency chest type
 * @author Kiran Marturu
 *
 */
public enum CcType {
    RECEIPTS("R", "Receipts"),
    PAYMENTS("P", "Payments");

    private final String code;
    private final String description;

    CcType(String code, String desc) {
        this.code = code;
        this.description = desc;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static CcType fromCode(String code) {
        for (CcType n : CcType.values()) {
            if (n.code.equalsIgnoreCase(code)) {
                return n;
            }
        }
        throw new IllegalArgumentException("Invalid CcType code: " + code);
    }

    public static List<IdNameDesc> getAsIdNameAndDesc() {
        List<IdNameDesc> data = new ArrayList<>();
        for (CcType n : CcType.values()) {
            data.add(new IdNameDesc(n.code + "", n.toString(), n.description));
        }

        return data;
    }
}
