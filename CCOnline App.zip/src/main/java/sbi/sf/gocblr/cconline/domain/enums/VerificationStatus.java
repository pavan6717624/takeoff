package sbi.sf.gocblr.cconline.domain.enums;

import java.util.ArrayList;
import java.util.List;
import sbi.sf.gocblr.cconline.model.ui.NzFilterMenu;

public enum VerificationStatus {
    IN_PROGRESS("P", "In-Progress"),
    REPORT_SUBMITTED("S", "Verification/Visit Report Submitted"),
    CMP_SUBMITTED_BY_BR_MAKER("CSBM", "Compliance Submitted by Branch Maker"),
    CMP_REJECTED_BY_BR_HEAD("CRBH", "Compliance Rejected by Branch Head"),
    CMP_SUBMITTED_BY_BR_HEAD("CSBH", "Compliance Submitted by Branch Head"),
    CMP_REJECTED_BY_SCRUTINIZER("CRBS", "Compliance Rejected by Scrutinizer"),
    CMP_SUBMITTED_BY_SCRUTINIZER("CSBS", "Compliance Submitted by Scrutinizer"),
    CMP_VERIFIED_BY_VO("CVBVO", "Compliance Verified by Verification Officer"),
    CMP_REJECTED_BY_CA("CRBCA", "Compliance Rejected by Closure Authority"),
    CMP_CLOSED("C", "Closure");

    private final String code;
    private final String description;

    VerificationStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public static VerificationStatus fromCode(String code) {
        for (VerificationStatus vs : VerificationStatus.values()) {
            if (vs.code().equalsIgnoreCase(code)) {
                return vs;
            }
        }
        return null;
    }

    public static List<NzFilterMenu> forFrontEndFilter() {
        List<NzFilterMenu> data = new ArrayList<>();

        for (VerificationStatus vs : VerificationStatus.values()) {
            data.add(new NzFilterMenu(vs.description, vs.code));
        }

        return data;
    }
}
