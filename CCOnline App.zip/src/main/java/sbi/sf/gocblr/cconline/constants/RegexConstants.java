package sbi.sf.gocblr.cconline.constants;

public class RegexConstants {

	public static final String MOBILE_NO = "^[6-9]\\d{9}$";
	
}
