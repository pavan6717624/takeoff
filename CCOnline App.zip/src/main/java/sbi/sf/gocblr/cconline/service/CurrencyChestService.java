package sbi.sf.gocblr.cconline.service;

import java.util.Optional;
import javax.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.CcEmployeeDetails;
import sbi.sf.gocblr.cconline.domain.CcProfileSaveData;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.enums.CcProfileStatus;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.CcProfileSaveDataRepository;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.web.rest.vm.ChestProfileSaveVM;

@Slf4j
@Service
@RequiredArgsConstructor
public class CurrencyChestService {

    private final CurrencyChestRepository currencyChestRepository;
    private final CcProfileSaveDataRepository ccProfileSaveDataRepository;
    private final EmployeeDetailsService empService;

    @Transactional
    public CurrencyChest ccProfile(Long branchCode) {
        return currencyChestRepository
            .getByBranchCode(branchCode)
            .orElseThrow(() -> new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode)));
    }

    public boolean isCcBranch(long branchCode) {
        return currencyChestRepository.findByBranchCode(branchCode).isPresent();
    }

    @Transactional
    public void saveCcProfile(Long branchCode, ChestProfileSaveVM saveData) {
        CurrencyChest cc = currencyChestRepository.findByBranchCode(branchCode).orElse(null);

        if (cc == null) {
            throw new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode));
        } else {
            Optional<CcProfileSaveData> sd = ccProfileSaveDataRepository.findByCurrencyChest(cc);

            CcProfileSaveData toSave;

            // To fetch Accountant Name and Mobile No. through HRMS API
            if (saveData.getAccountantId() != null) {
                var emp = empService.getEmployeeDetails(saveData.getAccountantId().intValue());
                saveData.setAccountantMobileNo(emp.getMobileNo());
                saveData.setAccountantName(emp.getName());
            }

            // To fetch Cash Officer Name and Mobile No. through HRMS API
            if (saveData.getCoId() != null) {
                var emp1 = empService.getEmployeeDetails(saveData.getCoId().intValue());
                saveData.setCoMobileNo(emp1.getMobileNo());
                saveData.setCoName(emp1.getName());
            }

            // To fetch CM(CnR) Name and Mobile No. through HRMS API
            if (saveData.getCmCrPfId() != null) {
                var emp2 = empService.getEmployeeDetails(saveData.getCmCrPfId().intValue());
                saveData.setCmCrMobileNo(emp2.getMobileNo());
                saveData.setCmCrName(emp2.getName());
            }

            // To fetch RM Name and Mobile No. through HRMS API
            if (saveData.getRmPfId() != null) {
                var emp3 = empService.getEmployeeDetails(saveData.getRmPfId().intValue());
                saveData.setRmMobileNo(emp3.getMobileNo());
                saveData.setRmName(emp3.getName());
            }

            // To fetch BM Name and Mobile No. through HRMS API
            if (saveData.getBmId() != null) {
                var emp4 = empService.getEmployeeDetails(saveData.getBmId().intValue());
                saveData.setBmMobileNo(emp4.getMobileNo());
                saveData.setBmName(emp4.getName());
            }

            // To fetch FSLO Name and AGM Mobile No. through HRMS API
            if (saveData.getFsloAgmPfId() != null) {
                var emp5 = empService.getEmployeeDetails(saveData.getFsloAgmPfId().intValue());
                saveData.setFsloAgmMobileNo(emp5.getMobileNo());
                saveData.setFsloAgmName(emp5.getName());
            }

            // To fetch FSLO Other Officer Name and Mobile No. through HRMS API
            if (saveData.getFsloOffPfId() != null) {
                var emp6 = empService.getEmployeeDetails(saveData.getFsloOffPfId().intValue());
                saveData.setFsloOffMobileNo(emp6.getMobileNo());
                saveData.setFsloOffName(emp6.getName());
            }

            // 1. if already saved
            if (sd.isPresent()) {
                toSave = sd.get();
                toSave.setData(saveData);
                toSave.setCcProfileStatus(CcProfileStatus.SAVED);
            }
            // 2. saving for first time
            else {
                toSave = new CcProfileSaveData();
                toSave.setCurrencyChest(cc);
                toSave.setData(saveData);
                toSave.setCcProfileStatus(CcProfileStatus.SAVED);
            }
            ccProfileSaveDataRepository.save(toSave);
        }
    }

    @Transactional
    public void submitCcProfile(Long branchCode, ChestProfileSaveVM submitData) {
        CurrencyChest cc = currencyChestRepository.findByBranchCode(branchCode).orElse(null);

        if (cc == null) {
            throw new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode));
        } else {
            Optional<CcProfileSaveData> sd = ccProfileSaveDataRepository.findByCurrencyChestBranchCode(branchCode);
            CcProfileSaveData toSubmit;

            // To fetch Accountant Name and Mobile No. through HRMS API
            if (submitData.getAccountantId() != null) {
                var emp = empService.getEmployeeDetails(submitData.getAccountantId().intValue());
                //submitData.setAccountantId(submitData.getAccountantId());
                submitData.setAccountantMobileNo(emp.getMobileNo());
                submitData.setAccountantName(emp.getName());
            }

            // To fetch Cash Officer Name and Mobile No. through HRMS API
            if (submitData.getCoId() != null) {
                var emp1 = empService.getEmployeeDetails(submitData.getCoId().intValue());
                submitData.setCoMobileNo(emp1.getMobileNo());
                submitData.setCoName(emp1.getName());
            }

            // To fetch CM(CnR) Name and Mobile No. through HRMS API
            if (submitData.getCmCrPfId() != null) {
                var emp2 = empService.getEmployeeDetails(submitData.getCmCrPfId().intValue());
                submitData.setCmCrMobileNo(emp2.getMobileNo());
                submitData.setCmCrName(emp2.getName());
            }

            // To fetch RM Name and Mobile No. through HRMS API
            if (submitData.getRmPfId() != null) {
                var emp3 = empService.getEmployeeDetails(submitData.getRmPfId().intValue());
                submitData.setRmMobileNo(emp3.getMobileNo());
                submitData.setRmName(emp3.getName());
            }

            // To fetch BM Name and Mobile No. through HRMS API
            if (submitData.getBmId() != null) {
                var emp4 = empService.getEmployeeDetails(submitData.getBmId().intValue());
                submitData.setBmMobileNo(emp4.getMobileNo());
                submitData.setBmName(emp4.getName());
            }

            // To fetch FSLO AGM Name and Mobile No. through HRMS API
            if (submitData.getFsloAgmPfId() != null) {
                var emp5 = empService.getEmployeeDetails(submitData.getFsloAgmPfId().intValue());
                submitData.setFsloAgmMobileNo(emp5.getMobileNo());
                submitData.setFsloAgmName(emp5.getName());
            }

            // To fetch FSLO Other Officer Name and Mobile No. through HRMS API
            if (submitData.getFsloOffPfId() != null) {
                var emp6 = empService.getEmployeeDetails(submitData.getFsloOffPfId().intValue());
                submitData.setFsloOffMobileNo(emp6.getMobileNo());
                submitData.setFsloOffName(emp6.getName());
            }

            // 1. if already saved
            if (sd.isPresent()) {
                toSubmit = sd.get();
                toSubmit.setData(submitData);
                toSubmit.setCcProfileStatus(CcProfileStatus.SUBMITTED);
            }
            // 2. saving for first time
            else {
                toSubmit = new CcProfileSaveData();
                toSubmit.setCurrencyChest(cc);
                toSubmit.setData(submitData);
                toSubmit.setCcProfileStatus(CcProfileStatus.SUBMITTED);
            }
            ccProfileSaveDataRepository.save(toSubmit);
        }
    }

    @Transactional
    public void approveCcProfile(Long branchCode) {
        CurrencyChest cc = currencyChestRepository.findByBranchCode(branchCode).orElse(null);

        if (cc == null) {
            throw new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode));
        } else {
            Optional<CurrencyChest> existing = currencyChestRepository.findByBranchCode(branchCode);
            Optional<CcProfileSaveData> saved = ccProfileSaveDataRepository.findByCurrencyChestBranchCode(branchCode);
            CurrencyChest cce = existing.get();
            //CcProfileSaveData ccs = saved.get();

            if (saved.isPresent()) {
                ChestProfileSaveVM data = saved.get().getData();

                cce.getAddress().setCenterName(data.getCenterName());
                cce.getAddress().setCenterType(data.getCenterType());
                cce.setCcCode(data.getCcCode());
                cce.getAddress().setPoliceStation(data.getPoliceStation());
                cce.setDateOfOpening(data.getDateOfOpening());
                cce.setCcType(data.getBranchType());
                cce.setValidityDateOfStrongRoomFitnessCertificate(data.getValidityDateofStrongRoomFitnessCertificate());
                cce.setStrongRoomSize(data.getStrongRoomSize());
                cce.setCashProcessingArea(data.getCashProcessingArea());
                cce.setChestClass(data.getChestClass());
                cce.setCashBalanceLimit(data.getCashBalanceLimit());
                cce.setCapacityToStoreCashInBundles(data.getCapacityToStoreCashInBundles());
                cce.setTotalStaff(data.getTotalStaff());
                cce.setCashDeptStaff(data.getCashDeptStaff());

                if (cc.getCcEmployeeDetails() == null) {
                    cc.setCcEmployeeDetails(new CcEmployeeDetails());
                }

                if (cce.getCcEmployeeDetails() != null && data.getAccountantId() != null) {
                    cce.getCcEmployeeDetails().setAccountantId(data.getAccountantId());
                    cce.getCcEmployeeDetails().setAccountantName(data.getAccountantName());
                    cce.getCcEmployeeDetails().setAccountantDateOfTakingOver(data.getAccountantDateOfTakingOver());
                    cce.getCcEmployeeDetails().setAccountantMobileNo(data.getAccountantMobileNo());
                }

                if (cce.getCcEmployeeDetails() != null && data.getCoId() != null) {
                    cce.getCcEmployeeDetails().setCoId(data.getCoId());
                    cce.getCcEmployeeDetails().setCoName(data.getCoName());
                    cce.getCcEmployeeDetails().setCoDateOfTakingOver(data.getCoDateOfTakingOver());
                    cce.getCcEmployeeDetails().setCoMobileNo(data.getCoMobileNo());
                }

                if (cce.getCcEmployeeDetails() != null && data.getBmId() != null) {
                    cce.getCcEmployeeDetails().setBmId(data.getBmId());
                    cce.getCcEmployeeDetails().setBmName(data.getBmName());
                    cce.getCcEmployeeDetails().setBmMobileNo(data.getBmMobileNo());
                }

                cce.setNoOfGuardsPosted(data.getNoOfGuardsPosted());
                cce.setNoOfOtherBankBranchesLinked(data.getNoOfGuardsPosted());
                cce.setNoOfBinsAvailable(data.getNoOfBinsAvailable());
                cce.setNoOfCCsMappedinCBS(data.getNoOfCCsMappedinCBS());
                cce.setHoldingCapacityOfBins(data.getHoldingCapacityOfBins());
                cce.setCoinVendingMachineAvailable(data.getCoinVendingMachineAvailable());

                if (cce.getRegion() != null && data.getCmCrPfId() != null) {
                    cce.getRegion().setCmCrPfId(data.getCmCrPfId());
                    cce.getRegion().setCmCrName(data.getCmCrName());
                    cce.getRegion().setCmCrMobileNo(data.getCmCrMobileNo());
                }

                if (cce.getRegion() != null && data.getRmPfId() != null) {
                    cce.getRegion().setRmPfId(data.getRmPfId());
                    cce.getRegion().setRmName(data.getRmName());
                    cce.getRegion().setRmMobileNo(data.getRmMobileNo());
                }

                cce.setNoOf4plus1TypeNSM(data.getNoOf4plus1TypeNSM());
                cce.setNoOf3plus1TypeNSM(data.getNoOf3plus1TypeNSM());
                cce.setNoOf2plus1TypeNSM(data.getNoOf2plus1TypeNSM());
                cce.setNoOf1plus1TypeNSM(data.getNoOf1plus1TypeNSM());

                if (cce.getFslo().getAgm() != null && data.getFsloAgmPfId() != null) {
                    cce.getFslo().getAgm().setPfId(data.getFsloAgmPfId());
                    cce.getFslo().getAgm().setName(data.getFsloAgmName());
                    cce.getFslo().getAgm().setMobileNo(data.getFsloAgmMobileNo());
                }

                if (cce.getFslo().getOtherOfficer() != null && data.getFsloOffPfId() != null) {
                    cce.getFslo().getOtherOfficer().setPfId(data.getFsloOffPfId());
                    cce.getFslo().getOtherOfficer().setName(data.getFsloOffName());
                    cce.getFslo().getOtherOfficer().setMobileNo(data.getFsloOffMobileNo());
                }
            }

            currencyChestRepository.save(cce);
            ccProfileSaveDataRepository.deleteByCurrencyChestBranchCode(branchCode);
        }
    }

    @Transactional
    public void rejectCcProfile(Long branchCode) {
        CurrencyChest cc = currencyChestRepository.findByBranchCode(branchCode).orElse(null);

        if (cc == null) {
            throw new ResourceNotFoundException(String.format("No currency chest found with branch code %d", branchCode));
        } else {
            //Optional<CcProfileSaveData> saved = ccProfileSaveDataRepository.findByCurrencyChestBranchCode(branchCode);
            //CcProfileSaveData ccs = saved.get();

            ccProfileSaveDataRepository.deleteByCurrencyChestBranchCode(branchCode);
        }
    }

    @Transactional
    public ChestProfileSaveVM profileForEditing(long branchCode) {
        var cc = currencyChestRepository.getByBranchCode(branchCode).orElseThrow(() -> new ResourceNotFoundException(""));
        CcProfileSaveData sd = ccProfileSaveDataRepository.findByCurrencyChest(cc).orElse(null);

        ChestProfileSaveVM vm = new ChestProfileSaveVM();

        log.debug("cc.getRegion().getCmCrMobileNo() {} ", cc.getRegion().getCmCrMobileNo());

        //assign data from main table for initial display of edit page
        vm.setCenterName(cc.getAddress().getCenterName());
        vm.setCenterType(cc.getAddress().getCenterType());
        vm.setCcCode(cc.getCcCode());
        vm.setPoliceStation(cc.getAddress().getPoliceStation());

        vm.setDateOfOpening(cc.getDateOfOpening() == null ? null : cc.getDateOfOpening());

        vm.setBranchType(cc.getCcType());
        vm.setValidityDateofStrongRoomFitnessCertificate(
            cc.getValidityDateOfStrongRoomFitnessCertificate() == null ? null : cc.getValidityDateOfStrongRoomFitnessCertificate()
        );
        vm.setStrongRoomSize(cc.getStrongRoomSize());
        vm.setCashProcessingArea(cc.getCashProcessingArea());
        vm.setChestClass(cc.getChestClass());
        vm.setCashBalanceLimit(cc.getCashBalanceLimit());
        vm.setCapacityToStoreCashInBundles(cc.getCapacityToStoreCashInBundles());
        vm.setTotalStaff(cc.getTotalStaff());
        vm.setCashDeptStaff(cc.getCashDeptStaff());

        if (cc.getCcEmployeeDetails() == null) {
            cc.setCcEmployeeDetails(new CcEmployeeDetails());
        }
        vm.setAccountantId(cc.getCcEmployeeDetails().getAccountantId());
        vm.setAccountantName(cc.getCcEmployeeDetails().getAccountantName());
        vm.setAccountantDateOfTakingOver(
            cc.getCcEmployeeDetails().getAccountantDateOfTakingOver() == null
                ? null
                : cc.getCcEmployeeDetails().getAccountantDateOfTakingOver()
        );
        vm.setAccountantMobileNo(cc.getCcEmployeeDetails().getAccountantMobileNo());

        vm.setCoId(cc.getCcEmployeeDetails().getCoId());
        vm.setCoName(cc.getCcEmployeeDetails().getCoName());
        vm.setCoDateOfTakingOver(
            cc.getCcEmployeeDetails().getCoDateOfTakingOver() == null ? null : cc.getCcEmployeeDetails().getCoDateOfTakingOver()
        );
        vm.setCoMobileNo(cc.getCcEmployeeDetails().getCoMobileNo());

        vm.setBmId(cc.getCcEmployeeDetails().getBmId());
        vm.setBmName(cc.getCcEmployeeDetails().getBmName());
        vm.setBmMobileNo(cc.getCcEmployeeDetails().getBmMobileNo());

        vm.setNoOfGuardsPosted(cc.getNoOfGuardsPosted());
        //vm.setLinked_branch_code(cc.getLinkedBranches());
        vm.setNoOfOtherBankBranchesLinked(cc.getNoOfOtherBankBranchesLinked());
        vm.setNoOfBinsAvailable(cc.getNoOfBinsAvailable());
        vm.setNoOfCCsMappedinCBS(cc.getNoOfCCsMappedinCBS());
        vm.setHoldingCapacityOfBins(cc.getHoldingCapacityOfBins());
        vm.setCoinVendingMachineAvailable(cc.getCoinVendingMachineAvailable());

        vm.setCmCrPfId(cc.getRegion().getCmCrPfId());
        vm.setCmCrName(cc.getRegion().getCmCrName());
        vm.setCmCrMobileNo(cc.getRegion().getCmCrMobileNo());

        vm.setRmPfId(cc.getRegion().getRmPfId());
        vm.setRmName(cc.getRegion().getRmName());
        vm.setRmMobileNo(cc.getRegion().getRmMobileNo());

        vm.setNoOf4plus1TypeNSM(cc.getNoOf4plus1TypeNSM());
        vm.setNoOf3plus1TypeNSM(cc.getNoOf3plus1TypeNSM());
        vm.setNoOf2plus1TypeNSM(cc.getNoOf2plus1TypeNSM());
        vm.setNoOf1plus1TypeNSM(cc.getNoOf1plus1TypeNSM());

        setFsloAgmDetails(cc, vm);

        vm.setFsloOffPfId(cc.getFslo().getOtherOfficer().getPfId());
        vm.setFsloOffName(cc.getFslo().getOtherOfficer().getName());
        vm.setFsloOffMobileNo(cc.getFslo().getOtherOfficer().getMobileNo());

        //assign data from from temp table after save
        if (sd != null && sd.getData() != null) {
            log.debug("saved data exists; updating view model");
            vm.setCenterName(sd.getData().getCenterName());
            vm.setCenterType(sd.getData().getCenterType());
            vm.setCcCode(sd.getData().getCcCode());
            vm.setPoliceStation(sd.getData().getPoliceStation());
            vm.setDateOfOpening(sd.getData().getDateOfOpening());
            vm.setBranchType(sd.getData().getBranchType());
            vm.setValidityDateofStrongRoomFitnessCertificate(sd.getData().getValidityDateofStrongRoomFitnessCertificate());
            vm.setStrongRoomSize(sd.getData().getStrongRoomSize());
            vm.setCashProcessingArea(sd.getData().getCashProcessingArea());
            vm.setChestClass(sd.getData().getChestClass());
            vm.setCashBalanceLimit(sd.getData().getCashBalanceLimit());
            vm.setCapacityToStoreCashInBundles(sd.getData().getCapacityToStoreCashInBundles());
            vm.setTotalStaff(sd.getData().getTotalStaff());
            vm.setCashDeptStaff(sd.getData().getCashDeptStaff());

            vm.setAccountantId(sd.getData().getAccountantId());
            vm.setAccountantName(sd.getData().getAccountantName());
            vm.setAccountantDateOfTakingOver(sd.getData().getAccountantDateOfTakingOver());
            vm.setAccountantMobileNo(sd.getData().getAccountantMobileNo());

            vm.setCoId(sd.getData().getCoId());
            vm.setCoName(sd.getData().getCoName());
            vm.setCoDateOfTakingOver(sd.getData().getCoDateOfTakingOver());
            vm.setCoMobileNo(sd.getData().getCoMobileNo());

            vm.setBmId(sd.getData().getBmId());
            vm.setBmName(sd.getData().getBmName());
            vm.setBmMobileNo(sd.getData().getBmMobileNo());

            vm.setNoOfGuardsPosted(sd.getData().getNoOfGuardsPosted());
            //vm.setLinked_branch_code(sd.getData().getLinkedBranches());
            vm.setNoOfOtherBankBranchesLinked(sd.getData().getNoOfOtherBankBranchesLinked());
            vm.setNoOfBinsAvailable(sd.getData().getNoOfBinsAvailable());
            vm.setNoOfCCsMappedinCBS(sd.getData().getNoOfCCsMappedinCBS());
            vm.setHoldingCapacityOfBins(sd.getData().getHoldingCapacityOfBins());
            vm.setCoinVendingMachineAvailable(sd.getData().getCoinVendingMachineAvailable());

            vm.setCmCrPfId(sd.getData().getCmCrPfId());
            vm.setCmCrName(sd.getData().getCmCrName());
            vm.setCmCrMobileNo(sd.getData().getCmCrMobileNo());

            vm.setRmPfId(sd.getData().getRmPfId());
            vm.setRmName(sd.getData().getRmName());
            vm.setRmMobileNo(sd.getData().getRmMobileNo());

            vm.setNoOf4plus1TypeNSM(sd.getData().getNoOf4plus1TypeNSM());
            vm.setNoOf3plus1TypeNSM(sd.getData().getNoOf3plus1TypeNSM());
            vm.setNoOf2plus1TypeNSM(sd.getData().getNoOf2plus1TypeNSM());
            vm.setNoOf1plus1TypeNSM(sd.getData().getNoOf1plus1TypeNSM());

            vm.setFsloAgmPfId(sd.getData().getFsloAgmPfId());
            vm.setFsloAgmName(sd.getData().getFsloAgmName());
            vm.setFsloAgmMobileNo(sd.getData().getFsloAgmMobileNo());

            vm.setFsloOffPfId(sd.getData().getFsloOffPfId());
            vm.setFsloOffName(sd.getData().getFsloOffName());
            vm.setFsloOffMobileNo(sd.getData().getFsloOffMobileNo());
            //log.debug("sd.getData().getCmCrMobileNo():{}", sd.getData().getCmCrMobileNo());
        }

        log.debug("view model: {}", vm);
        return vm;
    }

    private void setFsloAgmDetails(CurrencyChest cc, ChestProfileSaveVM vm) {
        if (cc.getFslo().getAgm() != null) {
            vm.setFsloAgmPfId(cc.getFslo().getAgm().getPfId());
            vm.setFsloAgmName(cc.getFslo().getAgm().getName());
            vm.setFsloAgmMobileNo(cc.getFslo().getAgm().getMobileNo());
        }
    }

    public CurrencyChest getByBranchCode(long branchCode) {
        return currencyChestRepository
            .findByBranchCode(branchCode)
            .orElseThrow(() -> new ResourceNotFoundException("No currency chest found with branch code " + branchCode));
    }

    public Optional<CurrencyChest> byBranchCode(long branchCode) {
        return currencyChestRepository.findByBranchCode(branchCode);
    }

    public CurrencyChest getBranchCodeForFslo(long branchCode, long fsloCode) {
        return currencyChestRepository
            .findByBranchCodeAndFsloBranchCode(branchCode, fsloCode)
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        String.format("No currency chest found for %d associated to fslo %d", branchCode, fsloCode)
                    )
            );
    }

    public CurrencyChest getBranchCode(long branchCode) {
        // TODO Auto-generated method stub
        return currencyChestRepository
            .findByBranchCode(branchCode)
            .orElseThrow(() -> new ResourceNotFoundException(String.format("No currency chest found for %d ", branchCode)));
    }
}
