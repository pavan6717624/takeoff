package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
@Entity
public class AutoAlertsDetailsHbb implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 8292759441383926987L;
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 Long id;
	
	   @OneToOne
	   @JoinColumn(name = "for_role", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_vs_auto_alert_for_receipients_hbb"))
	   AutoAlertsRecipientsHbb forRole;
	 
		 @OneToOne
	 @JoinColumn(name = "branch_code", referencedColumnName = "branch_code", foreignKey = @ForeignKey(name = "fk_vs_auto_alert_for_branch_hbb"))
	 Branch branch;
		 
		 
	 
	 String email;
	 
	 Long updatedBy;
}
