package sbi.sf.gocblr.cconline.repository.custom;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Component;

@Component
public class CustomChestSlipRepositoryImpl implements CustomChestSlipRepository {

    @PersistenceContext
    EntityManager em;
}
