package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DifferenceReport {

    private LocalDate date;
    private double bglBalance;
    private double ccBalance;
    private String file;
    private String report;
    private double deposits;
    private double withdrawals;
}
