package sbi.sf.gocblr.cconline.exception;

public class InvalidParameterException extends ServiceException {

    private static final long serialVersionUID = 4099954685184838016L;

    public InvalidParameterException(String msg) {
        super(msg);
    }
}
