package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class EmployeeDetails {

    private String pfId;
    private String name;
    private String branchCode;
    private String branchName;
    private String designation;
    private String emailId;
    private String mobileNo;
}
