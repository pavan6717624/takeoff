package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author Kiran Marturu
 *
 */
@Data
public class ModuleId implements Serializable {

    private static final long serialVersionUID = 969470077764461694L;

    private Network network;
    private Long moduleCode;
}
