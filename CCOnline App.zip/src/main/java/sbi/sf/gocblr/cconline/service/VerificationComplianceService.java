package sbi.sf.gocblr.cconline.service;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.domain.criteria.VerificationScrutinyCriteria;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.repository.VerificationRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.dto.VerificationForListModel;
import sbi.sf.gocblr.cconline.utils.TextUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class VerificationComplianceService {

    private final VerificationRepository repo;

    public List<VerificationForListModel> verificationsForCompliance(long branchCode) {
        VerificationScrutinyCriteria criteria = new VerificationScrutinyCriteria();
        criteria.setBranchCode(branchCode);
        criteria.setTypes(
            List.of(
                VerificationTypeConstants.BI_MONTHLY,
                VerificationTypeConstants.QUARTERLY,
                VerificationTypeConstants.HALF_YEARLY,
                VerificationTypeConstants.DGM_CFO,
                VerificationTypeConstants.SECURITY_OFFICER,
                VerificationTypeConstants.RM_DGM_CONTROLLER_VISIT,
                VerificationTypeConstants.DGM_BO_MODULE_HEAD_VISIT,
                VerificationTypeConstants.DGM_CFO_VISIT,
                VerificationTypeConstants.GM_NETWORK_VISIT,
                VerificationTypeConstants.CGM_VISIT
            )
        );

        return repo.compliance(criteria);
    }

    public List<VerificationForListModel> verificationsForCompliance(Long branchCode, Long type, Long year, Long cstatus, Long pending) {
        VerificationScrutinyCriteria criteria = new VerificationScrutinyCriteria();
        List<String> types = List.of(
            VerificationTypeConstants.BI_MONTHLY,
            VerificationTypeConstants.QUARTERLY,
            VerificationTypeConstants.HALF_YEARLY,
            VerificationTypeConstants.DGM_CFO,
            VerificationTypeConstants.SECURITY_OFFICER,
            VerificationTypeConstants.RM_DGM_CONTROLLER_VISIT,
            VerificationTypeConstants.DGM_BO_MODULE_HEAD_VISIT,
            VerificationTypeConstants.DGM_CFO_VISIT,
            VerificationTypeConstants.GM_NETWORK_VISIT,
            VerificationTypeConstants.CGM_VISIT
        );

        criteria.setBranchCode(branchCode);
        criteria.setTypes(List.of(types.get(type.intValue() - 1)));
        criteria.setYear(year);
        criteria.setCstatus(cstatus);
        criteria.setPending(pending);

        return repo.compliance(criteria);
    }

    public String getComplianceRole(AppUser loggedInUser, Verification verification) {
        String role = "";

        log.trace(">> getComplianceRole()");
        log.trace("   isComplianceVerificationOfficer: {}", isComplianceVerificationOfficer(loggedInUser, verification));
        log.trace("   Is Branch User: {}", SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_USER));

        if (isComplianceVerificationOfficer(loggedInUser, verification)) {
            role = RoleConstants.VERIFICATION_OFFICER;
        } else {
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_USER)) {
                role = RoleConstants.BRANCH_USER;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.BRANCH_HEAD)) {
                role = RoleConstants.BRANCH_HEAD;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.RBO_CM)) {
                role = RoleConstants.RBO_CM;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.RM)) {
                role = RoleConstants.RM;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.AO_USER)) {
                role = RoleConstants.AO_USER;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.AGM_GB)) {
                role = RoleConstants.AGM_GB;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.DGM_CFO)) {
                role = RoleConstants.DGM_CFO;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.DGM_BO)) {
                role = RoleConstants.DGM_BO;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.GM_NW)) {
                role = RoleConstants.GM_NW;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.CGM_CIRCLE)) {
                role = RoleConstants.CGM_CIRCLE;
            }
            if (SecurityUtils.isCurrentUserInRole(RoleConstants.DGM_ABD)) {
                role = RoleConstants.DGM_ABD;
            }
        }

        if (TextUtils.hasText(role)) {
            log.trace("   returning role: {}", role);
            return role;
        }

        throw new InvalidOperationException("You are not authorized to access this resource/perform this action.");
    }

    private boolean isComplianceVerificationOfficer(AppUser loggedInUser, Verification v) {
        VerificationType type = v.getType();
        long userId = loggedInUser.getId();

        return isHalfYearlyComplianceVerificationOfficer(v, type, userId) || isBiMonthlyComplianceVerificationOfficer(v, type, userId);
    }

    private boolean isBiMonthlyComplianceVerificationOfficer(Verification v, VerificationType type, long userId) {
        if (v.getComplianceVerificationOfficer() != null) {
            return (
                type.getKey().equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY) &&
                userId == v.getComplianceVerificationOfficer().getPfId()
            );
        }
        return false;
    }

    private boolean isHalfYearlyComplianceVerificationOfficer(Verification v, VerificationType type, long userId) {    	
        return (
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.HALF_YEARLY) &&
            (
        		userId == v.getOfficer().getPfId() || 
        		(v.getComplianceVerificationOfficer() != null && userId == v.getComplianceVerificationOfficer().getPfId())
    		)
        );
    }
}
