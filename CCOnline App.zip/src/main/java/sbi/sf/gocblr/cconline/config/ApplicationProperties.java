package sbi.sf.gocblr.cconline.config;

import java.time.LocalDate;
import java.util.List;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import sbi.sf.gocblr.cconline.service.RoleConstants;

@Data
@Component
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {

    public static final List<String> ROLES_ALLOWED_FOR_ABD = List.of(
        RoleConstants.ABD_USER,
        RoleConstants.DGM_ABD,
        RoleConstants.FSLO_USER,
        RoleConstants.CIRCLE_ADMIN,
        RoleConstants.DGM_CFO,
        RoleConstants.SECURITY_OFFICER,
        RoleConstants.GM_NW
    );
    public static final List<String> ROLES_ALLOWED_FOR_CIRCLE_ADMIN = List.of(
        RoleConstants.FSLO_USER,
        RoleConstants.CIRCLE_ADMIN,
        RoleConstants.DGM_CFO,
        RoleConstants.SECURITY_OFFICER,
        RoleConstants.BRANCH_HEAD,
        RoleConstants.GM_NW
    );

    private String version;
    private String frontEndUrl;
    private String frontEndLoginCallBackUrl;
    private String jwtSecret;
    private LocalDate appStartDate;
    private String fileUploadsBasePath;
    private String bglsFilePath;
    private String hbbFilePath;
    private String ssoLogoutUrl;
    private String sftpUsername;
    private String sftpPassword;
    private String hbbSftpUsername;
    private String hbbSftpPassword;
    private String sftpHost;
    private String sftpPort;
    private String sftpFolder;
    private String hbbSftpFolder;

    private String eisHrmsApiUrl;

    private String appPrivateKey;
    private String eisPublicKey;
    private String eisHttpsCertificate;
    private String eisSourceId;

    // SMS related
    private String smsApiUrl;
    private String smsApiSenderId;
    private String smsApiUserId;
    private String smsApiPassword;

    private Long smsPreProdNumber;
    private LocalDate smsDummyDate;

    private String smsCsNotUploadedText;
    private String smsBglDiffText;
    private String smsCblExceededText;
    private String smsVerificationAssigned;
    private String smsComplianceVerificationAssigned;

    // Email related
    private String mailAppEmail;
    private String mailProdTeamEmailId;
    private String mailServerPr;
    private int mailServerPortPr;
    private String mailServerDr;
    private int mailServerPortDr;
	public String mailReceiverEmail;
	public String mailServerPassword;
	public String mailServerUsername;
}
