package sbi.sf.gocblr.cconline.model;

import java.time.Instant;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class BGLStatement {

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }

    public double getRegion() {
        return region;
    }

    public void setRegion(double region) {
        this.region = region;
    }

    public String getTransaction() {
        return transaction;
    }

    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public Long getCcCode() {
        return ccCode;
    }

    public void setCcCode(Long ccCode) {
        this.ccCode = ccCode;
    }

    public Long getFsloCode() {
        return Math.abs(fsloCode);
    }

    public void setFsloCode(Long fsloCode) {
        this.fsloCode = fsloCode;
    }

    public Long getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(Long branchCode) {
        this.branchCode = branchCode;
    }

    public double getWithdrawal() {
        return withdrawal;
    }

    public void setWithdrawal(double withdrawal) {
        this.withdrawal = withdrawal;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getCcName() {
        return ccName;
    }

    public void setCcName(String ccName) {
        this.ccName = ccName;
    }

    private LocalDate date;
    private Instant timestamp;
    private double region;
    private String transaction;
    private double deposit;
    private Long ccCode;
    private Long fsloCode;
    private Long branchCode;
    private double withdrawal;
    private double balance;
    private String ccName;
}
