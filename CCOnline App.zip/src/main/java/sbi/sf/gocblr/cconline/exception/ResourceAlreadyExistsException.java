package sbi.sf.gocblr.cconline.exception;

public class ResourceAlreadyExistsException extends RuntimeException {

    private static final long serialVersionUID = 5003069275200787248L;

    public ResourceAlreadyExistsException(String msg) {
        super(msg);
    }
}
