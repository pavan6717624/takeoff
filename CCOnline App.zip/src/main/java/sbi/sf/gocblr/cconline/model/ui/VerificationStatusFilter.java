package sbi.sf.gocblr.cconline.model.ui;

public enum VerificationStatusFilter {
    VO_NOT_ASSIGNED,
    VER_NOT_STARTED,
    IN_PROGRESS,
    REPORT_SUBMITTED,
    PENDING_AT_BRANCH,
    PENDING_AT_CONTROLLER,
    AWAITING_FOR_CLOSURE,
    CLOSED,
    ASSIGN_COMPL_VO,
}
