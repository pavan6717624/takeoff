package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Kiran Marturu
 *
 */
@Entity
@Table(name = "branches")
@Inheritance(strategy = InheritanceType.JOINED)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Branch implements Serializable {

    private static final long serialVersionUID = 6137125581334138679L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns(
        value = {
            @JoinColumn(name = "circle_code", referencedColumnName = "circle_code"),
            @JoinColumn(name = "network_code", referencedColumnName = "network_code"),
            @JoinColumn(name = "module_code", referencedColumnName = "module_code"),
            @JoinColumn(name = "region_code", referencedColumnName = "region_code"),
        },
        foreignKey = @ForeignKey(name = "fk_branches_region")
    )
    private Region region;

    @Id
    @Column(name = "branch_code")
    @EqualsAndHashCode.Include
    private Long branchCode;

    /**
     * Abs bcoz for special case where a branch is both FSLO and Currency Chest,
     * FSLO is stored as -branchCode
     * @return
     */
    public Long getBranchCode() {
        return Math.abs(branchCode);
    }

    @Column(name = "branch_name", length = 80)
    private String branchName;

    @Column(name = "branch_type_code")
    private Integer branchTypeCode;

    @Column(name = "branch_type_desc")
    private String branchTypeDescription;

    // have to check whether any issues will arise
    @ManyToOne
    @JoinColumn(
        name = "circle_code",
        referencedColumnName = "circle_code",
        insertable = false,
        updatable = false,
        foreignKey = @ForeignKey(name = "fk_branches_circle")
    )
    private Circle circle;

    @ManyToOne
    @JoinColumns(
        value = {
            @JoinColumn(name = "network_code", referencedColumnName = "network_code", insertable = false, updatable = false),
            @JoinColumn(name = "circle_code", referencedColumnName = "circle_code", insertable = false, updatable = false),
        },
        foreignKey = @ForeignKey(name = "fk_branches_network")
    )
    private Network network;

    @ManyToOne
    @JoinColumns(
        value = {
            @JoinColumn(name = "module_code", referencedColumnName = "module_code", insertable = false, updatable = false),
            @JoinColumn(name = "network_code", referencedColumnName = "network_code", insertable = false, updatable = false),
            @JoinColumn(name = "circle_code", referencedColumnName = "circle_code", insertable = false, updatable = false),
        },
        foreignKey = @ForeignKey(name = "fk_branches_module")
    )
    private Module module;
}
