package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.ValueStatementCompliance;
import sbi.sf.gocblr.cconline.domain.ValueStatementVerification;

public interface ValueStatementComplianceRepository extends JpaRepository<ValueStatementCompliance, Long> {
    Optional<ValueStatementCompliance> findByVsVerification(ValueStatementVerification vsVerification);
}
