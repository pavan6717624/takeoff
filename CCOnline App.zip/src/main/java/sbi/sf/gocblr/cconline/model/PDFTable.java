package sbi.sf.gocblr.cconline.model;

import java.util.List;
import lombok.Data;

@Data
public class PDFTable {

    List<String> particulars;
    String[] denominations;

    String[][] data;
    Integer size;
}
