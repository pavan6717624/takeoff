package sbi.sf.gocblr.cconline.utils;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;

/**
 * Utils class for generating block based on verification type
 *
 * Note: Bi-Monthly follows Calendar Year whereas quarterly and half-yearly
 * follows financial year
 *
 * @author Kiran Marturu
 *
 */
public final class BlockUtils {

    private BlockUtils() {
        // static utils class not to be initalized
    }

    public static List<Block> getBlocks(LocalDate startDate, LocalDate endDate, String blockType) {
        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException(
                String.format(
                    "End date %s cannot be before start date %s",
                    endDate.format(DateUtils.STANDARD_DATE_TIME_FROMAT),
                    startDate.format(DateUtils.STANDARD_DATE_TIME_FROMAT)
                )
            );
        }

        List<Block> blocks = new ArrayList<>();

        int startMonth = startDate.getMonthValue();
        int startYear = startDate.getYear();
        int endMonth = endDate.getMonthValue();
        int endYear = endDate.getYear();

        if (blockType.equalsIgnoreCase(VerificationTypeConstants.BI_MONTHLY)) {
            startMonth = startMonth + (startMonth % 2 - 1);
            blocks.addAll(blocksBasedOnSpan(startMonth, startYear, endMonth, endYear, 2));
        } else if (
            blockType.equalsIgnoreCase(VerificationTypeConstants.QUARTERLY) || blockType.equalsIgnoreCase(VerificationTypeConstants.DGM_CFO)
        ) {
            startMonth = getQuarterStartMonth(startMonth);
            blocks.addAll(blocksBasedOnSpan(startMonth, startYear, endMonth, endYear, 3));
        } else if (blockType.equalsIgnoreCase(VerificationTypeConstants.HALF_YEARLY)) {
            LocalDate newStartDate = getHalfYearStartDate(startDate);

            while (newStartDate.isBefore(endDate)) {
                LocalDate blockStart = newStartDate;
                LocalDate blockEnd = blockStart.plusMonths(5).with(TemporalAdjusters.lastDayOfMonth());
                blocks.add(new Block(blockStart, blockEnd));

                newStartDate = blockEnd.plusDays(1);
            }
        } else if (blockType.equalsIgnoreCase(VerificationTypeConstants.SECURITY_OFFICER)) {
            //            if (startMonth < 4) {
            //                startYear = startYear - 1;
            //            }
            //            for (int year = startYear; year <= endYear; year++) {
            //                LocalDate blockStart = LocalDate.of(year, 4, 1);
            //                LocalDate blockEnd = LocalDate.of(year + 1, 3, 31);
            //                blocks.add(new Block(blockStart, blockEnd));
            //            }
        }
        return blocks;
    }

    private static List<Block> blocksBasedOnSpan(int startMonth, int startYear, int endMonth, int endYear, int blockSpan) {
        List<Block> bBlocks = new ArrayList<>();

        YearMonth startYearMonth = YearMonth.of(startYear, startMonth);
        YearMonth endYearMonth = YearMonth.of(endYear, endMonth);

        for (YearMonth ym = startYearMonth; !ym.isAfter(endYearMonth); ym = ym.plusMonths(blockSpan)) {
            LocalDate blockStart = LocalDate.of(ym.getYear(), ym.getMonth(), 1);
            LocalDate blockEnd = blockStart.plusMonths(blockSpan - 1L).with(TemporalAdjusters.lastDayOfMonth());
            bBlocks.add(new Block(blockStart, blockEnd));
        }
        return bBlocks;
    }

    private static int getQuarterStartMonth(int startMonth) {
        switch (startMonth) {
            case 1:
            case 2:
            case 3:
                return 1;
            case 4:
            case 5:
            case 6:
                return 4;
            case 7:
            case 8:
            case 9:
                return 7;
            case 10:
            case 11:
            case 12:
                return 10;
            default:
                throw new IllegalArgumentException("Invalid month " + startMonth);
        }
    }

    private static LocalDate getHalfYearStartDate(LocalDate date) {
        int m = date.getMonthValue();
        if (m < 3) {
            return LocalDate.of(date.getYear() - 1, 10, 1);
        } else {
            return LocalDate.of(date.getYear(), 4, 1);
        }
    }

    // Method to display only month when period is spanning one month (i.e BlockFrom and BlockTo are same)
    public static String formatBlockDescription(LocalDate blockFrom, LocalDate blockTo) {
        YearMonth from = YearMonth.from(blockFrom);
        YearMonth to = YearMonth.from(blockTo);

        if (from.equals(to)) {
            return from.format(DateUtils.FOR_BLOCK_DESC);
        }

        return String.format("%s %s %s", blockFrom.format(DateUtils.FOR_BLOCK_DESC), " - ", blockTo.format(DateUtils.FOR_BLOCK_DESC));
    }
}
