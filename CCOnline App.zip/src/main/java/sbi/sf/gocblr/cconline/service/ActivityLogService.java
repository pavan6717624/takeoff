package sbi.sf.gocblr.cconline.service;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.PersistentAuditEvent;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.utils.JsonUtils;
import sbi.sf.gocblr.cconline.utils.WebUtils;

/**
 * Service for doing any activity logs,
 * currently only logging to file, DB is yet to be implemented
 *
 * @author Kiran Marturu
 *
 */
@Service
@RequiredArgsConstructor
public class ActivityLogService {

    private static final Logger activityLog = LoggerFactory.getLogger("app.activity");

    private final WebUtils webUtils;

    public void logActivity(String activityName) {
        logActivity(activityName, new HashMap<>());
    }

    public void logActivity(String activityName, Map<String, String> data) {
        AppUser loggedInUser = SecurityUtils.getLoggedInUser();

        PersistentAuditEvent activity = new PersistentAuditEvent();
        activity.setEventType(activityName);
        activity.setUser(loggedInUser == null ? "NOUSER" : loggedInUser.getId() + "");
        activity.setEventDate(ZonedDateTime.now());

        Map<String, String> dataMutable = new HashMap<>(data);
        dataMutable.put("userIp", webUtils.getClientIp());
        activity.setData(dataMutable);

        if (activityLog.isInfoEnabled()) {
            activityLog.info(JsonUtils.toString(activity));
        }
    }
}
