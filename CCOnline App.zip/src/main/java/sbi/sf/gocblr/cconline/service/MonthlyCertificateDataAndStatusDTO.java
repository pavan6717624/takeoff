package sbi.sf.gocblr.cconline.service;

import java.util.List;
import lombok.Data;
import sbi.sf.gocblr.cconline.service.dto.MonthlyCertificateDataDTO;

@Data
public class MonthlyCertificateDataAndStatusDTO {

    private List<MonthlyCertificateDataDTO> monthlyCertificateStmts;
    private boolean saved;
}
