package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.ChestSlips;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.exception.NothingSpecificException;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.model.DenomintaionAndPiecesDTO;
import sbi.sf.gocblr.cconline.repository.ChestSlipUploadDetailsRepository;
import sbi.sf.gocblr.cconline.repository.ChestSlipsRepository;
import sbi.sf.gocblr.cconline.repository.TotalsTableRepository;
import sbi.sf.gocblr.cconline.service.dto.NotesAndCoinsDenominationAndPiecesDTO;
import sbi.sf.gocblr.cconline.utils.DateUtils;

@Service
@RequiredArgsConstructor
public class ChestSlipService {

    private final ChestSlipUploadDetailsRepository csUploadRepo;
    private final ChestSlipsRepository repo;
    private final ParticularService particularsService;
    private final TotalsTableRepository totalsTableRepository;

    /**
     * Closing balance details for a given CC on a particular date
     *
     * @param cc   Currency Chest
     * @param date Date for which data required
     * @return Optional of ChestSlip
     */
    @Transactional(readOnly = true)
    public Optional<ChestSlips> denominationWiseClosingBalance(CurrencyChest cc, LocalDate date) {
        ChestSlipUploadDetails csUploadDetails = csUploadRepo.findChestSlipUploadDetailsBySlipDateBrcode(date, cc);

        if (csUploadDetails != null) {
            return repo.findByCheckSlipUploadDetailsAndParticularsParticularLike(csUploadDetails, "Closing");
        }
        return Optional.empty();
    }

    @Transactional(readOnly = true)
    public NotesAndCoinsDenominationAndPiecesDTO getNotesClosingBalance(CurrencyChest cc, LocalDate date) {
        ChestSlipUploadDetails csUploadDetails = csUploadRepo.findChestSlipUploadDetailsBySlipDateBrcode(date, cc);

        if (csUploadDetails == null) {
            throw new ResourceNotFoundException(
                String.format(
                    "No chest slip data found for %s (%d) on %s. Advise branch to upload data and continue.",
                    cc.getBranchName(),
                    cc.getBranchCode(),
                    DateUtils.format(date)
                )
            );
        }

        var notesParticular = particularsService.getNotesClosingBalance();
        var coinsParticular = particularsService.getCoinsClosingBalance();

        if (notesParticular == null || coinsParticular == null) {
            throw new NothingSpecificException("Notes/Coins particulars is not present. Contact application helpdesk team.");
        }

        List<DenomintaionAndPiecesDTO> notes = repo.getDetailsForDate(csUploadDetails, notesParticular, "N");
        List<DenomintaionAndPiecesDTO> coins = repo.getDetailsForDate(csUploadDetails, coinsParticular, "C");

        NotesAndCoinsDenominationAndPiecesDTO dto = new NotesAndCoinsDenominationAndPiecesDTO();
        dto.setNotes(notes);
        dto.setCoins(coins);

        return dto;
    }

    @Transactional(readOnly = true)
    public double getSoiledNotesClosingBalance(CurrencyChest cc) {
        Long chestSlipUploadId = csUploadRepo.getMaxUploadId(cc);

        if (chestSlipUploadId != null) {
            var soiledNotesParticular = particularsService.getSoiledNotesClosingBalance();
            var t = totalsTableRepository.findByCheckSlipUploadDetailsIdAndParticular(chestSlipUploadId, soiledNotesParticular);

            if (t.isPresent()) {
                return t.get().getTotalValue();
            }
        }
        return 0d;
    }

    @Transactional(readOnly = true)
    public double getSoiledNotesClosingBalance(long branchCode, LocalDate asOn) {
        Optional<Long> chestSlipUploadId = csUploadRepo.getIdForChestSlipAsOn(branchCode, asOn);

        if (chestSlipUploadId.isPresent()) {
            var soiledNotesParticular = particularsService.getSoiledNotesClosingBalance();
            var t = totalsTableRepository.findByCheckSlipUploadDetailsIdAndParticular(chestSlipUploadId.get(), soiledNotesParticular);

            if (t.isPresent()) {
                return t.get().getTotalValue();
            }
        }
        return 0d;
    }
}
