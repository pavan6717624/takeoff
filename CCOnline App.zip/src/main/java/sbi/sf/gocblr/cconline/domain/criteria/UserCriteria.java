package sbi.sf.gocblr.cconline.domain.criteria;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.List;
import java.util.Set;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.enums.RequestStatus;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserCriteria implements Serializable {

    private static final long serialVersionUID = -3084693782367008932L;

    private Long userPfId;
    private String name;
    private RequestStatus requestStatus;
    private String role;

    @JsonIgnore
    private List<String> roles;

    @JsonIgnore
    private Set<Long> branches;

    @JsonIgnore
    private long loggedInUserId;

    @JsonIgnore
    private Long userCircleCode;
}
