package sbi.sf.gocblr.cconline.security;

import java.util.Optional;
import org.springframework.data.domain.AuditorAware;

public class AppAuditorAware implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        return Optional.of(SecurityUtils.getCurrentUserId().orElse(""));
    }
}
