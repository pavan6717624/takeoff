package sbi.sf.gocblr.cconline.service;

import com.helger.pdflayout4.PDFCreationException;
import com.helger.pdflayout4.PageLayoutPDF;
import com.helger.pdflayout4.base.EPLPlaceholder;
import com.helger.pdflayout4.base.IPLRenderableObject;
import com.helger.pdflayout4.base.PLPageSet;
import com.helger.pdflayout4.element.table.EPLTableGridType;
import com.helger.pdflayout4.element.table.PLTable;
import com.helger.pdflayout4.element.table.PLTableCell;
import com.helger.pdflayout4.element.text.PLText;
import com.helger.pdflayout4.spec.BorderStyleSpec;
import com.helger.pdflayout4.spec.EHorzAlignment;
import com.helger.pdflayout4.spec.EVertAlignment;
import com.helger.pdflayout4.spec.FontSpec;
import com.helger.pdflayout4.spec.PreloadFont;
import java.awt.Color;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.joda.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.constants.SectionRouteConstants;
import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.BalanceVerification;
import sbi.sf.gocblr.cconline.domain.BalanceVerificationDetails;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationBranchProfile;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.domain.enums.ComplianceStatus;
import sbi.sf.gocblr.cconline.domain.enums.DenominationType;
import sbi.sf.gocblr.cconline.domain.enums.OptionCompliance;
import sbi.sf.gocblr.cconline.exception.ReportGenerationFailedException;
import sbi.sf.gocblr.cconline.model.MonthWiseVerificationReport;
import sbi.sf.gocblr.cconline.repository.CircleRepository;
import sbi.sf.gocblr.cconline.repository.VerificationRepository;
import sbi.sf.gocblr.cconline.service.dto.DetailedVerificationDTO;
import sbi.sf.gocblr.cconline.service.dto.NotesAdjudicatedDetailsDTO;
import sbi.sf.gocblr.cconline.service.dto.ValueStatementVerificationDTO;
import sbi.sf.gocblr.cconline.service.dto.VerificationSectionDTO;
import sbi.sf.gocblr.cconline.service.dto.VerificationSectionsViewModel;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.utils.NumberUtils;
import sbi.sf.gocblr.cconline.utils.TextUtils;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class VerificationReportService {

    private static final String VALUE_HEADING = "Value (Rs.)";
    private static final String NO_OF_PIECES_HEADING = "No. of pieces";
    private static final String DENOMINATION_HEADING = "Denomination";

    private final VerificationService verificationService;
    private final VerificationSectionService sectionService;
    private final VerificationBranchProfileService branchProfileService;
    private final BalanceVerificationService balanaceVerificationService;
    private final DetailedVerificationService detailedVerificationService;
    private final NotesAdjudicatedService notesAdjudicatedService;
    private final ValueStatementService vsService;
    private final VerificationRepository vRepo;
    private final CircleRepository circleRepository;

    private static final FontSpec r8 = new FontSpec(PreloadFont.REGULAR, 8);
    private static final FontSpec r9 = new FontSpec(PreloadFont.REGULAR, 9);
    private static final FontSpec r11 = new FontSpec(PreloadFont.REGULAR, 11);
    private static final FontSpec r11b = new FontSpec(PreloadFont.REGULAR_BOLD, 11);

    @Transactional
    public List<MonthWiseVerificationReport> getMonthWiseVerifications(LocalDate fromDate, LocalDate toDate) {
        List<MonthWiseVerificationReport> report = vRepo.getMonthWiseVerifications(fromDate, toDate);

        List<String> all_circles = circleRepository.findAllCirlces();

        List<String> circleNames = report.stream().map(urEntity -> urEntity.getCircleName()).collect(Collectors.toList());

        all_circles.removeAll(circleNames);

        report.addAll(vRepo.getZeroMonthWiseVerifications(fromDate, all_circles));

        report.add(vRepo.getMonthWiseVerificationsSum(fromDate, toDate));

        Collections.sort(
            report,
            new Comparator<MonthWiseVerificationReport>() {
                @Override
                public int compare(MonthWiseVerificationReport a1, MonthWiseVerificationReport a2) {
                    return (int) (a1.getCircleName().compareTo(a2.getCircleName()));
                }
            }
        );

        return report;
    }

    @Transactional
    public String verificationReportPdf(long verificationId, OutputStream os) {
        VerificationSectionsViewModel sectionsVm = sectionService.sectionsViewModel(verificationId);
        Verification verification = verificationService.submitted(verificationId);

        try {
            PageLayoutPDF pageLayout = new PageLayoutPDF();

            PLPageSet pageSet = new PLPageSet(PDRectangle.A4).setMargin(30, 20).setPadding(15);

            pageSet.setPageFooter(footer());

            pageSet.addElement(reportHeadingView(sectionsVm));

            for (VerificationSectionDTO section : sectionsVm.getSections()) {
                pageSet.addElement(new PLText(section.getDisplayNo() + ". " + section.getName(), r11).addMarginTop(5).addMarginBottom(5));

                if (section.getRoute() != null) {
                    switch (section.getRoute().toLowerCase()) {
                        case SectionRouteConstants.BRANCH_PROFILE:
                            VerificationBranchProfile bp = branchProfileService.getSavedBranchProfile(verificationId);
                            pageSet.addElement(
                                branchProfileView(
                                    bp,
                                    verification.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.SECURITY_OFFICER),
                                    isTopOfficialsVisit(verification.getType())
                                )
                            );
                            break;
                        case SectionRouteConstants.BALANCE_VERIFICATION:
                            BalanceVerification bv = balanaceVerificationService.getSavedBalanceVerification(verificationId);
                            pageSet.addElement(
                                new PLText("Balances as on: " + DateUtils.format(bv.getBalancesAsOn()), r9).setPaddingBottom(5)
                            );
                            pageSet.addElement(balanceVerificationView(bv));
                            break;
                        case SectionRouteConstants.NOTES_VERIFICATION:
                            List<DetailedVerificationDTO> dv = detailedVerificationService.getDetails(verificationId);
                            pageSet.addElement(notesVerificationView(dv));
                            break;
                        case SectionRouteConstants.NOTES_ADJUDICATED:
                            List<NotesAdjudicatedDetailsDTO> nad = notesAdjudicatedService.notesAdjudicatedDetails(verificationId);
                            pageSet.addElement(notesAdjudicatedView(nad));
                            break;
                        default:
                            boolean isVsSection =
                                section.getIsValueStatementSection() != null && section.getIsValueStatementSection().booleanValue();
                            boolean isHeader = section.getIsHeader() != null && section.getIsHeader().booleanValue();

                            if (isVsSection && !isHeader) {
                                List<ValueStatementVerificationDTO> vss = vsService.valueStatementsWithVerification(
                                    verificationId,
                                    section.getId()
                                );
                                pageSet.addElement(valueStatementsView(vss));
                            }
                    }
                }
            }

            // observations & certificate
            var cTable = PLTable.createWithPercentage(30f, 70f);
            cTable.addRow(
                defaultTableCell("Observations / Comments / Suggestion on visit:"),
                defaultTableCell(verification.getVerificationOfficerComments())
            );

            cTable.addRow(new PLTableCell(new PLText(certificateText(verification), r9), 2).setPadding(2f));

            cTable.addRow(
                new PLTableCell(
                    new PLText(
                        String.format(
                            "%n%n%n%n(%s)%nPF Index: %d%nDesignation: %s",
                            verification.getOfficer().getName(),
                            verification.getOfficer().getPfId(),
                            verification.getOfficer().getDesignation()
                        ),
                        r9
                    ),
                    2
                )
                    .setPadding(2f)
            );

            cTable.addRow(
                new PLTableCell(
                    new PLText(String.format("Date of Verification: %s", DateUtils.format(verification.getDateOfVerification())), r9),
                    2
                )
                    .setPadding(2f)
            );

            EPLTableGridType.FULL.applyGridToTable(cTable, new BorderStyleSpec(Color.BLACK, 0.25f));

            pageSet.addElement(cTable.addMarginTop(10f));

            pageLayout.addPageSet(pageSet);
            pageLayout.renderTo(os);
        } catch (PDFCreationException e) {
            throw new ReportGenerationFailedException(e.getMessage(), e);
        }

        log.trace("'{}', '{}'", sectionsVm.getVerificationType(), sectionsVm.getBlock());

        return reportFileName(sectionsVm.getBranchCode(), sectionsVm.getVerificationType(), sectionsVm.getBlock());
    }

    private String reportFileName(long branchCode, String type, String period) {
        String fileName = String.format("%s_%s_%s", StringUtils.leftPad(branchCode + "", 5, "0"), type.trim(), period);
        return fileName.replaceAll("[^a-zA-Z0-9\\.\\-\\_]", "_");
    }

    @Transactional
    public String verificationComplianceReportPdf(long verificationId, OutputStream os) {
        VerificationSectionsViewModel sectionsVm = sectionService.sectionsViewModel(verificationId);
        Verification verification = verificationService.submitted(verificationId);

        try {
            PageLayoutPDF pageLayout = new PageLayoutPDF();

            PLPageSet pageSet = new PLPageSet(PDRectangle.A4).setMargin(30, 20).setPadding(15);

            pageSet.setPageFooter(footer());

            pageSet.addElement(reportHeadingView(sectionsVm));

            for (VerificationSectionDTO section : sectionsVm.getSections()) {
                pageSet.addElement(new PLText(section.getDisplayNo() + ". " + section.getName(), r11).addMarginTop(5).addMarginBottom(5));

                if (section.getRoute() != null) {
                    switch (section.getRoute().toLowerCase()) {
                        case SectionRouteConstants.BRANCH_PROFILE:
                            VerificationBranchProfile bp = branchProfileService.getSavedBranchProfile(verificationId);
                            pageSet.addElement(
                                branchProfileView(
                                    bp,
                                    verification.getType().getKey().equalsIgnoreCase(VerificationTypeConstants.SECURITY_OFFICER),
                                    isTopOfficialsVisit(verification.getType())
                                )
                            );
                            break;
                        case SectionRouteConstants.BALANCE_VERIFICATION:
                            BalanceVerification bv = balanaceVerificationService.getSavedBalanceVerification(verificationId);
                            pageSet.addElement(
                                new PLText("Balances as on: " + DateUtils.format(bv.getBalancesAsOn()), r9).setPaddingBottom(5)
                            );
                            pageSet.addElement(balanceVerificationView(bv));
                            break;
                        case SectionRouteConstants.NOTES_VERIFICATION:
                            List<DetailedVerificationDTO> dv = detailedVerificationService.getDetails(verificationId);
                            pageSet.addElement(notesVerificationView(dv));
                            break;
                        case SectionRouteConstants.NOTES_ADJUDICATED:
                            List<NotesAdjudicatedDetailsDTO> nad = notesAdjudicatedService.notesAdjudicatedDetails(verificationId);
                            pageSet.addElement(notesAdjudicatedView(nad));
                            break;
                        default:
                            boolean isVsSection =
                                section.getIsValueStatementSection() != null && section.getIsValueStatementSection().booleanValue();
                            boolean isHeader = section.getIsHeader() != null && section.getIsHeader().booleanValue();

                            if (isVsSection && !isHeader) {
                                List<ValueStatementVerificationDTO> vss = vsService.valueStatementsWithVerification(
                                    verificationId,
                                    section.getId()
                                );
                                pageSet.addElement(valueStatementsComplianceView(vss));
                            }
                    }
                }
            }

            String displayText = "";
            String comments = "";
            // observations & certificate
            var cTable = PLTable.createWithPercentage(30f, 70f);

            displayText = "Observations / Comments / Suggestion on visit: ";

            if (verification.getReportSubmittedBy() != null) displayText +=
                String.format("%n(PFID - " + verification.getReportSubmittedBy() + ")");
            if (verification.getReportSubmittedOn() != null) comments = verification.getVerificationOfficerComments(); else comments = "";

            cTable.addRow(defaultTableCell(displayText), defaultTableCell(comments));

            displayText = "Branch Head Comments: ";

            if (verification.getBranchHeadPfId() != null) displayText +=
                String.format("%n(PFID - " + verification.getBranchHeadPfId() + ")");
            if (verification.getBranchHeadSubmittedOn() != null) comments = verification.getBranchHeadComments(); else comments =
                "Compliance Pending at Branch...";

            cTable.addRow(defaultTableCell(displayText), defaultTableCell(comments));

            displayText = "Scrutiny Officer Comments : ";

            if (verification.getScrutinizerPfId() != null) displayText +=
                String.format("%n(PFID - " + verification.getScrutinizerPfId() + ")");
            if (verification.getScrutinizerSubmittedOn() != null) comments = verification.getScrutinizerComments(); else comments =
                "Scrutiny Pending....";

            cTable.addRow(defaultTableCell(displayText), defaultTableCell(comments));

            displayText = "Compliance Verification Comments : ";

            if (verification.getVerificationOfficerCompliancePfId() != null) displayText +=
                String.format("%n(PFID - " + verification.getVerificationOfficerCompliancePfId() + ")");

            if (verificationService.isBiMonthlyOrHalfYearly(verification.getType().getKey())) {
                if (verification.getVoComplianceSubmittedOn() != null) {
                    comments = verification.getVerificationOfficerComplianceComments();
                } else {
                    comments = "Compliance Verification Pending....";
                }
            } else {
                comments = "N/A";
            }

            cTable.addRow(defaultTableCell(displayText), defaultTableCell(comments));

            displayText = "Closure Comments: ";

            if (verification.getClosureBy() != null) displayText += String.format("%n(PFID - " + verification.getClosureBy() + ")");
            if (verification.getClosureOn() != null) comments = verification.getClosureComments(); else comments = "Closure Pending....";

            cTable.addRow(defaultTableCell(displayText), defaultTableCell(comments));

            cTable.addRow(new PLTableCell(new PLText(certificateText(verification), r9), 2).setPadding(2f));

            cTable.addRow(
                new PLTableCell(
                    new PLText(
                        String.format(
                            "%n%n%n%n(%s)%nPF Index: %d%nDesignation: %s",
                            verification.getOfficer().getName(),
                            verification.getOfficer().getPfId(),
                            verification.getOfficer().getDesignation()
                        ),
                        r9
                    ),
                    2
                )
                    .setPadding(2f)
            );

            cTable.addRow(
                new PLTableCell(
                    new PLText(String.format("Date of Verification: %s", DateUtils.format(verification.getDateOfVerification())), r9),
                    2
                )
                    .setPadding(2f)
            );

            EPLTableGridType.FULL.applyGridToTable(cTable, new BorderStyleSpec(Color.BLACK, 0.25f));

            pageSet.addElement(cTable.addMarginTop(10f));

            pageLayout.addPageSet(pageSet);
            pageLayout.renderTo(os);

            return reportFileName(sectionsVm.getBranchCode(), sectionsVm.getVerificationType(), sectionsVm.getBlock());
        } catch (PDFCreationException e) {
            throw new ReportGenerationFailedException(e.getMessage(), e);
        }
    }

    private boolean isTopOfficialsVisit(VerificationType type) {
        return (
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.RM_DGM_CONTROLLER_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_BO_MODULE_HEAD_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.GM_NETWORK_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.CGM_VISIT) ||
            type.getKey().equalsIgnoreCase(VerificationTypeConstants.DGM_CFO_VISIT)
        );
    }

    private String certificateText(Verification verification) {
        return verification.getType().getCertificateText();
    }

    private PLTable reportHeadingView(VerificationSectionsViewModel sectionsVm) {
        PLTable headingTable = PLTable.createWithEvenlySizedColumns(1);
        headingTable.addRow(
            new PLTableCell(new PLText(String.format("%s (%d)", sectionsVm.getBranchName(), sectionsVm.getBranchCode()), r11b))
                .setHorzAlign(EHorzAlignment.CENTER)
        );
        headingTable.addRow(
            new PLTableCell(
                new PLText(
                    String.format("%s for %s period", sectionsVm.getVerificationType() + " Verification", sectionsVm.getBlock()),
                    r11b
                )
            )
                .setHorzAlign(EHorzAlignment.CENTER)
        );

        headingTable.setMarginBottom(5f);
        return headingTable;
    }

    private IPLRenderableObject<?> notesAdjudicatedView(List<NotesAdjudicatedDetailsDTO> nad) {
        final PLTable nadt = PLTable.createWithEvenlySizedColumns(7);

        nadt.addRow(
            new PLTableCell(new PLText("", r9)).setPadding(2f),
            new PLTableCell(new PLText("Full Value", r9), 2).setPadding(2f),
            new PLTableCell(new PLText("Half Value", r9), 2).setPadding(2f),
            new PLTableCell(new PLText("Rejected", r9), 2).setPadding(2f)
        );

        nadt.addRow(
            defaultTableCell(DENOMINATION_HEADING, EHorzAlignment.RIGHT),
            defaultTableCell(NO_OF_PIECES_HEADING, EHorzAlignment.RIGHT),
            defaultTableCell(VALUE_HEADING, EHorzAlignment.RIGHT),
            defaultTableCell(NO_OF_PIECES_HEADING, EHorzAlignment.RIGHT),
            defaultTableCell(VALUE_HEADING, EHorzAlignment.RIGHT),
            defaultTableCell(NO_OF_PIECES_HEADING, EHorzAlignment.RIGHT),
            defaultTableCell(VALUE_HEADING, EHorzAlignment.RIGHT)
        );

        nadt.setHeaderRowCount(2);

        for (var n : nad) {
            nadt.addRow(
                defaultTableCell(NumberUtils.inrFormat(n.getDenominationValue()), EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(n.getFullValuePieces()), EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(n.getDenominationValue() * n.getFullValuePieces()), EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(n.getHalfValuePieces()), EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(n.getDenominationValue() * n.getHalfValuePieces()), EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(n.getRejectedPieces()), EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(n.getDenominationValue() * n.getRejectedPieces()), EHorzAlignment.RIGHT)
            );
        }

        EPLTableGridType.FULL.applyGridToTable(nadt, new BorderStyleSpec(Color.BLACK, 0.25f));

        return nadt;
    }

    private IPLRenderableObject<?> notesVerificationView(List<DetailedVerificationDTO> dv) {
        final PLTable dvt = PLTable.createWithEvenlySizedColumns(8);

        dvt.addRow(
            new PLTableCell(new PLText("", r9), 3).setPadding(2f),
            new PLTableCell(new PLText("Discrepancy observed", r9), 2).setPadding(2),
            new PLTableCell(new PLText("", r9), 3).setPadding(2f)
        );

        dvt.addRow(
            defaultTableCell(DENOMINATION_HEADING).setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell(NO_OF_PIECES_HEADING).setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell(VALUE_HEADING).setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell("Shortage/Excess").setHorzAlign(EHorzAlignment.CENTER),
            defaultTableCell("Discrepancy Pieces").setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell("FICN").setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell("Soiled notes Classified as Re-issuable").setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell("Mutilated notes classified as soiled/Re-issuable").setHorzAlign(EHorzAlignment.CENTER)
        );
        dvt.setHeaderRowCount(2);

        for (var d : dv) {
            dvt.addRow(
                defaultTableCell(NumberUtils.inrFormat(d.getDenominationValue())).setHorzAlign(EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(d.getNoOfPieces())).setHorzAlign(EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(d.getDenominationValue() * d.getNoOfPieces())).setHorzAlign(EHorzAlignment.RIGHT),
                defaultTableCell(d.getDiscrepancyType() == null ? "--" : d.getDiscrepancyType().description())
                    .setHorzAlign(EHorzAlignment.CENTER),
                defaultTableCell(NumberUtils.inrFormat(d.getDiscrepancyPieces())).setHorzAlign(EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(d.getFicn())).setHorzAlign(EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(d.getSoiledWronglyClassified())).setHorzAlign(EHorzAlignment.RIGHT),
                defaultTableCell(NumberUtils.inrFormat(d.getMutilatedWronglyClassified())).setHorzAlign(EHorzAlignment.RIGHT)
            );
        }

        EPLTableGridType.FULL.applyGridToTable(dvt, new BorderStyleSpec(Color.BLACK, 0.25f));

        return dvt;
    }

    /**
     * Balance Verification
     * @param bv
     * @return
     */
    private IPLRenderableObject<?> balanceVerificationView(BalanceVerification bv) {
        final PLTable bvt = PLTable.createWithEvenlySizedColumns(2);

        bvt.addRow(defaultTableCell("Notes", EHorzAlignment.CENTER), defaultTableCell("Coins", EHorzAlignment.CENTER));

        final PLTable notes = PLTable.createWithEvenlySizedColumns(3);
        notes.addRow(
            defaultTableCell(DENOMINATION_HEADING).setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell(NO_OF_PIECES_HEADING).setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell("Value (Rs)").setHorzAlign(EHorzAlignment.RIGHT)
        );
        notes.setHeaderRowCount(1);

        final PLTable coins = PLTable.createWithEvenlySizedColumns(3);
        coins.addRow(
            defaultTableCell(DENOMINATION_HEADING).setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell(NO_OF_PIECES_HEADING).setHorzAlign(EHorzAlignment.RIGHT),
            defaultTableCell("Value (Rs)").setHorzAlign(EHorzAlignment.RIGHT)
        );
        coins.setHeaderRowCount(1);

        List<BalanceVerificationDetails> sorted = bv
            .getDenominationWiseDetails()
            .stream()
            .sorted(Comparator.comparingInt(d -> d.getDenomination().getValue()))
            .collect(Collectors.toList());
        Collections.reverse(sorted);

        for (var n : sorted) {
            if (n.getDenomination().getType().equalsIgnoreCase(DenominationType.NOTE.code())) {
                notes.addRow(
                    defaultTableCell(NumberUtils.inrFormat(n.getDenomination().getValue())).setHorzAlign(EHorzAlignment.RIGHT),
                    defaultTableCell(NumberUtils.inrFormat(n.getNoOfPieces())).setHorzAlign(EHorzAlignment.RIGHT),
                    defaultTableCell(NumberUtils.inrFormat(n.getDenomination().getValue() * n.getNoOfPieces()))
                        .setHorzAlign(EHorzAlignment.RIGHT)
                );
            } else if (n.getDenomination().getType().equalsIgnoreCase(DenominationType.COIN.code())) {
                coins.addRow(
                    defaultTableCell(NumberUtils.inrFormat(n.getDenomination().getValue())).setHorzAlign(EHorzAlignment.RIGHT),
                    defaultTableCell(NumberUtils.inrFormat(n.getNoOfPieces())).setHorzAlign(EHorzAlignment.RIGHT),
                    defaultTableCell(NumberUtils.inrFormat(n.getDenomination().getValue() * n.getNoOfPieces()))
                        .setHorzAlign(EHorzAlignment.RIGHT)
                );
            }
        }

        EPLTableGridType.FULL.applyGridToTable(notes, new BorderStyleSpec(Color.BLACK, 0.05f));
        EPLTableGridType.FULL.applyGridToTable(coins, new BorderStyleSpec(Color.BLACK, 0.05f));

        bvt.addRow(new PLTableCell(notes), new PLTableCell(coins));

        bvt.addRow(
            defaultTableCell("Has Discrepancy: " + ((bv.getHasDiscrepancy() && bv.getHasDiscrepancy().booleanValue()) ? "Yes" : "No")),
            new PLTableCell(new PLText(TextUtils.getNullPlaceHolder(bv.getDiscrepancyDetails(), "--"), r9)).setPadding(2f)
        );

        EPLTableGridType.FULL.applyGridToTable(bvt, new BorderStyleSpec(Color.BLACK, 0.25f));

        return bvt;
    }

    /**
     * Page footer
     * @return
     */
    private PLTable footer() {
        PLTable footerTable = PLTable.createWithEvenlySizedColumns(3);
        footerTable.addRow(
            new PLTableCell(new PLText("State Bank of India", r8)).setHorzAlign(EHorzAlignment.LEFT),
            new PLTableCell(
                new PLText(
                    String.format(
                        "Page %s of %s",
                        EPLPlaceholder.PAGESET_NUMBER.getVariable(),
                        EPLPlaceholder.TOTAL_PAGE_COUNT.getVariable()
                    ),
                    r8
                )
                    .setReplacePlaceholder(true)
            )
                .setHorzAlign(EHorzAlignment.CENTER),
            new PLTableCell(new PLText("Generated on: " + LocalDateTime.now().toString(), r8)).setHorzAlign(EHorzAlignment.RIGHT)
        );
        return footerTable;
    }

    private PLTable branchProfileView(VerificationBranchProfile bp, boolean isSecurityOfficer, boolean isTopOfficialsVisit) {
        if (isTopOfficialsVisit) {
            return branchProfileViewTopOfficialsVisit(bp, isTopOfficialsVisit);
        } else if (isSecurityOfficer) {
            return branchProfileViewSecurityOfficer(bp, isSecurityOfficer);
        } else {
            return branchProfileViewOthers(bp);
        }
    }

    private PLTable branchProfileViewOthers(VerificationBranchProfile bp) {
        final PLTable bpt = PLTable.createWithPercentage(50, 50);

        addBranchProfileRow(bpt, "Branch Code", bp.getBranchCode().toString());
        addBranchProfileRow(bpt, "Branch Name", bp.getBranchName());
        addBranchProfileRow(
            bpt,
            "Circle/NW/Zone/RBO",
            String.format("%s/NW-%d/%s/REG-%d", bp.getCircleName(), bp.getNetworkCode(), bp.getModuleName(), bp.getRegionCode())
        );
        addBranchProfileRow(
            bpt,
            "Branch incumbency/Since",
            String.format("Scale: %d / %s", bp.getIncumbency(), DateUtils.format(bp.getIncumbencySince()))
        );
        addBranchProfileRow(bpt, "Receipt/Payment branch", bp.getCcType().description());
        addBranchProfileRow(bpt, "Strong room size (in cubft)", NumberUtils.inrFormat(bp.getStrongRoomSize()));
        addBranchProfileRow(bpt, "CBL fixed by RBI (Rs. In Crore)", NumberUtils.inrFormat(bp.getCashBalanceLimit()));
        addBranchProfileRow(bpt, "Capacity to store cash in bundles", NumberUtils.inrFormat(bp.getCapacityToStoreCashInBundles()));
        addBranchProfileRow(bpt, "Average daily Receipt (Rs in Lakh)", NumberUtils.inrFormat(bp.getAverageDailyReciept()));
        addBranchProfileRow(bpt, "Average daily Payment (Rs. in lakh)", NumberUtils.inrFormat(bp.getAverageDailyPayment()));

        addBranchProfileRow(bpt, "Staff position (Award & Supervisory) at the branch", bp.getTotalStaff().total() + "");
        addBranchProfileRow(bpt, "Staff position (Award & Supervisory) in Cash department", bp.getCashDeptStaff().total() + "");

        addBranchProfileRow(
            bpt,
            "Currency Chest balance reported by the branch in CyM",
            NumberUtils.inrFormat(bp.getCcBalanceReportedInCyM())
        );
        addBranchProfileRow(bpt, "Balance of BGL account:98958", NumberUtils.inrFormat(bp.getBgl98958Balance()));
        addBranchProfileRow(bpt, "Soiled Note balance reported by the branch", NumberUtils.inrFormat(bp.getSoiledNotesBalanceReported()));
        addBranchProfileRow(
            bpt,
            "Balance of Soiled Notes available in the Currency Chest",
            NumberUtils.inrFormat(bp.getBalanceOfSoiledNotesAvailableInCc())
        );

        bpt.addRow(new PLTableCell(new PLText("Date of last Currency Chest Verification", r9).setPadding(2), 2));

        addBranchProfileRow(bpt, "Bi-monthly", DateUtils.format(bp.getLastBiMonthlyVerification()));
        addBranchProfileRow(bpt, "Quarterly", DateUtils.format(bp.getLastQuarterlyVerification()));
        addBranchProfileRow(bpt, "Half-yearly", DateUtils.format(bp.getLastHalfYearlyVerification()));

        addBranchProfileRow(
            bpt,
            "Expiry date of Strong Room fitness certificate",
            DateUtils.format(bp.getStrongRoomFitnessCertExpiryDate())
        );

        EPLTableGridType.FULL.applyGridToTable(bpt, new BorderStyleSpec(Color.BLACK, 0.25f));
        return bpt;
    }

    private PLTable branchProfileViewSecurityOfficer(VerificationBranchProfile bp, boolean isSecurityOfficer) {
        final PLTable bpt = PLTable.createWithPercentage(50, 50);

        addBranchProfileRow(bpt, "Branch Code", bp.getBranchCode().toString());
        addBranchProfileRow(bpt, "Branch Name", bp.getBranchName());
        addBranchProfileRow(
            bpt,
            "Circle/NW/Zone/RBO",
            String.format("%s/NW-%d/%s/REG-%d", bp.getCircleName(), bp.getNetworkCode(), bp.getModuleName(), bp.getRegionCode())
        );
        addBranchProfileRow(
            bpt,
            "Branch incumbency/Since",
            String.format("Scale: %d / %s", bp.getIncumbency(), DateUtils.format(bp.getIncumbencySince()))
        );
        addBranchProfileRow(bpt, "Receipt/Payment branch", bp.getCcType().description());
        addBranchProfileRow(bpt, "Strong room size (in cubft)", NumberUtils.inrFormat(bp.getStrongRoomSize()));
        addBranchProfileRow(bpt, "CBL fixed by RBI (Rs. In Crore)", NumberUtils.inrFormat(bp.getCashBalanceLimit()));
        addBranchProfileRow(bpt, "Capacity to store cash in bundles", NumberUtils.inrFormat(bp.getCapacityToStoreCashInBundles()));
        addBranchProfileRow(bpt, "Average daily Receipt (Rs in Lakh)", NumberUtils.inrFormat(bp.getAverageDailyReciept()));
        addBranchProfileRow(bpt, "Average daily Payment (Rs. in lakh)", NumberUtils.inrFormat(bp.getAverageDailyPayment()));

        addBranchProfileRow(bpt, "Staff position (Award & Supervisory) at the branch", bp.getTotalStaff().total() + "");
        addBranchProfileRow(bpt, "Staff position (Award & Supervisory) in Cash department", bp.getCashDeptStaff().total() + "");

        bpt.addRow(new PLTableCell(new PLText("Date of last Currency Chest Verification", r9).setPadding(2), 2));

        addBranchProfileRow(bpt, "Security Officer", DateUtils.format(bp.getLastSecurityOfficerVist()));

        addBranchProfileRow(
            bpt,
            "Expiry date of Strong Room fitness certificate",
            DateUtils.format(bp.getStrongRoomFitnessCertExpiryDate())
        );

        EPLTableGridType.FULL.applyGridToTable(bpt, new BorderStyleSpec(Color.BLACK, 0.25f));
        return bpt;
    }

    private PLTable branchProfileViewTopOfficialsVisit(VerificationBranchProfile bp, boolean isTopOfficialsVisit) {
        final PLTable bpt = PLTable.createWithPercentage(50, 50);

        addBranchProfileRow(bpt, "Branch Code", bp.getBranchCode().toString());
        addBranchProfileRow(bpt, "Branch Name", bp.getBranchName());
        addBranchProfileRow(
            bpt,
            "Circle/NW/Zone/RBO",
            String.format("%s/NW-%d/%s/REG-%d", bp.getCircleName(), bp.getNetworkCode(), bp.getModuleName(), bp.getRegionCode())
        );
        addBranchProfileRow(bpt, "Strong room size (in cubft)", NumberUtils.inrFormat(bp.getStrongRoomSize()));
        addBranchProfileRow(bpt, "CBL fixed by RBI (Rs. In Crore)", NumberUtils.inrFormat(bp.getCashBalanceLimit()));
        addBranchProfileRow(bpt, "Capacity to store cash in bundles", NumberUtils.inrFormat(bp.getCapacityToStoreCashInBundles()));
        addBranchProfileRow(bpt, "Average daily Receipt (Rs in Lakh)", NumberUtils.inrFormat(bp.getAverageDailyReciept()));
        addBranchProfileRow(bpt, "Average daily Payment (Rs. in lakh)", NumberUtils.inrFormat(bp.getAverageDailyPayment()));
        addBranchProfileRow(bpt, "Balance of BGL account:98958", NumberUtils.inrFormat(bp.getBgl98958Balance()));
        addBranchProfileRow(bpt, "Soiled Note balance reported by the branch", NumberUtils.inrFormat(bp.getSoiledNotesBalanceReported()));

        EPLTableGridType.FULL.applyGridToTable(bpt, new BorderStyleSpec(Color.BLACK, 0.25f));
        return bpt;
    }

    private PLTableCell defaultTableCell(String text) {
        return new PLTableCell(new PLText(text, r9)).setPadding(2f);
    }

    private PLTableCell defaultTableCell(String text, EHorzAlignment hAlign) {
        return new PLTableCell(new PLText(text, r9)).setHorzAlign(hAlign).setPadding(2f);
    }

    private void addBranchProfileRow(final PLTable branchProfileTable, String heading, String data) {
        branchProfileTable.addRow(
            new PLTableCell(new PLText(heading, r9).setPadding(2)),
            new PLTableCell(new PLText(data, r9).setPadding(2))
        );
    }

    /**
     * Value Statements View
     * @param vss
     * @return
     */
    private PLTable valueStatementsComplianceView(Collection<ValueStatementVerificationDTO> vss) {
        final PLTable vsTable = PLTable.createWithPercentage(4, 35, 9, 24, 9, 19);
        vsTable.setHeaderRowCount(1);

        vsTable.addRow(
            new PLTableCell(new PLText("#", r9)).setPadding(2).setHorzAlign(EHorzAlignment.RIGHT).setVertAlign(EVertAlignment.BOTTOM),
            new PLTableCell(new PLText("Description", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM),
            new PLTableCell(new PLText("Comp.", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM).setVertSplittable(false),
            new PLTableCell(new PLText("Verification Officer Comments", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM),
            new PLTableCell(new PLText("Br. Comp.", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM),
            new PLTableCell(new PLText("Branch Comments", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM)
        );

        for (ValueStatementVerificationDTO vs : vss) {
            String complianceDescription = getOptionComplianceDescription(vs.getCompliance());

            String branchComplianceDescription = getComplianceStatusDescription(vs.getBranchCompliance());

            if (!Boolean.TRUE.equals(vs.getValueStatement().getIsOnlyAsHeader())) {
                switch (vs.getValueStatement().getInputType()) {
                    case DATE:
                        complianceDescription = DateUtils.format(vs.getDateInput());
                        break;
                    case NUMBER:
                        complianceDescription = NumberUtils.inrFormat(vs.getNumberInput());
                        break;
                    default:
                        break;
                }
            }
            vsTable.addRow(
                new PLTableCell(new PLText(vs.getValueStatement().getDisplayNumber() + ".", r9))
                    .setPadding(2)
                    .setHorzAlign(EHorzAlignment.RIGHT),
                new PLTableCell(new PLText(vs.getValueStatement().getDescription(), r9)).setPadding(2),
                new PLTableCell(new PLText(complianceDescription, r9)).setPadding(2),
                new PLTableCell(new PLText(TextUtils.trimAndSafeNull(vs.getComments(), ""), r9)).setPadding(2),
                new PLTableCell(new PLText(TextUtils.trimAndSafeNull(branchComplianceDescription, ""), r9)).setPadding(2),
                new PLTableCell(new PLText(TextUtils.trimAndSafeNull(vs.getBranchComments(), ""), r9)).setPadding(2)
            );
        }

        EPLTableGridType.FULL.applyGridToTable(vsTable, new BorderStyleSpec(Color.BLACK, 0.25f));
        return vsTable;
    }

    private PLTable valueStatementsView(Collection<ValueStatementVerificationDTO> vss) {
        final PLTable vsTable = PLTable.createWithPercentage(4, 49, 11, 36);
        vsTable.setHeaderRowCount(1);

        vsTable.addRow(
            new PLTableCell(new PLText("#", r9)).setPadding(2).setHorzAlign(EHorzAlignment.RIGHT).setVertAlign(EVertAlignment.BOTTOM),
            new PLTableCell(new PLText("Description", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM),
            new PLTableCell(new PLText("Comp.", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM).setVertSplittable(false),
            new PLTableCell(new PLText("Comments", r9)).setPadding(2).setVertAlign(EVertAlignment.BOTTOM)
        );

        for (ValueStatementVerificationDTO vs : vss) {
            String complianceDescription = getOptionComplianceDescription(vs.getCompliance());

            if (!Boolean.TRUE.equals(vs.getValueStatement().getIsOnlyAsHeader())) {
                switch (vs.getValueStatement().getInputType()) {
                    case DATE:
                        complianceDescription = DateUtils.format(vs.getDateInput());
                        break;
                    case NUMBER:
                        complianceDescription = NumberUtils.inrFormat(vs.getNumberInput());
                        break;
                    default:
                        break;
                }
            }
            vsTable.addRow(
                new PLTableCell(new PLText(vs.getValueStatement().getDisplayNumber() + ".", r9))
                    .setPadding(2)
                    .setHorzAlign(EHorzAlignment.RIGHT),
                new PLTableCell(new PLText(vs.getValueStatement().getDescription(), r9)).setPadding(2),
                new PLTableCell(new PLText(complianceDescription, r9)).setPadding(2),
                new PLTableCell(new PLText(TextUtils.trimAndSafeNull(vs.getComments(), ""), r9)).setPadding(2)
            );
        }

        EPLTableGridType.FULL.applyGridToTable(vsTable, new BorderStyleSpec(Color.BLACK, 0.25f));
        return vsTable;
    }

    private String getOptionComplianceDescription(OptionCompliance oc) {
        if (oc == null) {
            return "";
        }
        return oc.description();
    }

    private String getComplianceStatusDescription(ComplianceStatus oc) {
        if (oc == null) {
            return "";
        }
        return oc.description();
    }
}
