package sbi.sf.gocblr.cconline.model;

public interface VsConsolidatedSummaryCircleWise {
    Long getCircleCode();
    String getCircleName();
    String getSectionDisplayNo();
    Integer getSectionDisplayOrder();

    Integer getParentParentDisplayOrder();
    String getParentParentDisplayNumber();

    Integer getParentDisplayOrder();
    String getParentDisplayNumber();

    long getVsId();

    Integer getDisplayOrder();
    String getDisplayNumber();

    Integer getIndentLevel();

    String getDescription();

    Boolean getIsOnlyAsHeader();

    Integer getNotCompliedCount();
}
