package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.Optional;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.domain.CcBglBalance;
import sbi.sf.gocblr.cconline.domain.CcCloseRequests;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.repository.CcClosureRepository;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.dto.CyMClosingBalance;
import sbi.sf.gocblr.cconline.utils.JsonUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.CcClosureDataVM;
import sbi.sf.gocblr.cconline.web.rest.vm.CcClosureModel;

@Slf4j
@Service
@RequiredArgsConstructor
public class CcClosureService {

    private final CurrencyChestService currencyChestService;
    private final CcClosureRepository closeRepo;

    @Transactional
    public CcClosureDataVM fetchCcClosure(CcClosureModel fetchData) {
        log.trace(">> submitCcClosure: {}", fetchData);

        // 1: whether it is a currency chest branch
        CurrencyChest cc = currencyChestService.getBranchCode(fetchData.getBrCode());

        log.trace("if (cc.isPresent() )");

        //2: check if is currency chest is closed already
        if (Boolean.TRUE.equals(cc.getIsClosed())) {
            log.trace("If Boolean.TRUE.equals(cc.get().getIsClosed())");
            throw new InvalidOperationException("Currency Chest: " + fetchData.getBrCode() + " is closed already");
        } else {
            Optional<CyMClosingBalance> cb = closeRepo.getCyMClosingBalance(fetchData.getBrCode());
            Optional<CcBglBalance> bgl98908 = closeRepo.getBGL98908ClosingBalance(fetchData.getBrCode());
            Optional<CcBglBalance> bgl98958 = closeRepo.getBGL98958ClosingBalance(fetchData.getBrCode());

            CcClosureDataVM ccVm = new CcClosureDataVM();

            ccVm.setCircleCode(cc.getCircle().getCircleCode());
            ccVm.setCircleName(cc.getCircle().getCircleName());
            ccVm.setNetworkCode(cc.getNetwork().getNetworkCode());
            ccVm.setModuleCodeCode(cc.getModule().getModuleCode());
            ccVm.setModuleName(cc.getModule().getModuleName());
            ccVm.setRegionCode(cc.getRegion().getRegionCode());
            ccVm.setBranchCode(cc.getBranchCode());
            ccVm.setBranchName(cc.getBranchName());
            ccVm.setFsloCode(cc.getFslo().getBranchCode());
            ccVm.setCcCode(cc.getCcCode());

            ccVm.setCcClosingBalance(cb.isPresent() ? cb.get().getCcClosingBalance() : null);
            ccVm.setCcClosingBalanceDate(cb.isPresent() ? cb.get().getCcClosingBalanceDate() : null);
            ccVm.setCcBalanceZeroFlag(cb.isPresent() ? cb.get().getCcClosingBalance() == 0 : null);

            ccVm.setBgl98908ClosingBalance(bgl98908.isPresent() ? bgl98908.get().getValue() : null);
            ccVm.setBgl98908ClosingDate(bgl98908.isPresent() ? bgl98908.get().getDate() : null);

            ccVm.setBgl98958ClosingBalance(bgl98958.isPresent() ? bgl98958.get().getValue() : null);
            ccVm.setBgl98958ClosingDate(bgl98958.isPresent() ? bgl98958.get().getDate() : null);

            log.debug("<< submitCcClosure: {}", ccVm);

            return ccVm;
        }
    }

    @Transactional
    public void submitCcClosure(@Valid CcClosureModel submitData) {
        log.debug(JsonUtils.toString(submitData));

        CurrencyChest cc = currencyChestService.getBranchCode(submitData.getBrCode());

        cc.setIsClosed(true);
        cc.setClosedDate(submitData.getDateOfClosure());

        CcCloseRequests toSubmit = new CcCloseRequests();

        toSubmit.setCc(cc);
        toSubmit.setClosedOn(submitData.getDateOfClosure());
        toSubmit.setClosedInSystem(LocalDate.now());
        toSubmit.setClosedBy(SecurityUtils.getLoggedInUser().getId());

        closeRepo.save(toSubmit);
    }
}
