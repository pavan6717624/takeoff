package sbi.sf.gocblr.cconline.config;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import javax.annotation.Nullable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.zalando.logbook.Correlation;
import org.zalando.logbook.HttpLogFormatter;
import org.zalando.logbook.HttpRequest;
import org.zalando.logbook.HttpResponse;
import org.zalando.logbook.Precorrelation;
import org.zalando.logbook.json.JsonHttpLogFormatter;
import sbi.sf.gocblr.cconline.security.AppUser;

public class PrincipalHttpLogFormatter implements HttpLogFormatter {

    private final JsonHttpLogFormatter delegate;

    PrincipalHttpLogFormatter(final JsonHttpLogFormatter delegate) {
        this.delegate = delegate;
    }

    @Override
    public String format(Precorrelation precorrelation, HttpRequest request) throws IOException {
        final Map<String, Object> content = delegate.prepare(precorrelation, request);
        content.put("timestamp", ZonedDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        content.put("principal", getPrincipal());
        content.put("sessionId", getSessionId());
        content.put("client", request.getRemote());
        return delegate.format(content);
    }

    @Override
    public String format(Correlation correlation, HttpResponse response) throws IOException {
        final Map<String, Object> content = delegate.prepare(correlation, response);
        content.put("timestamp", ZonedDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        content.put("principal", getPrincipal());
        content.put("sessionId", getSessionId());
        content.put("responseSize", response.getBody().length);
        return delegate.format(content);
    }

    private Object getPrincipal() {
        final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {
            @Nullable
            final String principal = authentication.getName();
            return principal == null ? "anonymous" : principal;
        }
        return "anonymous";
    }

    private Long getSessionId() {
        if (
            SecurityContextHolder.getContext().getAuthentication() != null &&
            SecurityContextHolder.getContext().getAuthentication().getPrincipal() != null
        ) {
            Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (principal instanceof AppUser) {
                AppUser user = (AppUser) principal;
                return user.getSessionId();
            }
        }
        return -1L;
    }
}
