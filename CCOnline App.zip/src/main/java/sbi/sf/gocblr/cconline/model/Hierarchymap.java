package sbi.sf.gocblr.cconline.model;

public class Hierarchymap {

    String key;
    String value;
}
