package sbi.sf.gocblr.cconline.service;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface SmsApiService {
    @FormUrlEncoded
    @POST("/bmg/sms/sbiabdinf")
    Call<String> sendSms(
        @Field("content-type") String contentType,
        @Field("sender_id") String senderId,
        @Field("Mobile") String mobile,
        @Field("Message") String message,
        @Field("Intflag") int international,
        @Field("Charging") int chargeApplicable
    );
}
