package sbi.sf.gocblr.cconline.model;

import lombok.Data;

@Data
public class VerificationLetterModel {

    private String officerTitle;
    private String officerName;
    private Long officerPfIndex;
    private String officerDesignation;
    private String officerBranchName;
    private Long officerBranchCode;
    private String letterDate;
    private String verificationType;
    private String verificationBranchName;
    private Long verificationBranchCode;
    private String verificationToBeCompletedBefore;

    private String circleName;

    private boolean halfYearly;
}
