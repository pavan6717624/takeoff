package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "verification_sections")
public class VerificationSection implements Serializable {

    private static final long serialVersionUID = 4186113971165452146L;

    @Id
    private Long id;

    @Column(name = "display_order")
    private Integer displayOrder;

    @Column(name = "display_no")
    private String displayNo;

    @Column(length = 100)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "verification_type_id", foreignKey = @ForeignKey(name = "fk_verification_section_verification_type"))
    private VerificationType verificationType;

    @Column(name = "is_value_statement_section")
    private Boolean isValueStatementSection;

    @Column(name = "is_header")
    private Boolean isHeader;

    @OneToMany(mappedBy = "section")
    private Set<ValueStatement> valueStatements;

    @ManyToOne
    @JoinColumn(name = "parent_section_id", foreignKey = @ForeignKey(name = "fk_verification_section_parent"))
    private VerificationSection parentSection;

    @OneToMany(mappedBy = "parentSection")
    private Set<VerificationSection> subSections;

    @Column(length = 100)
    private String route;
}
