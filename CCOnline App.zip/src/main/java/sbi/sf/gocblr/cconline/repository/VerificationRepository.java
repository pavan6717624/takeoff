package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.domain.VerificationOfficer;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.model.MonthWiseVerificationReport;
import sbi.sf.gocblr.cconline.model.StatusSummary;
import sbi.sf.gocblr.cconline.model.StatusSummaryDTO;
import sbi.sf.gocblr.cconline.model.VisitsStatusSummary;
import sbi.sf.gocblr.cconline.model.VsConsolidatedSummaryCircleWise;
import sbi.sf.gocblr.cconline.model.verificationmis.RepeatedObservationBranches;
import sbi.sf.gocblr.cconline.model.verificationmis.VsBranchPair;
import sbi.sf.gocblr.cconline.model.verificationmis.VsClosureParameterWisePending;
import sbi.sf.gocblr.cconline.model.verificationmis.VsClosureStatistics;
import sbi.sf.gocblr.cconline.model.verificationmis.VsConsolidatedBranchDetails;
import sbi.sf.gocblr.cconline.repository.custom.CustomizedVerificationRepository;

@Repository
public interface VerificationRepository
    extends JpaRepository<Verification, Long>, JpaSpecificationExecutor<Verification>, CustomizedVerificationRepository {
    default Page<Verification> assignedVerifications(
        VerificationType ty,
        LocalDate f,
        LocalDate t,
        VerificationOfficer v,
        Pageable pageable
    ) {
        return findByTypeAndBlockFromAndBlockToAndOfficer(ty, f, t, v, pageable);
    }

    abstract Page<Verification> findByTypeAndBlockFromAndBlockToAndOfficer(
        VerificationType type,
        LocalDate f,
        LocalDate t,
        VerificationOfficer v,
        Pageable pageable
    );

    @EntityGraph(attributePaths = { "currencyChest" })
    Optional<Verification> findByTypeAndBlockFromAndBlockToAndCurrencyChest(
        VerificationType vt,
        LocalDate pf,
        LocalDate pt,
        CurrencyChest cc
    );

    default Optional<Verification> findExisting(VerificationType vt, LocalDate pf, LocalDate pt, CurrencyChest cc) {
        return findByTypeAndBlockFromAndBlockToAndCurrencyChest(vt, pf, pt, cc);
    }

    @EntityGraph(attributePaths = { "currencyChest", "officer" })
    Optional<Verification> getById(Long id);

    @EntityGraph(
        attributePaths = {
            "currencyChest",
            "currencyChest.region",
            "currencyChest.region.module",
            "currencyChest.region.module.network",
            "currencyChest.region.module.network.circle",
            "officer",
        }
    )
    List<Verification> findByTypeAndOfficerPfId(VerificationType vt, Long pfId);

    /**
     * Find verification for id and assigned to officer
     * @param id verification id
     * @param vo assigned officer
     * @return Optional<Verification>
     */
    Optional<Verification> findByIdAndOfficer(long id, VerificationOfficer vo);

    List<Verification> findByCurrencyChestBranchCode(long branchCode);

    Optional<Verification> findByCurrencyChestBranchCodeAndTypeAndBlockFromAndBlockTo(
        long branchCode,
        VerificationType vt,
        LocalDate bf,
        LocalDate bt
    );

    @Query(
        "SELECT v " +
        "  FROM Verification v " +
        "       JOIN FETCH v.currencyChest c " +
        " WHERE c.circle.circleCode = :circleCode " +
        "   AND v.type.id IN (:types)"
    )
    List<Verification> closure(@Param("circleCode") long circleCode, @Param("types") int[] types);

    @Query(
        "SELECT v " +
        "  FROM Verification v " +
        " WHERE v.currencyChest.circle.circleCode = :circleCode " +
        "   AND v.currencyChest.network.networkCode = :networkCode " +
        "   AND v.currencyChest.module.moduleCode = :moduleCode " +
        "   AND v.type.id IN (:types)"
    )
    List<Verification> closure(
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("types") int[] types
    );
    
    
    /*
     *  IN_PROGRESS("P", "In-Progress"),
    REPORT_SUBMITTED("S", "Verification/Visit Report Submitted"),
    CMP_SUBMITTED_BY_BR_MAKER("CSBM", "Compliance Submitted by Branch Maker"),
    CMP_REJECTED_BY_BR_HEAD("CRBH", "Compliance Rejected by Branch Head"),
    CMP_SUBMITTED_BY_BR_HEAD("CSBH", "Compliance Submitted by Branch Head"),
    CMP_REJECTED_BY_SCRUTINIZER("CRBS", "Compliance Rejected by Scrutinizer"),
    CMP_SUBMITTED_BY_SCRUTINIZER("CSBS", "Compliance Submitted by Scrutinizer"),
    CMP_VERIFIED_BY_VO("CVBVO", "Compliance Verified by Verification Officer"),
    CMP_REJECTED_BY_CA("CRBCA", "Compliance Rejected by Closure Authority"),
    CMP_CLOSED("C", "Closure");
     * 
     */
    

    @Query(
        "SELECT c.circle.circleName as circle, " +
        "       SUM (1) as totalCcs, " +
        "       SUM (CASE WHEN vo IS NULL THEN 1 ELSE 0 END) as voNotIdentified, " +
        "       SUM (CASE WHEN vo IS NOT NULL AND v.status IS NULL THEN 1 ELSE 0 END) as notStarted, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status = 'P' THEN 1 ELSE 0 END) as inProgress, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('S', 'CSBM', 'CRBH', 'CRBS') THEN 1 ELSE 0 END) as pendingAtBranch, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('CSBH', 'CRBCA') THEN 1 ELSE 0 END) as pendingAtController, " +
        "		SUM (CASE WHEN v.type.key in ('bi-monthly','half-yearly') AND v.status IS NOT NULL and v.status IN ('CSBS') THEN 1 ELSE 0 END) as pendingAtCompliance, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND ((v.type.key not in ('bi-monthly','half-yearly') AND v.status IN ('CSBS', 'CVBVO')) or (v.type.key in ('bi-monthly','half-yearly') AND v.status IN ('CVBVO')))  THEN 1 ELSE 0 END) as awaitingForClosure, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('C') THEN 1 ELSE 0 END) as closed " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN Verification v " +
        "              ON v.currencyChest = c " +
        "             AND v.type = :verificationType " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        "       LEFT JOIN VerificationOfficer vo " +
        "              ON vo.verification = v " +
        " WHERE NVL(c.dateOfOpening, :blockTo) <= :blockTo " +
        "   AND NVL(c.closedDate, (:blockTo + 1)) >= :blockTo " +
        " GROUP BY c.circle.circleName " +
        " ORDER BY c.circle.circleName"
    )
    List<StatusSummary> statusSummaryCircleWise(
        @Param("verificationType") VerificationType type,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo
    );

    @Query(
        "SELECT c.circle.circleName as circle, " +
        "       c.network.networkCode as network, " +
        "       c.module.moduleName as module, " +
        "       c.region.regionCode as region, " +
        "       SUM (1) as totalCcs, " +
        "       SUM (CASE WHEN v.officer IS NULL THEN 1 ELSE 0 END) as voNotIdentified, " +
        "       SUM (CASE WHEN v.officer IS NOT NULL AND v.status IS NULL THEN 1 ELSE 0 END) as notStarted, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status = 'P' THEN 1 ELSE 0 END) as inProgress, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('S', 'CSBM', 'CRBH', 'CRBS') THEN 1 ELSE 0 END) as pendingAtBranch, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('CSBH', 'CRBCA') THEN 1 ELSE 0 END) as pendingAtController, " +
        "		SUM (CASE WHEN v.type.key in ('bi-monthly','half-yearly') AND v.status IS NOT NULL and v.status IN ('CSBS') THEN 1 ELSE 0 END) as pendingAtCompliance, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND ((v.type.key not in ('bi-monthly','half-yearly') AND v.status IN ('CSBS', 'CVBVO')) or (v.type.key in ('bi-monthly','half-yearly') AND v.status IN ('CVBVO')))  THEN 1 ELSE 0 END) as awaitingForClosure, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('C') THEN 1 ELSE 0 END) as closed " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN Verification v " +
        "              ON v.currencyChest = c " +
        "             AND v.type = :verificationType " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        " WHERE NVL(c.dateOfOpening, :blockTo) <= :blockTo " +
        "   AND NVL(c.closedDate, (:blockTo + 1)) >= :blockTo " +
        "   AND (:circleCode IS NULL OR c.circle.circleCode = :circleCode) " +
        "   AND (:networkCode IS NULL OR c.network.networkCode = :networkCode) " +
        "   AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR c.region.regionCode = :regionCode) " +
        " GROUP BY c.circle.circleName, c.network.networkCode, c.module.moduleName, c.region.regionCode " +
        " ORDER BY circle, network, module, region"
    )
    List<StatusSummary> statusSummary(
        @Param("verificationType") VerificationType type,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode
    );
    
    
    
    
    
    
    @Query(
            "SELECT c.circle.circleName as circle, " +
            " 		v.type.key as type, "+
            "		concat(v.blockFrom,' To ',v.blockTo) as block, "+
            "       c.network.networkCode as network, " +
            "       c.module.moduleName as module, " +
            "       c.region.regionCode as region, " +
            "       SUM (1) as totalCcs, " +
            "       SUM (CASE WHEN v.officer IS NULL THEN 1 ELSE 0 END) as voNotIdentified, " +
            "       SUM (CASE WHEN v.officer IS NOT NULL AND v.status IS NULL THEN 1 ELSE 0 END) as notStarted, " +
            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status = 'P' THEN 1 ELSE 0 END) as inProgress, " +
            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted, " +
            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('S', 'CSBM', 'CRBH', 'CRBS') THEN 1 ELSE 0 END) as pendingAtBranch, " +
            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('CSBH', 'CRBCA') THEN 1 ELSE 0 END) as pendingAtController, " +
            "		SUM (CASE WHEN v.type.key in ('bi-monthly','half-yearly') AND v.status IS NOT NULL and v.status IN ('CSBS') THEN 1 ELSE 0 END) as pendingAtCompliance, " +
            "       SUM (CASE WHEN v.status IS NOT NULL AND ((v.type.key not in ('bi-monthly','half-yearly') AND v.status IN ('CSBS', 'CVBVO')) or (v.type.key in ('bi-monthly','half-yearly') AND v.status IN ('CVBVO')))  THEN 1 ELSE 0 END) as awaitingForClosure, " +
            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('C') THEN 1 ELSE 0 END) as closed, " 
            
+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as rmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=c.circle.circleCode and a.branch.network.networkCode=c.network.networkCode and a.branch.module.moduleCode=c.module.moduleCode and a.branch.region.regionCode=c.region.regionCode and a.branch.branchTypeCode=22 and length(trim(email)) > 1 and a.forRole.receivers like 'Regional Manager' ) as rmEmail, "
+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as cmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=c.circle.circleCode and a.branch.network.networkCode=c.network.networkCode and a.branch.module.moduleCode=c.module.moduleCode and a.branch.region.regionCode=c.region.regionCode and a.branch.branchTypeCode=22 and length(trim(email)) > 1 and a.forRole.receivers like 'CM (C&O)' ) as cmEmail, "


+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmEmailDirect from AutoAlertsDetails a where a.branch.circle.circleCode=c.circle.circleCode and a.branch.network.networkCode=c.network.networkCode and a.branch.module.moduleCode=c.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM (B&O)' ) as dgmEmailDirect, "
+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as cmagmEmailDirect from AutoAlertsDetails a where a.branch.circle.circleCode=c.circle.circleCode and a.branch.network.networkCode=c.network.networkCode and a.branch.module.moduleCode=c.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'CM/AGM (GB)' ) as cmagmEmailDirect, "



+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=c.circle.circleCode and a.branch.network.networkCode=c.network.networkCode and a.branch.module.moduleCode=c.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM (B&O)' ) as dgmEmail, "
+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as cmagmEmail from AutoAlertsDetails a where a.branch.circle.circleCode=c.circle.circleCode and a.branch.network.networkCode=c.network.networkCode and a.branch.module.moduleCode=c.module.moduleCode and a.branch.branchTypeCode=17 and length(trim(email)) > 1 and a.forRole.receivers like 'CM/AGM (GB)' ) as cmagmEmail, "


//+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as agmfsloEmail from AutoAlertsDetails a where abs(a.branch.branchCode)=abs(c.fslo.branchCode) and length(trim(email)) > 1 and a.forRole.receivers like 'AGM FSLO' ) as agmfsloEmail, "
+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmcfoEmail from AutoAlertsDetails a where a.branch.branchTypeCode=18 and a.branch.circle.circleCode=c.circle.circleCode and length(trim(email)) > 1 and a.forRole.receivers like 'DGM & CFO' ) as dgmcfoEmail, "
+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as dgmabdEmail from AutoAlertsDetails a where a.branch.branchCode=3999 and length(trim(email)) > 1 and a.forRole.receivers like 'DGM ABD' ) as dgmabdEmail, "
+ " (select distinct (case when count(distinct email)!=1 then null else min(email) end) as abdEmail from AutoAlertsDetails a where a.branch.branchCode=3999 and length(trim(email)) > 1 and a.forRole.receivers like 'ABD DEPT.' ) as abdEmail "

            
          +  "  FROM CurrencyChest c " +
            "       LEFT JOIN Verification v " +
            "              ON v.currencyChest = c " +
            "             AND ((v.blockFrom in (select max(vb.blockFrom) from VerificationBlock vb where vb.type=v.type)" +
            "             AND v.blockTo in (select max(vb.blockTo) from VerificationBlock vb where vb.type=v.type))"
            + "				OR (v.blockFrom in (select max(vb1.blockFrom) from VerificationBlock vb1 where vb1.type=v.type and vb1.blockFrom not in (select max(vb.blockFrom) from VerificationBlock vb where vb.type=v.type))"
            + "                AND v.blockTo in (select max(vb1.blockTo) from VerificationBlock vb1 where vb1.type=v.type and vb1.blockTo not in (select max(vb.blockTo) from VerificationBlock vb where vb.type=v.type))))" +
            
            
            " WHERE NVL(c.dateOfOpening, v.blockTo) <= v.blockTo " +
            "   AND NVL(c.closedDate, (v.blockTo + 1)) >= v.blockTo " +
            " GROUP BY c.circle.circleName, c.circle.circleCode, c.network.networkCode, c.module.moduleName, c.module.moduleCode, c.region.regionCode, v.type.key, concat(v.blockFrom,' To ',v.blockTo) " +
            " ORDER BY circle, network, module, region, block"
        )
        List<StatusSummary> statusSummaryAlerts();
    
    
    
    

    @Query(
        "SELECT CONCAT(cc.branchCode, 'b', vs.id) as code, " +
        "       vsv.compliance as compliance, " +
        " case when (vsc!=NULL and v.status = 'C') then case when vsc.branchCompliance='NC' then '(NR)' else '(R)' end else '' end as nextStatus"+
        "  FROM ValueStatementVerification vsv " +
        "       JOIN Verification v " +
        "         ON v = vsv.verification " +
        "       JOIN ValueStatement vs " +
        "         ON vs = vsv.valueStatement " +
        "       JOIN CurrencyChest cc " +
        "         ON cc = v.currencyChest " +
        "      LEFT JOIN ValueStatementCompliance vsc " +
        "         ON vsc.vsVerification.id = vsv.id " +
                " WHERE v.type.id = :type " +
        "   AND v.blockFrom = :blockFrom " +
        "   AND v.blockTo = :blockTo " +
        "   AND (:circleCode IS NULL OR cc.circle.circleCode = :circleCode) " +
        "   AND (:networkCode IS NULL OR cc.network.networkCode = :networkCode) " +
        "   AND (:moduleCode IS NULL OR cc.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR cc.region.regionCode = :regionCode)"
    )
    List<VsBranchPair> vsConsolidatedBranchWiseNew(
        @Param("type") int typeId,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode
    );

    // prettier-ignore
    @Query(
    	"SELECT c " +
    	"  FROM Circle c " +
    	" WHERE c.circleCode NOT IN (0, 15, 16, 17, 18, 20, 22) " +
    	" ORDER BY c.circleName"
    )
    List<Circle> vsConsilatedCircleWiseCircles(
        @Param("type") int typeId,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo
    );

    @Query(
        "SELECT s.displayNo as sectionDisplayNo, " +
        "       s.displayOrder as sectionDisplayOrder, " +
        "       NVL(vs.displayNumber, '') as displayNumber, " +
        "       vs.displayOrder as displayOrder, " +
        "       vs.description as description, " +
        "       NVL(vs.isOnlyAsHeader, 0) as isOnlyAsHeader, " +
        "       NVL(vs.indentLevel, 0) as indentLevel, " +
        "       c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       vs.id as vsId, " +
        "       SUM(CASE WHEN NVL(vsv.compliance, 'NA') = 'NC' THEN 1 ELSE 0 END) as notCompliedCount " +
        "  FROM ValueStatement vs " +
        "       JOIN VerificationSection s " +
        "         ON s = vs.section " +
        "        AND s.verificationType.id = :type " +
        "       LEFT JOIN Verification v " +
        "              ON v.type.id = :type " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        "             AND COALESCE(v.status, 'P') <> 'P' " +
        "       LEFT JOIN CurrencyChest c " +
        "              ON c = v.currencyChest " +
        "       LEFT JOIN ValueStatementVerification vsv " +
        "              ON vsv.valueStatement = vs " +
        "             AND vsv.verification = v " +
        " GROUP BY s.displayNo, s.displayOrder, NVL(vs.displayNumber, ''), vs.displayOrder, vs.description, NVL(vs.isOnlyAsHeader, 0), " +
        "          NVL(vs.indentLevel, 0), c.circle.circleCode, c.circle.circleName, vs.id"
    )
    List<VsConsolidatedSummaryCircleWise> vsConsilatedCircleWise(
        @Param("type") int typeId,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo
    );

    @Query(
        "SELECT vs.id as vsId, " +
        "       s.id as sectionId, " +
        "       NVL(s.displayOrder, 0) as sectionDisplayOrder, " +
        "       s.displayNo as sectionDisplayNo, " +
        "       NVL(vs.displayOrder, 0) as displayOrder, " +
        "       vs.displayNumber as displayNumber, " +
        "       NVL(vs.indentLevel, 0) as indentLevel, " +
        "       vs.description as description, " +
        "       NVL(vs.isOnlyAsHeader, 0) as isOnlyAsHeader, " +
        "       vs.inputType as inputType, " +
        "       SUM(CASE WHEN NVL(vsv.compliance, 'NULL') = 'NC' THEN 1 ELSE 0 END) as discrepanciesObserved, " +
        "       SUM(CASE WHEN NVL(vsv.compliance, 'NULL') = 'C' THEN 1 ELSE 0 END) as noDiscrepancyObserved, " +
        "       SUM(CASE WHEN NVL(vsc.branchCompliance, 'NULL') = 'C' THEN 1 ELSE 0 END) as discrepanciesClosed " +
        "  FROM ValueStatement vs " +
        "       JOIN VerificationSection s " +
        "         ON s = vs.section " +
        "        AND s.verificationType.id = :type " +
        "       LEFT JOIN Verification v " +
        "              ON v.type.id = :type " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo  " +
        "             AND (NVL(v.status, 'P') = 'C') " +
        "       LEFT JOIN ValueStatementVerification vsv " +
        "              ON vsv.valueStatement = vs " +
        "             AND vsv.verification = v " +
        "       LEFT JOIN ValueStatementCompliance vsc " +
        "              ON vsc.vsVerification = vsv " +
        "       LEFT JOIN CurrencyChest c " +
        "              ON c = v.currencyChest " +
        " WHERE s.verificationType.id = :type " +
        "   AND (:circle IS NULL OR c.circle.circleCode = :circle) " +
        "   AND (:network IS NULL OR c.network.networkCode = :network) " +
        "   AND (:module IS NULL OR c.module.moduleCode = :module) " +
        "   AND (:region IS NULL OR c.region.regionCode = :region) " +
        " GROUP BY s.id, vs.id, NVL(s.displayOrder, 0), s.displayNo, NVL(vs.displayOrder, 0), vs.displayNumber, " +
        "          NVL(vs.indentLevel, 0), vs.description, NVL(vs.isOnlyAsHeader, 0), vs.inputType " +
        " ORDER BY sectionDisplayOrder, sectionId, displayOrder, vsId"
    )
    List<VsClosureStatistics> vsClosureStatistics(
        @Param("type") int typeId,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circle") Long circleCode,
        @Param("network") Long networkCode,
        @Param("module") Long moduleCode,
        @Param("region") Long regionCode
    );

    @Query(
        "SELECT vs.id as vsId, " +
        "       s.id as sectionId, " +
        "       NVL(s.displayOrder, 0) as sectionDisplayOrder, " +
        "       s.displayNo as sectionDisplayNo, " +
        "       NVL(vs.displayOrder, 0) as displayOrder, " +
        "       vs.displayNumber as displayNumber, " +
        "       vs.description as description, " +
        "       NVL(vs.indentLevel, 0) as indentLevel, " +
        "       vs.description as description, " +
        "       NVL(vs.isOnlyAsHeader, 0) as isOnlyAsHeader, " +
        "       vs.inputType as inputType, " +
        "       SUM(CASE WHEN NVL(vsc.branchCompliance, 'NULL') = 'NC' THEN 1 ELSE 0 END) as pendingBranches " +
        "  FROM ValueStatement vs " +
        "       JOIN VerificationSection s " +
        "         ON s = vs.section " +
        "        AND s.verificationType.id = :type " +
        "       LEFT JOIN Verification v " +
        "              ON v.type.id = :type " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo  " +
        "             AND (NVL(v.status, 'P') = 'C') " +
        "       LEFT JOIN ValueStatementVerification vsv " +
        "              ON vsv.valueStatement = vs " +
        "             AND vsv.verification = v " +
        "       LEFT JOIN ValueStatementCompliance vsc " +
        "              ON vsc.vsVerification = vsv " +
        "       LEFT JOIN CurrencyChest c " +
        "              ON c = v.currencyChest " +
        " WHERE (:circle IS NULL OR c.circle.circleCode = :circle) " +
        "   AND (:network IS NULL OR c.network.networkCode = :network) " +
        "   AND (:module IS NULL OR c.module.moduleCode = :module) " +
        "   AND (:region IS NULL OR c.region.regionCode = :region) " +
        " GROUP BY s.id, vs.id, NVL(s.displayOrder, 0), s.displayNo, NVL(vs.displayOrder, 0), vs.displayNumber, " +
        "         vs.description, NVL(vs.indentLevel, 0), vs.description, NVL(vs.isOnlyAsHeader, 0), vs.inputType " +
        " ORDER BY sectionDisplayOrder, sectionId, displayOrder, vsId"
    )
    List<VsClosureParameterWisePending> vsClosureParameterWisePending(
        @Param("type") int typeId,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circle") Long circleCode,
        @Param("network") Long networkCode,
        @Param("module") Long moduleCode,
        @Param("region") Long regionCode
    );

    // prettier-ignore
    @Query(
    		nativeQuery = true,
    		value = 
				"SELECT vs.id as vsId, " + 
				"       vs.description as vsDescription, " + 
				"       vs.display_no as vsDisplayNo, " + 
				"       NVL(vs.display_order, 0) as vsDisplayOrder, " +
				"       NVL(vs.indent_level, 0) as vsIndentLevel, " + 
				"       vs.input_type as vsInputType, " + 
				"       NVL(vs.is_only_as_header, 0) as isOnlyAsHeader, " +
				"       rb.repeating_branches as repeatingBranches, " +
				"       s.id as sectionId, " + 
				"       s.display_no as sectionDisplayNo, " + 
				"       s.name as sectionName " +
				"  FROM value_statements vs " +
				"       LEFT JOIN (SELECT vvs1.value_statement_id, " + 
				"                         LISTAGG(v1.cc_branch_code, ', ') WITHIN GROUP (ORDER BY v1.cc_branch_code) as repeating_branches " +
				"                    FROM verifications v1 " +
				"                         JOIN currency_chests c " +
				"                           ON c.branch_code = v1.cc_branch_code " +
				"                         JOIN branches b " +
				"                           ON b.branch_code = c.branch_code " +
				"                         JOIN verification_value_statements vvs1 " +
				"                           ON vvs1.verification_id = v1.id " +
				"                         LEFT JOIN verifications v2 " +
				"                              ON v2.verification_type_id = v1.verification_type_id " +
				"                             AND v2.block_from = (:blockFrom + 1) " +
				"                             AND v2.cc_branch_code = v1.cc_branch_code  " +
				"                         LEFT JOIN verification_value_statements vvs2 " +
				"                           ON vvs2.verification_id = v2.id " +
				"                          AND vvs2.value_statement_id = vvs1.value_statement_id  " +
				"                        WHERE NVL(v1.status, 'P') <> 'P' " +
				"                          AND v1.verification_type_id = :type " +
				"                          AND NVL(v2.status, 'P') <> 'P' " +
				"                          AND v1.block_from = :blockFrom " +
				"                          AND v1.block_to = :blockTo " +
				"                          AND (NVL(vvs1.verification_compliance, 'NA') = 'NC' AND NVL(vvs2.verification_compliance, 'NC') = 'NC') " +
				"                          AND (:circle = -1 OR b.circle_code = :circle) " +
				"                          AND (:network = -1 OR b.network_code = :network) " +
				"                          AND (:module = -1 OR b.module_code = :module) " +
				"                          AND (:region = -1 OR b.region_code = :region) " +
				"                        GROUP BY vvs1.value_statement_id) rb " +
				"                 ON rb.value_statement_id = vs.id " +
				"       JOIN verification_sections s " +
				"         ON s.id = vs.verification_section_id " +
				" WHERE s.verification_type_id = :type" +
				" ORDER BY s.display_order, s.id, vs.display_order, vs.id"
	)
    List<RepeatedObservationBranches> repeatingBranches(
    		@Param("type") long typeId, 
    		@Param("blockFrom") LocalDate blockFrom,
    		@Param("blockTo") LocalDate blockTo,
    		@Param("circle") Long circle,
    		@Param("network") Long network, 
    		@Param("module") Long module,
    		@Param("region") Long region
	);

    @Query(
        "SELECT c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "       NVL(v.dateOfVerification, v.reportSubmittedOn) as verificationDate " +
        "  FROM Verification v " +
        "       JOIN CurrencyChest c " +
        "         ON c = v.currencyChest " +
        " WHERE v.type.id = :type " +
        "   AND v.blockFrom = :blockFrom " +
        "   AND v.blockTo = :blockTo " +
        "   AND NVL(v.status, 'P') <> 'P' " +
        "   AND (:circle IS NULL OR c.circle.circleCode = :circle) " +
        "   AND (:network IS NULL OR c.network.networkCode = :network) " +
        "   AND (:module IS NULL OR c.module.moduleCode = :module) " +
        "   AND (:region IS NULL OR c.region.regionCode = :region) " +
        " ORDER BY circleName, networkCode, c.module.moduleCode, regionCode, branchCode"
    )
    List<VsConsolidatedBranchDetails> branches(
        @Param("type") int typeId,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circle") Long circle,
        @Param("network") Long network,
        @Param("module") Long module,
        @Param("region") Long region
    );

    @Query(
        "select v.currencyChest.circle.circleName as circleName,count(*) as total, " +
        " INITCAP(trim(to_char((:blockFrom),'MONTH'))) as month , " +
        "sum(case when v.type.id=1 then 1 else 0 end) as biMonthly, " +
        "sum(case when v.type.id=2 then 1 else 0 end) as quarterly, " +
        "sum(case when v.type.id=3 then 1 else 0 end) as halfYearly, " +
        "sum(case when v.type.id=4 then 1 else 0 end) as securityOfficer, " +
        "sum(case when v.type.id=5 then 1 else 0 end) as dgmcfo, " +
        "sum(case when v.type.id=6 then 1 else 0 end) as controllerVisit, " +
        "sum(case when v.type.id=7 then 1 else 0 end) as moduleHeadVisit, " +
        "sum(case when v.type.id=8 then 1 else 0 end) as gmNetworkVisit, " +
        "sum(case when v.type.id=9 then 1 else 0 end) as cgmVisit, " +
        "sum(case when v.type.id=10 then 1 else 0 end) as dgmCFO " +
        "from  Verification v where (:blockFrom) <=v.dateOfVerification and (:blockTo) > v.dateOfVerification and v.reportSubmittedBy is not null group by v.currencyChest.circle.circleName order by v.currencyChest.circle.circleName"
    )
    List<MonthWiseVerificationReport> getMonthWiseVerifications(
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo
    );

    @Query(
        "select circleName as circleName,0 as total, " +
        " INITCAP(trim(to_char((:blockFrom),'MONTH'))) as month , " +
        "0 as biMonthly, " +
        "0 as quarterly, " +
        "0 as halfYearly, " +
        "0 as securityOfficer, " +
        "0 as dgmcfo, " +
        "0 as controllerVisit, " +
        "0 as moduleHeadVisit, " +
        "0 as gmNetworkVisit, " +
        "0 as cgmVisit, " +
        "0 as dgmCFO " +
        "from  Circle c where c.circleName in (:circleNames) order by c.circleName"
    )
    List<MonthWiseVerificationReport> getZeroMonthWiseVerifications(
        @Param("blockFrom") LocalDate blockFrom,
        @Param("circleNames") List<String> circleNames
    );

    @Query(
        "select 'Total' as circleName,count(*) as total, " +
        " INITCAP(trim(to_char((:blockFrom),'MONTH'))) as month , " +
        "sum(case when v.type.id=1 then 1 else 0 end) as biMonthly, " +
        "sum(case when v.type.id=2 then 1 else 0 end) as quarterly, " +
        "sum(case when v.type.id=3 then 1 else 0 end) as halfYearly, " +
        "sum(case when v.type.id=4 then 1 else 0 end) as securityOfficer, " +
        "sum(case when v.type.id=5 then 1 else 0 end) as dgmcfo, " +
        "sum(case when v.type.id=6 then 1 else 0 end) as controllerVisit, " +
        "sum(case when v.type.id=7 then 1 else 0 end) as moduleHeadVisit, " +
        "sum(case when v.type.id=8 then 1 else 0 end) as gmNetworkVisit, " +
        "sum(case when v.type.id=9 then 1 else 0 end) as cgmVisit, " +
        "sum(case when v.type.id=10 then 1 else 0 end) as dgmCFO " +
        "from  Verification v where (:blockFrom) <=v.dateOfVerification and (:blockTo) > v.dateOfVerification and v.reportSubmittedBy is not null"
    )
    MonthWiseVerificationReport getMonthWiseVerificationsSum(@Param("blockFrom") LocalDate blockFrom, @Param("blockTo") LocalDate blockTo);

    @Query(
        "SELECT " +
        //            "		c.circle.circleName as circle, " +
        //            "       c.network.networkCode as network, " +
        //            "       c.module.moduleName as module, " +
        //            "       c.region.regionCode as region, " +
        "       SUM (1) as totalCcs, " +
        //            "       SUM (CASE WHEN v.officer IS NULL THEN 1 ELSE 0 END) as voNotIdentified, " +
        //            "       SUM (CASE WHEN v.officer IS NOT NULL AND v.status IS NULL THEN 1 ELSE 0 END) as notStarted, " +
        //            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status = 'P' THEN 1 ELSE 0 END) as inProgress, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted " +
        //            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('S', 'CSBM', 'CRBH', 'CRBS') THEN 1 ELSE 0 END) as pendingAtBranch, " +
        //            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('CSBH', 'CRBCA') THEN 1 ELSE 0 END) as pendingAtController, " +
        //            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('CSBS', 'CVBVO') THEN 1 ELSE 0 END) as awaitingForClosure, " +
        //            "       SUM (CASE WHEN v.status IS NOT NULL AND v.status IN ('C') THEN 1 ELSE 0 END) as closed " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN Verification v " +
        "              ON v.currencyChest = c " +
        "             AND v.type = :verificationType " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        " WHERE NVL(c.dateOfOpening, :blockTo) <= :blockTo " +
        "   AND NVL(c.closedDate, (:blockTo + 1)) >= :blockTo " +
        "   AND v.type = :verificationType " +
        "   AND (:circleCode IS NULL OR c.circle.circleCode = :circleCode) " +
        "   AND (:networkCode IS NULL OR c.network.networkCode = :networkCode) " +
        "   AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR c.region.regionCode = :regionCode) " +
        " GROUP BY c.circle.circleName, c.network.networkCode, c.module.moduleName, c.region.regionCode "/*+
            " ORDER BY circle, network, module, region"*/
    )
    VisitsStatusSummary visitsStatusSummary(
        @Param("verificationType") VerificationType type,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode
    );

    @Query(
        "SELECT " +
        "       SUM (1) as totalCcs, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN Verification v " +
        "              ON v.currencyChest = c " +
        "             AND v.type = :verificationType " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        " WHERE NVL(c.dateOfOpening, :blockTo) <= :blockTo " +
        "   AND NVL(c.closedDate, (:blockTo + 1)) >= :blockTo " +
        "   AND v.type = :verificationType " +
        "   AND (:circleCode IS NULL OR c.circle.circleCode = :circleCode) " +
        " GROUP BY c.circle.circleCode"
    )
    VisitsStatusSummary visitsStatusSummaryCircle(
        @Param("verificationType") VerificationType type,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circleCode") Long circleCode
    );

    @Query(
        "SELECT " +
        "       SUM (1) as totalCcs, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN Verification v " +
        "              ON v.currencyChest = c " +
        "             AND v.type = :verificationType " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        " WHERE NVL(c.dateOfOpening, :blockTo) <= :blockTo " +
        "   AND NVL(c.closedDate, (:blockTo + 1)) >= :blockTo " +
        "   AND v.type = :verificationType " +
        "   AND (:circleCode IS NULL OR c.circle.circleCode = :circleCode) " +
        "   AND (:networkCode IS NULL OR c.network.networkCode = :networkCode) " +
        " GROUP BY c.circle.circleCode, c.network.networkCode"
    )
    VisitsStatusSummary visitsStatusSummaryNetwork(
        @Param("verificationType") VerificationType type,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode
    );

    @Query(
        "SELECT " +
        "       SUM (1) as totalCcs, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN Verification v " +
        "              ON v.currencyChest = c " +
        "             AND v.type = :verificationType " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        " WHERE NVL(c.dateOfOpening, :blockTo) <= :blockTo " +
        "   AND NVL(c.closedDate, (:blockTo + 1)) >= :blockTo " +
        "   AND v.type = :verificationType " +
        "   AND (:circleCode IS NULL OR c.circle.circleCode = :circleCode) " +
        "   AND (:networkCode IS NULL OR c.network.networkCode = :networkCode) " +
        "   AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        " GROUP BY c.circle.circleCode, c.network.networkCode, c.module.moduleCode"
    )
    VisitsStatusSummary visitsStatusSummaryModule(
        @Param("verificationType") VerificationType type,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode,
        @Param("moduleCode") Long moduleCode
    );

    @Query(
        "SELECT " +
        "       SUM (1) as totalCcs, " +
        "       SUM (CASE WHEN v.status IS NOT NULL AND v.status <> 'P' THEN 1 ELSE 0 END) as voReportSubmitted " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN Verification v " +
        "              ON v.currencyChest = c " +
        "             AND v.type = :verificationType " +
        "             AND v.blockFrom = :blockFrom " +
        "             AND v.blockTo = :blockTo " +
        " WHERE NVL(c.dateOfOpening, :blockTo) <= :blockTo " +
        "   AND NVL(c.closedDate, (:blockTo + 1)) >= :blockTo " +
        "   AND v.type = :verificationType " +
        "   AND (:circleCode IS NULL OR c.circle.circleCode = :circleCode) " +
        "   AND (:networkCode IS NULL OR c.network.networkCode = :networkCode) " +
        "   AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        "	AND c.region.regionCode >= 7 " +
        " GROUP BY c.circle.circleCode, c.network.networkCode, c.module.moduleCode"
    )
    VisitsStatusSummary visitsStatusSummaryModuleDirectBrs(
        @Param("verificationType") VerificationType type,
        @Param("blockFrom") LocalDate blockFrom,
        @Param("blockTo") LocalDate blockTo,
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode,
        @Param("moduleCode") Long moduleCode
    );
}
