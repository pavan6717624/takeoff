package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.CcProfileSaveData;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.enums.CcProfileStatus;

@Repository
public interface CcProfileSaveDataRepository extends JpaRepository<CcProfileSaveData, Long> {
    Optional<CcProfileSaveData> findByCurrencyChest(CurrencyChest c);
    Optional<CcProfileSaveData> findByCurrencyChestBranchCode(Long branchCode);
    Optional<CcProfileSaveData> findByCurrencyChestBranchCodeAndCcProfileStatus(Long branchCode, CcProfileStatus status);
    Optional<CcProfileSaveData> deleteByCurrencyChestBranchCode(Long branchCode);
}
