package sbi.sf.gocblr.cconline.domain.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import sbi.sf.gocblr.cconline.domain.enums.DenominationType;

/**
 * Attribute convert for @see sbi.sf.gocblr.cconline.domain.enums.DenominationType
 * @author Kiran Marturu
 *
 */
@Converter(autoApply = true)
public class DenominationTypeConverter implements AttributeConverter<DenominationType, String> {

    @Override
    public String convertToDatabaseColumn(DenominationType denominationType) {
        return denominationType.code();
    }

    @Override
    public DenominationType convertToEntityAttribute(String code) {
        if (code == null) {
            return null;
        }
        return DenominationType.fromCode(code);
    }
}
