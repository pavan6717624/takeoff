package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.PenaltyDebitType;
import sbi.sf.gocblr.cconline.domain.PenaltyReason;

@Repository
public interface PenaltyReasonRepository extends JpaRepository<PenaltyReason, Long> {
    List<PenaltyReason> findByTypeOrderByIdAsc(PenaltyDebitType penalty_debit_type);
}
