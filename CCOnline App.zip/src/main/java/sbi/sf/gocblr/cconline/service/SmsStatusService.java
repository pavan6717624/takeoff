package sbi.sf.gocblr.cconline.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sbi.sf.gocblr.cconline.domain.SmsStatus;
import sbi.sf.gocblr.cconline.repository.SmsNotificationRepository;
import sbi.sf.gocblr.cconline.repository.SmsStatusRepository;
import sbi.sf.gocblr.cconline.utils.TextUtils;

@Service
@RequiredArgsConstructor
public class SmsStatusService {

    private final SmsStatusRepository repo;
    private final SmsNotificationRepository msgRepo;

    @Transactional
    public SmsStatus save(SmsStatus s) {
        return repo.save(s);
    }

    @Transactional
    public void saveAll(Iterable<SmsStatus> statuses) {
        repo.saveAll(statuses);
    }

    @Transactional
    public void updateMessageStatus(long msgId, boolean isSuccess, String errorMessage) {
        var msg = msgRepo.findById(msgId);
        if (msg.isPresent()) {
            msg.get().setSuccess(isSuccess);
            if (TextUtils.hasText(errorMessage)) {
                msg.get().setMessage(errorMessage);
            }
        }
    }
}
