package sbi.sf.gocblr.cconline.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import sbi.sf.gocblr.cconline.domain.RoleComplianceRole;
import sbi.sf.gocblr.cconline.domain.VerificationType;

public interface RoleComplianceRoleRepository extends JpaRepository<RoleComplianceRole, Long> {
    Optional<RoleComplianceRole> findByVerificationTypeAndForRoleName(VerificationType vt, String role);
}
