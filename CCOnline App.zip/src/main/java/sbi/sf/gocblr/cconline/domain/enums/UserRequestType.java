package sbi.sf.gocblr.cconline.domain.enums;

public enum UserRequestType {
    CREATE,
    MODIFY,
    ENABLE,
    DISABLE,
    DELETE,
}
