package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "penalty_data")
public class PenaltyData implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -3005417358967882660L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    LocalDate reportDate;
    String Particulars;

    @Column(columnDefinition = "NUMBER(20, 2)")
    Double debit;

    @ManyToOne
    @JoinColumn(name = "rbi_region_code", foreignKey = @ForeignKey(name = "fk_penalty_rbi_fslo_mapping"))
    RBIFSLOMapping fslo;

    String status;
    String postedStatus;

    Long pfid;
    String ipaddress;
    
    String disposalStatus;
}
