package sbi.sf.gocblr.cconline.model;

import java.time.LocalDateTime;
import java.util.Set;
import lombok.Data;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.UserRequest;
import sbi.sf.gocblr.cconline.domain.enums.RequestStatus;
import sbi.sf.gocblr.cconline.domain.enums.UserRequestType;

@Data
public class UserRequestModel {

    public UserRequestModel(UserRequest ur) {
        this.id = ur.getId();
        this.roles = ur.getRoles();
        this.requestType = ur.getRequestType();
        this.requestedBy = ur.getRequestedBy();
        this.requestedOn = ur.getRequestedOn();
        this.requestStatus = ur.getRequestStatus();
        this.statusBy = ur.getStatusBy();
        this.statusOn = ur.getStatusOn();
        this.requestMessage = ur.getRequestMessage();
    }

    private Long id;
    private Set<Role> roles;
    private UserRequestType requestType;
    private Long requestedBy;
    private LocalDateTime requestedOn;
    private RequestStatus requestStatus;
    private Long statusBy;
    private LocalDateTime statusOn;
    private String requestMessage;
}
