package sbi.sf.gocblr.cconline.service.dto;

import sbi.sf.gocblr.cconline.domain.VerificationType;

public interface DetailsForNotify {
    long getBranchCode();
    String getBranchName();

    Long getMobileNo();
    String getEmailId();

    VerificationType getVerificationType();
}
