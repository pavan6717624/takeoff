package sbi.sf.gocblr.cconline.service.dto;

public interface IBranchDTO {
    Integer getBranchCode();
    String getBranchName();
}
