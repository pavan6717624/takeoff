package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import sbi.sf.gocblr.cconline.domain.SftpHbbStatus;

public interface SftpHbbStatusRepository extends JpaRepository<SftpHbbStatus, Long> {
    @Query("select NVL(max(fileDate),TO_DATE('2000-01-01', 'yyyy-MM-dd')) from SftpHbbStatus where status like 'Success'")
    LocalDate getLatestUploadDate();
}
