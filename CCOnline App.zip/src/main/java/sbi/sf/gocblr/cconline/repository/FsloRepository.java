package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Fslo;

public interface FsloRepository extends JpaRepository<Fslo, Long> {
    @Query("SELECT f FROM Fslo f WHERE f.branchCode=(:branchCode) or f.branchCode=-(:branchCode)")
    Optional<Fslo> findByBranchCode(@Param("branchCode") Long branchCode);

    @Query("select abs(f.branchCode) from Fslo f where f.branchCode!=3999")
    List<Long> findAllFslos();
}
