package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Denomination;
import sbi.sf.gocblr.cconline.domain.NotesAdjudicated;
import sbi.sf.gocblr.cconline.domain.NotesAdjudicatedDetails;
import sbi.sf.gocblr.cconline.domain.Verification;
import sbi.sf.gocblr.cconline.service.dto.NotesAdjudicatedDetailsDTO;

public interface NotesAdjudicatedDetailsRepository extends JpaRepository<NotesAdjudicatedDetails, Long> {
    @Query(
        "SELECT d.id as denominationId, " +
        "       d.value as denominationValue," +
        "       d.type as denominationType," +
        "       nad.fullValuePieces as fullValuePieces," +
        "       nad.halfValuePieces as halfValuePieces," +
        "       nad.rejectedPieces as rejectedPieces" +
        "  FROM Denomination d " +
        "       LEFT JOIN NotesAdjudicated na " +
        "              ON na.verification = :verification " +
        "       LEFT JOIN NotesAdjudicatedDetails nad " +
        "              ON nad.denomination = d " +
        "             AND nad.notesAdjudicated = na " +
        " WHERE d.type = 'N'" +
        " ORDER BY d.value DESC"
    )
    List<NotesAdjudicatedDetailsDTO> notesAdjudicatedDetails(@Param("verification") Verification verification);

    Optional<NotesAdjudicatedDetails> findByNotesAdjudicatedAndDenomination(NotesAdjudicated na, Denomination d);
}
