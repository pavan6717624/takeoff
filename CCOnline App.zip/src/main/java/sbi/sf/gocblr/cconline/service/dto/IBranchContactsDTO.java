package sbi.sf.gocblr.cconline.service.dto;

public interface IBranchContactsDTO {
    Long getCoMobileNo();
    Long getAccountantMobileNo();
    Long getBmMobileNo();
}
