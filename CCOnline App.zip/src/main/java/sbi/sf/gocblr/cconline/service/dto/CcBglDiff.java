package sbi.sf.gocblr.cconline.service.dto;

public interface CcBglDiff extends IBranchDTO, IFsloDTO {
    Integer getCircleCode();
    String getCircleName();
    Long getCymValue();
    Long getBglValue();
    Long getDifference();
}
