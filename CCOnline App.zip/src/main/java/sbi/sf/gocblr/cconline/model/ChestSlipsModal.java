package sbi.sf.gocblr.cconline.model;

import lombok.Data;
import sbi.sf.gocblr.cconline.domain.ChestSlipParticular;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.Denomination;

/**
 *
 * @author Pavan Kumar Rangaiahgari
 *
 */
@Data
public class ChestSlipsModal {

    private Long csid;
    private ChestSlipParticular particulars;
    private Denomination denominations;
    double value;
    private ChestSlipUploadDetails checkSlipUploadDetails;
}
