package sbi.sf.gocblr.cconline.model;

import java.util.Arrays;
import java.util.List;
import lombok.Data;

@Data
public class VsConsolidatedSummaryCircleWiseImpl {

    //	private String sectionDisplayNo;
    //	private int sectionDisplayOrder;

    //	private int parentParentDisplayOrder;
    //	private String parentParentDisplayNumber;

    //	private int parentDisplayOrder;
    //	private String parentDisplayNumber;

    private int displayOrder;
    private String displayNumber;
    private int indentLevel;
    private String description;
    private boolean isOnlyAsHeader;

    private List<Integer> notCompliedCount;

    public VsConsolidatedSummaryCircleWiseImpl(
        int displayOrder,
        String displayNumber,
        int indentLevel,
        String description,
        boolean isOnlyAsHeader,
        Integer... notCompliedCount
    ) {
        this.displayOrder = displayOrder;
        this.displayNumber = displayNumber;
        this.indentLevel = indentLevel;
        this.description = description;
        this.isOnlyAsHeader = isOnlyAsHeader;
        this.notCompliedCount = Arrays.asList(notCompliedCount);
    }
}
