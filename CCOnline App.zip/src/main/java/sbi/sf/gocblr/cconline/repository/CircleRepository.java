package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import sbi.sf.gocblr.cconline.domain.Circle;
import sbi.sf.gocblr.cconline.domain.Network;

public interface CircleRepository extends JpaRepository<Circle, Long> {
    Optional<Circle> findByCircleCode(long circleCode);
    Set<Network> findNetworksByCircleCode(long code);
    Optional<Circle> findByCircleName(String circle);

    @Query("select circleName from Circle where circleCode in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,23,24,27) order by circleName")
    List<String> findAllCirlces();
}
