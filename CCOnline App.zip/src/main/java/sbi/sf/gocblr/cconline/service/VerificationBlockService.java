package sbi.sf.gocblr.cconline.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sbi.sf.gocblr.cconline.constants.VerificationTypeConstants;
import sbi.sf.gocblr.cconline.domain.VerificationBlock;
import sbi.sf.gocblr.cconline.domain.VerificationType;
import sbi.sf.gocblr.cconline.repository.VerificationBlockRepository;
import sbi.sf.gocblr.cconline.utils.DateUtils;
import sbi.sf.gocblr.cconline.web.rest.vm.VerificationBlocksDTO;

@Service
@Transactional
@RequiredArgsConstructor
public class VerificationBlockService {

    private final VerificationBlockRepository repo;
    private final VerificationTypeService verificationTypeService;

    public List<VerificationBlock> listBlocks(VerificationType vt, LocalDate startDate, LocalDate till) {
        int startYear = startDate.getYear();

        int startMonth = startDate.getMonthValue();
        if (startMonth > 1 && startMonth % 2 != 0) {
            startMonth = startMonth - 1;
        }

        int endYear = till.getYear();
        List<VerificationBlock> vps = new ArrayList<>();
        for (int sy = startYear; sy <= endYear; sy++) {
            // for every year
            for (int sm = startMonth; sm <= 12; sm = sm + 2) {
                LocalDate periodFrom = LocalDate.of(sy, sm, 1);
                LocalDate periodTo = DateUtils.getLastDay(sy, sm + 1);
                vps.add(VerificationBlock.builder().type(vt).blockFrom(periodFrom).blockTo(periodTo).build());
            }
        }
        return vps;
    }

    public VerificationBlocksDTO verificationBlocks(String verificationType) {
        VerificationType vt = verificationTypeService.getByKeyOrThrow(verificationType);
        VerificationBlocksDTO dto = new VerificationBlocksDTO();
        dto.setBlocks(repo.getVerificationBlocks(vt, List.of(VerificationTypeConstants.BI_MONTHLY, VerificationTypeConstants.HALF_YEARLY)));

        return dto;
    }

    public Optional<VerificationBlock> findLastOneFor(VerificationType vt) {
        return repo.findTopByTypeOrderByBlockToDesc(vt);
    }

    public List<VerificationBlock> blocksFor(VerificationType vt) {
        return repo.findByType(vt);
    }

    public void addBlocks(List<VerificationBlock> blocksToBeAdded) {
        repo.saveAll(blocksToBeAdded);
    }
}
