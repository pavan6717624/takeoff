package sbi.sf.gocblr.cconline.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.Region;
import sbi.sf.gocblr.cconline.domain.RegionId;

public interface RegionRepository extends JpaRepository<Region, RegionId>, JpaSpecificationExecutor<Region> {
    @Query(
        "SELECT r " +
        "  FROM Region r " +
        " WHERE r.regionCode = :regionCode " +
        "   AND r.module.moduleCode = :moduleCode " +
        "   AND r.module.network.networkCode = :networkCode " +
        "   AND r.module.network.circle.circleCode = :circleCode "
    )
    Optional<Region> getRegion(
        @Param("circleCode") long circleCode,
        @Param("networkCode") long networkCode,
        @Param("moduleCode") long moduleCode,
        @Param("regionCode") long regionCode
    );

    List<Region> findAll(Specification<Region> spec);
}
