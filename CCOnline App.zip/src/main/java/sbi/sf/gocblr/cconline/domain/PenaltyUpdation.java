package sbi.sf.gocblr.cconline.domain;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "penalty_updation")
public class PenaltyUpdation implements Serializable {

	
	public PenaltyUpdation()
	{
		
	}
	
    public PenaltyUpdation(PenaltyUpdation p, Double amount) {
	
		this.reason = p.reason;
		this.subReason = p.subReason;
		this.narration = p.narration;
		this.currencyChest = p.currencyChest;
		this.amount = amount;
		this.status = p.status;
		this.disposal = p.disposal;
		this.updatedByPfid = p.updatedByPfid;
		this.disposedByPfid = p.disposedByPfid;
		this.updatedOnIp = p.updatedOnIp;
		this.disposedOnIp = p.disposedOnIp;
		this.disposedDate = p.disposedDate;
		this.updatedDate = p.updatedDate;
		this.splitId=p.id;
	}

	private static final long serialVersionUID = -3915542741007462058L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    Long splitId;
    
    @ManyToOne
    @JoinColumn(name = "penalty_reason", foreignKey = @ForeignKey(name = "fk_penalty_updation_reason_mapping"))
    PenaltyReason reason;

    @ManyToOne
    @JoinColumn(name = "penalty_sub_reason", foreignKey = @ForeignKey(name = "fk_penalty_updation_sub_reason_mapping"))
    PenaltySubReason subReason;

    @ManyToOne
    @JoinColumn(name = "penalty_data", foreignKey = @ForeignKey(name = "fk_penalty_updation_data_mapping"))
    PenaltyData narration;

    @ManyToOne
    @JoinColumn(
        name = "cc_branch_code",
        referencedColumnName = "branch_code",
        foreignKey = @ForeignKey(name = "fk_penalty_updation_currency_chest")
    )
    private CurrencyChest currencyChest;

    @Column(columnDefinition = "NUMBER(20, 2)")
    Double amount;

    String status;

    @ManyToOne
    @JoinColumn(name = "penalty_disposal", foreignKey = @ForeignKey(name = "fk_penalty_updation_disposal_mapping"))
    PenaltyDisposal disposal;

    Long updatedByPfid;
    Long disposedByPfid;

    String updatedOnIp;
    String disposedOnIp;

    @Column(name = "disposed_date")
    LocalDate disposedDate;

    @Column(name = "updated_date")
    LocalDate updatedDate;
}
