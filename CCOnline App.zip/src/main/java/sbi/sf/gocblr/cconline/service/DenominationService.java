package sbi.sf.gocblr.cconline.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.Denomination;
import sbi.sf.gocblr.cconline.domain.enums.DenominationType;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.DenominationRepository;

@Service
@RequiredArgsConstructor
public class DenominationService {

    private final DenominationRepository repo;

    public Denomination getById(long denominationId) {
        return repo
            .findById(denominationId)
            .orElseThrow(() -> new ResourceNotFoundException("No denomination found with id: " + denominationId));
    }

    public Denomination getByValue(int value) {
        return repo.findByValue(value).orElseThrow(() -> new ResourceNotFoundException("No denomination found with value: " + value));
    }

    public Denomination getByValueAndType(int value, DenominationType type) {
        return repo
            .findByValueAndType(value, type.code())
            .orElseThrow(() -> new ResourceNotFoundException("No denomination found with value: " + value));
    }
}
