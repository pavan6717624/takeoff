package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import lombok.Data;

@Data
public class MISReport implements IMisReport {

    String circle;
    Long network;
    Long module;
    String moduleName;
    Long region;
    Long brcode;
    String brname;
    Long cccode;
    Long fslocode;
    String fsloName;
    Long cbl;
    Double total;
    LocalDate lastUploadedDate;
}
