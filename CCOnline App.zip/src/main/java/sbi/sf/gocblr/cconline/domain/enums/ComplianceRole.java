package sbi.sf.gocblr.cconline.domain.enums;

public enum ComplianceRole {
    BRANCH_MAKER,
    BRANCH_HEAD,
    SCRUTINIZER,
    VERIFICATION_OFFICER,
    CLOSURE_AUTHORITY,
}
