package sbi.sf.gocblr.cconline.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.enums.NotificationType;
import sbi.sf.gocblr.cconline.exception.ResourceNotFoundException;
import sbi.sf.gocblr.cconline.repository.NotificationTypeRepository;

@Service
@RequiredArgsConstructor
public class NotificationTypeService {

    private final NotificationTypeRepository repo;

    public NotificationType getByName(String name) {
        return repo.findByName(name).orElseThrow(() -> new ResourceNotFoundException("No notification type found for name: " + name));
    }
}
