package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.service.dto.CcBranchesReport;
import sbi.sf.gocblr.cconline.service.dto.CcBranchesSummaryReport;
import sbi.sf.gocblr.cconline.service.dto.CcClosedBranchesReport;

public interface CcBranchesRepository extends JpaRepository<CurrencyChest, Long> {
    // for CC branches list
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "		abs(c.fslo.branchCode) as fsloCode, " +
        "       c.ccCode as ccCode, " +
        "       c.address.state.name as state, " +
        "       c.address.district as district, " +
        "       c.address.centerName as centerName, " +
        "       c.address.centerType as centreType, " +
        "       c.ccType as ccType, " +
        "       c.address.populationGroup as populationGroup, " +
        "       c.capacityToStoreCashInBundles as storageCapacity, " +
        "       c.cashBalanceLimit as cashBalanceLimit " +
        "  FROM CurrencyChest c " +
        "  WHERE NVL(c.dateOfOpening, :asOn) <=  :asOn " +
        "    AND NVL(c.closedDate, :asOn + 1) > :asOn " +
        "    AND (:fsloCode IS NULL OR ABS(c.fslo.branchCode) = :fsloCode) " +
        "    AND (:circleCode IS NULL OR c.circle.circleCode = :circleCode) " +
        "    AND (:networkCode IS NULL OR c.network.networkCode = :networkCode) " +
        "    AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        "    AND (:regionCode IS NULL OR c.region.regionCode = :regionCode) " +
        "  ORDER BY circleName, networkCode, moduleName, regionCode, branchCode "
    )
    List<CcBranchesReport> getCcBranchesReport(
        @Param("asOn") LocalDate asOn,
        @Param("fsloCode") Long fsloCode,
        @Param("circleCode") Long circleCode,
        @Param("networkCode") Long networkCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode
    );

    // for CC branches summary
    // ABD
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       count(c.branchCode) as  branchesCount " +
        "  FROM CurrencyChest c " +
        "  WHERE NVL(c.dateOfOpening, :asOn) <=  :asOn " +
        "    AND NVL(c.closedDate, :asOn + 1) > :asOn " +
        "  GROUP BY c.circle.circleCode, c.circle.circleName " +
        "  ORDER BY c.circle.circleName "
    )
    List<CcBranchesSummaryReport> getCcBranchesSummaryReport(@Param("asOn") LocalDate asOn);

    // for CC closed branches list
    // ABD
    @Query(
        "SELECT c.circle.circleCode as circleCode, " +
        "       c.circle.circleName as circleName, " +
        "       c.network.networkCode as networkCode, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as regionCode, " +
        "       c.branchCode as branchCode, " +
        "       c.branchName as branchName, " +
        "		abs(c.fslo.branchCode) as fsloCode, " +
        "       c.ccCode as ccCode, " +
        "       c.address.state.name as state, " +
        "       c.address.district as district, " +
        "       c.address.centerName as centerName, " +
        "       c.closedDate as closedDate " +
        "  FROM CurrencyChest c " +
        "  WHERE c.closedDate >=  :fromDate " +
        "    AND c.closedDate <= :toDate " +
        "    AND c.isClosed = 1 " +
        "  ORDER BY circleName, networkCode, moduleName, regionCode, branchCode "
    )
    List<CcClosedBranchesReport> getCcBranchesClosedReport(@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate);
}
