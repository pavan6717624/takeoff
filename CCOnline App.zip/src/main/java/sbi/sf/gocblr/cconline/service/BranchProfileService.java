package sbi.sf.gocblr.cconline.service;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.Fslo;
import sbi.sf.gocblr.cconline.exception.NothingSpecificException;
import sbi.sf.gocblr.cconline.repository.CurrencyChestRepository;
import sbi.sf.gocblr.cconline.repository.FsloRepository;

@Service
@RequiredArgsConstructor
public class BranchProfileService {

    private final CurrencyChestRepository ccRepository;
    private final FsloRepository fsloRepository;

    public List<CurrencyChest> getBranchProfile(Long branchCode) {
        Optional<Fslo> fslo = fsloRepository.findByBranchCode(branchCode);
        if (fslo.isPresent()) {
            return ccRepository.findByFsloOrderByBranchCodeAsc(fslo.get());
        } else {
            Optional<CurrencyChest> cc = ccRepository.findByBranchCode(branchCode);
            if (cc.isPresent()) {
                return List.of(cc.get());
            } else {
                throw new NothingSpecificException(String.format("User branch %d is neither currency chest/fslo", branchCode));
            }
        }
    }
}
