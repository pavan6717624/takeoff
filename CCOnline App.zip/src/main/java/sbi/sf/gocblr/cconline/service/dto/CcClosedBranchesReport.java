package sbi.sf.gocblr.cconline.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.time.LocalDate;

@JsonInclude(content = Include.NON_NULL)
public interface CcClosedBranchesReport {
    Integer getCircleCode();
    String getCircleName();
    Integer getNetworkCode();
    String getModuleName();
    Integer getRegionCode();
    Integer getBranchCode();
    String getBranchName();
    Integer getFsloCode();
    Integer getCcCode();
    String getState();
    String getDistrict();
    String getCenterName();
    LocalDate getClosedDate();
}
