package sbi.sf.gocblr.cconline.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sbi.sf.gocblr.cconline.domain.ChestSlipUploadDetails;
import sbi.sf.gocblr.cconline.domain.ChestSlips;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;
import sbi.sf.gocblr.cconline.domain.TotalsTable;
import sbi.sf.gocblr.cconline.model.CBLExceedingDaysReport;
import sbi.sf.gocblr.cconline.model.CustomReportChestSlipData;
import sbi.sf.gocblr.cconline.model.CustomReportTotalData;
import sbi.sf.gocblr.cconline.model.CustomReportsDTO;
import sbi.sf.gocblr.cconline.model.IMisReport;
import sbi.sf.gocblr.cconline.model.LastUploadModal;
import sbi.sf.gocblr.cconline.model.ViewChestSlip;
import sbi.sf.gocblr.cconline.service.dto.CcBglDiff;
import sbi.sf.gocblr.cconline.service.dto.CurrenyChestForSms;

@Repository
public interface ChestSlipUploadDetailsRepository extends JpaRepository<ChestSlipUploadDetails, Long> {
    @Query("SELECT c FROM ChestSlipUploadDetails c where id=(:id) and status='New'")
    ChestSlipUploadDetails findChestSlipUploadDetails(@Param("id") Long id);

    @Query("select distinct c.circle.circleName from CurrencyChest c order by c.circle.circleName asc")
    List<String> getCircles();

    @Query(
        "select uploadFile from  ChestSlipUploadDetails c where chestSlipDate = (:chestSlipDate) and c.currencyChest.branchCode=(:branchCode) and status like 'New'"
    )
    String getPDFFile(@Param("chestSlipDate") LocalDate chestSlipDate, @Param("branchCode") Long branchCode);

    @Query(
        nativeQuery = true,
        value = "select cc_branch_code as ccBranchCode, max(cs_date) as maxDate from (select u.cs_date,u.cc_branch_code,b.bgl_value, sum(case when (p.pid = :closingId1 or p.pid=:closingId2) then total_value end) as closing_balance, " +
        "(b.bgl_value + sum(case when (p.pid = :closingId1 or p.pid=:closingId2) then total_value end)) as balance from {h-schema}chest_slip_particular_totals t, {h-schema}particulars p, {h-schema}chest_slip_upload_details u,{h-schema}cc_bgl_balances b  " +
        "where u.status='New' and u.id=t.cs_upload_id and p.pid = t.cs_particular_id and b.balance_on=u.cs_date and b.cc_branch_code=u.cc_branch_code  and b.cc_closing_balance_id=1 and p.pid in (:closingId1,:closingId2)  " +
        "group by u.cs_date,u.cc_branch_code,b.bgl_value order by u.cs_date,u.cc_branch_code asc) where bgl_value!=0 and closing_balance!=0 and balance=0 group by cc_branch_code order by cc_branch_code"
    )
    List<LastUploadModal> getLastTalliedDateOfBGL98958(@Param("closingId1") Long closingId1, @Param("closingId2") Long closingId2);

    @Query(
        nativeQuery = true,
        value = "select cc_branch_code as ccBranchCode,max(cs_date) as maxDate from " +
        "(select u.cs_date,u.cc_branch_code, sum(case when (p.pid=:depositId1 or p.pid=:depositId2) then -total_value when (p.pid=:withdrawalsId1 or p.pid=:withdrawalsId2) then total_value end) as ct, b.bgl_value, " +
        "(sum(case when (p.pid=:depositId1 or p.pid=:depositId2) then -total_value when (p.pid=:withdrawalsId1 or p.pid=:withdrawalsId2) then total_value end) - b.bgl_value) as balance " +
        "from {h-schema}chest_slip_particular_totals t, {h-schema}particulars p, {h-schema}chest_slip_upload_details u,{h-schema}cc_bgl_balances b " +
        "where u.status='New' and  u.id=t.cs_upload_id and p.pid = t.cs_particular_id and b.balance_on=u.cs_date and b.cc_branch_code=u.cc_branch_code  and b.cc_closing_balance_id=2 and p.pid in (:depositId1,:depositId2,:withdrawalsId1,:withdrawalsId2) " +
        "group by u.cs_date,u.cc_branch_code,b.bgl_value order by u.cs_date,u.cc_branch_code asc) where bgl_value!=0 and ct!=0 and balance=0 group by cc_branch_code order by cc_branch_code"
    )
    List<LastUploadModal> getLastTalliedDateOfBGL98908(
        @Param("depositId1") Long depositId1,
        @Param("depositId2") Long depositId2,
        @Param("withdrawalsId1") Long withdrawalsId1,
        @Param("withdrawalsId2") Long withdrawalsId2
    );

    @Query(
        "select distinct c.network.networkCode from CurrencyChest c where c.circle.circleName like (:circleName) order by c.network.networkCode asc"
    )
    List<String> getNetworks(@Param("circleName") String circleName);

    @Query(
        "select distinct c.module.moduleName from CurrencyChest c where c.circle.circleName like (:circleName) and concat(c.network.networkCode,'') like (:networkCode) order by c.module.moduleName asc"
    )
    List<String> getModules(@Param("circleName") String circleName, @Param("networkCode") String networkCode);

    @Query(
        "select distinct c.region.regionCode from CurrencyChest c where c.circle.circleName like (:circleName) and concat(c.network.networkCode,'') like (:networkCode) and c.module.moduleName like (:moduleName) order by c.region.regionCode asc"
    )
    List<String> getRegions(
        @Param("circleName") String circleName,
        @Param("networkCode") String networkCode,
        @Param("moduleName") String moduleName
    );

    @Query(
        "SELECT ud FROM ChestSlipUploadDetails ud where ud.chestSlipDate=(:chestSlipDate) and currencyChest = (:currencyChest) and status='New'"
    )
    ChestSlipUploadDetails findChestSlipUploadDetailsBySlipDateBrcode(
        @Param("chestSlipDate") LocalDate chestSlipDate,
        @Param("currencyChest") CurrencyChest currencyChest
    );

    @Query(
        nativeQuery = true,
        value = "select to_char(u.cs_date,'DD/MM/YYYY') as csdate,ci.circle_name as circle,b.network_code as net,m.module_name as zone,b.region_code as region, u.cc_branch_code as brcode,b.branch_name as brname,c.currency_chest_code as cccode,c.fslo_code as fslocode, " +
        "case when (c.population_group = 'M') then 'Metro' when (c.population_group = 'SU') then 'Semi-Urban' when (c.population_group = 'R') then 'Rural' when (c.population_group = 'U') then 'Urban' end as popcode, " +
        "s.name as state,c.cash_balance_limit as cbl, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11,0) + nvl(sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11,0) + nvl(sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c, {h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and p.pid in (:reportList) and u.cs_date >= (:fromdate) " +
        "and u.cs_date <=  (:todate) and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 " +
        " and ((b.circle_code like :qcircle ) or (c.fslo_code like :qfslo) or (:qfslo='%' and :qcircle='%'))   and b.network_code like :qnetwork and m.module_code like :qmodule and b.region_code like :qregion and b.branch_code like :qbranch " +
        "group by u.cs_date,u.cc_branch_code,c.currency_chest_code,b.branch_name,b.circle_code,b.network_code,b.module_code,b.region_code,c.fslo_code,c.population_group,c.state_code,s.name,c.cash_balance_limit,ci.circle_name,m.module_name " +
        "order by u.cs_date, ci.circle_name, b.network_code,m.module_name, b.region_code,u.cc_branch_code"
    )
    List<CustomReportsDTO> getCustomReports(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("qcircle") String qcircle,
        @Param("qnetwork") String qnetwork,
        @Param("qmodule") String qmodule,
        @Param("qregion") String qregion,
        @Param("qbranch") String qbranch,
        @Param("qfslo") String qfslo,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select ci.circle_name as circle, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c, {h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and (p.pid in :reportList) and u.cs_date >=  :fromdate " +
        "and u.cs_date <=  :todate and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 " +
        "group by b.circle_code,ci.circle_name  order by ci.circle_name"
    )
    List<CustomReportsDTO> getCustomReportsCircleSummary(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select 'TOTAL' as circle, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c, {h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and (p.pid in :reportList) and u.cs_date >=  :fromdate " +
        "and u.cs_date <=  :todate and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 "
    )
    CustomReportsDTO getSumCustomReportsCircleSummary(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select ci.circle_name as circle, s.name as state, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c, {h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and (p.pid in :reportList) and u.cs_date >=  :fromdate " +
        "and u.cs_date <=  :todate and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 " +
        "group by b.circle_code,ci.circle_name,s.code,s.name  order by ci.circle_name"
    )
    List<CustomReportsDTO> getCustomReportsCircleStateSummary(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select 'TOTAL' as state, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11,0) + nvl( sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c,{h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and (p.pid in :reportList) and u.cs_date >=  :fromdate " +
        "and u.cs_date <=  :todate and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 "
    )
    CustomReportsDTO getSumCustomReportsCircleStateSummary(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select abs(fslo_code) as fslocode,(select branch_name from branches where branch_code=c.fslo_code) as fsloname, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c, {h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and (p.pid in :reportList) and u.cs_date >=  :fromdate " +
        "and u.cs_date <=  :todate and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 " +
        "group by c.fslo_code  order by c.fslo_code"
    )
    List<CustomReportsDTO> getCustomReportsFsloSummary(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select 'TOTAL' as fsloname, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11 ,0) + nvl(sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c, {h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and (p.pid in :reportList) and u.cs_date >=  :fromdate " +
        "and u.cs_date <=  :todate and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 "
    )
    CustomReportsDTO getSumCustomReportsFsloSummary(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select 'TOTAL' as circle, nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_pieces end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_pieces end)/5,0) as totalpieces , " +
        "nvl(sum(case when (p.type like 'Notes') then t.total_value end)/11 ,0) + nvl( sum(case when (p.type like 'Coins') then t.total_value end)/5,0) as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c, {h-schema}branches b, {h-schema}circles ci, {h-schema}modules m, {h-schema}states s " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and p.pid in (:reportList) and u.cs_date >= (:fromdate) " +
        "and u.cs_date <=  (:todate) and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code and b.branch_code=c.branch_code and ci.circle_code = b.circle_code " +
        "and m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code and s.code=c.state_code and t.total_pieces!=0 and c.is_closed=0 " +
        " and ((b.circle_code like :qcircle) or (c.fslo_code like :qfslo )  or (:qfslo='%' and :qcircle='%'))  and b.network_code like :qnetwork and m.module_name like :qmodule and b.region_code like :qregion and b.branch_code like :qbranch "
    )
    CustomReportsDTO getSumCustomReports(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("qcircle") String qcircle,
        @Param("qnetwork") String qnetwork,
        @Param("qmodule") String qmodule,
        @Param("qregion") String qregion,
        @Param("qbranch") String qbranch,
        @Param("qfslo") String qfslo,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15,
        @Param("reportList") List<Long> reportList
    );

    @Query(
        nativeQuery = true,
        value = "select to_char(u.cs_date,'DD/MM/YYYY') as csdate,u.cc_branch_code as brcode,p.keyword as particular, c.currency_chest_code as cccode,p.type as type, " +
        "nvl(sum(case when (s.denomination_id=:did0) then s.value end),0) as n1, " +
        "nvl(sum(case when (s.denomination_id=:did1) then s.value end),0) as n2, " +
        "nvl(sum(case when (s.denomination_id=:did2) then s.value end),0) as n5, " +
        "nvl(sum(case when (s.denomination_id=:did3) then s.value end),0) as n10, " +
        "nvl(sum(case when (s.denomination_id=:did4) then s.value end),0) as n20, " +
        "nvl(sum(case when (s.denomination_id=:did5) then s.value end),0) as n50, " +
        "nvl(sum(case when (s.denomination_id=:did6) then s.value end),0) as n100, " +
        "nvl(sum(case when (s.denomination_id=:did7) then s.value end),0) as n200, " +
        "nvl(sum(case when (s.denomination_id=:did8) then s.value end),0) as n500, " +
        "nvl(sum(case when (s.denomination_id=:did9) then s.value end),0) as n1000, " +
        "nvl(sum(case when (s.denomination_id=:did10) then s.value end),0) as n2000, " +
        "nvl(sum(case when (s.denomination_id=:did11) then s.value end),0) as c1, " +
        "nvl(sum(case when (s.denomination_id=:did12) then s.value end),0) as c2, " +
        "nvl(sum(case when (s.denomination_id=:did13) then s.value end),0) as c5, " +
        "nvl(sum(case when (s.denomination_id=:did14) then s.value end),0) as c10, " +
        "nvl(sum(case when (s.denomination_id=:did15) then s.value end),0) as c20, " +
        "t.total_pieces as totalpieces,t.total_value as totalvalue " +
        "from {h-schema}chest_slips s, {h-schema}chest_slip_upload_details u, {h-schema}chest_slip_particular_totals t,{h-schema}particulars p,{h-schema}currency_chests c " +
        "where u.id=s.check_slip_upload_details_upload_id and u.id=t.cs_upload_id and u.status like 'New' and u.cs_date=:chestSlipDate and u.cc_branch_code=:branchCode and s.particular_id=t.cs_particular_id and s.particular_id=p.pid and c.branch_code=u.cc_branch_code " +
        "group by u.cs_date,u.cc_branch_code,s.particular_id,p.keyword,t.total_pieces,t.total_value,c.currency_chest_code,p.type order by s.particular_id "
    )
    List<ViewChestSlip> viewChestSlipNew(
        @Param("chestSlipDate") LocalDate chestSlipDate,
        @Param("branchCode") Long branchCode,
        @Param("did0") Long did0,
        @Param("did1") Long did1,
        @Param("did2") Long did2,
        @Param("did3") Long did3,
        @Param("did4") Long did4,
        @Param("did5") Long did5,
        @Param("did6") Long did6,
        @Param("did7") Long did7,
        @Param("did8") Long did8,
        @Param("did9") Long did9,
        @Param("did10") Long did10,
        @Param("did11") Long did11,
        @Param("did12") Long did12,
        @Param("did13") Long did13,
        @Param("did14") Long did14,
        @Param("did15") Long did15
    );

    @Query(
        "SELECT ud FROM ChestSlipUploadDetails ud where ud.currencyChest = (:currencyChest) and status='New' and ud.chestSlipDate= (:chestSlipDate)"
    )
    Optional<ChestSlipUploadDetails> findByCurrencyChestAndChestSlipDate(
        @Param("currencyChest") CurrencyChest currencyChest,
        @Param("chestSlipDate") LocalDate chestSlipDate
    );

    @Query("select max(id) from ChestSlipUploadDetails ud where chestSlipDate in (SELECT max(chestSlipDate) FROM ChestSlipUploadDetails ud where ud.currencyChest = (:currencyChest) and ud.status='New') AND ud.currencyChest = (:currencyChest) and ud.status='New'")
    Long getMaxUploadId(@Param("currencyChest") CurrencyChest currencyChest);

    @Query(
        "select max(id) from ChestSlipUploadDetails ud where chestSlipDate in (SELECT max(chestSlipDate) FROM ChestSlipUploadDetails ud where ud.currencyChest = (:currencyChest) and status='New' and ud.chestSlipDate!= (:chestSlipDate)) and ud.currencyChest = (:currencyChest) and status='New' and ud.chestSlipDate!= (:chestSlipDate)"
    )
    Long getMaxUploadIdIgnoreDate(@Param("currencyChest") CurrencyChest currencyChest, @Param("chestSlipDate") LocalDate chestSlipDate);

    @Query(
        "SELECT max(id) " +
        "  FROM ChestSlipUploadDetails csud " +
        " WHERE csud.currencyChest.branchCode = :branchCode " +
        "   AND csud.status = 'New' " +
        "   AND csud.chestSlipDate = :asOn "
    )
    Optional<Long> getIdForChestSlipAsOn(@Param("branchCode") long branchCode, @Param("asOn") LocalDate asOn);

    @Query(
        "SELECT c from CurrencyChest c where c not in (select currencyChest from ChestSlipUploadDetails c1 where c1.status like 'New' and c1.chestSlipDate = (:chestSlipDate))"
    )
    List<CurrencyChest> listOfNotUploadedBranches(@Param("chestSlipDate") LocalDate chestSlipDate);

    @Query(
        "SELECT c from CurrencyChest c where c in (select currencyChest from ChestSlipUploadDetails c1 where c1.status like 'New' and c1.chestSlipDate = (:chestSlipDate))"
    )
    List<CurrencyChest> listOfUploadedBranches(@Param("chestSlipDate") LocalDate chestSlipDate);

    @Query(
        "SELECT c from CurrencyChest c where 0.85*(c.cashBalanceLimit*10000000) < " +
        "(select sum(totalValue) from TotalsTable t where t.particular in " +
        "(select p from ChestSlipParticular p where p.keyword like 'Closing%') group by  t.checkSlipUploadDetails having t.checkSlipUploadDetails = " +
        "(select c1 from ChestSlipUploadDetails c1 where status like 'New' and c1.chestSlipDate = (:chestSlipDate) and c1.currencyChest = c)) "
    )
    List<CurrencyChest> getListofCCAboveCBL(@Param("chestSlipDate") LocalDate chestSlipDate);

    @Query(
        "select c from ChestSlips c where c.checkSlipUploadDetails in " +
        "(select c1 from ChestSlipUploadDetails c1 where c1.status like 'New' and c1.chestSlipDate between (:fromdate) and (:todate)) and " +
        "c.particulars in (select p from ChestSlipParticular p where p.particular like (:report)) order by c.checkSlipUploadDetails.chestSlipUploadDate,c.checkSlipUploadDetails.currencyChest.branchCode,c.denominations.id"
    )
    List<ChestSlips> getReports(@Param("fromdate") LocalDate fromdate, @Param("todate") LocalDate todate, @Param("report") String report);

    
    
//    @Query(nativeQuery = true,
//            value = "select " 
//    		+ " b.branch_code, b. branch_name, b.circle_code, b.module_code, b.network_code, b.region_code ,"
//    		+ " (select circle_name from circles c where c.circle_code=b.circle_code) as circle_name,"
//    		+ " (select module_name from modules m where m.module_code=b.module_code and m.circle_code=b.circle_code and m.network_code=b.network_code) as module_name,"
//    		+ " (select cash_balance_limit*10000000 from currency_chests c where c.branch_code=b.branch_code) as cash_balance_limit,"
//    		+ " dates, closings, status from"
//    		+ " (select cc_branch_code, LISTAGG(closing_value, ', ') WITHIN GROUP (ORDER BY cs_date asc) as closings , LISTAGG(cs_date, ', ') WITHIN GROUP (ORDER BY cs_date asc) as dates, concat(LISTAGG(status, ', ') WITHIN GROUP (ORDER BY cs_date asc),'') as status"
//    		+ " from (select u.cc_branch_code,u.cs_date,sum(total_value) as closing_value, c.cash_balance_limit*10000000 as cbl, case when sum(total_value) > c.cash_balance_limit*10000000 then 'Exceeded' else 'Not Exceeded' end as status"
//    		+ " from currency_chests c, chest_slip_particular_totals t, chest_slip_upload_details u"
//    		+ " where c.branch_code=u.cc_branch_code and t.cs_upload_id=u.id and cs_particular_id in"
//    		+ " (select pid from particulars where keyword like 'Closing Balance (OB +') and status like 'New' and cs_date>=(:fromdate) and cs_date<=(:todate) group by cs_upload_id,u.cc_branch_code,u.cs_date,c.cash_balance_limit"
//    		+ " order by cc_branch_code, cs_date) t group by cc_branch_code) t1, branches b where b.branch_code=cc_branch_code and "
//    		+ " (b.branch_code = (:branchCode) or (:branchCode) = -1) and "
//    		+ " (b.circle_code = (:circleCode) or (:circleCode) = -1) and "
//    		+ " (b.network_code = (:networkCode) or (:networkCode) = -1) and "
//    		+ " (b.module_code = (:moduleCode) or (:moduleCode) = -1) and "
//    		+ " (b.region_code = (:regionCode) or (:regionCode) = -1)")    	
    
    @Query("select t.checkSlipUploadDetails.currencyChest.branchCode as branchCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.branchName as branchName, "
    		+ " t.checkSlipUploadDetails.currencyChest.region.regionCode as regionCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleName as moduleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleCode as moduleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.network.networkCode as networkCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleCode as circleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleName as circleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.cashBalanceLimit as cashBalanceLimit, "
    		+ " t.checkSlipUploadDetails.currencyChest.fslo.branchCode as fsloCode, "
    		+ " t.checkSlipUploadDetails. currencyChest.branchCode as branchCode, "
    		+ "	t.checkSlipUploadDetails. chestSlipDate as chestSlipDate , "
    		+ " case when sum(totalValue) > (t.checkSlipUploadDetails.currencyChest.cashBalanceLimit*10000000) then 'Exceeded' else 'Not Exceeded' end as status, "
    		+ " sum(totalValue) as closingBalance from TotalsTable t where t.particular in "
    		+ " (select p from ChestSlipParticular p where p.keyword like 'Closing%') and t.checkSlipUploadDetails.status like 'New' and t.checkSlipUploadDetails. chestSlipDate >=(:fromDate) and t.checkSlipUploadDetails. chestSlipDate <= (:toDate) "
    		
    		
    		+ "   AND ( (ABS(t.checkSlipUploadDetails. currencyChest.fslo.branchCode) = :fsloCode) OR ( t.checkSlipUploadDetails.currencyChest.circle.circleCode = :circleCode) or (:fsloCode =-1L AND :circleCode =-1L) ) " 
    	    +    "   AND (:moduleCode =-1L OR t.checkSlipUploadDetails.currencyChest.module.moduleCode = :moduleCode) " 
    	    +    "   AND (:regionCode =-1L OR t.checkSlipUploadDetails.currencyChest.region.regionCode = :regionCode) " 
    	    +    "   AND (:branchCode =-1L OR t.checkSlipUploadDetails.currencyChest.branchCode = :branchCode) " 
    		+ " group by  t.checkSlipUploadDetails. currencyChest.branchCode ,"
    		+ " t.checkSlipUploadDetails.currencyChest.branchName , "
    		+ " t.checkSlipUploadDetails.currencyChest.region.regionCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.module.moduleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.network.networkCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleCode, "
    		+ " t.checkSlipUploadDetails.currencyChest.circle.circleName, "
    		+ " t.checkSlipUploadDetails.currencyChest.fslo.branchCode, "
    		
    		+ " t.checkSlipUploadDetails.currencyChest.cashBalanceLimit,"
    		+ " t.checkSlipUploadDetails. chestSlipDate, "
    		+ " t.checkSlipUploadDetails  order by t.checkSlipUploadDetails. currencyChest.branchCode ASC,t.checkSlipUploadDetails. chestSlipDate DESC ")
    
    List<CBLExceedingDaysReport> getCBLExceedingDaysReport(@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate,
            @Param("fsloCode") Long fsloCode,
            @Param("circleCode") Long circleCode,
            @Param("moduleCode") Long moduleCode,
            @Param("regionCode") Long regionCode,
            @Param("branchCode") Long branchCode);
    
    
    
    @Query(
        "SELECT csud.chestSlipDate as chestSlipDate, " +
        "       cc.branchCode as branchCode, " +
        "       cc.branchName as branchName, " +
        "       ci.circleName as circleName, " +
        "       cc.network.networkCode as networkCode, " +
        "       cc.module.moduleCode as moduleCode, " +
        "       mo.moduleName as moduleName, " +
        "       cc.region.regionCode as regionCode, " +
        "       ABS(cc.fslo.branchCode) as fsloBranchCode, " +
        "       cc.address.populationGroup as populationGroup, " +
        "       s.name as stateName, " +
        "		cc.cashBalanceLimit	as cashBalanceLimit," +
        "       c.value as value " +
        "  FROM ChestSlipUploadDetails csud " +
        "       JOIN ChestSlips c " +
        "         ON c.checkSlipUploadDetails = csud " +
        "       JOIN CurrencyChest cc " +
        "         ON cc = csud.currencyChest " +
        "       JOIN Circle ci " +
        "         ON ci = cc.circle " +
        "       JOIN Module mo " +
        "         ON mo = cc.module " +
        "       JOIN State s " +
        "         ON s = cc.address.state " +
        "       JOIN ChestSlipParticular p " +
        "         ON p = c.particulars " +
        " WHERE csud.status = 'New' " +
        "   AND csud.chestSlipDate BETWEEN :fromdate AND :todate " +
        "   AND p.particular LIKE :report " +
        "   AND ( (:fsloCode IS NULL OR ABS(cc.fslo.branchCode) = :fsloCode) OR (:circleCode IS NULL OR cc.circle.circleCode = :circleCode) ) " +
        "   AND (:moduleCode IS NULL OR cc.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR cc.region.regionCode = :regionCode) " +
        "   AND (:branchCode IS NULL OR cc.branchCode = :branchCode) " +
        " ORDER BY cc.circle, cc.network, cc.module, cc.region, cc.branchCode, cc.branchCode, csud.chestSlipDate, c.denominations.id"
    )
    List<CustomReportChestSlipData> getReportsNew(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("report") String report,
        @Param("fsloCode") Long fsloCode,
        @Param("circleCode") Long circleCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode,
        @Param("branchCode") Long branchCode
    );

    @Query(
        "select t from TotalsTable t where t.checkSlipUploadDetails in " +
        "(select c1 from ChestSlipUploadDetails c1 where c1.status like 'New' and c1.chestSlipDate between (:fromdate) and (:todate)) and " +
        "t.particular in (select p from ChestSlipParticular p where p.particular like (:report)) order by t.checkSlipUploadDetails.chestSlipUploadDate,t.checkSlipUploadDetails.currencyChest.branchCode"
    )
    List<TotalsTable> getTotalsReport(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("report") String report
    );

    @Query(
        "SELECT t.totalValue as totalValue, " +
        "       t.totalPieces as totalPieces " +
        " FROM ChestSlipUploadDetails csud " +
        "      JOIN TotalsTable t " +
        "        ON t.checkSlipUploadDetails = csud " +
        "      JOIN ChestSlipParticular p " +
        "        ON p = t.particular " +
        "      JOIN CurrencyChest cc " +
        "        ON cc = csud.currencyChest " +
        " WHERE csud.status = 'New' " +
        "   AND csud.chestSlipDate BETWEEN :fromdate AND :todate " +
        "   AND p.particular LIKE :report " +
        "   AND ( (:fsloCode IS NULL OR ABS(csud.currencyChest.fslo.branchCode) = :fsloCode) OR (:circleCode IS NULL OR csud.currencyChest.circle.circleCode = :circleCode) ) " +
        "   AND (:moduleCode IS NULL OR csud.currencyChest.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR csud.currencyChest.region.regionCode = :regionCode) " +
        "   AND (:branchCode IS NULL OR csud.currencyChest.branchCode = :branchCode) " +
        " ORDER BY cc.circle, cc.network, cc.module, cc.region, cc.branchCode, csud.chestSlipDate"
    )
    List<CustomReportTotalData> getTotalsReportNew(
        @Param("fromdate") LocalDate fromdate,
        @Param("todate") LocalDate todate,
        @Param("report") String report,
        @Param("fsloCode") Long fsloCode,
        @Param("circleCode") Long circleCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode,
        @Param("branchCode") Long branchCode
    );

    // ~ EmailReminderController Queries
    // =================================

    @Query(
        nativeQuery = true,
        value = "SELECT ci.circle_name as circleName, " +
        "       fb.branch_name as fsloName, " +
        "       c.branch_code as branchCode, " +
        "       b.branch_name as branchName, " +
        "       c.accountant_mobile_no acMobileNo, " +
        "       c.co_mobile_no coMobileNo, " +
        "       cs2.last_uploaded_on as lastUploadedOn " +
        "  FROM {h-schema}currency_chests c " +
        "       JOIN {h-schema}branches b " +
        "            ON b.branch_code = c.branch_code " +
        "       JOIN {h-schema}circles ci " +
        "            ON ci.circle_code = b.circle_code " +
        "       JOIN {h-schema}fslos f " +
        "         ON f.branch_code = c.fslo_code " +
        "       JOIN {h-schema}branches fb " +
        "         ON fb.branch_code = f.branch_code " +
        "       LEFT JOIN {h-schema}chest_slip_upload_details cs1 " +
        "              ON cs1.status = 'New' " +
        "             AND cs1.cc_branch_code = c.branch_code " +
        "             AND cs1.cs_date = TO_DATE(:asOn, 'DD-MM-YYYY') " +
        "       LEFT JOIN (SELECT cc_branch_code, MAX(cs_date) last_uploaded_on " +
        "                    FROM {h-schema}chest_slip_upload_details csd " +
        "                   WHERE csd.status = 'New' " +
        "                     AND csd.cs_date <= TO_DATE(:asOn, 'DD-MM-YYYY') " +
        "                   GROUP BY cc_branch_code) cs2 " +
        "               ON cs2.cc_branch_code = c.branch_code " +
        " WHERE cs1.id IS NULL " +
        "   AND ( (:fsloCode IS NULL OR ABS(c.fslo_code) = :fsloCode) OR (:circleCode IS NULL OR b.circle_code = :circleCode) )" +
        "   AND NVL(c.date_of_opening, TO_DATE(:asOn, 'DD-MM-YYYY')) <=  TO_DATE(:asOn, 'DD-MM-YYYY') " +
        "   AND NVL(c.closed_date, SYSDATE)  > TO_DATE(:asOn, 'DD-MM-YYYY')"
    )
    List<CurrenyChestForSms> chestSlipNotUploadedCircleOrFslo(
        @Param("fsloCode") long fsloCode,
        @Param("circleCode") long circleCode,
        @Param("asOn") String asOn
    );

    @Query(
        nativeQuery = true,
        value = "SELECT ci.circle_code as circleCode, " +
        "       ci.circle_name as circleName, " +
        "       bf.branch_code fsloCode, " +
        "       bf.branch_name fsloName, " +
        "       csud.cc_branch_code as branchCode, " +
        "       b.branch_name as branchName, " +
        "       csud.cs_date, " +
        "       t.cym_value cymValue, " +
        "       bgl.bgl_value bglValue, " +
        "       (bgl.bgl_value + t.cym_value) as difference " +
        "  FROM {h-schema}chest_slip_upload_details csud " +
        "       JOIN {h-schema}currency_chests c " +
        "         ON c.branch_code = csud.cc_branch_code " +
        "       JOIN {h-schema}fslos f " +
        "         ON f.branch_code = c.fslo_code " +
        "       JOIN {h-schema}branches bf " +
        "         ON bf.branch_code = f.branch_code " +
        "       JOIN {h-schema}branches b " +
        "         ON b.branch_code = csud.cc_branch_code " +
        "       JOIN {h-schema}circles ci " +
        "         ON ci.circle_code = b.circle_code " +
        "       JOIN (SELECT t.cs_upload_id, SUM(t.total_value) cym_value " +
        "               FROM {h-schema}chest_slip_particular_totals t " +
        "                    LEFT JOIN {h-schema}particulars p " +
        "                           ON p.pid = t.cs_particular_id " +
        "              WHERE p.keyword LIKE 'Closing Balance%' " +
        "              GROUP BY t.cs_upload_id) t " +
        "            ON csud.id = t.cs_upload_id " +
        "       JOIN {h-schema}cc_bgl_balances bgl " +
        "            ON csud.cc_branch_code =  bgl.cc_branch_code " +
        "           AND csud.cs_date = bgl.balance_on " +
        "       JOIN {h-schema}cc_closing_balances cb " +
        "            ON bgl.cc_closing_balance_id = cb.id " +
        " WHERE cb.field_name = 'BGL98958Closing' " +
        "   AND (bgl.bgl_value + t.cym_value) <> 0 " +
        "   AND csud.cs_date >= TO_DATE(:since, 'DD-MM-YYYY') " +
        "   AND ( (:fsloCode IS NULL OR ABS(c.fslo_code) = :fsloCode) OR (:circleCode IS NULL OR b.circle_code = :circleCode) )" +
        "   AND NVL(c.date_of_opening, :since) <=  TO_DATE(:since, 'DD-MM-YYYY') " +
        "   AND NVL(c.closed_date, sysdate)  > TO_DATE(:since, 'DD-MM-YYYY')"
    )
    List<CcBglDiff> bgl98958DiffCircleOrFslo(
        @Param("fsloCode") long fsloCode,
        @Param("circleCode") long circleCode,
        @Param("since") String since
    );

    @Query(
        nativeQuery = true,
        value = "SELECT ci.circle_code as circleCode, " +
        "       ci.circle_name as circleName, " +
        "       bf.branch_code fsloCode, " +
        "       bf.branch_name fsloName, " +
        "       csud.cc_branch_code as branchCode, " +
        "       b.branch_name as branchName, " +
        "       csud.cs_date, " +
        "       t.cym_value cymValue, " +
        "       bgl.bgl_value bglValue, " +
        "       (t.cym_value - bgl.bgl_value) as difference " +
        "  FROM {h-schema}chest_slip_upload_details csud " +
        "       JOIN {h-schema}currency_chests c\n" +
        "         ON c.branch_code = csud.cc_branch_code\n" +
        "       JOIN {h-schema}fslos f\n" +
        "         ON f.branch_code = c.fslo_code\n" +
        "       JOIN {h-schema}branches bf\n" +
        "         ON bf.branch_code = f.branch_code\n" +
        "       JOIN {h-schema}branches b\n" +
        "         ON b.branch_code = csud.cc_branch_code\n" +
        "       JOIN {h-schema}circles ci " +
        "         ON ci.circle_code = b.circle_code \n" +
        "       JOIN (SELECT t.cs_upload_id, SUM(CASE WHEN p.keyword LIKE 'Deposits%' THEN (-1 * t.total_value) ELSE t.total_value END) cym_value\n" +
        "               FROM {h-schema}chest_slip_particular_totals t\n" +
        "                    LEFT JOIN {h-schema}particulars p\n" +
        "                           ON p.pid = t.cs_particular_id\n" +
        "              WHERE (p.keyword LIKE 'Deposits%' OR p.keyword LIKE 'Withdrawals%')\n" +
        "              GROUP BY t.cs_upload_id) t\n" +
        "            ON csud.id = t.cs_upload_id\n" +
        "       JOIN {h-schema}cc_bgl_balances bgl\n" +
        "            ON csud.cc_branch_code =  bgl.cc_branch_code\n" +
        "           AND csud.cs_date = bgl.balance_on\n" +
        "       JOIN {h-schema}cc_closing_balances cb\n" +
        "            ON bgl.cc_closing_balance_id = cb.id\n" +
        " WHERE cb.field_name = 'BGL98908Closing' " +
        "   AND (t.cym_value - bgl.bgl_value) <> 0 " +
        "   AND ( (:fsloCode IS NULL OR ABS(c.fslo_code) = :fsloCode) OR (:circleCode IS NULL OR b.circle_code = :circleCode) )" +
        "   AND csud.cs_date >= TO_DATE(:since, 'DD-MM-YYYY') \n" +
        "   AND NVL(c.date_of_opening, :since) <=  TO_DATE(:since, 'DD-MM-YYYY') \n" +
        "   AND NVL(c.closed_date, sysdate)  > TO_DATE(:since, 'DD-MM-YYYY')"
    )
    List<CcBglDiff> bgl98908DiffCircleOrFslo(
        @Param("fsloCode") long fsloCode,
        @Param("circleCode") long circleCode,
        @Param("since") String since
    );

    // ~ End of EmailReminderService Queries

    @Query(
        "SELECT csud.currencyChest.fslo.branchCode as fslocode, " +
        "       csud.currencyChest.fslo.branchName as fsloName, " +
        "       csud.currencyChest.circle.circleName as circle, " +
        "       csud.currencyChest.network.networkCode as network, " +
        "       csud.currencyChest.module.moduleCode as module, " +
        "       csud.currencyChest.module.moduleName as moduleName, " +
        "       csud.currencyChest.region.regionCode as region, " +
        "       csud.currencyChest.branchCode as brcode, " +
        "       csud.currencyChest.branchName as brname, " +
        "       csud.currencyChest.ccCode as cccode " +
        "  FROM ChestSlipUploadDetails csud " +
        " WHERE csud.status = 'New' " +
        "   AND csud.chestSlipDate = :asOn " +
        "   AND ( (:fsloCode IS NULL OR ABS(csud.currencyChest.fslo.branchCode) = :fsloCode) OR (:circleCode IS NULL OR csud.currencyChest.circle.circleCode = :circleCode) ) " +
        "   AND (:moduleCode IS NULL OR csud.currencyChest.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR csud.currencyChest.region.regionCode = :regionCode) " +
        "   AND (:branchCode IS NULL OR csud.currencyChest.branchCode = :branchCode) " +
        " ORDER BY csud.currencyChest.circle.circleName, csud.currencyChest.network.networkCode, " +
        "          csud.currencyChest.module.moduleCode, csud.currencyChest.region.regionCode, csud.currencyChest.branchCode"
    )
    List<IMisReport> chestSlipUploadedBranches(
        @Param("asOn") LocalDate asOn,
        @Param("fsloCode") Long fsloCode,
        @Param("circleCode") Long circleCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode,
        @Param("branchCode") Long branchCode
    );

    @Query(
        "SELECT c.fslo.branchCode as fslocode, " +
        "       c.fslo.branchName as fsloName, " +
        "       c.circle.circleName as circle, " +
        "       c.network.networkCode as network, " +
        "       c.module.moduleCode as module, " +
        "       c.module.moduleName as moduleName, " +
        "       c.region.regionCode as region,  " +
        "       c.branchCode as brcode, " +
        "       c.branchName as brname, " +
        "       c.ccCode as cccode, " +
        "       cslu.lastUploadedOn as lastUploadedDate " +
        "  FROM CurrencyChest c " +
        "       LEFT JOIN ChestSlipUploadDetails csud " +
        "              ON csud.status = 'New' " +
        "             AND csud.currencyChest = c " +
        "             AND csud.chestSlipDate = :asOn " +
        "       LEFT JOIN ChestSlipLastUploadedOn cslu " +
        "              ON cslu.ccBranchCode = c.branchCode " +
        " WHERE csud IS NULL" +
        "   AND NVL(c.dateOfOpening, :asOn) <= :asOn " +
        "   AND NVL(c.closedDate, :asOn + 1) > :asOn " +
        "   AND ( (:fsloCode IS NULL OR ABS(c.fslo.branchCode) = :fsloCode) OR (:circleCode IS NULL OR c.circle.circleCode = :circleCode) ) " +
        "   AND (:moduleCode IS NULL OR c.module.moduleCode = :moduleCode) " +
        "   AND (:regionCode IS NULL OR c.region.regionCode = :regionCode) " +
        "   AND (:branchCode IS NULL OR c.branchCode = :branchCode) " +
        " ORDER BY c.circle, c.network, c.module, c.region, c.branchCode"
    )
    List<IMisReport> chestSlipNotUploadedBranches(
        @Param("asOn") LocalDate asOn,
        @Param("fsloCode") Long fsloCode,
        @Param("circleCode") Long circleCode,
        @Param("moduleCode") Long moduleCode,
        @Param("regionCode") Long regionCode,
        @Param("branchCode") Long branchCode
    );

    @Query("select distinct LPAD(abs(c.fslo.branchCode), 5, '0') from CurrencyChest c where (c.circle.circleCode = (:circleCode) or (:circleCode)=0) order by LPAD(abs(c.fslo.branchCode), 5, '0') asc")
	List<String> getFslos(@Param("circleCode") Long circleCode);
}
