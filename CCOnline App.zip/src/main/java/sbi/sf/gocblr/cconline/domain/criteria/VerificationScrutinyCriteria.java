package sbi.sf.gocblr.cconline.domain.criteria;

import java.util.List;
import lombok.Data;

@Data
public class VerificationScrutinyCriteria {

    private Long circleCode;
    private Long moduleCode;
    private Long regionCode;

    private Long branchCode;

    private List<String> types;
    
    private Long year;
    private Long cstatus;
    private Long pending;
}
