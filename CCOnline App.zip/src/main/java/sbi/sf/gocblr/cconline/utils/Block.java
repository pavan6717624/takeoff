package sbi.sf.gocblr.cconline.utils;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor
public class Block {

    private LocalDate blockFrom;
    private LocalDate blockTo;

    @Override
    public String toString() {
        return (
            "Block {" +
            "blockFrom=" +
            blockFrom.format(DateUtils.STANDARD_DATE_TIME_FROMAT) +
            ", blockTo=" +
            blockTo.format(DateUtils.STANDARD_DATE_TIME_FROMAT) +
            '}'
        );
    }
}
