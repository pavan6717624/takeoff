package sbi.sf.gocblr.cconline.utils;

import javax.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class WebUtils {

    private final HttpServletRequest request;

    public String getClientIp() {
        String clientIp = "";
        if (request != null) {
            clientIp = request.getHeader("X-FORWARDED-FOR");
            if (!TextUtils.hasText(clientIp)) {
                clientIp = request.getRemoteAddr();
            }
        }
        return clientIp;
    }
}
