package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;
import java.util.List;
import lombok.Data;

@Data
public class BGLStatementFile {

    private double openingBalance;
    private double closingBalance;
    private LocalDate date;
    private List<BGLStatement> bglStatementTable;
    private List<String> headers;
    private String fileName;
}
