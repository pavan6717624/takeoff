package sbi.sf.gocblr.cconline.service.dto;

public interface MonthlyCertificateVsYesList {
    Integer getCircleCode();
    String getCircleName();
    Integer getNetworkCode();
    Integer getModuleCode();
    String getModuleName();
    Integer getRegionCode();
    Integer getBranchCode();
    String getBranchName();
}
