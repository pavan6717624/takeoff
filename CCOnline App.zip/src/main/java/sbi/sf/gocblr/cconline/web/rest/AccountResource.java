package sbi.sf.gocblr.cconline.web.rest;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sbi.sf.gocblr.cconline.service.UserService;
import sbi.sf.gocblr.cconline.service.dto.UserModelDto;
import sbi.sf.gocblr.cconline.utils.MsgUtils;

/**
 *
 * @author Kiran Marturu
 *
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AccountResource {

    private final UserService userService;
    private final MessageSource msgSource;

    @GetMapping("/account")
    public UserModelDto getAccount() {
        Optional<UserModelDto> userDto = userService.getUser();

        if (userDto.isEmpty()) {
            throw new AuthenticationCredentialsNotFoundException(MsgUtils.getMessage(msgSource, "login.not-logged-in"));
        }

        return userDto.get();
    }
}
