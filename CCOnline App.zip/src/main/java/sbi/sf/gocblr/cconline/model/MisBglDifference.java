package sbi.sf.gocblr.cconline.model;

public interface MisBglDifference {
    String getCircle();
    Long getNetwork();
    Long getModule();
    String getModuleName();
    Long getRegion();

    Long getBrCode();
    String getBrName();

    Double getBgl98958balance();
    Double getBgl98908balance();

    Double getClosingBalance();
    Double getNet();

    Long getClosingDifference();
    Long getNetDifference();
}
