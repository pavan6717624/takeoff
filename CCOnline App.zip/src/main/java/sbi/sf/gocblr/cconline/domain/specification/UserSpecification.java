package sbi.sf.gocblr.cconline.domain.specification;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.User;
import sbi.sf.gocblr.cconline.domain.UserRequest;
import sbi.sf.gocblr.cconline.domain.criteria.UserCriteria;

public class UserSpecification extends AbstractSpecification<User> {

    private static final long serialVersionUID = 4143928945709321356L;

    private final UserCriteria criteria;

    public UserSpecification(UserCriteria criteria) {
        this.criteria = criteria;
    }

    @Override
    public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
        Predicate predicate = cb.conjunction();
        List<Expression<Boolean>> expressions = predicate.getExpressions();

        if (null != criteria.getUserPfId()) {
            expressions.add(cb.equal(root.get("id"), criteria.getUserPfId()));
        }

        // name
        if (isNotBlank(criteria.getName())) {
            expressions.add(cb.or(cb.like(cb.lower((root.get("name"))), wildcardsAndLower(criteria.getName()))));
        }

        Join<User, UserRequest> request = root.join("userRequest", JoinType.LEFT);

        if (null != criteria.getRequestStatus()) {
            expressions.add(cb.equal(request.get("requestStatus"), criteria.getRequestStatus()));
        }

        expressions.add(cb.equal(root.get("isDeleted"), false));

        // filter for only authorized roles
        Join<User, Role> roles = root.join("roles");

        if (isNotBlank(criteria.getRole())) {
            expressions.add(cb.or(cb.equal(roles.get("name"), criteria.getRole())));
        }

        In<String> filterRoles = cb.in(roles.get("name"));
        for (String r : criteria.getRoles()) {
            filterRoles.value(r);
        }
        expressions.add(filterRoles);

        Join<User, Branch> branches = root.join("branch");
        if (null != criteria.getBranches()) {
            In<Long> filterBranches = cb.in(branches.get("branchCode"));
            for (Long branch : criteria.getBranches()) {
                filterBranches.value(branch);
            }
        }

        // ignore same user
        expressions.add(cb.notEqual(root.get("id"), criteria.getLoggedInUserId()));

        // filter circle
        if (null != criteria.getUserCircleCode()) {
            expressions.add(cb.equal(branches.get("circle").get("circleCode"), criteria.getUserCircleCode()));
        }

        return predicate;
    }
}
