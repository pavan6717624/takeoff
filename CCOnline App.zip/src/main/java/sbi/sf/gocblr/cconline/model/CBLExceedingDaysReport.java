package sbi.sf.gocblr.cconline.model;

import java.time.LocalDate;

public interface CBLExceedingDaysReport {
	
	Long getBranchCode();
	String getBranchName();
	Long getCircleCode();
	Long getNetworkCode();
	Long getModuleCode();
	Long getRegionCode();
	
	String getCircleName();
	String getModuleName();

	

	LocalDate getChestSlipDate();
	String getStatus();
	Double getClosingBalance();
	
	Double getCashBalanceLimit();

	

}
