package sbi.sf.gocblr.cconline.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.zalando.logbook.HttpLogFormatter;
import org.zalando.logbook.json.JsonHttpLogFormatter;

@Configuration
public class LogbookConfig {

    @Bean
    public HttpLogFormatter jsonFormatter(final ObjectMapper mapper) {
        return new PrincipalHttpLogFormatter(new JsonHttpLogFormatter(mapper));
    }
}
