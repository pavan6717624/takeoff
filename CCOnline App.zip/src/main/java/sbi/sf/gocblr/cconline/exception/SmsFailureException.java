package sbi.sf.gocblr.cconline.exception;

public class SmsFailureException extends RuntimeException {

    private static final long serialVersionUID = 1297871462493620450L;

    public SmsFailureException(Throwable e) {
        super(e);
    }

    public SmsFailureException(String msg) {
        super(msg);
    }
}
