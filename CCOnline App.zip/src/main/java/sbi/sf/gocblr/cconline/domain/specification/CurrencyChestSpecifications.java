package sbi.sf.gocblr.cconline.domain.specification;

import org.springframework.data.jpa.domain.Specification;
import sbi.sf.gocblr.cconline.domain.CurrencyChest;

public class CurrencyChestSpecifications {

    private CurrencyChestSpecifications() {
        // static class
    }

    public static Specification<CurrencyChest> modules(long circleCode, long networkCode, long moduleCode, long regionCode) {
        return (root, query, cb) ->
            cb.and(
                cb.equal(root.get("circle").get("circleCode"), circleCode),
                cb.equal(root.get("network").get("networkCode"), networkCode),
                cb.equal(root.get("module").get("moduleCode"), moduleCode),
                cb.equal(root.get("region").get("regionCode"), regionCode)
            );
    }

    public static Specification<CurrencyChest> open() {
        return (root, query, cb) -> cb.and(cb.equal(root.get("isClosed"), false));
    }
}
