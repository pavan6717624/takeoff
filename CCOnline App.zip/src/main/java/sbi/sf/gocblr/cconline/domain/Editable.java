package sbi.sf.gocblr.cconline.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import sbi.sf.gocblr.cconline.domain.enums.VerificationStatus;

@Getter
@Setter
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "editable_and_action_required")
public class Editable {

    @Id
    private Long id;

    @ManyToOne
    @JoinColumn(name = "verification_type_id", foreignKey = @ForeignKey(name = "fk_vs_editable_verification_type"))
    @EqualsAndHashCode.Include
    private VerificationType verificationType;

    @ManyToOne
    @JoinColumn(name = "for_role", referencedColumnName = "name", foreignKey = @ForeignKey(name = "fk_vs_editable_for_role"))
    @EqualsAndHashCode.Include
    private Role forRole;

    @Column(name = "verification_status", length = 50)
    @EqualsAndHashCode.Include
    private VerificationStatus status;

    @Column(name = "is_editable")
    private Boolean isEditable;
}
