package sbi.sf.gocblr.cconline.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import sbi.sf.gocblr.cconline.config.ApplicationProperties;
import sbi.sf.gocblr.cconline.domain.Branch;
import sbi.sf.gocblr.cconline.domain.Role;
import sbi.sf.gocblr.cconline.domain.User;
import sbi.sf.gocblr.cconline.domain.UserRequest;
import sbi.sf.gocblr.cconline.domain.UserSession;
import sbi.sf.gocblr.cconline.domain.criteria.UserCriteria;
import sbi.sf.gocblr.cconline.domain.enums.RequestStatus;
import sbi.sf.gocblr.cconline.domain.enums.UserRequestType;
import sbi.sf.gocblr.cconline.domain.specification.UserSpecification;
import sbi.sf.gocblr.cconline.exception.InvalidOperationException;
import sbi.sf.gocblr.cconline.exception.ValidationException;
import sbi.sf.gocblr.cconline.model.UserInputModel;
import sbi.sf.gocblr.cconline.model.UserModel;
import sbi.sf.gocblr.cconline.repository.UserRepository;
import sbi.sf.gocblr.cconline.repository.UserRequestRepository;
import sbi.sf.gocblr.cconline.security.AppUser;
import sbi.sf.gocblr.cconline.security.SecurityUtils;
import sbi.sf.gocblr.cconline.service.dto.UserModelDto;
import sbi.sf.gocblr.cconline.utils.JsonUtils;
import sbi.sf.gocblr.cconline.utils.TextUtils;

/**
 * User Service
 *
 * @author Kiran Marturu
 *
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private static final String NO_USER_FOUND_WITH_USER_ID = "No user found with user id: ";

    private final UserSessionService sessionService;
    private final UserRepository repo;
    private final UserRequestRepository requestRepo;
    private final EmployeeDetailsService empService;
    private final RoleService roleService;
    private final BranchMasterService bmService;

    private final ActivityLogService activity;

    @Transactional(readOnly = true)
    public Optional<UserSession> getUserWithRoles() {
        AppUser user = SecurityUtils.getLoggedInUser();
        if (user == null) {
            return Optional.empty();
        }
        if (user.getSessionId() == null) {
            return Optional.empty();
        } else {
            return sessionService.getSession(user.getSessionId());
        }
    }

    @Transactional(readOnly = true)
    public Optional<UserModelDto> getUser() {
        Optional<UserSession> user = getUserWithRoles();
        if (user.isPresent()) {
            return Optional.of(new UserModelDto(user.get()));
        } else {
            return Optional.empty();
        }
    }

    @Transactional(readOnly = true)
    public Page<UserModel> queryUsers(UserCriteria criteria, Pageable pageable) {
        List<String> filterRoles;

        AppUser lu = SecurityUtils.getLoggedInUser();

        if (SecurityUtils.isCurrentUserInRole(RoleConstants.DGM_ABD, RoleConstants.ABD_USER)) {
            filterRoles = ApplicationProperties.ROLES_ALLOWED_FOR_ABD;
        } else if (SecurityUtils.isCurrentUserInRole(RoleConstants.CIRCLE_ADMIN)) {
            criteria.setUserCircleCode(lu.getCircleCode());
            filterRoles = ApplicationProperties.ROLES_ALLOWED_FOR_CIRCLE_ADMIN;
        } else {
            filterRoles = new ArrayList<>();
        }

        if (TextUtils.hasText(criteria.getRole())) {
            Optional<Role> selectedRole = roleService.findByName(criteria.getRole());
            if (selectedRole.isEmpty()) {
                criteria.setRole(null);
            }
        }

        criteria.setRoles(filterRoles);
        criteria.setLoggedInUserId(SecurityUtils.getLoggedInUser().getId());
        return repo.findAll(new UserSpecification(criteria), pageable).map(UserModel::new);
    }

    @Transactional
    public UserModelDto createUser(UserInputModel userModel, long byUser) {
        log.trace(">> createUser()");

        Set<Role> newRoles = new HashSet<>();
        userModel.getRoles().forEach(r -> newRoles.add(roleService.getByName(r)));

        var emp = empService.getEmployeeDetails(userModel.getPfId().intValue());

        Optional<User> existing = repo.findById(emp.getPfId());

        User user;
        UserRequest req;
        if (existing.isPresent()) {
            user = existing.get();
            req = user.getUserRequest();
        } else {
            user = new User();
            req = new UserRequest();
        }

        user.setId(emp.getPfId());
        user.setTitle(emp.getTitle());
        user.setName(emp.getName());
        user.setDesignation(emp.getDesignation());

        Branch userBranch = bmService.getBranch(emp.getBranchCode());
        user.setBranch(userBranch);

        if (hasFsloRole(newRoles)) {
            user.setFslo(bmService.getFslo(userModel.getFslo()));
            req.setFsloCode(userModel.getFslo());
        }

        if (hasGmRole(newRoles)) {
            user.setNetwork(bmService.findByCircleAndNetworkCode(userBranch.getCircle(), userModel.getNetwork()));
        }

        user.setMobileNo(emp.getMobileNo());
        user.setEmailId(emp.getEmailId());
        user.setRoles(newRoles);
        user.setIsDeleted(false);
        user.setApproved(false);

        User savedUser = repo.save(user);
        log.debug("user saved");

        req.setUser(savedUser);
        req.setRequestType(UserRequestType.CREATE);
        req.setRequestStatus(RequestStatus.PENDING);
        req.setRoles(newRoles);
        req.setRequestedBy(byUser);
        req.setRequestedOn(LocalDateTime.now());

        requestRepo.save(req);
        log.debug("user request saved");

        savedUser.getRoles().size();
        return new UserModelDto(savedUser);
    }

    /**
     * Get user details for addition/modification, in case user exists it will return the details,
     * else gets data from Employee API and return
     * @param id user pf id
     * @return UserDTO object
     */
    @Transactional(readOnly = true)
    public UserModelDto getUserForAddition(Long id) {
        log.trace(">> getUserForAddition()");
        Optional<User> u = repo.getById(id);

        var emp = empService.getEmployeeDetails(id.intValue());

        UserModelDto dto;
        if (u.isPresent()) {
            if (isRequestPendingForUser(u)) {
                throw new InvalidOperationException(
                    String.format("A request is pending for the user %s (%d).", u.get().getName(), u.get().getId())
                );
            }

            boolean userDeleted = Boolean.TRUE.equals(u.get().getIsDeleted());

            dto = new UserModelDto(u.get());
            dto.setBranchCode(emp.getBranchCode());
            dto.setBranchName(emp.getBranchName());
            dto.setPresent(userDeleted);

            if (userDeleted) {
                dto.setRoles(new HashSet<>());
            }
        } else {
            dto = new UserModelDto();
            dto.setId(emp.getPfId());
            dto.setName(emp.getName());
            dto.setDesignation(emp.getDesignation());
            dto.setBranchCode(emp.getBranchCode());
            dto.setBranchName(emp.getBranchName());
            dto.setMobileNo(emp.getMobileNo());
            dto.setEmailId(emp.getEmailId());
            dto.setRoles(new HashSet<>());
            dto.setPresent(false);
        }
        return dto;
    }

    private boolean isRequestPendingForUser(Optional<User> u) {
        return (
            u.isPresent() &&
            u.get().getUserRequest() != null &&
            u.get().getUserRequest().getRequestStatus() == RequestStatus.PENDING &&
            Boolean.FALSE.equals(u.get().getIsDeleted())
        );
    }

    @Transactional
    public User modifyUser(@Valid UserInputModel userModel) {
        User user = repo
            .getById(userModel.getPfId())
            .orElseThrow(() -> new ResourceNotFoundException(NO_USER_FOUND_WITH_USER_ID + userModel.getPfId()));

        Set<Role> newRoles = new HashSet<>();
        userModel.getRoles().forEach(r -> newRoles.add(roleService.getByName(r)));

        boolean hasFsloRole = hasFsloRole(newRoles);

        if (user.getRoles().equals(newRoles) && (hasFsloRole && (user.getBranch().getBranchCode().equals(userModel.getFslo())))) {
            throw new ValidationException("Cannot modify as existing and new roles are identical");
        }

        var existingRoles = user.getRoles().stream().map(Role::getName).collect(Collectors.toSet());
        existingRoles.equals(userModel.getRoles());

        Optional<UserRequest> request = requestRepo.findById(userModel.getPfId());
        UserRequest newReq = setRequestDetailsFields(user, UserRequestType.MODIFY, request);
        newReq.setRoles(new HashSet<>(newRoles));
        newReq.setNetworkCode(userModel.getNetwork());

        if (hasFsloRole) {
            newReq.setFsloCode(userModel.getFslo());
        }

        return requestRepo.save(newReq).getUser();
    }

    private boolean hasFsloRole(Set<Role> newRoles) {
        return newRoles.stream().anyMatch(r -> r.getName().equalsIgnoreCase(RoleConstants.FSLO_USER));
    }

    private boolean hasGmRole(Set<Role> newRoles) {
        return newRoles.stream().anyMatch(r -> r.getName().equalsIgnoreCase(RoleConstants.GM_NW));
    }

    @Transactional
    public void approveRequest(long id) {
        User user = repo.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("No user found with id: %d", id)));
        if (user.getUserRequest() != null) {
            Map<String, String> logData = new HashMap<>();

            logData.put("type", user.getUserRequest().getRequestType().toString());

            switch (user.getUserRequest().getRequestType()) {
                case CREATE:
                    user.setApproved(true);
                    user.setIsEnabled(true);
                    user.setIsDeleted(false);
                    updateRequestStatus(user, RequestStatus.APPROVED);
                    break;
                case MODIFY:
                    user.setApproved(true);
                    user.setRoles(new HashSet<>(user.getUserRequest().getRoles()));

                    var emp = empService.getEmployeeDetails((int) id);

                    Branch branch = bmService.getBranch(emp.getBranchCode());
                    user.setBranch(branch);

                    if (hasFsloRole(user.getUserRequest().getRoles())) {
                        user.setFslo(bmService.getFslo(user.getUserRequest().getFsloCode()));
                    } else {
                        user.setFslo(null);
                    }

                    if (hasGmRole(user.getUserRequest().getRoles())) {
                        user.setNetwork(bmService.findByCircleAndNetworkCode(branch.getCircle(), user.getUserRequest().getNetworkCode()));
                    }

                    updateRequestStatus(user, RequestStatus.APPROVED);

                    logData.put("rolesBefore", JsonUtils.toString(user.getRoles()));
                    logData.put("rolesAfter", JsonUtils.toString(user.getUserRequest().getRoles()));

                    break;
                case DISABLE:
                    updateRequestStatus(user, RequestStatus.APPROVED);
                    user.setIsEnabled(Boolean.FALSE);
                    sessionService.blackListPreviousSessions(user.getId(), "Account has been disabled");
                    break;
                case ENABLE:
                    updateRequestStatus(user, RequestStatus.APPROVED);
                    user.setIsEnabled(Boolean.TRUE);
                    break;
                case DELETE:
                    user.setIsDeleted(Boolean.TRUE);
                    updateRequestStatus(user, RequestStatus.APPROVED);
                    sessionService.blackListPreviousSessions(user.getId(), "Account has been deleted");
                    break;
                default:
                    throw new InvalidOperationException("Invalid request type: " + user.getUserRequest().getRequestType());
            }
            repo.save(user);
            activity.logActivity("APPROVE_USER_REQUEST", logData);
        } else {
            throw new ResourceNotFoundException(String.format("No request found for user id: %d", id));
        }
    }

    private void updateRequestStatus(User user, RequestStatus status) {
        user.getUserRequest().setRequestStatus(status);
        user.getUserRequest().setStatusBy(SecurityUtils.getLoggedInUser().getId());
        user.getUserRequest().setStatusOn(LocalDateTime.now());
    }

    @Transactional
    public void rejectRequest(Long id, String remarks) {
        User user = repo.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("No user found with id: %d", id)));
        if (user.getUserRequest() != null) {
            Map<String, String> logData = new HashMap<>();
            logData.put("type", user.getUserRequest().getRequestType().toString());

            switch (user.getUserRequest().getRequestType()) {
                case CREATE:
                case MODIFY:
                case DISABLE:
                case ENABLE:
                case DELETE:
                    user.getUserRequest().setRequestMessage(remarks);
                    updateRequestStatus(user, RequestStatus.REJECTED);
                    break;
                default:
                    throw new InvalidOperationException("Invalid request type: " + user.getUserRequest().getRequestType());
            }
            requestRepo.save(user.getUserRequest());
            activity.logActivity("APPROVE_USER_REQUEST", logData);
        } else {
            throw new ResourceNotFoundException(String.format("No request found for user id: %d", id));
        }
    }

    @Transactional
    public void enable(long id) {
        User existing = repo.getById(id).orElseThrow(() -> new ResourceNotFoundException(NO_USER_FOUND_WITH_USER_ID + id));

        if (Boolean.TRUE.equals(existing.getIsEnabled())) {
            throw new InvalidOperationException("User is already in enabled state");
        }

        var request = requestRepo.findById(id);
        UserRequest newRequest = setRequestDetailsFields(existing, UserRequestType.ENABLE, request);
        requestRepo.save(newRequest);
    }

    @Transactional
    public void disable(long id) {
        User existing = repo.getById(id).orElseThrow(() -> new ResourceNotFoundException(NO_USER_FOUND_WITH_USER_ID + id));

        if (!Boolean.TRUE.equals(existing.getIsEnabled())) {
            throw new InvalidOperationException("User is already in disabled state");
        }

        var request = requestRepo.findById(id);
        UserRequest newRequest = setRequestDetailsFields(existing, UserRequestType.DISABLE, request);
        requestRepo.save(newRequest);
    }

    @Transactional
    public void delete(long id) {
        User existing = repo.getById(id).orElseThrow(() -> new ResourceNotFoundException(NO_USER_FOUND_WITH_USER_ID + id));

        var request = requestRepo.findById(id);

        // in case of rejected create request
        if (
            request.isPresent() &&
            request.get().getRequestType() == UserRequestType.CREATE &&
            request.get().getRequestStatus() == RequestStatus.REJECTED
        ) {
            request.get().getUser().setIsDeleted(true);
            return;
        }

        UserRequest newRequest = setRequestDetailsFields(existing, UserRequestType.DELETE, request);
        requestRepo.save(newRequest);
    }

    private UserRequest setRequestDetailsFields(User existing, UserRequestType requestType, Optional<UserRequest> existingRequest) {
        UserRequest newRequest;
        if (existingRequest.isPresent()) {
            newRequest = existingRequest.get();
        } else {
            newRequest = new UserRequest();
            newRequest.setUser(existing);
        }
        newRequest.setRequestType(requestType);
        newRequest.setRequestStatus(RequestStatus.PENDING);
        newRequest.setRequestedBy(SecurityUtils.getLoggedInUser().getId());
        newRequest.setRequestedOn(LocalDateTime.now());

        return newRequest;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public User deleteUser(User user, String reason) {
        user.setIsDeleted(true);
        user.setReasonForAutoDeletion(reason);

        return repo.save(user);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Branch updateUserBranchCode(User user, long branchCode) {
        Branch newBranch = bmService.getBranch(branchCode);
        user.setReasonForAutoDeletion(String.format("updated branch code from %d to %d", user.getBranch().getBranchCode(), branchCode));
        user.setBranch(newBranch);
        repo.save(user);

        return newBranch;
    }

    /**
     * Not being used, kept incase for reverting the auto-deletion feature
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Branch updateUserBranchCodeAndRevertDeletion(User user, long branchCode) {
        Branch newBranch = bmService.getBranch(branchCode);
        user.setReasonForAutoDeletion(String.format("updated branch code from %d to %d", user.getBranch().getBranchCode(), branchCode));
        user.setBranch(newBranch);
        user.setIsDeleted(false);

        repo.save(user);

        return newBranch;
    }
}
