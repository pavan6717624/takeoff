package sbi.sf.gocblr.cconline.model.ui;

import java.util.Date;
import javax.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class VerificationMisCriteria {

    @NotNull(message = "Verification type is required")
    private String type;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date blockFrom;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date blockTo;

    // UI filters
    private Long circle;
    private Long network;
    private Long module;
    private Long region;
}
