package sbi.sf.gocblr.cconline.domain.view;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Immutable
@Table(name = "view_net_deposits_withdrawals")
public class CcNetDepAndWdl {

    @Id
    @Column(name = "cs_upload_id")
    private Long csUploadId;

    @Column(name = "cym_value")
    private Long cymValue;
}
